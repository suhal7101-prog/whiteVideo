@echo off
setlocal
set JAVA_HOME=C:\Program Files\Java\jdk-17.0.19
set PATH=%JAVA_HOME%\bin;%PATH%
if not defined DB_USERNAME set DB_USERNAME=root
if not defined DB_PASSWORD set DB_PASSWORD=root
if not defined JWT_SECRET set JWT_SECRET=WhiteBearAnime2026LocalDevelopmentSecretKeyOnly
cd /d "%~dp0" || exit /b 1
echo ============================================
echo   白熊动漫平台正在启动... 端口 8088
echo ============================================
java -jar "%~dp0target\white-bear-anime-1.0.0.jar" --server.port=8088
echo 服务已停止
pause
