package com.whitebear.anime.controller;

import com.whitebear.anime.model.Result;
import com.whitebear.anime.service.RankingSyncService;
import org.junit.jupiter.api.Test;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;

class RankingControllerTest {

    @Test
    void reordersRankingWhenLikesChange() {
        DriverManagerDataSource dataSource = new DriverManagerDataSource(
                "jdbc:h2:mem:ranking;MODE=MySQL;DB_CLOSE_DELAY=-1", "sa", "");
        JdbcTemplate db = new JdbcTemplate(dataSource);
        db.execute("CREATE TABLE wb_video (" +
                "id BIGINT PRIMARY KEY, source_vod_id BIGINT, title VARCHAR(100), cover VARCHAR(255), category VARCHAR(50), " +
                "description VARCHAR(500), status VARCHAR(32), tags VARCHAR(255), `year` INT, " +
                "rating DECIMAL(3,1), views BIGINT, likes BIGINT, audit_status VARCHAR(16) DEFAULT 'approved', deleted TINYINT DEFAULT 0)");
        db.update("INSERT INTO wb_video(id,source_vod_id,title,rating,views,likes,deleted) VALUES(1,101,'A',9.0,1000,10,0)");
        db.update("INSERT INTO wb_video(id,source_vod_id,title,rating,views,likes,deleted) VALUES(2,102,'B',8.0,800,5,0)");
        db.update("INSERT INTO wb_video(id,title,rating,views,likes,deleted) VALUES(3,'本地占位数据',10.0,999999,999999,0)");
        db.update("INSERT INTO wb_video(id,source_vod_id,title,rating,views,likes,audit_status,deleted) " +
                "VALUES(4,104,'待审核投稿',10.0,999999,999999,'pending',0)");

        RankingController controller = new RankingController(db, mock(RankingSyncService.class));
        Result<Map<String, Object>> before = controller.getTop10();
        assertEquals(1L, firstId(before));

        db.update("UPDATE wb_video SET likes = 2000 WHERE id = 2");
        Result<Map<String, Object>> after = controller.getTop10();
        assertEquals(2L, firstId(after));
        assertEquals(102L, ((Number) first(after).get("sourceVodId")).longValue());
        assertEquals(10.0, first(after).get("dynamicScore"));
    }

    private long firstId(Result<Map<String, Object>> result) {
        return ((Number) first(result).get("id")).longValue();
    }

    @SuppressWarnings("unchecked")
    private Map<String, Object> first(Result<Map<String, Object>> result) {
        List<Map<String, Object>> list = (List<Map<String, Object>>) result.getData().get("list");
        return list.get(0);
    }
}
