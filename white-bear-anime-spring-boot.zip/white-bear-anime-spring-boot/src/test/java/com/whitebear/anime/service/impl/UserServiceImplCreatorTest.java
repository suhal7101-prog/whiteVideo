package com.whitebear.anime.service.impl;

import com.whitebear.anime.mapper.*;
import com.whitebear.anime.model.Result;
import com.whitebear.anime.model.dto.VideoDTO;
import com.whitebear.anime.model.dto.CreatorApplyDTO;
import com.whitebear.anime.model.entity.User;
import com.whitebear.anime.model.entity.Video;
import com.whitebear.anime.model.entity.Episode;
import com.whitebear.anime.security.JwtUtils;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class UserServiceImplCreatorTest {

    @Mock private UserMapper userMapper;
    @Mock private FavoriteMapper favoriteMapper;
    @Mock private WatchHistoryMapper watchHistoryMapper;
    @Mock private VideoMapper videoMapper;
    @Mock private EpisodeMapper episodeMapper;
    @Mock private LikeMapper likeMapper;
    @Mock private OperationLogMapper operationLogMapper;
    @Mock private PasswordEncoder passwordEncoder;
    @Mock private JwtUtils jwtUtils;
    @Mock private ObjectProvider<JavaMailSender> mailSenderProvider;

    @InjectMocks private UserServiceImpl service;

    @BeforeEach
    void authenticate() {
        UsernamePasswordAuthenticationToken authentication =
                new UsernamePasswordAuthenticationToken("creator@test.local", null, List.of());
        authentication.setDetails(7L);
        SecurityContextHolder.getContext().setAuthentication(authentication);
    }

    @AfterEach
    void clearAuthentication() {
        SecurityContextHolder.clearContext();
    }

    @Test
    void ordinaryUserApplicationWaitsForAdminAudit() {
        when(userMapper.selectById(7L)).thenReturn(User.builder().id(7L).role("user").build());

        CreatorApplyDTO dto = new CreatorApplyDTO();
        dto.setMessage("我主要创作国漫解说和原创动画，希望能够持续投稿。");
        Result<Object> result = service.applyCreator(dto);

        assertEquals(200, result.getCode());
        ArgumentCaptor<User> captor = ArgumentCaptor.forClass(User.class);
        verify(userMapper).updateById(captor.capture());
        assertEquals("user", captor.getValue().getRole());
        assertEquals("pending", captor.getValue().getCreatorApplyStatus());
        assertEquals("我主要创作国漫解说和原创动画，希望能够持续投稿。", captor.getValue().getCreatorApplyMessage());
    }

    @Test
    void ordinaryUserCannotSubmitWithoutCreatorRole() {
        when(userMapper.selectById(7L)).thenReturn(User.builder().id(7L).role("user").build());

        Result<Object> result = service.submitVideo(validVideo());

        assertEquals(403, result.getCode());
        verify(videoMapper, never()).insert(any(Video.class));
    }

    @Test
    void creatorSubmissionWaitsForAudit() {
        when(userMapper.selectById(7L)).thenReturn(User.builder().id(7L).role("creator").build());
        doAnswer(invocation -> {
            invocation.<Video>getArgument(0).setId(88L);
            return 1;
        }).when(videoMapper).insert(any(Video.class));

        Result<Object> result = service.submitVideo(validVideo());

        assertEquals(200, result.getCode());
        ArgumentCaptor<Video> captor = ArgumentCaptor.forClass(Video.class);
        verify(videoMapper).insert(captor.capture());
        assertEquals("pending", captor.getValue().getAuditStatus());
        assertEquals("user", captor.getValue().getSubmissionSource());
        assertEquals(7L, captor.getValue().getUploaderId());
        assertTrue(captor.getValue().getLikes() >= 500 && captor.getValue().getLikes() <= 900);
        ArgumentCaptor<Episode> episodeCaptor = ArgumentCaptor.forClass(Episode.class);
        verify(episodeMapper).insert(episodeCaptor.capture());
        assertEquals("/api/user/submission-video/test.mp4", episodeCaptor.getValue().getVideoUrl());
        assertEquals(1, episodeCaptor.getValue().getEpisodeNum());
    }

    @Test
    void administratorSubmissionIsApprovedImmediately() {
        when(userMapper.selectById(7L)).thenReturn(User.builder().id(7L).role("admin").build());
        doAnswer(invocation -> {
            invocation.<Video>getArgument(0).setId(89L);
            return 1;
        }).when(videoMapper).insert(any(Video.class));

        service.submitVideo(validVideo());

        ArgumentCaptor<Video> captor = ArgumentCaptor.forClass(Video.class);
        verify(videoMapper).insert(captor.capture());
        assertEquals("approved", captor.getValue().getAuditStatus());
        assertEquals(7L, captor.getValue().getAuditorId());
    }

    @Test
    @SuppressWarnings("unchecked")
    void creatorCanSearchExistingAnimeAndGetsNextEpisode() {
        when(userMapper.selectById(7L)).thenReturn(User.builder().id(7L).role("creator").build());
        Video existing = Video.builder()
                .id(21L)
                .title("完美世界")
                .cover("https://example.com/perfect-world.jpg")
                .category("中国动漫")
                .episodes(280)
                .year(2021)
                .region("CN")
                .build();
        when(videoMapper.searchSubmissionCandidates("完美世界")).thenReturn(List.of(existing));
        when(videoMapper.countSubmissionVideosByTitle("完美世界")).thenReturn(3L);
        when(videoMapper.selectNextSubmissionEpisode("完美世界")).thenReturn(281L);

        Result<Object> result = service.searchSubmissionAnime(" 完美世界 ");

        assertEquals(200, result.getCode());
        Map<String, Object> data = (Map<String, Object>) result.getData();
        List<Map<String, Object>> list = (List<Map<String, Object>>) data.get("list");
        assertEquals(1, list.size());
        assertEquals(3L, list.get(0).get("existingCount"));
        assertEquals(281L, list.get(0).get("nextEpisode"));
    }

    private VideoDTO validVideo() {
        VideoDTO dto = new VideoDTO();
        dto.setTitle("测试投稿");
        dto.setCategory("中国动漫");
        dto.setCover("https://example.com/cover.jpg");
        dto.setDescription("测试投稿简介");
        dto.setTags("热血,冒险");
        dto.setVideoUrl("/api/user/submission-video/test.mp4");
        dto.setVideoFileSize(1024L);
        dto.setEpisodeNumber(3);
        return dto;
    }
}
