package com.whitebear.anime.aspect;

import com.whitebear.anime.model.dto.LoginDTO;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class LogAspectTest {

    @Test
    void serializeArgsRedactsPasswords() {
        LoginDTO dto = new LoginDTO();
        dto.setEmail("user@example.com");
        dto.setPassword("plain-text-password");

        String serialized = LogAspect.serializeArgs(new Object[]{dto});

        assertFalse(serialized.contains("plain-text-password"));
        assertTrue(serialized.contains("***"));
        assertTrue(serialized.contains("user@example.com"));
    }
}
