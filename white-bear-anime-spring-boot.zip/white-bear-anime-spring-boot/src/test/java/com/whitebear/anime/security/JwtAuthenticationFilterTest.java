package com.whitebear.anime.security;

import com.whitebear.anime.mapper.UserMapper;
import com.whitebear.anime.model.entity.User;
import jakarta.servlet.FilterChain;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.security.core.context.SecurityContextHolder;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class JwtAuthenticationFilterTest {

    @AfterEach
    void clearSecurityContext() {
        SecurityContextHolder.clearContext();
    }

    @Test
    void usesCurrentDatabaseRoleInsteadOfRoleClaim() throws Exception {
        JwtUtils jwtUtils = mock(JwtUtils.class);
        UserMapper userMapper = mock(UserMapper.class);
        when(jwtUtils.validateToken("valid-token")).thenReturn(true);
        when(jwtUtils.getUserId("valid-token")).thenReturn(7L);
        when(userMapper.selectById(7L)).thenReturn(User.builder()
                .id(7L).email("user@example.com").role("user").status("active").build());

        JwtAuthenticationFilter filter = new JwtAuthenticationFilter(jwtUtils, userMapper);
        MockHttpServletRequest request = new MockHttpServletRequest();
        request.addHeader("Authorization", "Bearer valid-token");
        MockHttpServletResponse response = new MockHttpServletResponse();
        FilterChain chain = mock(FilterChain.class);

        filter.doFilter(request, response, chain);

        assertEquals("ROLE_USER", SecurityContextHolder.getContext().getAuthentication()
                .getAuthorities().iterator().next().getAuthority());
        verify(chain).doFilter(any(), any());
    }

    @Test
    void rejectsBannedUserEvenWithValidToken() throws Exception {
        JwtUtils jwtUtils = mock(JwtUtils.class);
        UserMapper userMapper = mock(UserMapper.class);
        when(jwtUtils.validateToken("valid-token")).thenReturn(true);
        when(jwtUtils.getUserId("valid-token")).thenReturn(9L);
        when(userMapper.selectById(9L)).thenReturn(User.builder()
                .id(9L).email("banned@example.com").role("admin").status("banned").build());

        JwtAuthenticationFilter filter = new JwtAuthenticationFilter(jwtUtils, userMapper);
        MockHttpServletRequest request = new MockHttpServletRequest();
        request.addHeader("Authorization", "Bearer valid-token");
        FilterChain chain = mock(FilterChain.class);

        filter.doFilter(request, new MockHttpServletResponse(), chain);

        assertNull(SecurityContextHolder.getContext().getAuthentication());
        verify(chain).doFilter(any(), any());
    }
}
