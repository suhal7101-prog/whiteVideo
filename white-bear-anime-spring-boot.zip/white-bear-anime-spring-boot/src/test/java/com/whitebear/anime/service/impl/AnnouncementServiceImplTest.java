package com.whitebear.anime.service.impl;

import com.whitebear.anime.mapper.AnnouncementMapper;
import com.whitebear.anime.mapper.AnnouncementReadMapper;
import com.whitebear.anime.model.Result;
import com.whitebear.anime.model.entity.Announcement;
import org.apache.ibatis.annotations.Select;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class AnnouncementServiceImplTest {

    @Mock
    private AnnouncementMapper announcementMapper;

    @Mock
    private AnnouncementReadMapper announcementReadMapper;

    @InjectMocks
    private AnnouncementServiceImpl service;

    @BeforeEach
    void authenticate() {
        UsernamePasswordAuthenticationToken authentication =
                new UsernamePasswordAuthenticationToken("user@example.com", null, List.of());
        authentication.setDetails(7L);
        SecurityContextHolder.getContext().setAuthentication(authentication);
    }

    @AfterEach
    void clearAuthentication() {
        SecurityContextHolder.clearContext();
    }

    @Test
    void unreadCountIsCalculatedForCurrentUser() {
        when(announcementMapper.selectPublishedForUser(7L)).thenReturn(List.of(
                Map.of("id", 1L, "isRead", 0),
                Map.of("id", 2L, "isRead", 1),
                Map.of("id", 3L, "isRead", false)
        ));

        Result<Object> result = service.getMyAnnouncements();

        assertEquals(200, result.getCode());
        Map<?, ?> data = (Map<?, ?>) result.getData();
        assertEquals(2L, data.get("unreadCount"));
        assertEquals(3, data.get("total"));
    }

    @Test
    void markReadUsesCurrentUserAndAnnouncement() {
        when(announcementMapper.selectById(11L)).thenReturn(
                Announcement.builder().id(11L).status("published").build());

        Result<Void> result = service.markRead(11L);

        assertEquals(200, result.getCode());
        verify(announcementReadMapper).markRead(7L, 11L);
    }

    @Test
    void publishedAnnouncementsAreNotDelayedByDatabaseClock() throws Exception {
        Select query = AnnouncementMapper.class
                .getMethod("selectPublishedForUser", Long.class)
                .getAnnotation(Select.class);

        assertFalse(String.join(" ", query.value()).contains("CURRENT_TIMESTAMP"));
    }
}
