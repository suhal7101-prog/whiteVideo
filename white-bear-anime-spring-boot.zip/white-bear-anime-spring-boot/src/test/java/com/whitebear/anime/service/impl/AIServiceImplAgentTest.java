package com.whitebear.anime.service.impl;

import com.whitebear.anime.mapper.VideoMapper;
import com.whitebear.anime.model.Result;
import com.whitebear.anime.model.dto.AIAgentDTO;
import com.whitebear.anime.model.entity.Video;
import com.whitebear.anime.service.UserService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class AIServiceImplAgentTest {

    @Mock
    private VideoMapper videoMapper;

    @Mock
    private UserService userService;

    @InjectMocks
    private AIServiceImpl service;

    @Test
    void naturalFollowCommandWritesFavorite() {
        Video video = video();
        when(videoMapper.findByTitle("完美世界")).thenReturn(video);
        when(userService.addFavorite(16L)).thenReturn(Result.success("追番成功"));

        Result<Object> response = service.agentCommand(command("帮我追《完美世界》"));

        assertEquals(200, response.getCode());
        assertEquals("follow_anime", data(response).get("action"));
        verify(userService).addFavorite(16L);
    }

    @Test
    void openCommandReturnsPlayableVideoWithoutChangingFavorites() {
        Video video = video();
        when(videoMapper.findByTitle("完美世界")).thenReturn(video);

        Result<Object> response = service.agentCommand(command("打开《完美世界》"));

        assertEquals(200, response.getCode());
        assertEquals("open_anime", data(response).get("action"));
        List<?> videos = (List<?>) data(response).get("videos");
        assertEquals("/play/141740", ((Map<?, ?>) videos.get(0)).get("playUrl"));
    }

    @Test
    void followingListContainsPlayableVideo() {
        when(userService.getFavorites()).thenReturn(Result.ok((Object) Map.of(
                "list", List.of(video()),
                "total", 1
        )));

        Result<Object> response = service.agentCommand(command("查看我的追番列表"));

        assertEquals(200, response.getCode());
        List<?> videos = (List<?>) data(response).get("videos");
        assertEquals(1, videos.size());
        assertEquals("/play/141740", ((Map<?, ?>) videos.get(0)).get("playUrl"));
    }

    @Test
    void unfollowBusinessFailureIsNotReportedAsSuccess() {
        when(videoMapper.findByTitle("完美世界")).thenReturn(video());
        when(userService.removeFavorite(16L)).thenReturn(Result.badRequest("追番记录不存在"));

        Result<Object> response = service.agentCommand(command("取消追番《完美世界》"));

        assertEquals(400, response.getCode());
        assertEquals("追番记录不存在", response.getMessage());
        verify(userService).removeFavorite(16L);
    }

    private AIAgentDTO command(String value) {
        AIAgentDTO dto = new AIAgentDTO();
        dto.setCommand(value);
        return dto;
    }

    @SuppressWarnings("unchecked")
    private Map<String, Object> data(Result<Object> response) {
        assertTrue(response.getData() instanceof Map<?, ?>);
        return (Map<String, Object>) response.getData();
    }

    private Video video() {
        return Video.builder()
                .id(16L)
                .sourceVodId(141740L)
                .title("完美世界")
                .cover("https://example.com/perfect-world.jpg")
                .category("中国动漫")
                .status("连载中")
                .rating(new BigDecimal("7.0"))
                .views(100L)
                .build();
    }
}
