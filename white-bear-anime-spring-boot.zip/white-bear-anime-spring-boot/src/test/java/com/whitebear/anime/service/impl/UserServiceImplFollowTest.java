package com.whitebear.anime.service.impl;

import com.whitebear.anime.mapper.*;
import com.whitebear.anime.model.Result;
import com.whitebear.anime.model.entity.User;
import com.whitebear.anime.model.entity.UserFollow;
import com.whitebear.anime.security.JwtUtils;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class UserServiceImplFollowTest {

    @Mock private UserMapper userMapper;
    @Mock private FavoriteMapper favoriteMapper;
    @Mock private WatchHistoryMapper watchHistoryMapper;
    @Mock private VideoMapper videoMapper;
    @Mock private EpisodeMapper episodeMapper;
    @Mock private LikeMapper likeMapper;
    @Mock private PostMapper postMapper;
    @Mock private OperationLogMapper operationLogMapper;
    @Mock private UserFollowMapper userFollowMapper;
    @Mock private PasswordEncoder passwordEncoder;
    @Mock private JwtUtils jwtUtils;
    @Mock private ObjectProvider<JavaMailSender> mailSenderProvider;

    @InjectMocks private UserServiceImpl service;

    @BeforeEach
    void authenticate() {
        UsernamePasswordAuthenticationToken authentication =
                new UsernamePasswordAuthenticationToken("viewer@test.local", null, List.of());
        authentication.setDetails(7L);
        SecurityContextHolder.getContext().setAuthentication(authentication);
    }

    @AfterEach
    void clearAuthentication() {
        SecurityContextHolder.clearContext();
    }

    @Test
    @SuppressWarnings("unchecked")
    void followIsPersistentIdempotentAndReturnsAllCurrentStats() {
        AtomicBoolean relationshipExists = new AtomicBoolean(false);
        when(userMapper.selectById(9L)).thenReturn(activeTarget());
        when(userFollowMapper.countRelationship(7L, 9L))
                .thenAnswer(invocation -> relationshipExists.get() ? 1L : 0L);
        doAnswer(invocation -> {
            relationshipExists.set(true);
            return 1;
        }).when(userFollowMapper).insert(any(UserFollow.class));
        stubStats();

        Result<Object> first = service.followUser(9L);
        Result<Object> duplicate = service.followUser(9L);

        assertEquals(200, first.getCode());
        assertEquals(200, duplicate.getCode());
        verify(userFollowMapper, times(1)).insert(any(UserFollow.class));

        ArgumentCaptor<UserFollow> captor = ArgumentCaptor.forClass(UserFollow.class);
        verify(userFollowMapper).insert(captor.capture());
        assertEquals(7L, captor.getValue().getFollowerId());
        assertEquals(9L, captor.getValue().getFollowingId());

        Map<String, Object> stats = (Map<String, Object>) first.getData();
        assertEquals(12L, stats.get("postCount"));
        assertEquals(345L, stats.get("receivedLikes"));
        assertEquals(8L, stats.get("followingCount"));
        assertEquals(21L, stats.get("followerCount"));
        assertTrue((Boolean) stats.get("isFollowing"));
        assertFalse((Boolean) stats.get("isSelf"));
    }

    @Test
    @SuppressWarnings("unchecked")
    void unfollowDeletesRelationshipAndReturnsUpdatedState() {
        when(userMapper.selectById(9L)).thenReturn(activeTarget());
        when(userFollowMapper.deleteRelationship(7L, 9L)).thenReturn(1);
        when(userFollowMapper.countRelationship(7L, 9L)).thenReturn(0L);
        stubStats();

        Result<Object> result = service.unfollowUser(9L);

        assertEquals(200, result.getCode());
        verify(userFollowMapper).deleteRelationship(7L, 9L);
        Map<String, Object> stats = (Map<String, Object>) result.getData();
        assertFalse((Boolean) stats.get("isFollowing"));
    }

    @Test
    void cannotFollowSelf() {
        Result<Object> result = service.followUser(7L);

        assertEquals(400, result.getCode());
        verify(userMapper, never()).selectById(any());
        verify(userFollowMapper, never()).insert(any(UserFollow.class));
    }

    private User activeTarget() {
        return User.builder().id(9L).username("target").status("active").build();
    }

    private void stubStats() {
        when(postMapper.countApprovedByAuthor(9L)).thenReturn(12L);
        when(postMapper.sumApprovedLikesByAuthor(9L)).thenReturn(345L);
        when(userFollowMapper.countFollowing(9L)).thenReturn(8L);
        when(userFollowMapper.countFollowers(9L)).thenReturn(21L);
    }
}
