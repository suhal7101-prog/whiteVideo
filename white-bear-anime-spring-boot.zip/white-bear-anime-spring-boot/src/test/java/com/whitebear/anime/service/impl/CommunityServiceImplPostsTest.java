package com.whitebear.anime.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.MybatisConfiguration;
import com.baomidou.mybatisplus.core.metadata.TableInfoHelper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.whitebear.anime.mapper.CommentMapper;
import com.whitebear.anime.mapper.DanmakuMapper;
import com.whitebear.anime.mapper.LikeMapper;
import com.whitebear.anime.mapper.PostMapper;
import com.whitebear.anime.mapper.UserMapper;
import com.whitebear.anime.model.Result;
import com.whitebear.anime.model.entity.Post;
import com.whitebear.anime.model.entity.User;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.apache.ibatis.builder.MapperBuilderAssistant;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class CommunityServiceImplPostsTest {

    @Mock private PostMapper postMapper;
    @Mock private CommentMapper commentMapper;
    @Mock private LikeMapper likeMapper;
    @Mock private DanmakuMapper danmakuMapper;
    @Mock private UserMapper userMapper;

    @InjectMocks private CommunityServiceImpl service;

    @Test
    @SuppressWarnings({"unchecked", "rawtypes"})
    void profilePostQueryFiltersByAuthorAndReturnsMatchingTotal() {
        TableInfoHelper.initTableInfo(
                new MapperBuilderAssistant(new MybatisConfiguration(), "community-post-test"),
                Post.class
        );
        Post post = Post.builder()
                .id(41L)
                .authorId(7L)
                .title("作者自己的帖子")
                .content("用于个人主页")
                .status("approved")
                .likes(120)
                .comments(3)
                .views(30)
                .deleted(0)
                .createTime(LocalDateTime.now())
                .build();
        when(postMapper.selectPage(any(Page.class), any(LambdaQueryWrapper.class)))
                .thenAnswer(invocation -> {
                    Page<Post> page = invocation.getArgument(0);
                    page.setRecords(List.of(post));
                    page.setTotal(1);
                    return page;
                });
        when(userMapper.selectById(7L)).thenReturn(User.builder().id(7L).username("author").build());
        when(commentMapper.countByPostId(41L)).thenReturn(3L);

        Result<Object> result = service.getPosts("new", 1, 20, null, 7L);

        assertEquals(200, result.getCode());
        Map<String, Object> data = (Map<String, Object>) result.getData();
        assertEquals(1L, data.get("total"));
        assertEquals(1, ((List<?>) data.get("list")).size());

        ArgumentCaptor<LambdaQueryWrapper<Post>> wrapperCaptor = ArgumentCaptor.forClass(LambdaQueryWrapper.class);
        verify(postMapper).selectPage(any(Page.class), wrapperCaptor.capture());
        LambdaQueryWrapper<Post> wrapper = wrapperCaptor.getValue();
        String sqlSegment = wrapper.getSqlSegment();
        assertTrue(sqlSegment.contains("status"));
        assertTrue(sqlSegment.contains("author_id"));
        assertTrue(wrapper.getParamNameValuePairs().containsValue("approved"));
        assertTrue(wrapper.getParamNameValuePairs().containsValue(7L));
    }
}
