package com.whitebear.anime.service.impl;

import com.whitebear.anime.mapper.*;
import com.whitebear.anime.model.dto.AnnouncementDTO;
import com.whitebear.anime.model.entity.Announcement;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.crypto.password.PasswordEncoder;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class AdminServiceImplAnnouncementTest {

    @Mock private UserMapper userMapper;
    @Mock private VideoMapper videoMapper;
    @Mock private BannerMapper bannerMapper;
    @Mock private PostMapper postMapper;
    @Mock private PlayStatsMapper playStatsMapper;
    @Mock private OperationLogMapper operationLogMapper;
    @Mock private AnnouncementMapper announcementMapper;
    @Mock private AnnouncementReadMapper announcementReadMapper;
    @Mock private PasswordEncoder passwordEncoder;

    @InjectMocks
    private AdminServiceImpl service;

    @Test
    void editingPublishedAnnouncementRepublishesForEveryUser() {
        when(announcementMapper.selectById(8L)).thenReturn(
                Announcement.builder().id(8L).status("published").build());

        service.updateAnnouncement(8L, dto("Updated title", "Updated content", "published"));

        ArgumentCaptor<Announcement> captor = ArgumentCaptor.forClass(Announcement.class);
        verify(announcementMapper).updateById(captor.capture());
        assertEquals("published", captor.getValue().getStatus());
        assertNotNull(captor.getValue().getPublishTime());
        verify(announcementReadMapper).deleteByAnnouncement(8L);
    }

    @Test
    void editingDraftDoesNotResetReadState() {
        when(announcementMapper.selectById(9L)).thenReturn(
                Announcement.builder().id(9L).status("draft").build());

        service.updateAnnouncement(9L, dto("Draft title", "Draft content", "draft"));

        verify(announcementReadMapper, never()).deleteByAnnouncement(9L);
    }

    private AnnouncementDTO dto(String title, String content, String status) {
        AnnouncementDTO dto = new AnnouncementDTO();
        dto.setTitle(title);
        dto.setContent(content);
        dto.setPinned(0);
        dto.setStatus(status);
        return dto;
    }
}
