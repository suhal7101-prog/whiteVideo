package com.whitebear.anime.config;

import org.junit.jupiter.api.Test;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.test.util.ReflectionTestUtils;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class DataInitializerTest {

    @Test
    void doesNotCreateManagedContentWhenSeedIsDisabled() {
        JdbcTemplate db = database("managed-content-disabled");
        DataInitializer initializer = initializer(db, false);

        initializer.run();

        assertEquals(0, db.queryForObject("SELECT COUNT(*) FROM wb_announcement", Integer.class));
        assertEquals(0, db.queryForObject("SELECT COUNT(*) FROM wb_advertisement", Integer.class));
        assertEquals(0, db.queryForObject(
                "SELECT COUNT(*) FROM wb_video WHERE audit_status <> 'approved' OR submission_source <> 'platform'",
                Integer.class));
    }

    @Test
    void addsVideoSubmissionAuditColumnsForExistingDatabase() {
        JdbcTemplate db = database("video-submission-migration");
        db.execute("CREATE TABLE wb_video (id BIGINT AUTO_INCREMENT PRIMARY KEY, title VARCHAR(256), deleted TINYINT DEFAULT 0)");
        db.update("INSERT INTO wb_video(title, deleted) VALUES('历史动漫', 0)");

        initializer(db, false).run();

        assertEquals("platform", db.queryForObject(
                "SELECT submission_source FROM wb_video WHERE title = '历史动漫'", String.class));
        assertEquals("approved", db.queryForObject(
                "SELECT audit_status FROM wb_video WHERE title = '历史动漫'", String.class));
    }

    @Test
    void addsCreatorApplicationColumnsAndKeepsExistingCreatorsApproved() {
        JdbcTemplate db = database("creator-application-migration");
        DataInitializer initializer = initializer(db, false);
        initializer.run();
        db.update("INSERT INTO wb_user(username,email,password,role,status) VALUES(?,?,?,?,?)",
                "creator", "creator@whitebear.test", "encoded", "creator", "active");

        initializer.run();

        assertEquals("approved", db.queryForObject(
                "SELECT creator_apply_status FROM wb_user WHERE username = 'creator'", String.class));
    }

    @Test
    void repairsLegacyHotPostWithRealUsersAndRealCommentRows() {
        JdbcTemplate db = database("community-hot-post-repair");
        DataInitializer initializer = initializer(db, false);
        initializer.run();
        db.update("INSERT INTO wb_user(username,email,password,role,status) VALUES(?,?,?,?,?)",
                "reader-one", "reader-one@whitebear.test", "encoded", "user", "active");
        db.update("INSERT INTO wb_user(username,email,password,role,status) VALUES(?,?,?,?,?)",
                "reader-two", "reader-two@whitebear.test", "encoded", "user", "active");
        db.update("INSERT INTO wb_post(title,content,author_id,tag,likes,comments,views,status) " +
                        "VALUES(?,?,?,?,?,?,?,?)",
                "旧版热门帖子", "评论数量曾经是写死的", 999L, "分享", 856, 128, 3200, "approved");
        db.update("INSERT INTO wb_comment(post_id,user_id,content,likes) VALUES(?,?,?,?)",
                1L, 1L, "原有真实评论", 3);

        initializer.run();
        initializer.run();

        assertEquals(24, db.queryForObject(
                "SELECT COUNT(*) FROM wb_comment WHERE post_id = 1 AND deleted = 0", Integer.class));
        assertEquals(24, db.queryForObject(
                "SELECT comments FROM wb_post WHERE id = 1", Integer.class));
        assertEquals(0, db.queryForObject(
                "SELECT COUNT(*) FROM wb_comment c LEFT JOIN wb_user u ON u.id = c.user_id " +
                        "WHERE c.post_id = 1 AND (u.id IS NULL OR u.deleted <> 0)", Integer.class));
        assertEquals(1, db.queryForObject(
                "SELECT COUNT(*) FROM wb_post p JOIN wb_user u ON u.id = p.author_id " +
                        "WHERE p.id = 1 AND u.deleted = 0 AND u.status = 'active'", Integer.class));
        Integer likes = db.queryForObject("SELECT likes FROM wb_post WHERE id = 1", Integer.class);
        assertTrue(likes != null && likes >= 100 && likes <= 300);
    }

    @Test
    void doesNotResurrectDeletedSeedContent() {
        JdbcTemplate db = database("managed-content-deletion");
        DataInitializer initializer = initializer(db, true);

        initializer.run();
        db.update("UPDATE wb_announcement SET deleted = 1 WHERE title = '新用户送额度'");
        db.update("UPDATE wb_advertisement SET deleted = 1 WHERE title = '新番导览专场'");
        initializer.run();

        assertEquals(0, db.queryForObject(
                "SELECT COUNT(*) FROM wb_announcement WHERE title = '新用户送额度' AND deleted = 0", Integer.class));
        assertEquals(1, db.queryForObject(
                "SELECT COUNT(*) FROM wb_announcement WHERE title = '新用户送额度'", Integer.class));
        assertEquals(0, db.queryForObject(
                "SELECT COUNT(*) FROM wb_advertisement WHERE title = '新番导览专场' AND deleted = 0", Integer.class));
        assertEquals(1, db.queryForObject(
                "SELECT COUNT(*) FROM wb_advertisement WHERE title = '新番导览专场'", Integer.class));
    }

    @Test
    void keepsLegacyPasswordWhenCleanupIsDisabled() {
        JdbcTemplate db = database("legacy-seed");
        PasswordEncoder encoder = new BCryptPasswordEncoder();
        DataInitializer initializer = new DataInitializer(db, encoder);
        ReflectionTestUtils.setField(initializer, "seedEnabled", false);
        ReflectionTestUtils.setField(initializer, "disableLegacyAccounts", false);

        initializer.run();
        db.update("INSERT INTO wb_user(username,email,password,role,status) VALUES(?,?,?,?,?)",
                "admin", "admin@whitebear.com", encoder.encode("admin123"), "admin", "active");

        initializer.run();

        String status = db.queryForObject("SELECT status FROM wb_user WHERE username = 'admin'", String.class);
        String password = db.queryForObject("SELECT password FROM wb_user WHERE username = 'admin'", String.class);
        assertEquals("active", status);
        assertTrue(encoder.matches("admin123", password));
    }

    @Test
    void disablesLegacyPasswordOnlyWhenCleanupIsEnabled() {
        JdbcTemplate db = database("legacy-seed-cleanup");
        PasswordEncoder encoder = new BCryptPasswordEncoder();
        DataInitializer initializer = new DataInitializer(db, encoder);
        ReflectionTestUtils.setField(initializer, "seedEnabled", false);
        ReflectionTestUtils.setField(initializer, "disableLegacyAccounts", true);

        initializer.run();
        db.update("INSERT INTO wb_user(username,email,password,role,status) VALUES(?,?,?,?,?)",
                "admin", "admin@whitebear.com", encoder.encode("admin123"), "admin", "active");

        initializer.run();

        String status = db.queryForObject("SELECT status FROM wb_user WHERE username = 'admin'", String.class);
        String password = db.queryForObject("SELECT password FROM wb_user WHERE username = 'admin'", String.class);
        assertEquals("banned", status);
        assertFalse(encoder.matches("admin123", password));
    }

    private JdbcTemplate database(String name) {
        DriverManagerDataSource dataSource = new DriverManagerDataSource(
                "jdbc:h2:mem:" + name + ";MODE=MySQL;DB_CLOSE_DELAY=-1", "sa", "");
        return new JdbcTemplate(dataSource);
    }

    private DataInitializer initializer(JdbcTemplate db, boolean seedEnabled) {
        DataInitializer initializer = new DataInitializer(db, new BCryptPasswordEncoder());
        ReflectionTestUtils.setField(initializer, "seedEnabled", seedEnabled);
        ReflectionTestUtils.setField(initializer, "disableLegacyAccounts", false);
        ReflectionTestUtils.setField(initializer, "adminEmail", "admin@whitebear.test");
        ReflectionTestUtils.setField(initializer, "adminPassword", "AdminPassword123!");
        ReflectionTestUtils.setField(initializer, "testPassword", "TestPassword123!");
        return initializer;
    }
}
