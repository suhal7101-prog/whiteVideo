package com.whitebear.anime.service.impl;

import com.whitebear.anime.mapper.LikeMapper;
import com.whitebear.anime.mapper.UserMapper;
import com.whitebear.anime.mapper.VideoCommentMapper;
import com.whitebear.anime.model.Result;
import com.whitebear.anime.model.dto.VideoCommentDTO;
import com.whitebear.anime.model.entity.Like;
import com.whitebear.anime.model.entity.User;
import com.whitebear.anime.model.entity.VideoComment;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class VideoCommentServiceImplTest {

    @Mock private VideoCommentMapper videoCommentMapper;
    @Mock private UserMapper userMapper;
    @Mock private LikeMapper likeMapper;

    @InjectMocks private VideoCommentServiceImpl service;

    @BeforeEach
    void authenticate() {
        UsernamePasswordAuthenticationToken authentication =
                new UsernamePasswordAuthenticationToken("viewer@test.local", null, List.of());
        authentication.setDetails(7L);
        SecurityContextHolder.getContext().setAuthentication(authentication);
    }

    @AfterEach
    void clearAuthentication() {
        SecurityContextHolder.clearContext();
    }

    @Test
    @SuppressWarnings("unchecked")
    void listIncludesReplyTargetAndCurrentLikeState() {
        VideoComment parent = VideoComment.builder()
                .id(1L).videoId(42L).sourceType("db").userId(8L)
                .content("原评论").likes(2).deleted(0).createTime(LocalDateTime.now()).build();
        VideoComment reply = VideoComment.builder()
                .id(2L).videoId(42L).sourceType("db").userId(9L).parentId(1L)
                .content("回复内容").likes(1).deleted(0).createTime(LocalDateTime.now()).build();
        when(videoCommentMapper.selectByVideo(42L, "db")).thenReturn(List.of(reply, parent));
        when(userMapper.selectById(8L)).thenReturn(User.builder().id(8L).username("alice").build());
        when(userMapper.selectById(9L)).thenReturn(User.builder().id(9L).username("bob").build());
        when(likeMapper.countByUserAndTarget(7L, 2L, "video_comment")).thenReturn(1);

        Result<Object> result = service.listComments(42L, "db");

        assertEquals(200, result.getCode());
        List<Map<String, Object>> list = (List<Map<String, Object>>) ((Map<?, ?>) result.getData()).get("list");
        assertEquals(2, list.size());
        assertEquals("alice", list.get(0).get("replyTo"));
        assertTrue((Boolean) list.get(0).get("liked"));
    }

    @Test
    void addReplyPersistsParentAndReturnsReplyUser() {
        VideoComment parent = VideoComment.builder()
                .id(11L).videoId(42L).sourceType("source").userId(8L).deleted(0).build();
        when(videoCommentMapper.selectById(11L)).thenReturn(parent);
        when(userMapper.selectById(7L)).thenReturn(User.builder().id(7L).username("viewer").build());
        when(userMapper.selectById(8L)).thenReturn(User.builder().id(8L).username("alice").build());
        doAnswer(invocation -> {
            VideoComment inserted = invocation.getArgument(0);
            inserted.setId(12L);
            return 1;
        }).when(videoCommentMapper).insert(any(VideoComment.class));
        VideoCommentDTO dto = new VideoCommentDTO();
        dto.setVideoId(42L);
        dto.setSourceType("source");
        dto.setParentId(11L);
        dto.setContent("  回复内容  ");

        Result<Object> result = service.addComment(dto);

        assertEquals(200, result.getCode());
        ArgumentCaptor<VideoComment> captor = ArgumentCaptor.forClass(VideoComment.class);
        verify(videoCommentMapper).insert(captor.capture());
        assertEquals(11L, captor.getValue().getParentId());
        assertEquals("回复内容", captor.getValue().getContent());
        assertEquals("alice", ((Map<?, ?>) result.getData()).get("replyTo"));
    }

    @Test
    void toggleLikePersistsLikeAndReturnsUpdatedCount() {
        when(videoCommentMapper.selectById(5L)).thenReturn(
                VideoComment.builder().id(5L).likes(2).deleted(0).build());
        when(likeMapper.countByUserAndTarget(7L, 5L, "video_comment")).thenReturn(0);

        Result<Object> result = service.toggleLike(5L);

        assertEquals(200, result.getCode());
        verify(likeMapper).insert(any(Like.class));
        verify(videoCommentMapper).incrementLikes(5L);
        assertEquals(true, ((Map<?, ?>) result.getData()).get("liked"));
        assertEquals(3, ((Map<?, ?>) result.getData()).get("likes"));
    }
}
