package com.whitebear.anime.service.impl;

import com.whitebear.anime.mapper.*;
import com.whitebear.anime.model.Result;
import com.whitebear.anime.model.entity.Video;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class AdminServiceImplStatsTest {

    @Mock private UserMapper userMapper;
    @Mock private VideoMapper videoMapper;
    @Mock private BannerMapper bannerMapper;
    @Mock private PostMapper postMapper;
    @Mock private PlayStatsMapper playStatsMapper;
    @Mock private OperationLogMapper operationLogMapper;
    @Mock private AnnouncementMapper announcementMapper;
    @Mock private AnnouncementReadMapper announcementReadMapper;
    @Mock private AdvertisementMapper advertisementMapper;
    @Mock private PasswordEncoder passwordEncoder;

    @InjectMocks
    private AdminServiceImpl service;

    @Test
    @SuppressWarnings("unchecked")
    void overviewReturnsCurrentDatabaseCounts() {
        when(userMapper.countTotalUsers()).thenReturn(7L);
        when(userMapper.countTodayNewUsers()).thenReturn(2L);
        when(videoMapper.countTotalVideos()).thenReturn(72L);
        when(postMapper.countTotalPosts()).thenReturn(15L);
        when(playStatsMapper.countTotalPlays()).thenReturn(109L);
        when(playStatsMapper.countTodayPlays()).thenReturn(8L);
        when(operationLogMapper.selectRecent(10)).thenReturn(List.of());

        Result<Object> result = service.getStatsOverview();
        Map<String, Object> data = (Map<String, Object>) result.getData();

        assertEquals(7L, data.get("totalUsers"));
        assertEquals(2L, data.get("todayNewUsers"));
        assertEquals(72L, data.get("totalVideos"));
        assertEquals(15L, data.get("totalPosts"));
        assertEquals(109L, data.get("totalPlays"));
        assertEquals(8L, data.get("todayPlays"));
        verify(playStatsMapper).countTodayPlays();
    }

    @Test
    @SuppressWarnings("unchecked")
    void rankingUsesVisibleViewsAndLikesForHeatScore() {
        when(videoMapper.selectTopByHeat(20)).thenReturn(List.of(
                Video.builder().id(24L).title("禅王渡尘").views(239121L).likes(15008L).build(),
                Video.builder().id(23L).title("先天九魂环").views(184774L).likes(15597L).build()
        ));

        Result<Object> result = service.getRankingStats("all");
        List<Map<String, Object>> ranking = (List<Map<String, Object>>)
                ((Map<String, Object>) result.getData()).get("ranking");

        assertEquals("禅王渡尘", ranking.get(0).get("title"));
        assertEquals(239121L, ranking.get(0).get("views"));
        assertEquals(15008L, ranking.get(0).get("likes"));
        assertEquals(389201L, ranking.get(0).get("heatScore"));
        verify(videoMapper).selectTopByHeat(20);
    }
}
