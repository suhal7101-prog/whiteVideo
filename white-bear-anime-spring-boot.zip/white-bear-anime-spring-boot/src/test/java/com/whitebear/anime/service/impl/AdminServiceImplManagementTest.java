package com.whitebear.anime.service.impl;

import com.whitebear.anime.mapper.*;
import com.whitebear.anime.model.Result;
import com.whitebear.anime.model.dto.VideoDTO;
import com.whitebear.anime.model.dto.VideoAuditDTO;
import com.whitebear.anime.model.dto.CreatorAuditDTO;
import com.whitebear.anime.model.entity.User;
import com.whitebear.anime.model.entity.Video;
import org.apache.ibatis.annotations.Select;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.crypto.password.PasswordEncoder;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class AdminServiceImplManagementTest {

    @Mock private UserMapper userMapper;
    @Mock private VideoMapper videoMapper;
    @Mock private BannerMapper bannerMapper;
    @Mock private PostMapper postMapper;
    @Mock private PlayStatsMapper playStatsMapper;
    @Mock private OperationLogMapper operationLogMapper;
    @Mock private AnnouncementMapper announcementMapper;
    @Mock private AnnouncementReadMapper announcementReadMapper;
    @Mock private AdvertisementMapper advertisementMapper;
    @Mock private PasswordEncoder passwordEncoder;

    @InjectMocks private AdminServiceImpl service;

    @Test
    void updatingVideoPersistsRegion() {
        when(videoMapper.selectById(12L)).thenReturn(Video.builder().id(12L).region("中国").build());
        VideoDTO dto = new VideoDTO();
        dto.setTitle("测试视频");
        dto.setCategory("动漫");
        dto.setRegion("日本");

        service.updateVideo(12L, dto);

        ArgumentCaptor<Video> captor = ArgumentCaptor.forClass(Video.class);
        verify(videoMapper).updateById(captor.capture());
        assertEquals("日本", captor.getValue().getRegion());
    }

    @Test
    void rejectingShortResetPasswordDoesNotUpdateDatabase() {
        when(userMapper.selectById(3L)).thenReturn(User.builder().id(3L).build());

        Result<Void> result = service.resetPassword(3L, "123");

        assertEquals(400, result.getCode());
        verify(userMapper, never()).updateById(any(User.class));
    }

    @Test
    void deletingMissingVideoReturnsNotFound() {
        when(videoMapper.selectById(404L)).thenReturn(null);

        Result<Void> result = service.deleteVideo(404L);

        assertEquals(404, result.getCode());
        verify(videoMapper, never()).deleteById(404L);
    }

    @Test
    void creatingVideoAutomaticallyAddsTwoDistinctTags() {
        VideoDTO dto = new VideoDTO();
        dto.setTitle("无标签视频");
        dto.setCategory("动漫");
        doAnswer(invocation -> {
            invocation.<Video>getArgument(0).setId(99L);
            return 1;
        }).when(videoMapper).insert(any(Video.class));

        service.createVideo(dto);

        ArgumentCaptor<Video> captor = ArgumentCaptor.forClass(Video.class);
        verify(videoMapper).insert(captor.capture());
        String[] tags = captor.getValue().getTags().split(",");
        assertEquals(2, tags.length);
        assertNotEquals(tags[0], tags[1]);
        assertEquals("platform", captor.getValue().getSubmissionSource());
        assertEquals("approved", captor.getValue().getAuditStatus());
    }

    @Test
    void approvingUserSubmissionMakesItVisibleWithoutRejectionReason() {
        Video submission = Video.builder()
                .id(88L)
                .submissionSource("user")
                .auditStatus("pending")
                .auditReason("旧说明")
                .build();
        when(videoMapper.selectById(88L)).thenReturn(submission);
        VideoAuditDTO dto = new VideoAuditDTO();
        dto.setStatus("approved");

        Result<Void> result = service.auditVideoSubmission(88L, dto);

        assertEquals(200, result.getCode());
        ArgumentCaptor<Video> captor = ArgumentCaptor.forClass(Video.class);
        verify(videoMapper).updateById(captor.capture());
        assertEquals("approved", captor.getValue().getAuditStatus());
        assertNull(captor.getValue().getAuditReason());
    }

    @Test
    void rejectingUserSubmissionRequiresReason() {
        when(videoMapper.selectById(89L)).thenReturn(Video.builder()
                .id(89L).submissionSource("user").auditStatus("pending").build());
        VideoAuditDTO dto = new VideoAuditDTO();
        dto.setStatus("rejected");
        dto.setReason("   ");

        Result<Void> result = service.auditVideoSubmission(89L, dto);

        assertEquals(400, result.getCode());
        verify(videoMapper, never()).updateById(any(Video.class));
    }

    @Test
    void approvingCreatorApplicationChangesUserRoleToCreator() {
        User applicant = User.builder()
                .id(31L)
                .role("user")
                .creatorApplyStatus("pending")
                .build();
        when(userMapper.selectById(31L)).thenReturn(applicant);
        CreatorAuditDTO dto = new CreatorAuditDTO();
        dto.setStatus("approved");

        Result<Void> result = service.auditCreatorApplication(31L, dto);

        assertEquals(200, result.getCode());
        ArgumentCaptor<User> captor = ArgumentCaptor.forClass(User.class);
        verify(userMapper).updateById(captor.capture());
        assertEquals("creator", captor.getValue().getRole());
        assertEquals("approved", captor.getValue().getCreatorApplyStatus());
        assertNull(captor.getValue().getCreatorApplyReason());
    }

    @Test
    void videoSubmissionQueryIncludesPlayableEpisodeData() throws Exception {
        Select select = VideoMapper.class
                .getMethod("selectVideoSubmissions", int.class, int.class, String.class, String.class)
                .getAnnotation(Select.class);
        String sql = String.join(" ", select.value());

        assertTrue(sql.contains("video_url"));
        assertTrue(sql.contains("videoUrl"));
        assertTrue(sql.contains("episodeNumber"));
        assertTrue(sql.contains("videoFileSize"));
    }
}
