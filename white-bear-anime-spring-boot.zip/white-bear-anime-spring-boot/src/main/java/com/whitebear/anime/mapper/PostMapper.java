package com.whitebear.anime.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.whitebear.anime.model.entity.Post;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

/**
 * 社区帖子 Mapper
 *
 * @author WhiteBear
 */
@Mapper
public interface PostMapper extends BaseMapper<Post> {

    @Select("SELECT COUNT(*) FROM wb_post WHERE deleted = 0")
    Long countTotalPosts();

    @Select("SELECT COUNT(*) FROM wb_post WHERE author_id = #{authorId} AND status = 'approved' AND deleted = 0")
    long countApprovedByAuthor(@Param("authorId") Long authorId);

    @Select("SELECT COALESCE(SUM(likes), 0) FROM wb_post WHERE author_id = #{authorId} AND status = 'approved' AND deleted = 0")
    long sumApprovedLikesByAuthor(@Param("authorId") Long authorId);

    /** 查询已审核帖子列表（最新） */
    @Select("SELECT * FROM wb_post WHERE status = 'approved' AND deleted = 0 ORDER BY create_time DESC")
    java.util.List<Post> selectApprovedPosts();

    /** 查询待审核帖子 */
    @Select("SELECT * FROM wb_post WHERE status = 'pending' AND deleted = 0 ORDER BY create_time ASC")
    java.util.List<Post> selectPendingPosts();

    /** 浏览量 +1 */
    @Update("UPDATE wb_post SET views = views + 1 WHERE id = #{id}")
    int incrementViews(@Param("id") Long id);

    /** 点赞数 +1 */
    @Update("UPDATE wb_post SET likes = likes + 1 WHERE id = #{id}")
    int incrementLikes(@Param("id") Long id);

    /** 点赞数 -1 */
    @Update("UPDATE wb_post SET likes = likes - 1 WHERE id = #{id} AND likes > 0")
    int decrementLikes(@Param("id") Long id);

    /** 评论数 +1 */
    @Update("UPDATE wb_post SET comments = comments + 1 WHERE id = #{id}")
    int incrementComments(@Param("id") Long id);
}
