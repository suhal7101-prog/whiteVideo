package com.whitebear.anime.model.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Min;
import lombok.Data;

/**
 * 新增/编辑视频 DTO
 *
 * @author WhiteBear
 */
@Data
@Schema(description = "视频请求 DTO")
public class VideoDTO {

    @Schema(description = "Python 视频源 ID（后台数据兼容字段）")
    private Long sourceVodId;

    @Schema(description = "上传后的视频播放地址")
    private String videoUrl;

    @Schema(description = "上传视频文件大小（字节）")
    private Long videoFileSize;

    @NotBlank(message = "标题不能为空")
    @Schema(description = "视频标题")
    private String title;

    @Schema(description = "封面图片 URL")
    private String cover;

    @NotBlank(message = "分类不能为空")
    @Schema(description = "分类")
    private String category;

    @Schema(description = "简介")
    private String description;

    @Schema(description = "状态: 连载中/已完结")
    private String status;

    @Schema(description = "评分")
    private Double rating;

    @Schema(description = "总集数")
    private Integer episodes;

    @Min(value = 1, message = "当前上传集数不能小于 1")
    @Schema(description = "当前上传的是第几集")
    private Integer episodeNumber;

    @Schema(description = "标签,逗号分隔")
    private String tags;

    @Schema(description = "播出年份")
    private Integer year;

    @Schema(description = "地区")
    private String region;
}
