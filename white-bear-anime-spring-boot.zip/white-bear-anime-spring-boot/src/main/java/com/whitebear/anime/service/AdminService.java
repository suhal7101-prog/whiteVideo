package com.whitebear.anime.service;

import com.whitebear.anime.model.Result;
import com.whitebear.anime.model.dto.BannerDTO;
import com.whitebear.anime.model.dto.AnnouncementDTO;
import com.whitebear.anime.model.dto.VideoDTO;
import com.whitebear.anime.model.dto.VideoAuditDTO;
import com.whitebear.anime.model.dto.CreatorAuditDTO;
import com.whitebear.anime.model.dto.AdvertisementDTO;

/**
 * 管理后台服务接口
 *
 * @author WhiteBear
 */
public interface AdminService {

    // ===== 用户管理 =====
    Result<Object> getUsers(Integer page, Integer size, String keyword, String role, String status);
    Result<Void> updateUser(Long id, Object data);
    Result<Void> deleteUser(Long id);
    Result<Void> resetPassword(Long id, String password);
    Result<Object> getCreatorApplications(Integer page, Integer size, String keyword, String applyStatus);
    Result<Void> auditCreatorApplication(Long userId, CreatorAuditDTO dto);

    // ===== 视频管理 =====
    Result<Object> getVideos(Integer page, Integer size, String keyword, String category);
    Result<Object> createVideo(VideoDTO dto);
    Result<Object> updateVideo(Long id, VideoDTO dto);
    Result<Void> deleteVideo(Long id);
    Result<Object> getVideoSubmissions(Integer page, Integer size, String keyword, String auditStatus);
    Result<Void> auditVideoSubmission(Long id, VideoAuditDTO dto);

    // ===== 内容管理 =====
    Result<Object> getBanners();
    Result<Object> createBanner(BannerDTO dto);
    Result<Object> updateBanner(Long id, BannerDTO dto);
    Result<Object> getPendingPosts(Integer page, Integer size);
    Result<Void> auditPost(Long postId, String status);
    Result<Object> getAnnouncements();
    Result<Object> createAnnouncement(AnnouncementDTO dto);
    Result<Void> updateAnnouncement(Long id, AnnouncementDTO dto);
    Result<Void> deleteAnnouncement(Long id);

    // ===== 广告管理 =====
    Result<Object> getAdvertisements();
    Result<Object> createAdvertisement(AdvertisementDTO dto);
    Result<Void> updateAdvertisement(Long id, AdvertisementDTO dto);
    Result<Void> deleteAdvertisement(Long id);

    // ===== 数据统计 =====
    Result<Object> getStatsOverview();
    Result<Object> getPlayStats(String period);
    Result<Object> getUserStats(String period);
    Result<Object> getRankingStats(String period);
}
