package com.whitebear.anime.model.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * 弹幕实体
 *
 * @author WhiteBear
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@TableName("wb_danmaku")
public class Danmaku {

    @TableId(type = IdType.AUTO)
    private Long id;

    /** 动漫 ID */
    private Long animeId;

    /** 剧集 ID */
    private Long episodeId;

    /** 用户 ID */
    private Long userId;

    /** 弹幕内容 */
    private String content;

    /** 弹幕时间点（秒） */
    private Double timestamp;

    /** 弹幕颜色 */
    private String color;

    /** 弹幕类型: scroll / top / bottom */
    private String type;

    /** 字体大小: small / normal / large */
    private String fontSize;

    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createTime;
}
