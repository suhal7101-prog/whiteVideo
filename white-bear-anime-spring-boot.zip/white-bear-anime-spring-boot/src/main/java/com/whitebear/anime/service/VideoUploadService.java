package com.whitebear.anime.service;

import com.whitebear.anime.config.MinioConfig;
import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.util.UriUtils;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;

/** 创作者投稿视频存储：优先使用 MinIO，未配置时保存到本地目录。 */
@Slf4j
@Service
@RequiredArgsConstructor
public class VideoUploadService {

    private static final long MAX_VIDEO_SIZE = 500L * 1024 * 1024;
    private static final Set<String> ALLOWED_EXTENSIONS = Set.of(".mp4", ".webm", ".mov", ".m4v");

    private final FileService fileService;
    private final MinioConfig minioConfig;

    @Value("${white-bear.submission.video-storage-dir:./data/submission-videos}")
    private String storageDir;

    private Path storageRoot;

    @PostConstruct
    void initializeStorage() throws IOException {
        storageRoot = Paths.get(storageDir).toAbsolutePath().normalize();
        Files.createDirectories(storageRoot);
    }

    public UploadedVideo upload(MultipartFile file) throws Exception {
        validate(file);
        if (minioConfig.isConfigured()) {
            try {
                String url = fileService.uploadVideo(file);
                return new UploadedVideo(url, safeOriginalName(file), file.getSize());
            } catch (Exception exception) {
                log.warn("[投稿视频] MinIO 上传失败，改用本地存储: {}", exception.getMessage());
            }
        }

        String extension = extensionOf(file.getOriginalFilename());
        String fileName = "submission-" + UUID.randomUUID().toString().replace("-", "") + extension;
        Path target = storageRoot.resolve(fileName).normalize();
        try (var input = file.getInputStream()) {
            Files.copy(input, target, StandardCopyOption.REPLACE_EXISTING);
        }
        log.info("[投稿视频] 已保存到本地: {}", target);
        String url = "/api/user/submission-video/"
                + UriUtils.encodePathSegment(fileName, StandardCharsets.UTF_8);
        return new UploadedVideo(url, safeOriginalName(file), file.getSize());
    }

    public Resource getResource(String fileName) {
        if (fileName == null || fileName.isBlank()) throw new IllegalArgumentException("投稿视频不存在");
        Path candidate = storageRoot.resolve(fileName).normalize();
        if (!candidate.getParent().equals(storageRoot) || !Files.isRegularFile(candidate)) {
            throw new IllegalArgumentException("投稿视频不存在");
        }
        return new FileSystemResource(candidate);
    }

    public String contentType(String fileName) {
        try {
            String detected = Files.probeContentType(storageRoot.resolve(fileName));
            return detected == null ? "video/mp4" : detected;
        } catch (IOException ignored) {
            return "video/mp4";
        }
    }

    private void validate(MultipartFile file) {
        if (file == null || file.isEmpty()) throw new IllegalArgumentException("请选择视频文件");
        if (file.getSize() > MAX_VIDEO_SIZE) throw new IllegalArgumentException("视频大小不能超过 500MB");
        String contentType = file.getContentType();
        if (contentType == null || !contentType.toLowerCase(Locale.ROOT).startsWith("video/")) {
            throw new IllegalArgumentException("仅支持视频文件");
        }
        if (!ALLOWED_EXTENSIONS.contains(extensionOf(file.getOriginalFilename()))) {
            throw new IllegalArgumentException("仅支持 MP4、WebM、MOV 或 M4V 视频");
        }
    }

    private String extensionOf(String fileName) {
        if (fileName == null) return "";
        int dot = fileName.lastIndexOf('.');
        return dot < 0 ? "" : fileName.substring(dot).toLowerCase(Locale.ROOT);
    }

    private String safeOriginalName(MultipartFile file) {
        String name = file.getOriginalFilename();
        return name == null || name.isBlank() ? "video" : Paths.get(name).getFileName().toString();
    }

    public record UploadedVideo(String url, String originalName, long size) {}
}
