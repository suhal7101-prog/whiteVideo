package com.whitebear.anime.model.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
public class AnnouncementDTO {

    @NotBlank(message = "公告标题不能为空")
    @Size(max = 256, message = "公告标题不能超过256个字符")
    private String title;

    @NotBlank(message = "公告内容不能为空")
    private String content;

    private Integer pinned;

    private String status;
}
