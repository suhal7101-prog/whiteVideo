package com.whitebear.anime.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.whitebear.anime.model.entity.AnnouncementRead;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface AnnouncementReadMapper extends BaseMapper<AnnouncementRead> {

    @Insert("INSERT INTO wb_announcement_read(user_id, announcement_id, read_time) " +
            "SELECT #{userId}, #{announcementId}, CURRENT_TIMESTAMP " +
            "WHERE NOT EXISTS (SELECT 1 FROM wb_announcement_read " +
            "WHERE user_id = #{userId} AND announcement_id = #{announcementId})")
    int markRead(@Param("userId") Long userId, @Param("announcementId") Long announcementId);

    @Delete("DELETE FROM wb_announcement_read WHERE announcement_id = #{announcementId}")
    int deleteByAnnouncement(@Param("announcementId") Long announcementId);
}
