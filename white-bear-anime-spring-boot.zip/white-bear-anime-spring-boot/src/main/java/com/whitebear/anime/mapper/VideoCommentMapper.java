package com.whitebear.anime.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.whitebear.anime.model.entity.VideoComment;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

@Mapper
public interface VideoCommentMapper extends BaseMapper<VideoComment> {

    @Select("SELECT * FROM wb_video_comment WHERE video_id = #{videoId} " +
            "AND source_type = #{sourceType} AND deleted = 0 ORDER BY create_time DESC, id DESC")
    List<VideoComment> selectByVideo(@Param("videoId") Long videoId,
                                     @Param("sourceType") String sourceType);

    @Update("UPDATE wb_video_comment SET likes = likes + 1 WHERE id = #{id} AND deleted = 0")
    int incrementLikes(@Param("id") Long id);

    @Update("UPDATE wb_video_comment SET likes = likes - 1 " +
            "WHERE id = #{id} AND deleted = 0 AND likes > 0")
    int decrementLikes(@Param("id") Long id);
}
