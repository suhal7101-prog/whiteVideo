package com.whitebear.anime.model.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

/**
 * 审核帖子 DTO
 *
 * @author WhiteBear
 */
@Data
@Schema(description = "审核帖子请求")
public class AuditPostDTO {

    @NotBlank(message = "审核状态不能为空")
    @Schema(description = "审核状态: approved / rejected", example = "approved")
    private String status;
}
