package com.whitebear.anime.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.whitebear.anime.model.entity.Episode;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * 剧集 Mapper
 *
 * @author WhiteBear
 */
@Mapper
public interface EpisodeMapper extends BaseMapper<Episode> {

    /** 根据视频 ID 查询剧集列表（按集数排序） */
    @Select("SELECT * FROM wb_episode WHERE video_id = #{videoId} AND deleted = 0 ORDER BY episode_num ASC")
    List<Episode> selectByVideoId(@Param("videoId") Long videoId);

    /** 查询下一集 */
    @Select("SELECT * FROM wb_episode WHERE video_id = #{videoId} AND episode_num > #{currentEp} " +
            "AND deleted = 0 ORDER BY episode_num ASC LIMIT 1")
    Episode selectNextEpisode(@Param("videoId") Long videoId, @Param("currentEp") Integer currentEp);
}
