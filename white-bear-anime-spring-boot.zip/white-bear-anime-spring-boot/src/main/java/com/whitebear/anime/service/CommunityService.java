package com.whitebear.anime.service;

import com.whitebear.anime.model.Result;
import com.whitebear.anime.model.dto.CommentDTO;
import com.whitebear.anime.model.dto.DanmakuDTO;
import com.whitebear.anime.model.dto.LikeDTO;
import com.whitebear.anime.model.dto.PostDTO;

/**
 * 社区服务接口
 *
 * @author WhiteBear
 */
public interface CommunityService {

    /** 获取帖子列表 */
    Result<Object> getPosts(String sort, int page, int size, String topic, Long authorId);

    /** 获取帖子详情 */
    Result<Object> getPostDetail(Long postId);

    /** 发布帖子 */
    Result<Object> createPost(PostDTO dto);

    /** 删除帖子 */
    Result<Void> deletePost(Long postId);

    /** 发表评论 */
    Result<Object> addComment(CommentDTO dto);

    /** 点赞/取消点赞 */
    Result<Object> toggleLike(LikeDTO dto);

    /** 分享 */
    Result<Void> share(Long targetId);

    /** 获取弹幕列表 */
    Result<Object> getDanmaku(Long animeId, Long episodeId);

    /** 发送弹幕 */
    Result<Object> sendDanmaku(DanmakuDTO dto);
}
