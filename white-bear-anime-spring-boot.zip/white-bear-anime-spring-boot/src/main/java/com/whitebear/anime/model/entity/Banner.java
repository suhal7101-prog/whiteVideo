package com.whitebear.anime.model.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * 轮播图实体
 *
 * @author WhiteBear
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@TableName("wb_banner")
public class Banner {

    @TableId(type = IdType.AUTO)
    private Long id;

    /** 标题 */
    private String title;

    /** 图片 URL */
    private String img;

    /** 关联动漫 ID */
    private Long animeId;

    /** 排序号 */
    private Integer sortOrder;

    /** 是否启用 */
    private Integer active;

    @TableLogic
    private Integer deleted;

    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createTime;

    @TableField(fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime updateTime;
}
