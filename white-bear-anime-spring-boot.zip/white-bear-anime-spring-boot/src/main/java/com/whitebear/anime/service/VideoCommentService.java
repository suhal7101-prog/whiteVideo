package com.whitebear.anime.service;

import com.whitebear.anime.model.Result;
import com.whitebear.anime.model.dto.VideoCommentDTO;

public interface VideoCommentService {

    Result<Object> listComments(Long videoId, String sourceType);

    Result<Object> addComment(VideoCommentDTO dto);

    Result<Object> toggleLike(Long commentId);
}
