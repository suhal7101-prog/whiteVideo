package com.whitebear.anime.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.whitebear.anime.model.entity.PlayStats;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;
import java.util.Map;

/**
 * 播放统计 Mapper
 *
 * @author WhiteBear
 */
@Mapper
public interface PlayStatsMapper extends BaseMapper<PlayStats> {

    @Select("SELECT COALESCE(SUM(play_count), 0) FROM wb_play_stats")
    Long countTotalPlays();

    /** 统计数据库服务器当天实际记录的播放次数 */
    @Select("SELECT COALESCE(SUM(play_count), 0) FROM wb_play_stats WHERE play_date = CURDATE()")
    Long countTodayPlays();

    /** 近 7 天每日播放量统计 */
    @Select("SELECT play_date AS date, SUM(play_count) AS count FROM wb_play_stats " +
            "WHERE play_date >= DATE_SUB(CURDATE(), INTERVAL 7 DAY) " +
            "GROUP BY play_date ORDER BY play_date ASC")
    List<Map<String, Object>> selectWeeklyPlayCount();

    /** 分类播放排行 */
    @Select("SELECT v.category, COALESCE(SUM(ps.play_count), 0) AS count " +
            "FROM wb_video v LEFT JOIN wb_play_stats ps ON v.id = ps.video_id " +
            "WHERE v.deleted = 0 AND v.category IS NOT NULL " +
            "GROUP BY v.category ORDER BY count DESC")
    List<Map<String, Object>> selectCategoryPlayRanking();

    /** 用户活跃度统计 */
    @Select("SELECT DATE(create_time) AS date, COUNT(DISTINCT user_id) AS active_users " +
            "FROM wb_play_stats " +
            "WHERE create_time >= DATE_SUB(NOW(), INTERVAL 7 DAY) " +
            "GROUP BY DATE(create_time) ORDER BY date ASC")
    List<Map<String, Object>> selectWeeklyActiveUsers();
}
