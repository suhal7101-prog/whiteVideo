package com.whitebear.anime.service.impl;

import com.alibaba.fastjson2.JSON;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.whitebear.anime.mapper.*;
import com.whitebear.anime.model.Result;
import com.whitebear.anime.model.dto.*;
import com.whitebear.anime.model.entity.*;
import com.whitebear.anime.security.SecurityUtils;
import com.whitebear.anime.service.CommunityService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.stream.Collectors;

/**
 * 社区服务实现类
 *
 * @author WhiteBear
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class CommunityServiceImpl implements CommunityService {

    private static final Set<String> ALLOWED_POST_TAGS = Set.of("分享", "追番", "推荐", "漫评", "资讯");

    private final PostMapper postMapper;
    private final CommentMapper commentMapper;
    private final LikeMapper likeMapper;
    private final DanmakuMapper danmakuMapper;
    private final UserMapper userMapper;

    /**
     * 获取帖子列表
     */
    @Override
    public Result<Object> getPosts(String sort, int page, int size, String topic, Long authorId) {
        int safePage = Math.max(1, page);
        int safeSize = Math.max(1, Math.min(size, 20));
        String safeSort = sort == null ? "all" : sort.trim().toLowerCase(Locale.ROOT);

        LambdaQueryWrapper<Post> wrapper = new LambdaQueryWrapper<Post>()
                .eq(Post::getStatus, "approved");
        if (authorId != null && authorId > 0) {
            wrapper.eq(Post::getAuthorId, authorId);
        }
        if ("hot".equals(safeSort)) {
            // 热门是全部已审核帖子中的综合热度排行，不设置最低点赞/评论门槛。
            // 点赞代表明确偏好，因此权重最高；评论体现讨论度；浏览量作为基础热度。
            wrapper.last("ORDER BY (COALESCE(likes, 0) * 5 + COALESCE(comments, 0) * 3 + COALESCE(views, 0)) DESC, id DESC");
        } else if ("following".equals(safeSort)) {
            wrapper.eq(Post::getTag, "追番").orderByDesc(Post::getCreateTime);
        } else {
            wrapper.orderByDesc(Post::getCreateTime);
        }
        if (topic != null && !topic.isBlank()) {
            String keyword = topic.trim();
            wrapper.and(query -> query.eq(Post::getTag, keyword)
                    .or().like(Post::getTitle, keyword)
                    .or().like(Post::getContent, keyword));
        }
        if (!"hot".equals(safeSort)) {
            wrapper.orderByDesc(Post::getId);
        }

        Page<Post> postPage = postMapper.selectPage(new Page<>(safePage, safeSize), wrapper);
        List<Post> posts = postPage.getRecords();

        Long currentUserId = SecurityUtils.getCurrentUserId();
        Set<Long> likedPostIds = currentUserId == null
                ? Collections.emptySet()
                : new HashSet<>(likeMapper.selectTargetIdsByUserAndType(currentUserId, "post"));

        // 组装返回数据（关联用户信息）
        List<Map<String, Object>> list = posts.stream().map(post -> {
            User author = userMapper.selectById(post.getAuthorId());
            Map<String, Object> item = new HashMap<>();
            item.put("id", post.getId());
            item.put("title", post.getTitle());
            item.put("content", post.getContent());
            item.put("tag", post.getTag());
            item.put("likes", post.getLikes());
            item.put("comments", commentMapper.countByPostId(post.getId()));
            item.put("views", post.getViews());
            item.put("liked", likedPostIds.contains(post.getId()));
            item.put("images", post.getImages() != null ? JSON.parseArray(post.getImages()) : new ArrayList<>());
            item.put("author", author != null ? author.getUsername() : "未知用户");
            item.put("authorId", post.getAuthorId());
            item.put("authorAvatar", author != null ? author.getAvatar() : "");
            item.put("time", formatTime(post.getCreateTime().toString()));
            return item;
        }).collect(Collectors.toList());

        Map<String, Object> data = new LinkedHashMap<>();
        data.put("list", list);
        data.put("page", safePage);
        data.put("size", safeSize);
        data.put("total", postPage.getTotal());
        data.put("hasMore", safePage * (long) safeSize < postPage.getTotal());
        return Result.ok(data);
    }

    /**
     * 获取帖子详情
     */
    @Override
    public Result<Object> getPostDetail(Long postId) {
        Post post = postMapper.selectById(postId);
        if (post == null || post.getDeleted() == 1) {
            return Result.notFound("帖子不存在");
        }

        // 浏览量 +1
        postMapper.incrementViews(postId);

        // 查询作者信息
        User author = userMapper.selectById(post.getAuthorId());
        Long currentUserId = SecurityUtils.getCurrentUserId();

        // 查询评论列表
        List<Comment> comments = commentMapper.selectByPostId(postId);
        List<Map<String, Object>> commentList = comments.stream().map(c -> {
            User commentUser = userMapper.selectById(c.getUserId());
            Map<String, Object> item = new HashMap<>();
            item.put("id", c.getId());
            item.put("content", c.getContent());
            item.put("images", c.getImages() != null ? JSON.parseArray(c.getImages()) : new ArrayList<>());
            item.put("likes", c.getLikes());
            item.put("liked", currentUserId != null &&
                    likeMapper.countByUserAndTarget(currentUserId, c.getId(), "comment") > 0);
            item.put("parentId", c.getParentId());
            item.put("userId", c.getUserId());
            item.put("isAuthor", Objects.equals(post.getAuthorId(), c.getUserId()));
            item.put("createTime", c.getCreateTime().toString());
            item.put("username", commentUser != null ? commentUser.getUsername() : "匿名");
            item.put("avatar", commentUser != null ? commentUser.getAvatar() : "");
            return item;
        }).collect(Collectors.toList());

        Map<String, Object> detail = new HashMap<>();
        detail.put("id", post.getId());
        detail.put("title", post.getTitle());
        detail.put("content", post.getContent());
        detail.put("tag", post.getTag());
        detail.put("likes", post.getLikes());
        detail.put("comments", commentList.size());
        detail.put("views", (post.getViews() == null ? 0 : post.getViews()) + 1);
        detail.put("shares", post.getShares());
        detail.put("liked", currentUserId != null &&
                likeMapper.countByUserAndTarget(currentUserId, post.getId(), "post") > 0);
        detail.put("images", post.getImages() != null ? JSON.parseArray(post.getImages()) : new ArrayList<>());
        detail.put("author", author != null ? author.getUsername() : "未知用户");
        detail.put("authorId", post.getAuthorId());
        detail.put("authorAvatar", author != null ? author.getAvatar() : "");
        detail.put("time", formatTime(post.getCreateTime().toString()));
        detail.put("commentList", commentList);

        return Result.ok(detail);
    }

    /**
     * 发布帖子
     */
    @Override
    @Transactional
    public Result<Object> createPost(PostDTO dto) {
        Long userId = SecurityUtils.getCurrentUserId();
        if (userId == null) {
            return Result.unauthorized("请先登录");
        }

        String tag = dto.getTag() == null ? "" : dto.getTag().trim();
        if (!ALLOWED_POST_TAGS.contains(tag)) {
            return Result.badRequest("内容标签无效，请选择分享、追番、推荐、漫评或资讯");
        }

        // 构建帖子对象
        Post post = Post.builder()
                .title(dto.getTitle())
                .content(dto.getContent())
                .authorId(userId)
                .tag(tag)
                .images(dto.getImages() != null ? JSON.toJSONString(dto.getImages()) : null)
                .likes(0)
                .comments(0)
                .views(0)
                .shares(0)
                .status("approved")  // 默认审核通过（实际项目中可设为 pending）
                .build();

        postMapper.insert(post);
        log.info("[社区] 用户 ID={} 发布帖子 ID={}", userId, post.getId());
        return Result.ok("发布成功", Map.of("id", post.getId()));
    }

    /**
     * 删除帖子
     */
    @Override
    public Result<Void> deletePost(Long postId) {
        Long userId = SecurityUtils.getCurrentUserId();
        Post post = postMapper.selectById(postId);

        if (post == null) {
            return Result.notFound("帖子不存在");
        }

        // 只有作者本人或管理员可以删除
        if (!userId.equals(post.getAuthorId()) && !SecurityUtils.isAdmin()) {
            return Result.forbidden("无权删除此帖子");
        }

        postMapper.deleteById(postId);
        log.info("[社区] 帖子 ID={} 被删除", postId);
        return Result.success("删除成功");
    }

    /**
     * 发表评论
     */
    @Override
    @Transactional
    public Result<Object> addComment(CommentDTO dto) {
        Long userId = SecurityUtils.getCurrentUserId();
        if (userId == null) {
            return Result.unauthorized("请先登录");
        }

        // 检查帖子是否存在
        Post post = postMapper.selectById(dto.getPostId());
        if (post == null) {
            return Result.notFound("帖子不存在");
        }

        String content = dto.getContent() == null ? "" : dto.getContent().trim();
        List<String> images = dto.getImages() == null
                ? new ArrayList<>()
                : dto.getImages().stream()
                        .filter(Objects::nonNull)
                        .map(String::trim)
                        .filter(value -> !value.isEmpty())
                        .toList();
        if (content.isEmpty() && images.isEmpty()) {
            return Result.badRequest("评论内容和图片不能同时为空");
        }
        if (images.size() > 9) {
            return Result.badRequest("评论图片最多上传9张");
        }

        // 保存评论
        Comment comment = Comment.builder()
                .postId(dto.getPostId())
                .userId(userId)
                .parentId(dto.getParentId())
                .content(content)
                .images(images.isEmpty() ? null : JSON.toJSONString(images))
                .likes(0)
                .build();
        commentMapper.insert(comment);

        // 帖子评论数 +1
        postMapper.incrementComments(dto.getPostId());

        User user = userMapper.selectById(userId);
        Map<String, Object> result = new HashMap<>();
        result.put("id", comment.getId());
        result.put("content", comment.getContent());
        result.put("images", images);
        result.put("username", user != null ? user.getUsername() : "");
        result.put("userId", userId);
        result.put("isAuthor", Objects.equals(post.getAuthorId(), userId));
        result.put("avatar", user != null ? user.getAvatar() : "");

        return Result.ok("评论成功", result);
    }

    /**
     * 点赞/取消点赞（toggle 模式）
     */
    @Override
    @Transactional
    public Result<Object> toggleLike(LikeDTO dto) {
        Long userId = SecurityUtils.getCurrentUserId();
        if (userId == null) {
            return Result.unauthorized("请先登录");
        }

        boolean alreadyLiked = likeMapper.countByUserAndTarget(userId, dto.getTargetId(), dto.getType()) > 0;

        if (alreadyLiked) {
            // 取消点赞
            likeMapper.deleteByUserAndTarget(userId, dto.getTargetId(), dto.getType());

            if ("post".equals(dto.getType())) {
                postMapper.decrementLikes(dto.getTargetId());
            } else if ("comment".equals(dto.getType())) {
                commentMapper.decrementLikes(dto.getTargetId());
            }

            return Result.ok("取消点赞", Map.of("liked", false));
        } else {
            // 点赞
            Like like = Like.builder()
                    .userId(userId)
                    .targetId(dto.getTargetId())
                    .type(dto.getType())
                    .build();
            likeMapper.insert(like);

            if ("post".equals(dto.getType())) {
                postMapper.incrementLikes(dto.getTargetId());
            } else if ("comment".equals(dto.getType())) {
                commentMapper.incrementLikes(dto.getTargetId());
            }

            return Result.ok("点赞成功", Map.of("liked", true));
        }
    }

    /**
     * 分享
     */
    @Override
    public Result<Void> share(Long targetId) {
        Post post = postMapper.selectById(targetId);
        if (post != null) {
            post.setShares((post.getShares() != null ? post.getShares() : 0) + 1);
            postMapper.updateById(post);
        }
        return Result.success("分享成功");
    }

    /**
     * 获取弹幕列表
     */
    @Override
    public Result<Object> getDanmaku(Long animeId, Long episodeId) {
        List<Danmaku> danmakus;
        if (episodeId != null) {
            danmakus = danmakuMapper.selectByAnimeAndEpisode(animeId, episodeId);
        } else {
            danmakus = danmakuMapper.selectByAnimeId(animeId);
        }

        // 转换为前端格式
        List<Map<String, Object>> list = danmakus.stream().map(d -> {
            Map<String, Object> m = new HashMap<>();
            m.put("id", d.getId());
            m.put("animeId", d.getAnimeId());
            m.put("content", d.getContent());
            m.put("timestamp", d.getTimestamp());
            m.put("color", d.getColor());
            m.put("type", d.getType());
            return m;
        }).collect(Collectors.toList());

        return Result.ok(Map.of("list", list));
    }

    /**
     * 发送弹幕
     */
    @Override
    public Result<Object> sendDanmaku(DanmakuDTO dto) {
        Long userId = SecurityUtils.getCurrentUserId();
        if (userId == null) {
            return Result.unauthorized("请先登录");
        }

        Danmaku danmaku = Danmaku.builder()
                .animeId(dto.getAnimeId())
                .episodeId(dto.getEpisodeId())
                .userId(userId)
                .content(dto.getContent())
                .timestamp(dto.getTimestamp())
                .color(dto.getColor() != null ? dto.getColor() : "#FFFFFF")
                .type(dto.getType() != null ? dto.getType() : "scroll")
                .fontSize("normal")
                .build();
        danmakuMapper.insert(danmaku);

        Map<String, Object> result = new HashMap<>();
        result.put("id", danmaku.getId());
        result.put("content", danmaku.getContent());
        result.put("timestamp", danmaku.getTimestamp());
        result.put("color", danmaku.getColor());
        result.put("type", danmaku.getType());

        return Result.ok("弹幕发送成功", result);
    }

    /** 简单时间格式化 */
    private String formatTime(String timeStr) {
        // 简化为直接返回，实际项目可用 Hutool DateUtil
        return timeStr != null ? timeStr.replace("T", " ") : "刚刚";
    }
}
