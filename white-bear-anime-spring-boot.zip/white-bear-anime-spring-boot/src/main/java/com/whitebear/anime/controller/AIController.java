package com.whitebear.anime.controller;

import com.whitebear.anime.model.Result;
import com.whitebear.anime.model.dto.AIAgentDTO;
import com.whitebear.anime.model.dto.AIChatDTO;
import com.whitebear.anime.service.AIService;
import com.whitebear.anime.security.SecurityUtils;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

/**
 * AI 智能控制器
 * 匹配前端 API: /api/ai/*
 * 功能: RAG 知识库问答、DeepSeek 对话、追番助手 Agent
 *
 * @author WhiteBear
 */
@Tag(name = "AI 模块", description = "AI 对话、知识库检索、追番助手、角色查询")
@RestController
@RequestMapping("/api/ai")
@RequiredArgsConstructor
public class AIController {

    private final AIService aiService;

    private static final int REQUESTS_PER_MINUTE = 20;
    private final ConcurrentMap<Long, RateWindow> rateWindows = new ConcurrentHashMap<>();

    @Operation(summary = "AI 对话（RAG + DeepSeek）")
    @PostMapping("/chat")
    public Result<?> chat(@Valid @RequestBody AIChatDTO dto) {
        Result<?> limited = checkRateLimit();
        if (limited != null) return limited;
        return aiService.chat(dto);
    }

    @Operation(summary = "AI 个性化推荐")
    @PostMapping("/recommend")
    public Result<?> recommend(@RequestBody Map<String, Object> preferences) {
        Result<?> limited = checkRateLimit();
        if (limited != null) return limited;
        return aiService.recommend(preferences != null ? preferences : Map.of());
    }

    @Operation(summary = "AI 追番助手 Agent")
    @PostMapping("/agent")
    public Result<?> agentCommand(@Valid @RequestBody AIAgentDTO dto) {
        Result<?> limited = checkRateLimit();
        if (limited != null) return limited;
        return aiService.agentCommand(dto);
    }

    @Operation(summary = "角色信息查询")
    @PostMapping("/character")
    public Result<?> queryCharacter(@RequestBody Map<String, String> body) {
        Result<?> limited = checkRateLimit();
        if (limited != null) return limited;
        return aiService.queryCharacter(body.getOrDefault("characterName", ""));
    }

    @Operation(summary = "RAG 知识库检索")
    @GetMapping("/search")
    public Result<?> searchKnowledge(@RequestParam String query) {
        Result<?> limited = checkRateLimit();
        if (limited != null) return limited;
        return aiService.searchKnowledge(query);
    }

    private Result<?> checkRateLimit() {
        Long userId = SecurityUtils.getCurrentUserId();
        if (userId == null) return Result.unauthorized("请先登录");

        long now = System.currentTimeMillis();
        RateWindow window = rateWindows.compute(userId, (id, current) -> {
            if (current == null || now - current.startedAt >= 60_000) {
                return new RateWindow(now, 1);
            }
            return new RateWindow(current.startedAt, current.count + 1);
        });
        return window.count > REQUESTS_PER_MINUTE
                ? Result.error(429, "请求过于频繁，请稍后再试")
                : null;
    }

    private record RateWindow(long startedAt, int count) {}
}
