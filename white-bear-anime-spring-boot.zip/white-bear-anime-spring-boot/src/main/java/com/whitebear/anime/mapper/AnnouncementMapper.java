package com.whitebear.anime.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.whitebear.anime.model.entity.Announcement;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;
import java.util.Map;

/**
 * 公告 Mapper
 *
 * @author WhiteBear
 */
@Mapper
public interface AnnouncementMapper extends BaseMapper<Announcement> {

    /** 查询公告列表（置顶优先，时间倒序） */
    @Select("SELECT * FROM wb_announcement WHERE deleted = 0 ORDER BY pinned DESC, publish_time DESC, create_time DESC")
    List<Announcement> selectAllOrdered();

    @Select("SELECT a.id, a.title, a.content, a.pinned, a.status, a.publisher_id AS publisherId, " +
            "a.publish_time AS publishTime, a.create_time AS createTime, a.update_time AS updateTime, " +
            "CASE WHEN ar.id IS NULL THEN 0 ELSE 1 END AS isRead, ar.read_time AS readTime " +
            "FROM wb_announcement a LEFT JOIN wb_announcement_read ar " +
            "ON ar.announcement_id = a.id AND ar.user_id = #{userId} " +
            "WHERE a.deleted = 0 AND a.status = 'published' " +
            "ORDER BY a.pinned DESC, a.publish_time DESC, a.create_time DESC")
    List<Map<String, Object>> selectPublishedForUser(@Param("userId") Long userId);

    @Select("SELECT a.id, a.title, a.content, a.pinned, a.status, a.publisher_id AS publisherId, " +
            "a.publish_time AS publishTime, a.create_time AS createTime, a.update_time AS updateTime, " +
            "(SELECT COUNT(*) FROM wb_announcement_read ar WHERE ar.announcement_id = a.id) AS readCount " +
            "FROM wb_announcement a WHERE a.deleted = 0 " +
            "ORDER BY a.pinned DESC, a.publish_time DESC, a.create_time DESC")
    List<Map<String, Object>> selectAdminList();
}
