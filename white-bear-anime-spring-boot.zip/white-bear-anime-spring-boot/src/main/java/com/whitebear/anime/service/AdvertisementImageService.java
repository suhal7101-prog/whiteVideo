package com.whitebear.anime.service;

import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.util.UriUtils;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;

@Service
public class AdvertisementImageService {

    private static final long MAX_IMAGE_SIZE = 10L * 1024 * 1024;
    private static final Set<String> ALLOWED_EXTENSIONS = Set.of(".png", ".jpg", ".jpeg", ".webp", ".gif");

    private final Path storageRoot;

    public AdvertisementImageService(
            @Value("${white-bear.advertisement.storage-dir:../ad}") String storageDir) {
        this.storageRoot = Paths.get(storageDir).toAbsolutePath().normalize();
    }

    @PostConstruct
    void initializeStorage() throws IOException {
        Files.createDirectories(storageRoot);
    }

    public List<AdvertisementImageInfo> listImages() throws IOException {
        try (var paths = Files.list(storageRoot)) {
            return paths.filter(Files::isRegularFile)
                    .filter(path -> isAllowedExtension(path.getFileName().toString()))
                    .sorted(Comparator.comparingLong(this::lastModified).reversed())
                    .map(this::toInfo)
                    .toList();
        }
    }

    public AdvertisementImageInfo upload(MultipartFile file) throws IOException {
        validate(file);
        String extension = extensionOf(file.getOriginalFilename());
        String fileName = "ad-" + UUID.randomUUID().toString().replace("-", "") + extension;
        Path target = storageRoot.resolve(fileName).normalize();
        try (var input = file.getInputStream()) {
            Files.copy(input, target, StandardCopyOption.REPLACE_EXISTING);
        }
        return toInfo(target);
    }

    public Resource getResource(String fileName) {
        if (fileName == null || fileName.isBlank()) throw new IllegalArgumentException("广告图片不存在");
        Path candidate = storageRoot.resolve(fileName).normalize();
        if (!candidate.getParent().equals(storageRoot) || !Files.isRegularFile(candidate)) {
            throw new IllegalArgumentException("广告图片不存在");
        }
        return new FileSystemResource(candidate);
    }

    public String contentType(String fileName) {
        try {
            String detected = Files.probeContentType(storageRoot.resolve(fileName));
            return detected == null ? "application/octet-stream" : detected;
        } catch (IOException ignored) {
            return "application/octet-stream";
        }
    }

    private void validate(MultipartFile file) {
        if (file == null || file.isEmpty()) throw new IllegalArgumentException("请选择广告图片");
        if (file.getSize() > MAX_IMAGE_SIZE) throw new IllegalArgumentException("广告图片不能超过 10MB");
        if (file.getContentType() == null || !file.getContentType().startsWith("image/")) {
            throw new IllegalArgumentException("仅支持图片文件");
        }
        if (!isAllowedExtension(file.getOriginalFilename())) {
            throw new IllegalArgumentException("仅支持 PNG、JPG、WEBP 或 GIF 图片");
        }
    }

    private AdvertisementImageInfo toInfo(Path path) {
        String name = path.getFileName().toString();
        try {
            return new AdvertisementImageInfo(name, publicUrl(name), Files.size(path), Files.getLastModifiedTime(path).toMillis());
        } catch (IOException exception) {
            throw new IllegalStateException("读取广告图片失败: " + name, exception);
        }
    }

    private String publicUrl(String fileName) {
        return "/api/advertisement-images/" + UriUtils.encodePathSegment(fileName, StandardCharsets.UTF_8);
    }

    private boolean isAllowedExtension(String fileName) {
        return ALLOWED_EXTENSIONS.contains(extensionOf(fileName));
    }

    private String extensionOf(String fileName) {
        if (fileName == null) return "";
        int dot = fileName.lastIndexOf('.');
        return dot < 0 ? "" : fileName.substring(dot).toLowerCase(Locale.ROOT);
    }

    private long lastModified(Path path) {
        try {
            return Files.getLastModifiedTime(path).toMillis();
        } catch (IOException ignored) {
            return 0L;
        }
    }

    public record AdvertisementImageInfo(String name, String url, long size, long lastModified) {}
}
