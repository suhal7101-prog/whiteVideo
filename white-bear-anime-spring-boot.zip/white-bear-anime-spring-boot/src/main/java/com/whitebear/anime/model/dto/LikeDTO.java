package com.whitebear.anime.model.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

/**
 * 点赞请求 DTO
 *
 * @author WhiteBear
 */
@Data
@Schema(description = "点赞请求")
public class LikeDTO {

    @NotNull(message = "目标ID不能为空")
    @Schema(description = "目标 ID（帖子ID或评论ID）")
    private Long targetId;

    @NotBlank(message = "类型不能为空")
    @Schema(description = "目标类型: post / comment", example = "post")
    private String type;
}
