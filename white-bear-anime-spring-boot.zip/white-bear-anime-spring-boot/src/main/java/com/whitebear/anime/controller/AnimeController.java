package com.whitebear.anime.controller;

import com.whitebear.anime.model.Result;
import com.whitebear.anime.service.VideoService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

/**
 * 动漫/视频控制器
 * 匹配前端 API: /api/anime/* 和 /api/bilibili/*
 *
 * @author WhiteBear
 */
@Tag(name = "动漫模块", description = "首页数据、视频详情、搜索、排行榜、分类")
@RestController
@RequiredArgsConstructor
public class AnimeController {

    private final VideoService videoService;

    // ==================== /api/anime/* ====================

    @Operation(summary = "获取首页热门推荐")
    @GetMapping({"/api/anime/hot", "/api/catalog/hot"})
    public Result<?> getHotVideos(
            @RequestParam(defaultValue = "20") int count,
            @RequestParam(defaultValue = "1") int page) {
        return videoService.getHotVideos(count, page);
    }

    @Operation(summary = "获取视频详情")
    @GetMapping({"/api/anime/{id}", "/api/catalog/{id}"})
    public Result<?> getVideoDetail(@PathVariable Long id) {
        return videoService.getVideoDetail(id);
    }

    @Operation(summary = "获取动漫剧集列表")
    @GetMapping({"/api/anime/{id}/episodes", "/api/catalog/{id}/episodes"})
    public Result<?> getEpisodes(@PathVariable Long id) {
        return videoService.getEpisodes(id);
    }

    @Operation(summary = "搜索动漫")
    @GetMapping({"/api/anime/search", "/api/catalog/search"})
    public Result<?> searchVideos(
            @RequestParam String keyword,
            @RequestParam(defaultValue = "1") int page) {
        return videoService.searchVideos(keyword, page);
    }

    @Operation(summary = "获取排行榜")
    @GetMapping({"/api/anime/ranking", "/api/catalog/ranking"})
    public Result<?> getRankings(@RequestParam(defaultValue = "hot") String type) {
        return videoService.getRankings(type);
    }

    @Operation(summary = "获取分类列表")
    @GetMapping({"/api/anime/categories", "/api/catalog/categories"})
    public Result<?> getCategories() {
        return videoService.getCategories();
    }

    @Operation(summary = "根据分类获取视频")
    @GetMapping({"/api/anime/category/{category}", "/api/catalog/category/{category}"})
    public Result<?> getVideosByCategory(
            @PathVariable String category,
            @RequestParam(defaultValue = "1") int page) {
        return videoService.getVideosByCategory(category, page);
    }

    @Operation(summary = "记录播放")
    @PostMapping({"/api/anime/play", "/api/catalog/play"})
    public Result<?> recordPlay(
            @RequestParam Long videoId,
            @RequestParam(required = false) Long episodeId) {
        return videoService.recordPlay(videoId, episodeId);
    }

    @Operation(summary = "按标题记录 Python 视频播放")
    @PostMapping("/api/catalog/play-by-title")
    public Result<?> recordPlayByTitle(@RequestParam String title) {
        return videoService.recordPlayByTitle(title);
    }

    @Operation(summary = "按资源站 ID 记录 Python 视频播放")
    @PostMapping("/api/catalog/play-by-source")
    public Result<?> recordPlayBySource(@RequestParam Long sourceVodId) {
        return videoService.recordPlayBySourceVodId(sourceVodId);
    }

    @Operation(summary = "数据库视频发现页")
    @GetMapping("/api/catalog/discover")
    public Result<?> discoverVideos(
            @RequestParam(defaultValue = "1") int page,
            @RequestParam(defaultValue = "20") int count,
            @RequestParam(required = false) String keyword,
            @RequestParam(required = false) String tag,
            @RequestParam(defaultValue = "hot") String sort) {
        return videoService.discoverVideos(page, count, keyword, tag, sort);
    }

    @Operation(summary = "数据库视频相关推荐")
    @GetMapping("/api/catalog/{id}/related")
    public Result<?> getRelatedVideos(
            @PathVariable Long id,
            @RequestParam(defaultValue = "6") int count) {
        return videoService.getRelatedVideos(id, count);
    }

    // ==================== /api/bilibili/* (兼容前端 Bilibili 代理接口) ====================

    @Operation(summary = "Bilibili视频信息（兼容）")
    @GetMapping("/api/bilibili/video/{bvid}")
    public Result<?> getBilibiliVideo(@PathVariable String bvid) {
        // Bilibili 代理接口 —— 转发到内部视频详情
        try {
            Long id = Long.valueOf(bvid.replace("BV", ""));
            return videoService.getVideoDetail(id);
        } catch (NumberFormatException e) {
            return videoService.searchVideos(bvid, 1);
        }
    }

    @Operation(summary = "Bilibili弹幕（兼容）")
    @GetMapping("/api/bilibili/danmaku/{bvid}")
    public Result<?> getBilibiliDanmaku(@PathVariable String bvid) {
        return Result.ok("弹幕数据已迁移到 /api/community/danmaku");
    }

    @Operation(summary = "Bilibili搜索（兼容）")
    @GetMapping("/api/bilibili/search")
    public Result<?> bilibiliSearch(
            @RequestParam String keyword,
            @RequestParam(defaultValue = "1") int page) {
        return videoService.searchVideos(keyword, page);
    }

    @Operation(summary = "Bilibili排行榜（兼容）")
    @GetMapping("/api/bilibili/ranking")
    public Result<?> bilibiliRanking(@RequestParam(defaultValue = "0") String rid,
                                     @RequestParam(defaultValue = "3") int day) {
        return videoService.getRankings("hot");
    }

    @Operation(summary = "Bilibili用户信息（兼容）")
    @GetMapping("/api/bilibili/user/{uid}")
    public Result<?> bilibiliUser(@PathVariable String uid) {
        return Result.ok("用户信息请通过 /api/user/profile 获取");
    }
}
