package com.whitebear.anime.model.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Data;

/** 管理员审核用户投稿视频请求。 */
@Data
@Schema(description = "用户投稿视频审核请求")
public class VideoAuditDTO {

    @NotBlank(message = "审核结果不能为空")
    @Pattern(regexp = "approved|rejected", message = "审核结果只能是 approved 或 rejected")
    @Schema(description = "审核结果: approved / rejected")
    private String status;

    @Size(max = 500, message = "审核说明不能超过500个字符")
    @Schema(description = "拒绝原因；拒绝投稿时必填")
    private String reason;
}
