package com.whitebear.anime.service.impl;

import com.alibaba.fastjson2.JSON;
import com.alibaba.fastjson2.JSONObject;
import com.whitebear.anime.mapper.VideoMapper;
import com.whitebear.anime.model.Result;
import com.whitebear.anime.model.dto.AIAgentDTO;
import com.whitebear.anime.model.dto.AIChatDTO;
import com.whitebear.anime.model.entity.Video;
import com.whitebear.anime.service.AIService;
import com.whitebear.anime.service.UserService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import okhttp3.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.math.BigDecimal;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

/**
 * AI 智能服务实现类
 * 使用 DeepSeek API + RAG 检索增强生成 + Agent 追番助手
 *
 * @author WhiteBear
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class AIServiceImpl implements AIService {

    private final VideoMapper videoMapper;
    private final UserService userService;

    private static final Pattern BOOK_TITLE_PATTERN = Pattern.compile("[《「『](.+?)[》」』]");

    @Value("${deepseek.api-key:sk-your-deepseek-api-key}")
    private String deepseekApiKey;

    @Value("${deepseek.base-url:https://api.deepseek.com}")
    private String deepseekBaseUrl;

    @Value("${deepseek.chat-model:deepseek-chat}")
    private String chatModel;

    @Value("${white-bear.python-api-url:http://localhost:8082}")
    private String pythonApiUrl;

    private static final OkHttpClient HTTP_CLIENT = new OkHttpClient.Builder()
            .connectTimeout(60, TimeUnit.SECONDS)
            .readTimeout(120, TimeUnit.SECONDS)
            .writeTimeout(60, TimeUnit.SECONDS)
            .build();

    private static final OkHttpClient VECTOR_HTTP_CLIENT = new OkHttpClient.Builder()
            .connectTimeout(2, TimeUnit.SECONDS)
            .readTimeout(5, TimeUnit.SECONDS)
            .build();

    /**
     * AI 对话 —— 基于 RAG 检索增强 + DeepSeek 回答
     * 1. 从本地知识库（视频描述、标签）中检索相关动漫信息
     * 2. 将检索结果作为上下文传给 DeepSeek
     * 3. DeepSeek 结合上下文生成回答
     */
    @Override
    public Result<Object> chat(AIChatDTO dto) {
        // 1. RAG 检索：从 Python Chroma 动漫知识库搜索相关信息
        String knowledgeContext = retrieveKnowledge(dto.getQuestion());

        // 2. 构建对话消息列表
        List<Map<String, String>> messages = new ArrayList<>();

        // 系统提示词（定义 AI 角色）
        messages.add(Map.of("role", "system", "content",
                "你是白熊动漫平台的动漫知识助手。请优先且严格依据 Chroma 知识库信息回答，" +
                "不要编造知识库中不存在的剧情、角色或制作信息；资料不足时请明确说明。" +
                "回答使用简洁自然的中文。推荐作品时说明推荐理由，并保留知识库提供的播放页。" +
                (knowledgeContext.isEmpty() ? "" : "\n\n相关知识库信息:\n" + knowledgeContext)));

        // 历史对话
        if (dto.getHistory() != null) {
            for (Map<String, String> h : dto.getHistory()) {
                messages.add(Map.of("role", h.get("role"), "content", h.get("content")));
            }
        }

        // 用户当前问题
        messages.add(Map.of("role", "user", "content", dto.getQuestion()));

        // 3. 调用 DeepSeek API
        String answer = callDeepSeek(messages);

        Map<String, Object> result = new HashMap<>();
        result.put("answer", answer);
        result.put("question", dto.getQuestion());
        result.put("knowledgeUsed", !knowledgeContext.isEmpty());

        return Result.ok("回答完成", result);
    }

    /**
     * AI 个性化推荐
     * 根据用户偏好推荐动漫
     */
    @Override
    public Result<Object> recommend(Map<String, Object> preferences) {
        String favoriteCategory = (String) preferences.getOrDefault("category", "热血");

        List<Map<String, Object>> vectorRecommendations = searchVectorKnowledge(favoriteCategory, 10);
        if (!vectorRecommendations.isEmpty()) {
            List<Map<String, Object>> playable = vectorRecommendations.stream().map(item -> {
                Map<String, Object> recommendation = new LinkedHashMap<>(item);
                recommendation.put("id", item.get("vod_id"));
                recommendation.put("sourceVodId", item.get("vod_id"));
                return recommendation;
            }).collect(Collectors.toList());
            return Result.ok(Map.of("recommendations", playable, "preference", favoriteCategory));
        }

        // 从数据库获取推荐视频
        List<Video> recommendVideos = videoMapper.selectByCategory(favoriteCategory);

        // 如果该分类视频不够，补充热门视频
        if (recommendVideos.size() < 5) {
            recommendVideos = videoMapper.selectHotVideos(10);
        }

        List<Map<String, Object>> list = recommendVideos.stream()
                .filter(v -> v.getSourceVodId() != null)
                .limit(10)
                .map(v -> {
                    Map<String, Object> m = new HashMap<>();
                    m.put("id", v.getId());
                    m.put("sourceVodId", v.getSourceVodId());
                    m.put("playUrl", "/play/" + v.getSourceVodId());
                    m.put("title", v.getTitle());
                    m.put("cover", v.getCover());
                    m.put("category", v.getCategory());
                    m.put("rating", v.getRating());
                    m.put("description", v.getDescription());
                    return m;
                }).collect(Collectors.toList());

        return Result.ok(Map.of("recommendations", list, "preference", favoriteCategory));
    }

    /**
     * AI 追番助手 Agent（智能代理）
     * 工具定义 + 意图识别 + 工具执行 + 结果汇总
     *
     * 支持的指令类型:
     * - "帮我找到类似XXX的动漫" → 相似推荐
     * - "帮我追番XXX" → 添加到追番列表
     * - "这周有什么新番" → 新番查询
     * - "评分最高的动漫有哪些" → 排行榜
     */
    @Override
    public Result<Object> agentCommand(AIAgentDTO dto) {
        String command = dto.getCommand().trim();
        String intent = recognizeIntent(command);
        Result<Map<String, Object>> execution = executeTool(intent, command);
        if (execution.getCode() != 200 || execution.getData() == null) {
            return Result.error(execution.getCode(), execution.getMessage());
        }

        Map<String, Object> agentResult = execution.getData();
        String summary = generateSummary(intent, agentResult);

        Map<String, Object> result = new LinkedHashMap<>();
        result.put("intent", intent);
        result.put("action", intent);
        result.put("success", true);
        result.put("command", command);
        result.put("summary", summary);
        result.put("message", agentResult.getOrDefault("message", summary));
        result.put("videos", agentResult.getOrDefault("videos", List.of()));
        result.put("result", agentResult);

        return Result.ok("指令执行完成", result);
    }

    /**
     * 角色信息查询
     */
    @Override
    public Result<Object> queryCharacter(String characterName) {
        // 通过 AI 查询角色信息
        List<Map<String, String>> messages = new ArrayList<>();
        messages.add(Map.of("role", "system", "content",
                "你是动漫角色专家，请详细介绍以下动漫角色，包括出自哪部动漫、角色特点、声优等信息。"));
        messages.add(Map.of("role", "user", "content", "请介绍动漫角色：" + characterName));

        String characterInfo = callDeepSeek(messages);

        Map<String, Object> result = new HashMap<>();
        result.put("characterName", characterName);
        result.put("info", characterInfo);

        return Result.ok(result);
    }

    /**
     * RAG 知识库检索
     */
    @Override
    public Result<Object> searchKnowledge(String query) {
        String knowledge = retrieveKnowledge(query);

        List<Map<String, Object>> videoList = searchVectorKnowledge(query, 5);
        if (videoList.isEmpty()) {
            videoList = videoMapper.searchByKeyword(query).stream().limit(5).map(v -> {
                Map<String, Object> item = new HashMap<>();
                item.put("id", v.getId());
                item.put("sourceVodId", v.getSourceVodId());
                item.put("title", v.getTitle());
                item.put("category", v.getCategory());
                item.put("description", v.getDescription());
                return item;
            }).collect(Collectors.toList());
        }

        Map<String, Object> result = new HashMap<>();
        result.put("query", query);
        result.put("knowledge", knowledge);
        result.put("videos", videoList);

        return Result.ok(result);
    }

    // ==================== 私有辅助方法 ====================

    /**
     * RAG 检索：优先使用 Python 本地向量库，失败时回退 MySQL 标题检索。
     */
    private String retrieveKnowledge(String query) {
        List<Map<String, Object>> vectorMatches = searchVectorKnowledge(query, 5);
        if (!vectorMatches.isEmpty()) {
            StringBuilder context = new StringBuilder();
            for (int i = 0; i < vectorMatches.size(); i++) {
                Map<String, Object> item = vectorMatches.get(i);
                context.append(String.format("%d. 《%s》[%s] 评分:%s - %s（播放页: %s）%n",
                        i + 1,
                        value(item, "title"),
                        value(item, "category"),
                        value(item, "rating"),
                        value(item, "description"),
                        value(item, "playUrl")));
            }
            return context.toString();
        }

        List<Video> videos = videoMapper.searchByKeyword(query);
        if (videos.isEmpty()) {
            return "";
        }

        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < Math.min(videos.size(), 5); i++) {
            Video v = videos.get(i);
            sb.append(String.format("%d. 《%s》[%s] 评分:%.1f - %s\n",
                    i + 1, v.getTitle(), v.getCategory(),
                    v.getRating() != null ? v.getRating() : 0,
                    v.getDescription() != null ? v.getDescription() : ""));
        }
        return sb.toString();
    }

    private List<Map<String, Object>> searchVectorKnowledge(String query, int limit) {
        if (query == null || query.isBlank()) {
            return List.of();
        }
        String searchQuery = normalizeKnowledgeQuery(query);
        String endpoint = pythonApiUrl.replaceAll("/+$", "") + "/api/vector/search?q="
                + URLEncoder.encode(searchQuery, StandardCharsets.UTF_8) + "&limit=" + limit;
        Request request = new Request.Builder().url(endpoint).get().build();
        try (Response response = VECTOR_HTTP_CLIENT.newCall(request).execute()) {
            if (!response.isSuccessful() || response.body() == null) {
                log.warn("[AI] 向量检索返回 HTTP {}，回退数据库检索", response.code());
                return List.of();
            }
            JSONObject root = JSON.parseObject(response.body().string());
            if (root == null || root.getIntValue("code") != 200
                    || root.getJSONObject("data") == null
                    || root.getJSONObject("data").getJSONArray("list") == null) {
                return List.of();
            }
            List<Map<String, Object>> matches = new ArrayList<>();
            for (Object value : root.getJSONObject("data").getJSONArray("list")) {
                if (value instanceof JSONObject item) {
                    matches.add(new LinkedHashMap<>(item));
                }
            }
            return matches;
        } catch (IOException | RuntimeException exception) {
            log.warn("[AI] 向量检索不可用，回退数据库检索: {}", exception.getMessage());
            return List.of();
        }
    }

    private String value(Map<String, Object> item, String key) {
        Object value = item.get(key);
        return value == null ? "" : String.valueOf(value);
    }

    private String normalizeKnowledgeQuery(String query) {
        String normalized = query;
        String[] fillers = {
                "请根据知识库", "请简要回答", "请简单回答", "请介绍一下", "介绍一下",
                "讲了什么故事", "讲的是什么", "讲什么", "有哪些", "有什么",
                "推荐几部", "推荐一些", "值得看", "请问"
        };
        for (String filler : fillers) {
            normalized = normalized.replace(filler, "");
        }
        normalized = normalized.replaceAll("[\\p{Punct}，。！？、；：‘’“”（）\\s]+", "").trim();
        return normalized.length() >= 2 ? normalized : query.trim();
    }

    /**
     * 调用 DeepSeek API
     */
    private String callDeepSeek(List<Map<String, String>> messages) {
        if (deepseekApiKey == null || deepseekApiKey.isBlank()
                || deepseekApiKey.contains("placeholder") || deepseekApiKey.contains("your-deepseek")) {
            log.error("[AI] 未配置 DEEPSEEK_API_KEY");
            return "AI 模型尚未配置，请联系管理员设置 DeepSeek API Key。";
        }
        try {
            JSONObject body = new JSONObject();
            body.put("model", chatModel);
            body.put("messages", messages);
            body.put("temperature", 0.7);
            body.put("max_tokens", 2048);
            body.put("stream", false);

            Request request = new Request.Builder()
                    .url(deepseekBaseUrl.replaceAll("/+$", "") + "/chat/completions")
                    .addHeader("Authorization", "Bearer " + deepseekApiKey)
                    .addHeader("Content-Type", "application/json")
                    .post(RequestBody.create(body.toJSONString(), MediaType.parse("application/json")))
                    .build();

            try (Response response = HTTP_CLIENT.newCall(request).execute()) {
                if (response.isSuccessful() && response.body() != null) {
                    String responseBody = response.body().string();
                    JSONObject jsonResponse = JSON.parseObject(responseBody);
                    if (jsonResponse == null || jsonResponse.getJSONArray("choices") == null
                            || jsonResponse.getJSONArray("choices").isEmpty()) {
                        log.error("[AI] DeepSeek 返回内容缺少 choices");
                        return "AI 服务返回内容不完整，请稍后重试。";
                    }
                    return jsonResponse.getJSONArray("choices")
                            .getJSONObject(0)
                            .getJSONObject("message")
                            .getString("content");
                } else {
                    log.error("[AI] DeepSeek API 调用失败: {}", response.code());
                    return "抱歉，AI 服务暂时不可用，请稍后再试。";
                }
            }
        } catch (IOException | RuntimeException e) {
            log.error("[AI] DeepSeek API 调用异常: {}", e.getMessage());
            return "抱歉，AI 服务出现异常，请检查网络连接后重试。";
        }
    }

    /** 对数据库写操作使用确定性意图识别，避免模型误判后修改用户数据。 */
    private String recognizeIntent(String command) {
        if (containsAny(command, "取消追番", "取消收藏", "移除追番", "不追了", "删除追番")) {
            return "unfollow_anime";
        }
        if (containsAny(command, "追番列表", "我的追番", "正在追", "已追", "收藏列表")) {
            return "list_following";
        }
        if (containsAny(command, "打开", "播放", "观看", "看一下", "我要看", "我想看")) {
            return "open_anime";
        }
        if (command.contains("类似") || command.contains("推荐") || command.contains("相同")) {
            return "similar_recommend";
        }
        if (containsAny(command, "追番", "帮我追", "追一下", "加入追番", "收藏")) {
            return "follow_anime";
        }
        if (command.contains("新番") || command.contains("最近") || command.contains("更新")) {
            return "new_anime";
        }
        if (command.contains("评分") || command.contains("排行") || command.contains("最")) {
            return "ranking";
        }
        return "general_query";
    }

    private boolean containsAny(String text, String... keywords) {
        return Arrays.stream(keywords).anyMatch(text::contains);
    }

    /** 执行 Agent 工具；业务失败直接返回失败状态，不伪装成成功结果。 */
    private Result<Map<String, Object>> executeTool(String intent, String command) {
        Map<String, Object> result = new LinkedHashMap<>();

        switch (intent) {
            case "open_anime": {
                Video video = resolveVideo(command, true);
                if (video == null || video.getSourceVodId() == null) {
                    return Result.notFound("没有找到可播放的动漫，请使用《动漫名》重新输入");
                }
                result.put("type", "打开动漫");
                result.put("message", "正在打开《" + video.getTitle() + "》");
                result.put("videos", List.of(toVideoCard(video)));
                break;
            }

            case "similar_recommend":
                String keyword = extractKeyword(command);
                List<Map<String, Object>> vectorSimilar = searchVectorKnowledge(keyword, 5);
                result.put("type", "相似推荐");
                result.put("message", vectorSimilar.isEmpty() ? "没有找到匹配的推荐" : "已为你找到相似动漫");
                if (!vectorSimilar.isEmpty()) {
                    result.put("videos", vectorSimilar.stream().map(this::toVectorCard).collect(Collectors.toList()));
                } else {
                    List<Video> similar = videoMapper.searchByKeyword(keyword);
                    result.put("videos", similar.stream().limit(5).map(this::toVideoCard).collect(Collectors.toList()));
                }
                break;

            case "follow_anime": {
                Video video = resolveVideo(command, true);
                if (video == null) {
                    return Result.notFound("没有找到要追的动漫，请使用《动漫名》重新输入");
                }
                Result<Void> favoriteResult = userService.addFavorite(video.getId());
                if (favoriteResult.getCode() != 200) {
                    return Result.error(favoriteResult.getCode(), favoriteResult.getMessage());
                }
                result.put("type", "追番");
                result.put("message", "已将《" + video.getTitle() + "》加入追番列表");
                result.put("videos", List.of(toVideoCard(video)));
                break;
            }

            case "unfollow_anime": {
                Video video = resolveVideo(command, false);
                if (video == null) {
                    return Result.notFound("追番列表中没有找到这部动漫");
                }
                Result<Void> favoriteResult = userService.removeFavorite(video.getId());
                if (favoriteResult.getCode() != 200) {
                    return Result.error(favoriteResult.getCode(), favoriteResult.getMessage());
                }
                result.put("type", "取消追番");
                result.put("message", "已从追番列表移除《" + video.getTitle() + "》");
                result.put("videos", List.of(toVideoCard(video)));
                break;
            }

            case "list_following": {
                Result<Object> favoritesResult = userService.getFavorites();
                if (favoritesResult.getCode() != 200) {
                    return Result.error(favoritesResult.getCode(), favoritesResult.getMessage());
                }
                List<Map<String, Object>> favorites = favoriteVideos(favoritesResult.getData());
                result.put("type", "我的追番");
                result.put("message", favorites.isEmpty()
                        ? "你的追番列表还是空的"
                        : "你正在追 " + favorites.size() + " 部动漫");
                result.put("videos", favorites);
                break;
            }

            case "new_anime":
                List<Video> newVideos = videoMapper.selectList(
                        new com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper<Video>()
                                .orderByDesc(Video::getCreateTime)
                                .last("LIMIT 10")
                );
                result.put("type", "最新动漫");
                result.put("message", "已查询最新动漫");
                result.put("videos", newVideos.stream().map(this::toVideoCard).collect(Collectors.toList()));
                break;

            case "ranking":
                List<Video> topVideos = videoMapper.selectTopByPlays(10);
                result.put("type", "热门排行");
                result.put("message", "已查询热门排行榜");
                result.put("videos", topVideos.stream().map(this::toVideoCard).collect(Collectors.toList()));
                break;

            default:
                result.put("type", "通用查询");
                List<Map<String, Object>> matches = searchVectorKnowledge(command, 5).stream()
                        .map(this::toVectorCard)
                        .collect(Collectors.toList());
                result.put("message", matches.isEmpty() ? "没有理解这条指令，请换一种方式描述" : "已找到相关动漫");
                result.put("videos", matches);
        }

        return Result.ok(result);
    }

    private Video resolveVideo(String command, boolean createWhenMissing) {
        String title = extractAnimeTitle(command);
        if (title.isBlank()) {
            title = extractKeyword(command);
        }
        if (title.isBlank()) return null;

        Video databaseVideo = videoMapper.findByTitle(title);
        if (databaseVideo != null) return databaseVideo;

        List<Video> keywordMatches = videoMapper.searchByKeyword(title);
        if (!keywordMatches.isEmpty()) return keywordMatches.get(0);

        List<Map<String, Object>> matches = searchVectorKnowledge(title, 8);
        if (matches.isEmpty()) return null;
        String searchTitle = normalizeTitle(title);
        Optional<Map<String, Object>> exactMatch = matches.stream()
                .filter(item -> normalizeTitle(value(item, "title")).equals(searchTitle))
                .findFirst();
        Map<String, Object> match = exactMatch.orElse(matches.get(0));
        if (exactMatch.isEmpty() && doubleValue(match.get("score")) < 0.45) return null;
        Long sourceVodId = longValue(match.get("vod_id"));
        if (sourceVodId == null) return null;

        databaseVideo = videoMapper.findBySourceVodId(sourceVodId);
        if (databaseVideo != null || !createWhenMissing) return databaseVideo;
        return createVideoFromVector(match);
    }

    private Video createVideoFromVector(Map<String, Object> item) {
        Long sourceVodId = longValue(item.get("vod_id"));
        String title = value(item, "title").trim();
        if (sourceVodId == null || title.isBlank()) return null;

        Video existing = videoMapper.findBySourceVodId(sourceVodId);
        if (existing != null) return existing;

        Video video = Video.builder()
                .sourceVodId(sourceVodId)
                .title(title)
                .cover(value(item, "cover"))
                .category(value(item, "category"))
                .description(value(item, "description"))
                .status(defaultIfBlank(value(item, "status"), "连载中"))
                .rating(decimalValue(item.get("rating")))
                .views(0L)
                .likes(0L)
                .episodes(0)
                .tags(tagsValue(item.get("tags")))
                .year(integerValue(item.get("year")))
                .region(value(item, "category").contains("中国") ? "中国" : null)
                .deleted(0)
                .build();
        videoMapper.insert(video);
        return video;
    }

    private List<Map<String, Object>> favoriteVideos(Object data) {
        if (!(data instanceof Map<?, ?> map) || !(map.get("list") instanceof List<?> list)) {
            return List.of();
        }
        return list.stream()
                .filter(Video.class::isInstance)
                .map(Video.class::cast)
                .map(this::toVideoCard)
                .collect(Collectors.toList());
    }

    private Map<String, Object> toVideoCard(Video video) {
        Map<String, Object> card = new LinkedHashMap<>();
        card.put("id", video.getId());
        card.put("sourceVodId", video.getSourceVodId());
        card.put("title", video.getTitle());
        card.put("cover", video.getCover());
        card.put("category", video.getCategory());
        card.put("description", video.getDescription());
        card.put("status", video.getStatus());
        card.put("rating", video.getRating());
        card.put("views", video.getViews());
        card.put("year", video.getYear());
        card.put("playUrl", video.getSourceVodId() != null
                ? "/play/" + video.getSourceVodId()
                : "/play/" + video.getId() + "?source=db");
        return card;
    }

    private Map<String, Object> toVectorCard(Map<String, Object> item) {
        Map<String, Object> card = new LinkedHashMap<>(item);
        Long sourceVodId = longValue(item.get("vod_id"));
        card.put("id", sourceVodId);
        card.put("sourceVodId", sourceVodId);
        if (sourceVodId != null) card.put("playUrl", "/play/" + sourceVodId);
        return card;
    }

    private String extractAnimeTitle(String command) {
        Matcher matcher = BOOK_TITLE_PATTERN.matcher(command);
        return matcher.find() ? matcher.group(1).trim() : "";
    }

    private String normalizeTitle(String title) {
        return title == null ? "" : title.replaceAll("[\\s·・:：]", "").toLowerCase(Locale.ROOT);
    }

    private Long longValue(Object value) {
        try {
            long parsed = Long.parseLong(String.valueOf(value));
            return parsed > 0 ? parsed : null;
        } catch (NumberFormatException exception) {
            return null;
        }
    }

    private Integer integerValue(Object value) {
        try {
            return value == null || String.valueOf(value).isBlank() ? null : Integer.valueOf(String.valueOf(value));
        } catch (NumberFormatException exception) {
            return null;
        }
    }

    private BigDecimal decimalValue(Object value) {
        try {
            return value == null || String.valueOf(value).isBlank() ? BigDecimal.ZERO : new BigDecimal(String.valueOf(value));
        } catch (NumberFormatException exception) {
            return BigDecimal.ZERO;
        }
    }

    private double doubleValue(Object value) {
        try {
            return value == null ? 0 : Double.parseDouble(String.valueOf(value));
        } catch (NumberFormatException exception) {
            return 0;
        }
    }

    private String tagsValue(Object tags) {
        if (tags instanceof Collection<?> collection) {
            return collection.stream().map(String::valueOf).collect(Collectors.joining(","));
        }
        return tags == null ? "" : String.valueOf(tags);
    }

    private String defaultIfBlank(String value, String fallback) {
        return value == null || value.isBlank() ? fallback : value;
    }

    /**
     * 从指令中提取关键词
     */
    private String extractKeyword(String command) {
        String title = extractAnimeTitle(command);
        if (!title.isBlank()) return title;
        return command.replace("帮我找到", "")
                .replace("帮我追", "")
                .replace("帮我打开", "")
                .replace("打开", "")
                .replace("播放", "")
                .replace("观看", "")
                .replace("看一下", "")
                .replace("我要看", "")
                .replace("我想看", "")
                .replace("追番", "")
                .replace("收藏", "")
                .replace("取消", "")
                .replace("移除", "")
                .replace("类似", "")
                .replace("一样的", "")
                .replace("的动漫", "")
                .replace("几部", "")
                .replace("一些", "")
                .replace("推荐", "")
                .trim();
    }

    /**
     * 生成 AI 美化的回答总结
     */
    private String generateSummary(String intent, Map<String, Object> agentResult) {
        if (containsAny(intent, "open_anime", "follow_anime", "unfollow_anime", "list_following")
                && agentResult.get("message") instanceof String message) {
            return message;
        }

        @SuppressWarnings("unchecked")
        List<Map<String, Object>> videos = (List<Map<String, Object>>) agentResult.get("videos");
        String type = (String) agentResult.get("type");

        if (videos != null && !videos.isEmpty()) {
            StringBuilder sb = new StringBuilder();
            sb.append("根据你的需求，我为你找到了 ").append(type).append(":\n\n");
            for (int i = 0; i < Math.min(videos.size(), 5); i++) {
                Map<String, Object> v = videos.get(i);
                sb.append(i + 1).append(". 《").append(v.get("title")).append("》");
                if (v.get("rating") != null) {
                    sb.append(" ⭐").append(v.get("rating"));
                }
                sb.append("\n");
            }
            return sb.toString();
        } else if (agentResult.get("message") != null) {
            return (String) agentResult.get("message");
        }

        return "我暂时无法完全理解你的需求，能换个方式描述一下吗？";
    }
}
