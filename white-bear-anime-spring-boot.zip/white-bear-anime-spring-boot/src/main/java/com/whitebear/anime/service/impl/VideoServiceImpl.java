package com.whitebear.anime.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.whitebear.anime.mapper.BannerMapper;
import com.whitebear.anime.mapper.EpisodeMapper;
import com.whitebear.anime.mapper.PlayStatsMapper;
import com.whitebear.anime.mapper.VideoMapper;
import com.whitebear.anime.mapper.WatchHistoryMapper;
import com.whitebear.anime.model.Result;
import com.whitebear.anime.model.entity.Banner;
import com.whitebear.anime.model.entity.Episode;
import com.whitebear.anime.model.entity.PlayStats;
import com.whitebear.anime.model.entity.Video;
import com.whitebear.anime.model.entity.WatchHistory;
import com.whitebear.anime.security.SecurityUtils;
import com.whitebear.anime.service.VideoService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class VideoServiceImpl implements VideoService {

    private final VideoMapper videoMapper;
    private final EpisodeMapper episodeMapper;
    private final PlayStatsMapper playStatsMapper;
    private final BannerMapper bannerMapper;
    private final WatchHistoryMapper watchHistoryMapper;

    @Override
    public Result<Map<String, Object>> getHotVideos(int count, int page) {
        int safeCount = Math.max(1, Math.min(count, 100));
        int safePage = Math.max(page, 1);

        List<Map<String, Object>> bannerList = bannerMapper.selectActiveBanners().stream()
                .map(this::toBannerItem)
                .collect(Collectors.toList());

        Page<Video> videoPage = videoMapper.selectPage(
                new Page<>(safePage, safeCount),
                new LambdaQueryWrapper<Video>()
                        .eq(Video::getAuditStatus, "approved")
                        .orderByDesc(Video::getViews)
                        .orderByAsc(Video::getId)
        );
        List<Map<String, Object>> list = videoPage.getRecords().stream()
                .map(this::toListItem)
                .collect(Collectors.toList());

        Map<String, Object> data = new LinkedHashMap<>();
        data.put("list", list);
        data.put("banners", bannerList);
        data.put("total", videoPage.getTotal());
        data.put("page", safePage);
        return Result.ok(data);
    }

    @Override
    public Result<Map<String, Object>> getVideoDetail(Long videoId) {
        Video video = videoMapper.selectById(videoId);
        if (video == null || !"approved".equals(video.getAuditStatus())) {
            return Result.notFound("视频不存在");
        }

        List<Episode> episodes = episodeMapper.selectByVideoId(videoId);
        Map<String, Object> detail = new LinkedHashMap<>();
        detail.put("video", video);
        detail.put("episodes", episodes);
        detail.put("episodeCount", episodes.size());
        return Result.ok(detail);
    }

    @Override
    public Result<Object> getEpisodes(Long videoId) {
        return Result.ok(Map.of("list", episodeMapper.selectByVideoId(videoId)));
    }

    @Override
    public Result<Object> searchVideos(String keyword, int page) {
        List<Map<String, Object>> list = videoMapper.searchByKeyword(keyword).stream()
                .map(this::toListItem)
                .collect(Collectors.toList());
        return Result.ok(Map.of("list", list, "total", list.size(), "page", page));
    }

    @Override
    public Result<Object> getRankings(String type) {
        LambdaQueryWrapper<Video> wrapper = new LambdaQueryWrapper<Video>()
                .eq(Video::getAuditStatus, "approved");
        if ("new".equals(type)) {
            wrapper.orderByDesc(Video::getCreateTime);
        } else if ("score".equals(type)) {
            wrapper.orderByDesc(Video::getRating);
        } else {
            wrapper.orderByDesc(Video::getViews);
        }
        wrapper.orderByAsc(Video::getId).last("LIMIT 20");

        List<Map<String, Object>> list = videoMapper.selectList(wrapper).stream()
                .map(this::toListItem)
                .collect(Collectors.toList());
        return Result.ok(Map.of("list", list, "type", type));
    }

    @Override
    public Result<Object> getCategories() {
        return Result.ok(Map.of("list", videoMapper.selectCategories()));
    }

    @Override
    public Result<Object> discoverVideos(int page, int size, String keyword, String category, String sort) {
        int safePage = Math.max(page, 1);
        int safeSize = Math.max(1, Math.min(size, 100));
        LambdaQueryWrapper<Video> wrapper = new LambdaQueryWrapper<Video>()
                .eq(Video::getAuditStatus, "approved");

        if (keyword != null && !keyword.isBlank()) {
            String value = keyword.trim();
            wrapper.and(query -> query.like(Video::getTitle, value)
                    .or().like(Video::getDescription, value)
                    .or().like(Video::getTags, value));
        }
        if (category != null && !category.isBlank()) {
            String value = category.trim();
            wrapper.and(query -> query.eq(Video::getCategory, value)
                    .or().like(Video::getTags, value));
        }

        if ("new".equals(sort)) {
            wrapper.orderByDesc(Video::getCreateTime);
        } else if ("score".equals(sort)) {
            wrapper.orderByDesc(Video::getRating);
        } else {
            wrapper.orderByDesc(Video::getViews);
        }
        wrapper.orderByAsc(Video::getId);

        Page<Video> resultPage = videoMapper.selectPage(new Page<>(safePage, safeSize), wrapper);
        List<Map<String, Object>> list = resultPage.getRecords().stream()
                .map(this::toListItem)
                .collect(Collectors.toList());

        Map<String, Object> data = new LinkedHashMap<>();
        data.put("page", safePage);
        data.put("size", safeSize);
        data.put("total", resultPage.getTotal());
        data.put("list", list);
        return Result.ok(data);
    }

    @Override
    public Result<Object> getRelatedVideos(Long videoId, int count) {
        Video current = videoMapper.selectById(videoId);
        if (current == null) {
            return Result.notFound("视频不存在");
        }

        int safeCount = Math.max(1, Math.min(count, 20));
        LambdaQueryWrapper<Video> wrapper = new LambdaQueryWrapper<Video>()
                .eq(Video::getAuditStatus, "approved")
                .ne(Video::getId, videoId)
                .orderByDesc(Video::getViews)
                .orderByAsc(Video::getId)
                .last("LIMIT " + safeCount);
        if (current.getCategory() != null && !current.getCategory().isBlank()) {
            wrapper.eq(Video::getCategory, current.getCategory());
        }

        List<Map<String, Object>> list = videoMapper.selectList(wrapper).stream()
                .map(this::toListItem)
                .collect(Collectors.toList());
        return Result.ok(Map.of("list", list));
    }

    @Override
    public Result<Object> getVideosByCategory(String category, int page) {
        List<Map<String, Object>> list = videoMapper.selectByCategory(category).stream()
                .map(this::toListItem)
                .collect(Collectors.toList());
        return Result.ok(Map.of("list", list, "category", category, "total", list.size()));
    }

    @Override
    public Result<Void> recordPlay(Long videoId, Long episodeId) {
        if (videoMapper.selectById(videoId) == null) {
            return Result.notFound("视频不存在");
        }

        savePlay(videoId, episodeId);
        return Result.ok();
    }

    @Override
    public Result<Void> recordPlayByTitle(String title) {
        if (title == null || title.isBlank()) {
            return Result.badRequest("视频标题不能为空");
        }
        Video video = videoMapper.findByTitle(title.trim());
        if (video == null) {
            return Result.notFound("排行榜中尚无该 Python 视频，请先在后台刷新排行榜");
        }

        savePlay(video.getId(), null);
        return Result.ok();
    }

    @Override
    public Result<Void> recordPlayBySourceVodId(Long sourceVodId) {
        if (sourceVodId == null || sourceVodId <= 0) {
            return Result.badRequest("Python 视频 ID 不正确");
        }
        Video video = videoMapper.findBySourceVodId(sourceVodId);
        if (video == null) {
            return Result.notFound("排行榜中尚无该 Python 视频，请先在后台刷新排行榜");
        }
        savePlay(video.getId(), null);
        return Result.ok();
    }

    private void savePlay(Long videoId, Long episodeId) {
        videoMapper.incrementViews(videoId);
        Long userId = SecurityUtils.getCurrentUserId();
        PlayStats stats = PlayStats.builder()
                .videoId(videoId)
                .episodeId(episodeId)
                .userId(userId)
                .playDate(LocalDate.now())
                .playCount(1)
                .build();
        playStatsMapper.insert(stats);

        if (userId != null) {
            WatchHistory history = watchHistoryMapper.selectByUserAndAnime(userId, videoId);
            if (history == null) {
                watchHistoryMapper.insert(WatchHistory.builder()
                        .userId(userId)
                        .animeId(videoId)
                        .episodeId(episodeId)
                        .currentTime(0)
                        .duration(0)
                        .watchedAt(LocalDateTime.now())
                        .build());
            } else {
                history.setEpisodeId(episodeId);
                history.setWatchedAt(LocalDateTime.now());
                watchHistoryMapper.updateById(history);
            }
        }
    }

    private Map<String, Object> toBannerItem(Banner banner) {
        Map<String, Object> item = new HashMap<>();
        item.put("vod_id", banner.getAnimeId());
        item.put("title", banner.getTitle());
        item.put("cover", banner.getImg());
        item.put("cover_proxy", banner.getImg());
        return item;
    }

    private Map<String, Object> toListItem(Video video) {
        Map<String, Object> item = new LinkedHashMap<>();
        item.put("vod_id", video.getId());
        item.put("sourceVodId", video.getSourceVodId());
        item.put("title", video.getTitle());
        item.put("cover", video.getCover());
        item.put("cover_proxy", video.getCover());
        item.put("category", video.getCategory());
        item.put("status", video.getStatus());
        item.put("score", video.getRating() != null ? video.getRating().toString() : "0.0");
        item.put("desc", video.getDescription());
        item.put("tags", video.getTags());
        item.put("year", video.getYear());
        item.put("episodes", video.getEpisodes());
        item.put("views", video.getViews());
        item.put("likes", video.getLikes());
        return item;
    }
}
