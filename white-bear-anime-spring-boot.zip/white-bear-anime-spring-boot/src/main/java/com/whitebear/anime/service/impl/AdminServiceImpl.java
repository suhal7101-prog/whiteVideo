package com.whitebear.anime.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.whitebear.anime.mapper.*;
import com.whitebear.anime.model.Result;
import com.whitebear.anime.model.dto.BannerDTO;
import com.whitebear.anime.model.dto.AnnouncementDTO;
import com.whitebear.anime.model.dto.AdvertisementDTO;
import com.whitebear.anime.model.dto.VideoDTO;
import com.whitebear.anime.model.dto.VideoAuditDTO;
import com.whitebear.anime.model.dto.CreatorAuditDTO;
import com.whitebear.anime.model.entity.*;
import com.whitebear.anime.service.AdminService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

/**
 * 管理后台服务实现类
 *
 * @author WhiteBear
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class AdminServiceImpl implements AdminService {

    private static final List<String> DEFAULT_VIDEO_TAGS = List.of(
            "热血", "战斗", "玄幻", "冒险", "搞笑", "日常", "奇幻",
            "科幻", "恋爱", "悬疑", "治愈", "校园", "穿越", "励志");

    private final UserMapper userMapper;
    private final VideoMapper videoMapper;
    private final BannerMapper bannerMapper;
    private final PostMapper postMapper;
    private final PlayStatsMapper playStatsMapper;
    private final OperationLogMapper operationLogMapper;
    private final AnnouncementMapper announcementMapper;
    private final AnnouncementReadMapper announcementReadMapper;
    private final AdvertisementMapper advertisementMapper;
    private final PasswordEncoder passwordEncoder;

    // ==================== 用户管理 ====================

    @Override
    public Result<Object> getUsers(Integer page, Integer size, String keyword, String role, String status) {
        LambdaQueryWrapper<User> wrapper = Wrappers.<User>lambdaQuery();
        if (keyword != null && !keyword.isEmpty()) {
            wrapper.and(w -> w.like(User::getUsername, keyword).or().like(User::getEmail, keyword));
        }
        if (role != null && !role.isEmpty()) {
            wrapper.eq(User::getRole, role);
        }
        if (status != null && !status.isEmpty()) {
            wrapper.eq(User::getStatus, status);
        }
        wrapper.orderByDesc(User::getCreateTime);

        Page<User> result = userMapper.selectPage(new Page<>(page, size), wrapper);
        result.getRecords().forEach(user -> user.setPassword(null));

        Map<String, Object> data = new HashMap<>();
        data.put("list", result.getRecords());
        data.put("total", result.getTotal());
        data.put("page", page);
        data.put("size", size);
        return Result.ok(data);
    }

    @Override
    public Result<Void> updateUser(Long id, Object userData) {
        User user = userMapper.selectById(id);
        if (user == null) {
            return Result.notFound("用户不存在");
        }
        // 只允许修改部分字段（昵称、头像、简介、状态）
        @SuppressWarnings("unchecked")
        Map<String, Object> map = (Map<String, Object>) userData;
        if (map.containsKey("nickname")) user.setNickname((String) map.get("nickname"));
        if (map.containsKey("avatar")) user.setAvatar((String) map.get("avatar"));
        if (map.containsKey("bio")) user.setBio((String) map.get("bio"));
        if (map.containsKey("status")) user.setStatus((String) map.get("status"));
        userMapper.updateById(user);
        log.info("[管理] 更新用户 ID={}", id);
        return Result.success("更新成功");
    }

    @Override
    @Transactional
    public Result<Void> deleteUser(Long id) {
        User user = userMapper.selectById(id);
        if (user == null) {
            return Result.notFound("用户不存在");
        }
        if ("admin".equals(user.getRole())) {
            return Result.error(400, "不能删除管理员");
        }
        userMapper.deleteById(id);
        log.info("[管理] 删除用户 ID={}", id);
        return Result.success("删除成功");
    }

    @Override
    public Result<Void> resetPassword(Long id, String password) {
        User user = userMapper.selectById(id);
        if (user == null) return Result.notFound("用户不存在");
        if (password == null || password.length() < 6) {
            return Result.badRequest("新密码至少需要6个字符");
        }
        user.setPassword(passwordEncoder.encode(password));
        userMapper.updateById(user);
        log.info("[管理] 重置用户 ID={} 密码", id);
        return Result.success("密码已重置");
    }

    @Override
    public Result<Object> getCreatorApplications(Integer page, Integer size, String keyword, String applyStatus) {
        int safePage = page == null || page < 1 ? 1 : page;
        int safeSize = size == null ? 10 : Math.max(1, Math.min(size, 100));
        String normalizedStatus = normalizeCreatorApplyFilter(applyStatus);

        LambdaQueryWrapper<User> wrapper = Wrappers.<User>lambdaQuery()
                .isNotNull(User::getCreatorApplyStatus);
        if (!"all".equals(normalizedStatus)) {
            wrapper.eq(User::getCreatorApplyStatus, normalizedStatus);
        }
        if (keyword != null && !keyword.isBlank()) {
            String value = keyword.trim();
            wrapper.and(w -> w.like(User::getUsername, value)
                    .or().like(User::getNickname, value)
                    .or().like(User::getEmail, value));
        }
        wrapper.orderByDesc(User::getCreatorApplyTime).orderByDesc(User::getId);

        Page<User> result = userMapper.selectPage(new Page<>(safePage, safeSize), wrapper);
        result.getRecords().forEach(user -> user.setPassword(null));
        Map<String, Object> data = new LinkedHashMap<>();
        data.put("list", result.getRecords());
        data.put("total", result.getTotal());
        data.put("page", safePage);
        data.put("size", safeSize);
        return Result.ok(data);
    }

    @Override
    @Transactional
    public Result<Void> auditCreatorApplication(Long userId, CreatorAuditDTO dto) {
        User user = userMapper.selectById(userId);
        if (user == null || user.getCreatorApplyStatus() == null) {
            return Result.notFound("创作者申请不存在");
        }
        if ("admin".equals(user.getRole())) {
            return Result.badRequest("管理员无需审核为创作者");
        }

        String status = dto.getStatus();
        String reason = dto.getReason() == null ? null : dto.getReason().trim();
        if (!"approved".equals(status) && !"rejected".equals(status)) {
            return Result.badRequest("审核结果只能是通过或拒绝");
        }
        if ("rejected".equals(status) && (reason == null || reason.isEmpty())) {
            return Result.badRequest("拒绝申请时请填写原因");
        }

        user.setCreatorApplyStatus(status);
        user.setCreatorApplyReason("rejected".equals(status) ? reason : null);
        user.setCreatorAuditTime(LocalDateTime.now());
        user.setCreatorAuditorId(com.whitebear.anime.security.SecurityUtils.getCurrentUserId());
        user.setRole("approved".equals(status) ? "creator" : "user");
        userMapper.updateById(user);
        log.info("[管理] 审核创作者申请 用户ID={}, 结果={}", userId, status);
        return Result.success("approved".equals(status) ? "创作者申请已通过" : "创作者申请已拒绝");
    }

    private String normalizeCreatorApplyFilter(String status) {
        if ("approved".equals(status) || "rejected".equals(status) || "all".equals(status)) {
            return status;
        }
        return "pending";
    }

    // ==================== 视频管理 ====================

    @Override
    public Result<Object> getVideos(Integer page, Integer size, String keyword, String category) {
        LambdaQueryWrapper<Video> wrapper = Wrappers.<Video>lambdaQuery();
        wrapper.eq(Video::getAuditStatus, "approved");
        if (keyword != null && !keyword.isEmpty()) {
            wrapper.like(Video::getTitle, keyword);
        }
        if (category != null && !category.isEmpty()) {
            // 管理页的筛选项同时检索分类与数据库 tags 字段。
            wrapper.and(w -> w.eq(Video::getCategory, category)
                    .or()
                    .like(Video::getTags, category));
        }
        wrapper.orderByDesc(Video::getCreateTime);

        Page<Video> result = videoMapper.selectPage(new Page<>(page, size), wrapper);

        Map<String, Object> data = new HashMap<>();
        data.put("list", result.getRecords());
        data.put("total", result.getTotal());
        data.put("page", page);
        data.put("size", size);
        return Result.ok(data);
    }

    @Override
    public Result<Object> createVideo(VideoDTO dto) {
        Video video = Video.builder()
                .title(dto.getTitle())
                .cover(dto.getCover())
                .category(dto.getCategory())
                .description(dto.getDescription())
                .status(dto.getStatus() != null ? dto.getStatus() : "连载中")
                .rating(dto.getRating() != null ? java.math.BigDecimal.valueOf(dto.getRating()) : java.math.BigDecimal.ZERO)
                .episodes(dto.getEpisodes() != null ? dto.getEpisodes() : 0)
                .tags(ensureAtLeastTwoVideoTags(dto.getTags()))
                .year(dto.getYear())
                .region(dto.getRegion())
                .submissionSource("platform")
                .auditStatus("approved")
                .views(java.util.concurrent.ThreadLocalRandom.current().nextLong(500, 901))
                .likes(java.util.concurrent.ThreadLocalRandom.current().nextLong(500, 901))
                .build();
        videoMapper.insert(video);
        log.info("[管理] 新增视频 ID={}, 标题={}", video.getId(), video.getTitle());
        return Result.ok("新增成功", Map.of("id", video.getId()));
    }

    @Override
    public Result<Object> updateVideo(Long id, VideoDTO dto) {
        Video video = videoMapper.selectById(id);
        if (video == null) {
            return Result.notFound("视频不存在");
        }
        if (dto.getTitle() != null) video.setTitle(dto.getTitle());
        if (dto.getCover() != null) video.setCover(dto.getCover());
        if (dto.getCategory() != null) video.setCategory(dto.getCategory());
        if (dto.getDescription() != null) video.setDescription(dto.getDescription());
        if (dto.getStatus() != null) video.setStatus(dto.getStatus());
        if (dto.getRating() != null) video.setRating(java.math.BigDecimal.valueOf(dto.getRating()));
        if (dto.getEpisodes() != null) video.setEpisodes(dto.getEpisodes());
        if (dto.getTags() != null) video.setTags(ensureAtLeastTwoVideoTags(dto.getTags()));
        if (dto.getYear() != null) video.setYear(dto.getYear());
        if (dto.getRegion() != null) video.setRegion(dto.getRegion());
        videoMapper.updateById(video);
        log.info("[管理] 更新视频 ID={}", id);
        return Result.ok("更新成功");
    }

    private String ensureAtLeastTwoVideoTags(String rawTags) {
        LinkedHashSet<String> tags = Arrays.stream(Optional.ofNullable(rawTags).orElse("").split(","))
                .map(String::trim)
                .filter(tag -> !tag.isEmpty())
                .collect(Collectors.toCollection(LinkedHashSet::new));
        if (tags.size() < 2) {
            List<String> candidates = new ArrayList<>(DEFAULT_VIDEO_TAGS);
            Collections.shuffle(candidates);
            for (String candidate : candidates) {
                tags.add(candidate);
                if (tags.size() >= 2) break;
            }
        }
        return String.join(",", tags);
    }

    @Override
    @Transactional
    public Result<Void> deleteVideo(Long id) {
        if (videoMapper.selectById(id) == null) {
            return Result.notFound("视频不存在");
        }
        videoMapper.deleteById(id);
        log.info("[管理] 删除视频 ID={}", id);
        return Result.success("删除成功");
    }

    @Override
    public Result<Object> getVideoSubmissions(Integer page, Integer size, String keyword, String auditStatus) {
        int safePage = page == null || page < 1 ? 1 : page;
        int safeSize = size == null ? 10 : Math.max(1, Math.min(size, 100));
        String normalizedStatus = normalizeAuditFilter(auditStatus);
        String normalizedKeyword = keyword == null ? null : keyword.trim();
        int offset = (safePage - 1) * safeSize;

        List<Map<String, Object>> list = videoMapper.selectVideoSubmissions(
                offset, safeSize, normalizedKeyword, normalizedStatus);
        long total = videoMapper.countVideoSubmissions(normalizedKeyword, normalizedStatus);

        Map<String, Object> data = new LinkedHashMap<>();
        data.put("list", list);
        data.put("total", total);
        data.put("page", safePage);
        data.put("size", safeSize);
        return Result.ok(data);
    }

    @Override
    @Transactional
    public Result<Void> auditVideoSubmission(Long id, VideoAuditDTO dto) {
        Video video = videoMapper.selectById(id);
        if (video == null || !"user".equals(video.getSubmissionSource())) {
            return Result.notFound("用户投稿不存在");
        }

        String status = dto.getStatus();
        String reason = dto.getReason() == null ? null : dto.getReason().trim();
        if (!"approved".equals(status) && !"rejected".equals(status)) {
            return Result.badRequest("审核结果只能是通过或拒绝");
        }
        if ("rejected".equals(status) && (reason == null || reason.isEmpty())) {
            return Result.badRequest("拒绝投稿时请填写原因");
        }

        video.setAuditStatus(status);
        video.setAuditReason("rejected".equals(status) ? reason : null);
        video.setAuditorId(com.whitebear.anime.security.SecurityUtils.getCurrentUserId());
        video.setAuditTime(LocalDateTime.now());
        videoMapper.updateById(video);
        log.info("[管理] 审核用户投稿 ID={}, 结果={}", id, status);
        return Result.success("approved".equals(status) ? "投稿已通过" : "投稿已拒绝");
    }

    private String normalizeAuditFilter(String auditStatus) {
        if ("approved".equals(auditStatus) || "rejected".equals(auditStatus) || "all".equals(auditStatus)) {
            return auditStatus;
        }
        return "pending";
    }

    // ==================== 内容管理 ====================

    @Override
    public Result<Object> getBanners() {
        List<Banner> banners = bannerMapper.selectActiveBanners();
        return Result.ok(Map.of("list", banners));
    }

    @Override
    public Result<Object> createBanner(BannerDTO dto) {
        Banner banner = Banner.builder()
                .title(dto.getTitle())
                .img(dto.getImg())
                .animeId(dto.getAnimeId())
                .sortOrder(dto.getSortOrder() != null ? dto.getSortOrder() : 0)
                .active(dto.getActive() != null ? dto.getActive() : 1)
                .build();
        bannerMapper.insert(banner);
        log.info("[管理] 新增轮播图 ID={}", banner.getId());
        return Result.ok("新增成功", Map.of("id", banner.getId()));
    }

    @Override
    public Result<Object> updateBanner(Long id, BannerDTO dto) {
        Banner banner = bannerMapper.selectById(id);
        if (banner == null) {
            return Result.notFound("轮播图不存在");
        }
        if (dto.getTitle() != null) banner.setTitle(dto.getTitle());
        if (dto.getImg() != null) banner.setImg(dto.getImg());
        if (dto.getAnimeId() != null) banner.setAnimeId(dto.getAnimeId());
        if (dto.getSortOrder() != null) banner.setSortOrder(dto.getSortOrder());
        if (dto.getActive() != null) banner.setActive(dto.getActive());
        bannerMapper.updateById(banner);
        return Result.ok("更新成功");
    }

    @Override
    public Result<Object> getPendingPosts(Integer page, Integer size) {
        List<Post> posts = postMapper.selectPendingPosts();
        return Result.ok(Map.of("list", posts, "total", posts.size()));
    }

    @Override
    public Result<Void> auditPost(Long postId, String status) {
        Post post = postMapper.selectById(postId);
        if (post == null) {
            return Result.notFound("帖子不存在");
        }
        post.setStatus(status);
        postMapper.updateById(post);
        log.info("[管理] 审核帖子 ID={}, 结果={}", postId, status);
        return Result.success("审核完成");
    }

    @Override
    public Result<Object> getAnnouncements() {
        List<Map<String, Object>> list = announcementMapper.selectAdminList();
        return Result.ok(Map.of("list", list, "total", list.size()));
    }

    @Override
    public Result<Object> createAnnouncement(AnnouncementDTO dto) {
        String status = normalizeAnnouncementStatus(dto.getStatus());
        Announcement announcement = Announcement.builder()
                .title(dto.getTitle().trim())
                .content(dto.getContent().trim())
                .pinned(dto.getPinned() != null && dto.getPinned() == 1 ? 1 : 0)
                .status(status)
                .publisherId(com.whitebear.anime.security.SecurityUtils.getCurrentUserId())
                .publishTime("published".equals(status) ? LocalDateTime.now() : null)
                .deleted(0)
                .build();
        announcementMapper.insert(announcement);
        log.info("[管理] 创建公告 ID={}, 状态={}", announcement.getId(), status);
        return Result.ok("published".equals(status) ? "公告发布成功" : "草稿保存成功",
                Map.of("id", announcement.getId()));
    }

    @Override
    @Transactional
    public Result<Void> updateAnnouncement(Long id, AnnouncementDTO dto) {
        Announcement announcement = announcementMapper.selectById(id);
        if (announcement == null) return Result.notFound("公告不存在");

        String status = normalizeAnnouncementStatus(dto.getStatus());
        boolean republishing = "published".equals(status);
        announcement.setTitle(dto.getTitle().trim());
        announcement.setContent(dto.getContent().trim());
        announcement.setPinned(dto.getPinned() != null && dto.getPinned() == 1 ? 1 : 0);
        announcement.setStatus(status);
        if (republishing) {
            announcement.setPublishTime(LocalDateTime.now());
        }
        announcementMapper.updateById(announcement);
        if (republishing) announcementReadMapper.deleteByAnnouncement(id);
        log.info("[管理] 更新公告 ID={}, 状态={}", id, status);
        return Result.success("公告更新成功");
    }

    @Override
    @Transactional
    public Result<Void> deleteAnnouncement(Long id) {
        Announcement announcement = announcementMapper.selectById(id);
        if (announcement == null) return Result.notFound("公告不存在");
        announcementReadMapper.deleteByAnnouncement(id);
        announcementMapper.deleteById(id);
        log.info("[管理] 删除公告 ID={}", id);
        return Result.success("公告已删除");
    }

    private String normalizeAnnouncementStatus(String status) {
        return "draft".equalsIgnoreCase(status) ? "draft" : "published";
    }

    // ==================== 广告管理 ====================

    @Override
    public Result<Object> getAdvertisements() {
        List<Advertisement> list = advertisementMapper.selectAllOrdered();
        return Result.ok(Map.of("list", list, "total", list.size()));
    }

    @Override
    public Result<Object> createAdvertisement(AdvertisementDTO dto) {
        if (invalidAdvertisementPeriod(dto)) return Result.badRequest("广告结束时间不能早于开始时间");
        Advertisement advertisement = Advertisement.builder()
                .title(dto.getTitle().trim())
                .description(trimToNull(dto.getDescription()))
                .imageUrl(dto.getImageUrl().trim())
                .targetUrl(trimToNull(dto.getTargetUrl()))
                .position(defaultAdvertisementPosition(dto.getPosition()))
                .status(normalizeAdvertisementStatus(dto.getStatus()))
                .startTime(dto.getStartTime())
                .endTime(dto.getEndTime())
                .sortOrder(dto.getSortOrder() == null ? 0 : dto.getSortOrder())
                .deleted(0)
                .build();
        advertisementMapper.insert(advertisement);
        return Result.ok("广告创建成功", Map.of("id", advertisement.getId()));
    }

    @Override
    public Result<Void> updateAdvertisement(Long id, AdvertisementDTO dto) {
        Advertisement advertisement = advertisementMapper.selectById(id);
        if (advertisement == null) return Result.notFound("广告不存在");
        if (invalidAdvertisementPeriod(dto)) return Result.badRequest("广告结束时间不能早于开始时间");
        advertisement.setTitle(dto.getTitle().trim());
        advertisement.setDescription(trimToNull(dto.getDescription()));
        advertisement.setImageUrl(dto.getImageUrl().trim());
        advertisement.setTargetUrl(trimToNull(dto.getTargetUrl()));
        advertisement.setPosition(defaultAdvertisementPosition(dto.getPosition()));
        advertisement.setStatus(normalizeAdvertisementStatus(dto.getStatus()));
        advertisement.setStartTime(dto.getStartTime());
        advertisement.setEndTime(dto.getEndTime());
        advertisement.setSortOrder(dto.getSortOrder() == null ? 0 : dto.getSortOrder());
        advertisementMapper.updateById(advertisement);
        return Result.success("广告更新成功");
    }

    @Override
    public Result<Void> deleteAdvertisement(Long id) {
        Advertisement advertisement = advertisementMapper.selectById(id);
        if (advertisement == null) return Result.notFound("广告不存在");
        advertisementMapper.deleteById(id);
        return Result.success("广告已删除");
    }

    private boolean invalidAdvertisementPeriod(AdvertisementDTO dto) {
        return dto.getStartTime() != null && dto.getEndTime() != null
                && dto.getEndTime().isBefore(dto.getStartTime());
    }

    private String normalizeAdvertisementStatus(String status) {
        return "inactive".equalsIgnoreCase(status) ? "inactive" : "active";
    }

    private String defaultAdvertisementPosition(String position) {
        return position == null || position.isBlank() ? "home_top" : position.trim();
    }

    private String trimToNull(String value) {
        return value == null || value.isBlank() ? null : value.trim();
    }

    // ==================== 数据统计 ====================

    @Override
    public Result<Object> getStatsOverview() {
        Map<String, Object> stats = new LinkedHashMap<>();
        stats.put("totalUsers", userMapper.countTotalUsers());
        stats.put("totalVideos", videoMapper.countTotalVideos());
        stats.put("totalPosts", postMapper.countTotalPosts());
        stats.put("totalPlays", playStatsMapper.countTotalPlays());
        stats.put("todayPlays", playStatsMapper.countTodayPlays());
        stats.put("todayNewUsers", userMapper.countTodayNewUsers());
        
        // 最近操作日志
        List<OperationLog> logs = operationLogMapper.selectRecent(10);
        stats.put("recentLogs", logs);

        return Result.ok(stats);
    }

    @Override
    public Result<Object> getPlayStats(String period) {
        List<Map<String, Object>> weeklyData = playStatsMapper.selectWeeklyPlayCount();
        return Result.ok(Map.of("period", period, "data", weeklyData));
    }

    @Override
    public Result<Object> getUserStats(String period) {
        List<Map<String, Object>> userData = playStatsMapper.selectWeeklyActiveUsers();
        return Result.ok(Map.of("period", period, "data", userData));
    }

    @Override
    public Result<Object> getRankingStats(String period) {
        List<Video> topVideos = videoMapper.selectTopByHeat(20);
        List<Map<String, Object>> ranking = topVideos.stream().map(v -> {
            Map<String, Object> m = new HashMap<>();
            long views = v.getViews() == null ? 0L : v.getViews();
            long likes = v.getLikes() == null ? 0L : v.getLikes();
            m.put("id", v.getId());
            m.put("title", v.getTitle());
            m.put("cover", v.getCover());
            m.put("plays", views);
            m.put("views", views);
            m.put("likes", likes);
            m.put("heatScore", views + likes * 10);
            m.put("category", v.getCategory());
            return m;
        }).collect(Collectors.toList());
        return Result.ok(Map.of("period", period, "ranking", ranking));
    }
}
