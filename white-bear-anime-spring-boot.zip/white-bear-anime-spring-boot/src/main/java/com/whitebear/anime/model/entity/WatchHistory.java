package com.whitebear.anime.model.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * 观看历史实体
 *
 * @author WhiteBear
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@TableName("wb_watch_history")
public class WatchHistory {

    @TableId(type = IdType.AUTO)
    private Long id;

    /** 用户 ID */
    private Long userId;

    /** 动漫 ID */
    private Long animeId;

    /** 剧集 ID */
    private Long episodeId;

    /** 当前播放时间（秒） */
    @TableField("`current_time`")
    private Integer currentTime;

    /** 总时长（秒） */
    private Integer duration;

    /** 观看时间 */
    private LocalDateTime watchedAt;

    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createTime;

    @TableField(fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime updateTime;
}
