package com.whitebear.anime.controller;

import com.whitebear.anime.model.Result;
import com.whitebear.anime.service.BannerEffectService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@Tag(name = "效果图", description = "AI与社区动态横幅效果图")
@RestController
@RequestMapping("/api/banner-effects")
@RequiredArgsConstructor
public class BannerEffectController {
    private final BannerEffectService bannerEffectService;

    @Operation(summary = "获取已启用效果图")
    @GetMapping("/active")
    public Result<?> getActiveEffects(@RequestParam(defaultValue = "ai") String targetPage) {
        return bannerEffectService.getActiveEffects(targetPage);
    }
}
