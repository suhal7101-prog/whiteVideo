package com.whitebear.anime.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.whitebear.anime.model.entity.Advertisement;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface AdvertisementMapper extends BaseMapper<Advertisement> {
    @Select("SELECT * FROM wb_advertisement WHERE deleted = 0 ORDER BY sort_order ASC, create_time DESC")
    List<Advertisement> selectAllOrdered();

    @Select("""
            <script>
            SELECT id, title, description, image_url, target_url, position, status,
                   start_time, end_time, sort_order
            FROM wb_advertisement
            WHERE deleted = 0
              AND status = 'active'
              AND (start_time IS NULL OR start_time &lt;= CURRENT_TIMESTAMP)
              AND (end_time IS NULL OR end_time &gt;= CURRENT_TIMESTAMP)
            <if test="position != null and position != ''">
              AND position = #{position}
            </if>
            ORDER BY sort_order ASC, create_time DESC
            </script>
            """)
    List<Advertisement> selectActive(@Param("position") String position);
}
