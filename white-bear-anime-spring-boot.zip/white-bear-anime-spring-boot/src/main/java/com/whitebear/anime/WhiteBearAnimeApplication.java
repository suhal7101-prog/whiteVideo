package com.whitebear.anime;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.mybatis.spring.annotation.MapperScan;

/**
 * 白熊动漫平台 - Spring Boot 启动类
 *
 * @author WhiteBear
 * @since 1.0.0
 */
@EnableAsync
@EnableScheduling
@SpringBootApplication
@MapperScan("com.whitebear.anime.mapper")
public class WhiteBearAnimeApplication {

    public static void main(String[] args) {
        SpringApplication.run(WhiteBearAnimeApplication.class, args);
        System.out.println("""
                
                ╔══════════════════════════════════════════════╗
                ║     🐻  白熊动漫平台 启动成功！               ║
                ║     接口文档: http://localhost:8088/doc.html  ║
                ║     前端地址: http://localhost:5174           ║
                ╚══════════════════════════════════════════════╝
                """);
    }
}
