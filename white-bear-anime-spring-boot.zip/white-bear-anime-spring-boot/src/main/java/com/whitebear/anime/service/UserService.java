package com.whitebear.anime.service;

import com.whitebear.anime.model.Result;
import com.whitebear.anime.model.dto.*;
import com.whitebear.anime.model.entity.User;

import java.util.Map;

/**
 * 用户服务接口
 *
 * @author WhiteBear
 */
public interface UserService {

    /** 用户登录 —— 返回 Token + 用户信息 */
    Result<Map<String, Object>> login(LoginDTO loginDTO);

    /** 用户注册 */
    Result<Void> register(RegisterDTO registerDTO);

    /** 获取当前用户个人信息 */
    Result<User> getProfile();

    /** 更新个人信息 */
    Result<Void> updateProfile(UpdateProfileDTO dto);

    /** 修改密码 */
    Result<Void> changePassword(ChangePasswordDTO dto);

    /** 当前用户申请成为创作者（管理员默认拥有权限）。 */
    Result<Object> applyCreator(CreatorApplyDTO dto);

    /** 创作者或管理员提交动漫投稿。 */
    Result<Object> submitVideo(VideoDTO dto);

    /** 搜索已有动漫，供投稿页自动填写资料和计算下一集。 */
    Result<Object> searchSubmissionAnime(String title);

    /** 当前用户是否拥有投稿权限。 */
    boolean canCurrentUserSubmit();

    /** 找回密码 */
    Result<Void> forgotPassword(String email);

    /** 使用一次性令牌重置密码 */
    Result<Void> resetPassword(ResetPasswordDTO dto);

    /** 获取追番列表 */
    Result<Object> getFavorites();

    /** 添加追番 */
    Result<Void> addFavorite(Long animeId);

    /** 取消追番 */
    Result<Void> removeFavorite(Long animeId);

    /** 获取观看历史 */
    Result<Object> getHistory();

    Result<Void> clearHistory();

    Result<Object> getVideoActionState(VideoActionDTO dto);

    Result<Object> toggleVideoFavorite(VideoActionDTO dto);

    Result<Object> toggleVideoLike(VideoActionDTO dto);

    Result<Object> getLikedVideos();

    /** 公开的活跃用户列表（不包含敏感字段）。 */
    Result<Object> getTopUsers(int limit);

    /** 按用户名读取公开主页信息。 */
    Result<Object> getPublicProfile(String username);

    /** 关注指定用户。 */
    Result<Object> followUser(Long targetUserId);

    /** 取消关注指定用户。 */
    Result<Object> unfollowUser(Long targetUserId);
}
