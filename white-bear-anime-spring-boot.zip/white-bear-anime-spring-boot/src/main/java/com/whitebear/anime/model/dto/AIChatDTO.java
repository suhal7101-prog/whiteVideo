package com.whitebear.anime.model.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

import java.util.List;
import java.util.Map;

/**
 * AI 对话 DTO
 *
 * @author WhiteBear
 */
@Data
@Schema(description = "AI 对话请求")
public class AIChatDTO {

    @NotBlank(message = "问题不能为空")
    @Schema(description = "用户问题")
    private String question;

    @Schema(description = "对话历史 [{role: 'user'|'assistant', content: '...'}]")
    private List<Map<String, String>> history;
}
