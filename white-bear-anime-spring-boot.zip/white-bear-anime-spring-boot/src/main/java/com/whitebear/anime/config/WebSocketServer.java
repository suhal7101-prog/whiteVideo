package com.whitebear.anime.config;

import com.alibaba.fastjson2.JSON;
import com.whitebear.anime.model.entity.Danmaku;
import jakarta.websocket.*;
import jakarta.websocket.server.PathParam;
import jakarta.websocket.server.ServerEndpoint;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArraySet;

/**
 * WebSocket 弹幕实时通信
 * 匹配前端 WebSocket 配置: ws://localhost:8088/ws/{animeId}
 *
 * @author WhiteBear
 */
@Slf4j
@Component
@ServerEndpoint("/ws/{animeId}")  // 前端 proxy 将 /ws 代理到后端
public class WebSocketServer {

    /** 当前在线连接数 */
    private static int onlineCount = 0;

    /** 存放每个 animeId 对应的客户端连接集合 */
    private static final Map<String, CopyOnWriteArraySet<WebSocketServer>> ROOMS = new ConcurrentHashMap<>();

    /** 当前客户端的 WebSocket 会话 */
    private Session session;

    /** 当前客户端所在的动漫房间 */
    private String animeId;

    /**
     * 连接建立成功时调用
     */
    @OnOpen
    public void onOpen(Session session, @PathParam("animeId") String animeId) {
        this.session = session;
        this.animeId = animeId;

        // 将当前客户端加入对应动漫房间
        ROOMS.computeIfAbsent(animeId, k -> new CopyOnWriteArraySet<>()).add(this);

        // 在线数 +1
        addOnlineCount();
        log.info("[WebSocket] 新连接加入房间 animeId={}, 当前在线: {}", animeId, getOnlineCount());
    }

    /**
     * 连接关闭时调用
     */
    @OnClose
    public void onClose() {
        // 从房间中移除
        CopyOnWriteArraySet<WebSocketServer> room = ROOMS.get(this.animeId);
        if (room != null) {
            room.remove(this);
            if (room.isEmpty()) {
                ROOMS.remove(this.animeId);
            }
        }

        // 在线数 -1
        subOnlineCount();
        log.info("[WebSocket] 连接断开 animeId={}, 当前在线: {}", this.animeId, getOnlineCount());
    }

    /**
     * 收到客户端消息时调用
     */
    @OnMessage
    public void onMessage(String message, Session session) {
        log.debug("[WebSocket] 收到消息 animeId={}: {}", this.animeId, message);
        // 将弹幕消息广播给同一房间的所有客户端
        broadcast(this.animeId, message);
    }

    /**
     * 发生错误时调用
     */
    @OnError
    public void onError(Session session, Throwable error) {
        log.error("[WebSocket] 连接错误 animeId={}: {}", this.animeId, error.getMessage());
    }

    /**
     * 向指定动漫房间的所有客户端广播消息
     * @param animeId 动漫 ID
     * @param message 消息内容（JSON 格式的弹幕数据）
     */
    public static void broadcast(String animeId, String message) {
        CopyOnWriteArraySet<WebSocketServer> room = ROOMS.get(animeId);
        if (room != null) {
            for (WebSocketServer client : room) {
                try {
                    synchronized (client) {
                        client.session.getBasicRemote().sendText(message);
                    }
                } catch (Exception e) {
                    log.error("[WebSocket] 广播消息失败: {}", e.getMessage());
                }
            }
        }
    }

    /**
     * 广播弹幕消息（便捷方法）
     */
    public static void broadcastDanmaku(Long animeId, Danmaku danmaku) {
        String message = JSON.toJSONString(Map.of(
                "type", "danmaku",
                "data", danmaku
        ));
        broadcast(String.valueOf(animeId), message);
    }

    // ==================== 在线数统计 ====================

    public static synchronized int getOnlineCount() {
        return onlineCount;
    }

    public static synchronized void addOnlineCount() {
        onlineCount++;
    }

    public static synchronized void subOnlineCount() {
        onlineCount--;
    }

    /**
     * 获取指定动漫房间的在线人数
     */
    public static int getRoomOnlineCount(String animeId) {
        CopyOnWriteArraySet<WebSocketServer> room = ROOMS.get(animeId);
        return room != null ? room.size() : 0;
    }
}
