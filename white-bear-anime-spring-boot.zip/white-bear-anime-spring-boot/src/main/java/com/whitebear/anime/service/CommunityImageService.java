package com.whitebear.anime.service;

import com.whitebear.anime.config.MinioConfig;
import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.util.UriUtils;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;

/**
 * 社区图片存储。优先使用已配置的 MinIO；开发环境没有 MinIO 时自动落盘。
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class CommunityImageService {

    private static final long MAX_IMAGE_SIZE = 10L * 1024 * 1024;
    private static final Set<String> ALLOWED_EXTENSIONS = Set.of(".png", ".jpg", ".jpeg", ".webp", ".gif");

    private final FileService fileService;
    private final MinioConfig minioConfig;

    @Value("${white-bear.community.storage-dir:./data/community-images}")
    private String storageDir;

    private Path storageRoot;

    @PostConstruct
    void initializeStorage() throws IOException {
        storageRoot = Paths.get(storageDir).toAbsolutePath().normalize();
        Files.createDirectories(storageRoot);
    }

    public String upload(MultipartFile file) throws Exception {
        validate(file);
        if (minioConfig.isConfigured()) {
            try {
                return fileService.uploadImage(file);
            } catch (Exception exception) {
                log.warn("[社区图片] MinIO 上传失败，改用本地存储: {}", exception.getMessage());
            }
        }

        String fileName = "community-" + UUID.randomUUID().toString().replace("-", "")
                + extensionOf(file.getOriginalFilename());
        Path target = storageRoot.resolve(fileName).normalize();
        try (var input = file.getInputStream()) {
            Files.copy(input, target, StandardCopyOption.REPLACE_EXISTING);
        }
        log.info("[社区图片] 已保存到本地: {}", target);
        return "/api/community/image/" + UriUtils.encodePathSegment(fileName, StandardCharsets.UTF_8);
    }

    public Resource getResource(String fileName) {
        if (fileName == null || fileName.isBlank()) throw new IllegalArgumentException("社区图片不存在");
        Path candidate = storageRoot.resolve(fileName).normalize();
        if (!candidate.getParent().equals(storageRoot) || !Files.isRegularFile(candidate)) {
            throw new IllegalArgumentException("社区图片不存在");
        }
        return new FileSystemResource(candidate);
    }

    public String contentType(String fileName) {
        try {
            String detected = Files.probeContentType(storageRoot.resolve(fileName));
            return detected == null ? "application/octet-stream" : detected;
        } catch (IOException ignored) {
            return "application/octet-stream";
        }
    }

    private void validate(MultipartFile file) {
        if (file == null || file.isEmpty()) throw new IllegalArgumentException("请选择图片文件");
        if (file.getSize() > MAX_IMAGE_SIZE) throw new IllegalArgumentException("图片大小不能超过 10MB");
        if (file.getContentType() == null || !file.getContentType().startsWith("image/")) {
            throw new IllegalArgumentException("仅支持图片文件");
        }
        if (!ALLOWED_EXTENSIONS.contains(extensionOf(file.getOriginalFilename()))) {
            throw new IllegalArgumentException("仅支持 PNG、JPG、WEBP 或 GIF 图片");
        }
    }

    private String extensionOf(String fileName) {
        if (fileName == null) return "";
        int dot = fileName.lastIndexOf('.');
        return dot < 0 ? "" : fileName.substring(dot).toLowerCase(Locale.ROOT);
    }
}
