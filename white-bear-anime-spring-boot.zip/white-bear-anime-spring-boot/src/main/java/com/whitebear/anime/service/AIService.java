package com.whitebear.anime.service;

import com.whitebear.anime.model.Result;
import com.whitebear.anime.model.dto.AIAgentDTO;
import com.whitebear.anime.model.dto.AIChatDTO;

import java.util.Map;

/**
 * AI 智能服务接口
 *
 * @author WhiteBear
 */
public interface AIService {

    /** AI 对话 —— 基于 RAG + DeepSeek */
    Result<Object> chat(AIChatDTO dto);

    /** AI 个性化推荐 */
    Result<Object> recommend(Map<String, Object> preferences);

    /** AI 追番助手 Agent */
    Result<Object> agentCommand(AIAgentDTO dto);

    /** 角色信息查询 */
    Result<Object> queryCharacter(String characterName);

    /** RAG 知识库检索 */
    Result<Object> searchKnowledge(String query);
}
