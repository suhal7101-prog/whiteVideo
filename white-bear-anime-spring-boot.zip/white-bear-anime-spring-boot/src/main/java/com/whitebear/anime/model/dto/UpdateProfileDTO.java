package com.whitebear.anime.model.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
 * 更新个人信息 DTO
 *
 * @author WhiteBear
 */
@Data
@Schema(description = "更新个人信息请求")
public class UpdateProfileDTO {

    @Schema(description = "昵称")
    private String nickname;

    @Schema(description = "头像 URL")
    private String avatar;

    @Schema(description = "个人简介")
    private String bio;
}
