package com.whitebear.anime.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.whitebear.anime.model.entity.WatchHistory;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Delete;

import java.util.List;

/**
 * 观看历史 Mapper
 *
 * @author WhiteBear
 */
@Mapper
public interface WatchHistoryMapper extends BaseMapper<WatchHistory> {

    /** 查询用户观看历史（最新在前） */
    @Select("SELECT * FROM wb_watch_history WHERE user_id = #{userId} ORDER BY watched_at DESC LIMIT #{limit}")
    List<WatchHistory> selectByUserId(@Param("userId") Long userId, @Param("limit") int limit);

    /** 查询用户某动漫的观看记录 */
    @Select("SELECT * FROM wb_watch_history WHERE user_id = #{userId} AND anime_id = #{animeId} ORDER BY watched_at DESC LIMIT 1")
    WatchHistory selectByUserAndAnime(@Param("userId") Long userId, @Param("animeId") Long animeId);

    @Delete("DELETE FROM wb_watch_history WHERE user_id = #{userId}")
    int deleteByUserId(@Param("userId") Long userId);
}
