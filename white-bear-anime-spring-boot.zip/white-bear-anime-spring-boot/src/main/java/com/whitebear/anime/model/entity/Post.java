package com.whitebear.anime.model.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * 社区帖子实体
 *
 * @author WhiteBear
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@TableName("wb_post")
public class Post {

    @TableId(type = IdType.AUTO)
    private Long id;

    /** 标题 */
    private String title;

    /** 内容 */
    private String content;

    /** 作者用户 ID */
    private Long authorId;

    /** 标签: 分享 / 追番 / 推荐 / 漫评 / 资讯 */
    private String tag;

    /** 图片 URL 列表, JSON 数组 */
    private String images;

    /** 点赞数 */
    private Integer likes;

    /** 评论数 */
    private Integer comments;

    /** 浏览量 */
    private Integer views;

    /** 分享数 */
    private Integer shares;

    /** 审核状态: pending / approved / rejected */
    private String status;

    @TableLogic
    private Integer deleted;

    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createTime;

    @TableField(fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime updateTime;
}
