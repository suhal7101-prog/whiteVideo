package com.whitebear.anime.model.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Data;

import java.time.LocalDateTime;

@Data
public class AdvertisementDTO {
    @NotBlank(message = "广告标题不能为空")
    @Size(max = 128, message = "广告标题不能超过128个字符")
    private String title;
    @Size(max = 500, message = "广告说明不能超过500个字符")
    private String description;
    @NotBlank(message = "广告图片不能为空")
    private String imageUrl;
    private String targetUrl;
    private String position;
    private String status;
    private LocalDateTime startTime;
    private LocalDateTime endTime;
    private Integer sortOrder;
}
