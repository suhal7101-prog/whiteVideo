package com.whitebear.anime.config;

import io.minio.MinioClient;
import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * MinIO 对象存储配置类
 * 用于存储头像、视频封面、帖子图片等文件
 *
 * @author WhiteBear
 */
@Data
@Configuration
@ConfigurationProperties(prefix = "minio")
public class MinioConfig {

    /** MinIO 服务地址 */
    private String endpoint;

    /** 访问密钥 */
    private String accessKey;

    /** 秘密密钥 */
    private String secretKey;

    /** 存储桶配置 */
    private BucketConfig bucket = new BucketConfig();

    @Data
    public static class BucketConfig {
        private String avatar = "white-bear-avatar";
        private String video = "white-bear-video";
        private String cover = "white-bear-cover";
        private String image = "white-bear-image";
    }

    /**
     * 创建 MinIO 客户端 Bean
     */
    @Bean
    public MinioClient minioClient() {
        return MinioClient.builder()
                .endpoint(endpoint)
                .credentials(accessKey, secretKey)
                .build();
    }

    public boolean isConfigured() {
        return accessKey != null && secretKey != null
                && !"not-configured".equals(accessKey)
                && !"not-configured".equals(secretKey);
    }
}
