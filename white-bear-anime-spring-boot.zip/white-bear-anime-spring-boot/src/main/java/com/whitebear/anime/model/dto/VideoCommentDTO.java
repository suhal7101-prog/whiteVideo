package com.whitebear.anime.model.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Data;

/** 播放器评论或回复请求。 */
@Data
@Schema(description = "播放器评论请求")
public class VideoCommentDTO {

    @NotNull(message = "视频ID不能为空")
    private Long videoId;

    @NotBlank(message = "视频来源不能为空")
    @Pattern(regexp = "db|source", message = "视频来源只能是 db 或 source")
    private String sourceType;

    @Schema(description = "父评论ID，回复时使用")
    private Long parentId;

    @NotBlank(message = "评论内容不能为空")
    @Size(max = 1000, message = "评论内容不能超过1000字")
    private String content;
}
