package com.whitebear.anime.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.whitebear.anime.model.entity.Favorite;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Delete;

import java.util.List;

/**
 * 追番 Mapper
 *
 * @author WhiteBear
 */
@Mapper
public interface FavoriteMapper extends BaseMapper<Favorite> {

    /** 查询用户追番列表 */
    @Select("SELECT * FROM wb_favorite WHERE user_id = #{userId} ORDER BY create_time DESC")
    List<Favorite> selectByUserId(@Param("userId") Long userId);

    /** 检查是否已追番 */
    @Select("SELECT COUNT(*) FROM wb_favorite WHERE user_id = #{userId} AND anime_id = #{animeId}")
    int countByUserAndAnime(@Param("userId") Long userId, @Param("animeId") Long animeId);

    /** 取消追番 */
    @Delete("DELETE FROM wb_favorite WHERE user_id = #{userId} AND anime_id = #{animeId}")
    int deleteByUserAndAnime(@Param("userId") Long userId, @Param("animeId") Long animeId);
}
