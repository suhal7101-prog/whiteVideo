package com.whitebear.anime.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.TimeUnit;

@Service
@RequiredArgsConstructor
public class RankingSyncService {

    private static final int TARGET_NEW_VIDEOS = 100;
    private static final int MAX_SOURCE_PAGES = 15;

    private static final OkHttpClient HTTP_CLIENT = new OkHttpClient.Builder()
            .connectTimeout(5, TimeUnit.SECONDS)
            .readTimeout(40, TimeUnit.SECONDS)
            .build();

    private final JdbcTemplate db;
    private final ObjectMapper objectMapper;

    @Value("${white-bear.python-api-url:http://localhost:8082}")
    private String pythonApiUrl;

    @Transactional
    public Map<String, Object> syncFromPython() {
        int assignedViews = assignMissingViews();
        int assignedLikes = normalizeLikeCounts();
        int created = 0;
        int updated = 0;
        int skipped = 0;
        int pages = 0;
        String warning = null;

        for (int page = 1; page <= MAX_SOURCE_PAGES && created < TARGET_NEW_VIDEOS; page++) {
            JsonNode items;
            try {
                items = fetchSourcePage(page);
                pages++;
            } catch (IOException exception) {
                if (page == 1) {
                    return retainedRanking(exception.getMessage(), assignedViews, assignedLikes);
                }
                warning = "第 " + page + " 页同步失败：" + exception.getMessage();
                break;
            }

            if (items.isEmpty()) {
                warning = "Python 视频源已没有更多数据";
                break;
            }

            for (JsonNode item : items) {
                Long sourceVodId = longOrNull(item.path("vod_id"));
                String title = text(item, "title");
                if (sourceVodId == null || title.isBlank()) {
                    skipped++;
                    continue;
                }

                String cover = firstNonBlank(text(item, "cover_proxy"), text(item, "cover"));
                String category = text(item, "category");
                String description = text(item, "desc");
                String status = text(item, "status");
                String tags = tags(item.path("tags"));
                String region = firstNonBlank(text(item, "area"), "CN");
                BigDecimal rating = decimalOrNull(text(item, "score"));
                Integer year = integerOrNull(text(item, "year"));
                Integer episodes = positiveOrNull(item.path("total_episodes").asInt(item.path("episodes").asInt(0)));

                List<Long> ids = db.queryForList(
                        "SELECT id FROM wb_video WHERE source_vod_id = ? AND deleted = 0 ORDER BY id ASC LIMIT 1",
                        Long.class, sourceVodId);
                if (ids.isEmpty()) {
                    ids = db.queryForList(
                            "SELECT id FROM wb_video WHERE title = ? AND deleted = 0 ORDER BY id ASC LIMIT 1",
                            Long.class, title);
                }
                if (ids.isEmpty()) {
                    if (created >= TARGET_NEW_VIDEOS) break;
                    db.update(
                            "INSERT INTO wb_video(title,source_vod_id,cover,category,description,status,rating,views,likes,episodes,tags,`year`,region,deleted) " +
                                    "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,0)",
                            title, sourceVodId, cover, category, description, status, rating,
                            randomViews(), randomLikes(), episodes, tags, year, region
                    );
                    created++;
                } else {
                    db.update(
                            "UPDATE wb_video SET " +
                                    "source_vod_id=?, " +
                                    "cover=COALESCE(NULLIF(?, ''), cover), " +
                                    "category=COALESCE(NULLIF(?, ''), category), " +
                                    "description=COALESCE(NULLIF(?, ''), description), " +
                                    "status=COALESCE(NULLIF(?, ''), status), " +
                                    "rating=COALESCE(?, rating), episodes=COALESCE(?, episodes), " +
                                    "tags=COALESCE(NULLIF(?, ''), tags), `year`=COALESCE(?, `year`), " +
                                    "region=COALESCE(NULLIF(?, ''), region), update_time=NOW() " +
                                    "WHERE id = ? AND deleted = 0",
                            sourceVodId, cover, category, description, status, rating, episodes, tags, year, region, ids.get(0)
                    );
                    updated++;
                }
            }
        }

        Map<String, Object> result = new LinkedHashMap<>();
        result.put("created", created);
        result.put("updated", updated);
        result.put("skipped", skipped);
        result.put("assignedViews", assignedViews);
        result.put("assignedLikes", assignedLikes);
        result.put("pages", pages);
        result.put("total", created + updated);
        result.put("synced", true);
        if (warning != null) result.put("warning", warning);
        return result;
    }

    private JsonNode fetchSourcePage(int page) throws IOException {
        String endpoint = pythonApiUrl.replaceAll("/+$", "") + "/api/anime/hot?count=60&page=" + page;
        Request request = new Request.Builder().url(endpoint).get().build();
        try (Response response = HTTP_CLIENT.newCall(request).execute()) {
            if (!response.isSuccessful() || response.body() == null) {
                throw new IOException("Python 视频服务返回 HTTP " + response.code());
            }
            JsonNode root = objectMapper.readTree(response.body().string());
            JsonNode items = root.path("data").path("list");
            if (root.path("code").asInt(-1) != 200 || !items.isArray()) {
                throw new IOException("Python 视频服务返回格式不正确");
            }
            return items;
        }
    }

    private int assignMissingViews() {
        List<Long> ids = db.queryForList(
                "SELECT id FROM wb_video WHERE deleted = 0 AND COALESCE(views, 0) <= 0",
                Long.class
        );
        for (Long id : ids) {
            db.update("UPDATE wb_video SET views = ?, update_time = NOW() WHERE id = ?", randomViews(), id);
        }
        return ids.size();
    }

    private long randomViews() {
        return ThreadLocalRandom.current().nextLong(500, 901);
    }

    private int normalizeLikeCounts() {
        List<Long> ids = db.queryForList(
                "SELECT id FROM wb_video WHERE deleted = 0 AND (likes IS NULL OR likes < 500 OR likes > 900)",
                Long.class
        );
        for (Long id : ids) {
            db.update("UPDATE wb_video SET likes = ?, update_time = NOW() WHERE id = ?", randomLikes(), id);
        }
        return ids.size();
    }

    private long randomLikes() {
        return ThreadLocalRandom.current().nextLong(500, 901);
    }

    private Map<String, Object> retainedRanking(String reason, int assignedViews, int assignedLikes) {
        Integer retained = db.queryForObject(
                "SELECT COUNT(*) FROM wb_video WHERE deleted = 0",
                Integer.class
        );
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("created", 0);
        result.put("updated", 0);
        result.put("skipped", 0);
        result.put("total", 0);
        result.put("retained", retained == null ? 0 : retained);
        result.put("assignedViews", assignedViews);
        result.put("assignedLikes", assignedLikes);
        result.put("synced", false);
        result.put("warning", "Python 视频源暂时不可用，已保留数据库现有排行榜：" + reason);
        return result;
    }

    private String text(JsonNode node, String field) {
        JsonNode value = node.path(field);
        return value.isMissingNode() || value.isNull() ? "" : value.asText("").trim();
    }

    private String tags(JsonNode node) {
        if (node.isArray()) {
            StringBuilder value = new StringBuilder();
            for (JsonNode tag : node) {
                if (!value.isEmpty()) value.append(',');
                value.append(tag.asText());
            }
            return value.toString();
        }
        return node.asText("").trim();
    }

    private String firstNonBlank(String first, String fallback) {
        return first == null || first.isBlank() ? fallback : first;
    }

    private BigDecimal decimalOrNull(String value) {
        try {
            return value == null || value.isBlank() ? null : new BigDecimal(value);
        } catch (NumberFormatException exception) {
            return null;
        }
    }

    private Integer integerOrNull(String value) {
        try {
            return value == null || value.isBlank() ? null : Integer.valueOf(value);
        } catch (NumberFormatException exception) {
            return null;
        }
    }

    private Integer positiveOrNull(int value) {
        return value > 0 ? value : null;
    }

    private Long longOrNull(JsonNode value) {
        return value != null && value.canConvertToLong() && value.asLong() > 0 ? value.asLong() : null;
    }
}
