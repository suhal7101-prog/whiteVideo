package com.whitebear.anime.service;

import com.whitebear.anime.model.Result;

public interface AnnouncementService {

    Result<Object> getMyAnnouncements();

    Result<Void> markRead(Long announcementId);
}
