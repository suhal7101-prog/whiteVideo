package com.whitebear.anime.model.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;

import java.util.List;

/**
 * 发表评论 DTO
 *
 * @author WhiteBear
 */
@Data
@Schema(description = "发表评论请求")
public class CommentDTO {

    @NotNull(message = "帖子ID不能为空")
    @Schema(description = "帖子 ID")
    private Long postId;

    @Schema(description = "父评论 ID（回复时使用）")
    private Long parentId;

    @Schema(description = "评论内容")
    private String content;

    @Size(max = 9, message = "评论图片最多上传9张")
    @Schema(description = "评论图片 URL 列表")
    private List<String> images;
}
