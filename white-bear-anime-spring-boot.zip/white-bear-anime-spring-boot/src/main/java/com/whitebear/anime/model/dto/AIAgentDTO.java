package com.whitebear.anime.model.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

/**
 * AI 追番助手 Agent DTO
 *
 * @author WhiteBear
 */
@Data
@Schema(description = "AI 追番助手指令")
public class AIAgentDTO {

    @NotBlank(message = "指令不能为空")
    @Schema(description = "用户自然语言指令: 如'帮我找到类似进击的巨人的动漫'")
    private String command;
}
