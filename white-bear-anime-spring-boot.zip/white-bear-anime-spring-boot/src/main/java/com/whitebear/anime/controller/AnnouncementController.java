package com.whitebear.anime.controller;

import com.whitebear.anime.model.Result;
import com.whitebear.anime.service.AnnouncementService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/announcements")
@RequiredArgsConstructor
public class AnnouncementController {

    private final AnnouncementService announcementService;

    @GetMapping
    public Result<?> getMyAnnouncements() {
        return announcementService.getMyAnnouncements();
    }

    @PostMapping("/{id}/read")
    public Result<?> markRead(@PathVariable Long id) {
        return announcementService.markRead(id);
    }
}
