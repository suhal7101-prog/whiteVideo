package com.whitebear.anime.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.whitebear.anime.model.entity.User;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * 用户 Mapper
 *
 * @author WhiteBear
 */
@Mapper
public interface UserMapper extends BaseMapper<User> {

    /** 根据邮箱查询用户 */
    @Select("SELECT * FROM wb_user WHERE email = #{email} AND deleted = 0")
    User findByEmail(@Param("email") String email);

    @Select("SELECT * FROM wb_user WHERE username = #{username} AND deleted = 0 LIMIT 1")
    User findByUsername(@Param("username") String username);

    @Select("SELECT * FROM wb_user WHERE deleted = 0 ORDER BY last_login DESC, create_time DESC LIMIT #{limit}")
    List<User> selectTopUsers(@Param("limit") int limit);

    /** 统计总用户数 */
    @Select("SELECT COUNT(*) FROM wb_user WHERE deleted = 0")
    Long countTotalUsers();

    /** 统计今日新增用户 */
    @Select("SELECT COUNT(*) FROM wb_user WHERE deleted = 0 AND DATE(register_date) = CURDATE()")
    Long countTodayNewUsers();
}
