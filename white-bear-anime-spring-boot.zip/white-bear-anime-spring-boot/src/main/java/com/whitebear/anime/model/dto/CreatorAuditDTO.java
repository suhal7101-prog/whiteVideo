package com.whitebear.anime.model.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Data;

/** 管理员审核创作者申请请求。 */
@Data
@Schema(description = "创作者申请审核请求")
public class CreatorAuditDTO {

    @NotBlank(message = "审核结果不能为空")
    @Pattern(regexp = "approved|rejected", message = "审核结果只能是 approved 或 rejected")
    private String status;

    @Size(max = 500, message = "审核说明不能超过500个字符")
    private String reason;
}
