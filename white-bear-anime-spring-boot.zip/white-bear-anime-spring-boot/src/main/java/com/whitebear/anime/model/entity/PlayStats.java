package com.whitebear.anime.model.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * 播放统计实体
 *
 * @author WhiteBear
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@TableName("wb_play_stats")
public class PlayStats {

    @TableId(type = IdType.AUTO)
    private Long id;

    /** 视频 ID */
    private Long videoId;

    /** 剧集 ID */
    private Long episodeId;

    /** 用户 ID */
    private Long userId;

    /** IP 地址 */
    private String ip;

    /** 播放日期 */
    private LocalDate playDate;

    /** 播放次数 */
    private Integer playCount;

    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createTime;
}
