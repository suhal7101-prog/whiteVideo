package com.whitebear.anime.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.socket.server.standard.ServerEndpointExporter;

/**
 * WebSocket 配置类
 * 启用 WebSocket 并注册 ServerEndpoint
 *
 * @author WhiteBear
 */
@Configuration
public class WebSocketConfig {

    /**
     * 自动注册 @ServerEndpoint 注解的 WebSocket 端点
     */
    @Bean
    public ServerEndpointExporter serverEndpointExporter() {
        return new ServerEndpointExporter();
    }
}
