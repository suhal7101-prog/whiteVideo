package com.whitebear.anime.service.impl;

import com.whitebear.anime.mapper.BannerEffectMapper;
import com.whitebear.anime.model.Result;
import com.whitebear.anime.model.dto.BannerEffectDTO;
import com.whitebear.anime.model.entity.BannerEffect;
import com.whitebear.anime.service.BannerEffectService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

@Service
@RequiredArgsConstructor
public class BannerEffectServiceImpl implements BannerEffectService {
    private static final Set<String> ALLOWED_PAGES = Set.of("ai", "community");
    private static final Set<String> ALLOWED_STATUSES = Set.of("active", "inactive");

    private final BannerEffectMapper bannerEffectMapper;

    @Override
    public Result<Object> getAdminEffects() {
        List<BannerEffect> list = bannerEffectMapper.selectAllOrdered();
        Map<String, Object> data = new LinkedHashMap<>();
        data.put("list", list);
        data.put("total", list.size());
        data.put("active", list.stream().filter(item -> "active".equals(item.getStatus())).count());
        return Result.ok(data);
    }

    @Override
    public Result<Object> getActiveEffects(String targetPage) {
        String page = normalize(targetPage, "ai");
        if (!ALLOWED_PAGES.contains(page)) page = "ai";
        List<BannerEffect> list = bannerEffectMapper.selectActive(page);
        return Result.ok(Map.of("list", list, "total", list.size()));
    }

    @Override
    @Transactional
    public Result<Object> updateEffect(Long id, BannerEffectDTO dto) {
        BannerEffect effect = bannerEffectMapper.selectById(id);
        if (effect == null) return Result.notFound("效果图不存在");

        String status = normalize(dto.getStatus(), "active");
        String page = normalize(dto.getTargetPage(), "ai");
        if (!ALLOWED_STATUSES.contains(status)) return Result.badRequest("效果图状态无效");
        if (!ALLOWED_PAGES.contains(page)) return Result.badRequest("投放页面无效");

        effect.setName(dto.getName().trim());
        effect.setStatus(status);
        effect.setTargetPage(page);
        effect.setSortOrder(dto.getSortOrder() == null ? 0 : dto.getSortOrder());
        bannerEffectMapper.updateById(effect);
        return Result.ok("效果图更新成功", Map.of("id", effect.getId()));
    }

    private String normalize(String value, String fallback) {
        return value == null || value.isBlank() ? fallback : value.trim().toLowerCase(Locale.ROOT);
    }
}
