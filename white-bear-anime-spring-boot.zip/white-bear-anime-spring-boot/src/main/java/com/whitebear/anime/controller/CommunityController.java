package com.whitebear.anime.controller;

import com.whitebear.anime.model.Result;
import com.whitebear.anime.model.dto.*;
import com.whitebear.anime.service.CommunityImageService;
import com.whitebear.anime.service.CommunityService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.core.io.Resource;
import org.springframework.http.CacheControl;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.multipart.MultipartFile;

import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * 社区控制器
 * 匹配前端 API: /api/community/*
 *
 * @author WhiteBear
 */
@Tag(name = "社区模块", description = "帖子、评论、点赞、弹幕")
@RestController
@RequestMapping("/api/community")
@RequiredArgsConstructor
public class CommunityController {

    private final CommunityService communityService;
    private final CommunityImageService communityImageService;

    @Operation(summary = "获取帖子列表")
    @GetMapping("/posts")
    public Result<?> getPosts(
            @RequestParam(defaultValue = "all") String sort,
            @RequestParam(defaultValue = "1") int page,
            @RequestParam(defaultValue = "5") int size,
            @RequestParam(required = false) String topic,
            @RequestParam(required = false) Long authorId) {
        return communityService.getPosts(sort, page, size, topic, authorId);
    }

    @Operation(summary = "获取帖子详情")
    @GetMapping("/post/{id}")
    public Result<?> getPostDetail(@PathVariable Long id) {
        return communityService.getPostDetail(id);
    }

    @Operation(summary = "发布帖子")
    @PostMapping("/post")
    public Result<?> createPost(@Valid @RequestBody PostDTO dto) {
        return communityService.createPost(dto);
    }

    @Operation(summary = "删除帖子")
    @DeleteMapping("/post/{id}")
    public Result<?> deletePost(@PathVariable Long id) {
        return communityService.deletePost(id);
    }

    @Operation(summary = "发表评论")
    @PostMapping("/comment")
    public Result<?> addComment(@Valid @RequestBody CommentDTO dto) {
        return communityService.addComment(dto);
    }

    @Operation(summary = "点赞/取消点赞")
    @PostMapping("/like")
    public Result<?> toggleLike(@Valid @RequestBody LikeDTO dto) {
        return communityService.toggleLike(dto);
    }

    @Operation(summary = "分享")
    @PostMapping("/share")
    public Result<?> share(@RequestBody LikeDTO dto) {
        return communityService.share(dto.getTargetId());
    }

    @Operation(summary = "获取弹幕列表")
    @GetMapping("/danmaku/{animeId}")
    public Result<?> getDanmaku(
            @PathVariable Long animeId,
            @RequestParam(required = false) Long episodeId) {
        return communityService.getDanmaku(animeId, episodeId);
    }

    @Operation(summary = "发送弹幕")
    @PostMapping("/danmaku")
    public Result<?> sendDanmaku(@Valid @RequestBody DanmakuDTO dto) {
        return communityService.sendDanmaku(dto);
    }

    @Operation(summary = "上传帖子图片")
    @PostMapping(value = "/image", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public Result<?> uploadImage(@RequestPart("file") MultipartFile file) throws Exception {
        return Result.ok(Map.of("url", communityImageService.upload(file)));
    }

    @Operation(summary = "读取本地社区图片")
    @GetMapping("/image/{fileName:.+}")
    public ResponseEntity<Resource> getImage(@PathVariable String fileName) {
        Resource resource = communityImageService.getResource(fileName);
        return ResponseEntity.ok()
                .contentType(MediaType.parseMediaType(communityImageService.contentType(fileName)))
                .cacheControl(CacheControl.maxAge(1, TimeUnit.DAYS).cachePublic())
                .body(resource);
    }
}
