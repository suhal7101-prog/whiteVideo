package com.whitebear.anime.controller;

import com.whitebear.anime.model.Result;
import com.whitebear.anime.model.dto.VideoCommentDTO;
import com.whitebear.anime.service.VideoCommentService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@Tag(name = "播放器评论", description = "视频评论、回复与点赞")
@RestController
@RequestMapping("/api/video-comments")
@RequiredArgsConstructor
public class VideoCommentController {

    private final VideoCommentService videoCommentService;

    @Operation(summary = "获取当前视频的评论")
    @GetMapping
    public Result<?> list(@RequestParam Long videoId, @RequestParam String sourceType) {
        return videoCommentService.listComments(videoId, sourceType);
    }

    @Operation(summary = "发表评论或回复")
    @PostMapping
    public Result<?> add(@Valid @RequestBody VideoCommentDTO dto) {
        return videoCommentService.addComment(dto);
    }

    @Operation(summary = "点赞或取消点赞")
    @PostMapping("/{commentId}/like")
    public Result<?> toggleLike(@PathVariable Long commentId) {
        return videoCommentService.toggleLike(commentId);
    }
}
