package com.whitebear.anime.service.impl;

import com.whitebear.anime.mapper.LikeMapper;
import com.whitebear.anime.mapper.UserMapper;
import com.whitebear.anime.mapper.VideoCommentMapper;
import com.whitebear.anime.model.Result;
import com.whitebear.anime.model.dto.VideoCommentDTO;
import com.whitebear.anime.model.entity.Like;
import com.whitebear.anime.model.entity.User;
import com.whitebear.anime.model.entity.VideoComment;
import com.whitebear.anime.security.SecurityUtils;
import com.whitebear.anime.service.VideoCommentService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

@Service
@RequiredArgsConstructor
public class VideoCommentServiceImpl implements VideoCommentService {

    private static final String LIKE_TYPE = "video_comment";

    private final VideoCommentMapper videoCommentMapper;
    private final UserMapper userMapper;
    private final LikeMapper likeMapper;

    @Override
    public Result<Object> listComments(Long videoId, String sourceType) {
        String normalizedSource = normalizeSource(sourceType);
        if (videoId == null || videoId <= 0 || normalizedSource == null) {
            return Result.badRequest("视频参数无效");
        }

        List<VideoComment> comments = videoCommentMapper.selectByVideo(videoId, normalizedSource);
        Map<Long, VideoComment> commentById = new HashMap<>();
        for (VideoComment comment : comments) {
            commentById.put(comment.getId(), comment);
        }

        Long currentUserId = SecurityUtils.getCurrentUserId();
        Map<Long, User> userCache = new HashMap<>();
        List<Map<String, Object>> items = new ArrayList<>();
        for (VideoComment comment : comments) {
            User author = findUser(comment.getUserId(), userCache);
            User replyUser = null;
            if (comment.getParentId() != null) {
                VideoComment parent = commentById.get(comment.getParentId());
                if (parent == null) {
                    parent = videoCommentMapper.selectById(comment.getParentId());
                }
                if (parent != null) {
                    replyUser = findUser(parent.getUserId(), userCache);
                }
            }
            items.add(toMap(comment, author, replyUser, currentUserId));
        }

        Map<String, Object> data = new HashMap<>();
        data.put("list", items);
        data.put("total", items.size());
        return Result.ok(data);
    }

    @Override
    @Transactional
    public Result<Object> addComment(VideoCommentDTO dto) {
        Long userId = SecurityUtils.getCurrentUserId();
        if (userId == null) {
            return Result.unauthorized("请先登录");
        }

        String sourceType = normalizeSource(dto.getSourceType());
        if (dto.getVideoId() == null || dto.getVideoId() <= 0 || sourceType == null) {
            return Result.badRequest("视频参数无效");
        }

        VideoComment parent = null;
        if (dto.getParentId() != null) {
            parent = videoCommentMapper.selectById(dto.getParentId());
            if (parent == null || Objects.equals(parent.getDeleted(), 1)
                    || !Objects.equals(parent.getVideoId(), dto.getVideoId())
                    || !Objects.equals(parent.getSourceType(), sourceType)) {
                return Result.badRequest("回复的评论不存在或不属于当前视频");
            }
        }

        VideoComment comment = VideoComment.builder()
                .videoId(dto.getVideoId())
                .sourceType(sourceType)
                .userId(userId)
                .parentId(dto.getParentId())
                .content(dto.getContent().trim())
                .likes(0)
                .deleted(0)
                .createTime(LocalDateTime.now())
                .build();
        videoCommentMapper.insert(comment);

        User author = userMapper.selectById(userId);
        User replyUser = parent == null ? null : userMapper.selectById(parent.getUserId());
        return Result.ok("评论成功", toMap(comment, author, replyUser, userId));
    }

    @Override
    @Transactional
    public Result<Object> toggleLike(Long commentId) {
        Long userId = SecurityUtils.getCurrentUserId();
        if (userId == null) {
            return Result.unauthorized("请先登录");
        }

        VideoComment comment = videoCommentMapper.selectById(commentId);
        if (comment == null || Objects.equals(comment.getDeleted(), 1)) {
            return Result.notFound("评论不存在");
        }

        boolean alreadyLiked = likeMapper.countByUserAndTarget(userId, commentId, LIKE_TYPE) > 0;
        int likes = comment.getLikes() == null ? 0 : comment.getLikes();
        boolean liked;
        if (alreadyLiked) {
            likeMapper.deleteByUserAndTarget(userId, commentId, LIKE_TYPE);
            videoCommentMapper.decrementLikes(commentId);
            liked = false;
            likes = Math.max(0, likes - 1);
        } else {
            likeMapper.insert(Like.builder()
                    .userId(userId)
                    .targetId(commentId)
                    .type(LIKE_TYPE)
                    .build());
            videoCommentMapper.incrementLikes(commentId);
            liked = true;
            likes += 1;
        }

        return Result.ok(Map.of("liked", liked, "likes", likes));
    }

    private User findUser(Long userId, Map<Long, User> cache) {
        if (userId == null) {
            return null;
        }
        if (!cache.containsKey(userId)) {
            cache.put(userId, userMapper.selectById(userId));
        }
        return cache.get(userId);
    }

    private Map<String, Object> toMap(VideoComment comment, User author, User replyUser, Long currentUserId) {
        Map<String, Object> item = new HashMap<>();
        item.put("id", comment.getId());
        item.put("videoId", comment.getVideoId());
        item.put("sourceType", comment.getSourceType());
        item.put("userId", comment.getUserId());
        item.put("username", author == null ? "匿名用户" : author.getUsername());
        item.put("avatar", author == null || author.getAvatar() == null ? "" : author.getAvatar());
        item.put("parentId", comment.getParentId());
        item.put("replyTo", replyUser == null ? "" : replyUser.getUsername());
        item.put("content", comment.getContent());
        item.put("likes", comment.getLikes() == null ? 0 : comment.getLikes());
        item.put("liked", currentUserId != null
                && likeMapper.countByUserAndTarget(currentUserId, comment.getId(), LIKE_TYPE) > 0);
        item.put("createTime", comment.getCreateTime() == null ? "" : comment.getCreateTime().toString());
        return item;
    }

    private String normalizeSource(String sourceType) {
        if (sourceType == null) {
            return null;
        }
        String normalized = sourceType.trim().toLowerCase();
        return "db".equals(normalized) || "source".equals(normalized) ? normalized : null;
    }
}
