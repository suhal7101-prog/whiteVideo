package com.whitebear.anime.security;

import io.jsonwebtoken.*;
import io.jsonwebtoken.security.Keys;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.util.Date;
import java.util.Map;

/**
 * JWT 令牌工具类
 * 功能: 生成 Token、解析 Token、验证 Token 有效性
 *
 * @author WhiteBear
 */
@Slf4j
@Component
public class JwtUtils {

    /** JWT 签名密钥 */
    private final SecretKey secretKey;

    /** Token 有效期（毫秒） */
    private final long expiration;

    /** Token 请求头名称 */
    @Value("${jwt.header:Authorization}")
    private String header;

    /** Token 前缀 */
    @Value("${jwt.token-prefix:Bearer }")
    private String tokenPrefix;

    /**
     * 构造器 —— 从配置文件读取密钥和过期时间
     */
    public JwtUtils(
            @Value("${jwt.secret}") String secret,
            @Value("${jwt.expiration}") long expiration) {
        byte[] keyBytes;
        if (secret == null || secret.isBlank()) {
            keyBytes = new byte[32];
            new SecureRandom().nextBytes(keyBytes);
            log.warn("[JWT] 未配置 JWT_SECRET，已生成仅本次启动有效的临时密钥");
        } else {
            keyBytes = secret.getBytes(StandardCharsets.UTF_8);
            if (keyBytes.length < 32) {
                throw new IllegalArgumentException("JWT_SECRET 至少需要 32 字节");
            }
        }
        this.secretKey = Keys.hmacShaKeyFor(keyBytes);
        this.expiration = expiration;
    }

    /**
     * 生成 JWT Token
     *
     * @param userId   用户 ID
     * @param email    用户邮箱
     * @param role     用户角色
     * @param claims   额外声明信息
     * @return JWT Token 字符串
     */
    public String generateToken(Long userId, String email, String role, Map<String, Object> claims) {
        Date now = new Date();
        Date expiryDate = new Date(now.getTime() + expiration);

        JwtBuilder builder = Jwts.builder()
                // 标准声明
                .subject(email)                      // 主体 → 邮箱
                .issuedAt(now)                       // 签发时间
                .expiration(expiryDate)              // 过期时间
                // 自定义声明
                .claim("userId", userId)
                .claim("role", role);

        // 附加额外声明
        if (claims != null && !claims.isEmpty()) {
            claims.forEach((k, v) -> {
                if (!"userId".equals(k) && !"role".equals(k) && !"sub".equals(k)) {
                    builder.claim(k, v);
                }
            });
        }

        return builder.signWith(secretKey).compact();
    }

    /**
     * 简化版 —— 生成 JWT Token
     */
    public String generateToken(Long userId, String email, String role) {
        return generateToken(userId, email, role, null);
    }

    /**
     * 从 Token 中解析所有声明
     */
    public Claims parseToken(String token) {
        return Jwts.parser()
                .verifyWith(secretKey)
                .build()
                .parseSignedClaims(token)
                .getPayload();
    }

    /**
     * 从 Token 中获取用户 ID
     */
    public Long getUserId(String token) {
        return parseToken(token).get("userId", Long.class);
    }

    /**
     * 从 Token 中获取邮箱（subject）
     */
    public String getEmail(String token) {
        return parseToken(token).getSubject();
    }

    /**
     * 从 Token 中获取角色
     */
    public String getRole(String token) {
        return parseToken(token).get("role", String.class);
    }

    /**
     * 验证 Token 是否有效
     */
    public boolean validateToken(String token) {
        try {
            parseToken(token);
            return true;
        } catch (ExpiredJwtException e) {
            log.warn("[JWT] Token 已过期: {}", e.getMessage());
        } catch (UnsupportedJwtException e) {
            log.warn("[JWT] 不支持的 Token: {}", e.getMessage());
        } catch (MalformedJwtException e) {
            log.warn("[JWT] Token 格式错误: {}", e.getMessage());
        } catch (SignatureException e) {
            log.warn("[JWT] Token 签名无效: {}", e.getMessage());
        } catch (IllegalArgumentException e) {
            log.warn("[JWT] Token 参数异常: {}", e.getMessage());
        }
        return false;
    }
}
