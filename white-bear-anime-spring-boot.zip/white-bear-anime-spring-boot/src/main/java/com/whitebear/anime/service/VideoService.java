package com.whitebear.anime.service;

import com.whitebear.anime.model.Result;

import java.util.Map;

/**
 * 动漫/视频服务接口
 *
 * @author WhiteBear
 */
public interface VideoService {

    /** 获取热门视频列表 */
    Result<Map<String, Object>> getHotVideos(int count, int page);

    /** 获取视频详情 */
    Result<Map<String, Object>> getVideoDetail(Long videoId);

    /** 获取剧集列表 */
    Result<Object> getEpisodes(Long videoId);

    /** 搜索视频 */
    Result<Object> searchVideos(String keyword, int page);

    /** 获取排行榜 */
    Result<Object> getRankings(String type);

    /** 获取分类列表 */
    Result<Object> getCategories();

    /** 从数据库分页筛选视频。 */
    Result<Object> discoverVideos(int page, int size, String keyword, String category, String sort);

    /** 获取同分类的数据库视频推荐。 */
    Result<Object> getRelatedVideos(Long videoId, int count);

    /** 根据分类获取视频 */
    Result<Object> getVideosByCategory(String category, int page);

    /** 记录播放量 */
    Result<Void> recordPlay(Long videoId, Long episodeId);

    /** 按标题记录 Python 视频播放量。 */
    Result<Void> recordPlayByTitle(String title);

    /** 按 Python 资源站 ID 记录播放量。 */
    Result<Void> recordPlayBySourceVodId(Long sourceVodId);
}
