package com.whitebear.anime.service;

import com.whitebear.anime.model.Result;
import com.whitebear.anime.model.dto.BannerEffectDTO;

public interface BannerEffectService {
    Result<Object> getAdminEffects();
    Result<Object> getActiveEffects(String targetPage);
    Result<Object> updateEffect(Long id, BannerEffectDTO dto);
}
