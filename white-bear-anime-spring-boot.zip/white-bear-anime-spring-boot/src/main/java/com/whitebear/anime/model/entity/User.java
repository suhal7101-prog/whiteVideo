package com.whitebear.anime.model.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * 用户实体
 * 
 * @author WhiteBear
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@TableName("wb_user")
public class User {

    @TableId(type = IdType.AUTO)
    private Long id;

    /** 用户名 */
    private String username;

    /** 邮箱（登录账号） */
    private String email;

    /** BCrypt 加密后的密码 */
    private String password;

    /** 头像 URL */
    private String avatar;

    /** 昵称 */
    private String nickname;

    /** 个人简介 */
    private String bio;

    /** 角色: user / creator / admin / moderator */
    private String role;

    /** 状态: active / banned */
    private String status;

    /** 注册日期 */
    private LocalDateTime registerDate;

    /** 最后登录时间 */
    private LocalDateTime lastLogin;

    /** 追番数 */
    private Integer favoriteCount;

    /** 创作者申请状态: pending / approved / rejected */
    private String creatorApplyStatus;

    /** 用户提交的创作者申请信息 */
    private String creatorApplyMessage;

    /** 创作者申请审核说明 */
    private String creatorApplyReason;

    /** 创作者申请时间 */
    private LocalDateTime creatorApplyTime;

    /** 创作者申请审核时间 */
    private LocalDateTime creatorAuditTime;

    /** 审核管理员 ID */
    private Long creatorAuditorId;

    /** 逻辑删除 */
    @TableLogic
    private Integer deleted;

    /** 创建时间 */
    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createTime;

    /** 更新时间 */
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime updateTime;
}
