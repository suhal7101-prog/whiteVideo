package com.whitebear.anime.model.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * 视频/动漫实体
 *
 * @author WhiteBear
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@TableName("wb_video")
public class Video {

    @TableId(type = IdType.AUTO)
    private Long id;

    /** 标题 */
    private String title;

    /** Python 资源站中的真实视频 ID */
    private Long sourceVodId;

    /** 封面图片 URL */
    private String cover;

    /** 分类 */
    private String category;

    /** 简介 */
    private String description;

    /** 状态: 连载中 / 已完结 */
    private String status;

    /** 评分 0.0~10.0 */
    private BigDecimal rating;

    /** 播放量 */
    private Long views;

    /** 点赞数 */
    private Long likes;

    /** 总集数 */
    private Integer episodes;

    /** 标签, 逗号分隔 */
    private String tags;

    /** 播出年份 */
    private Integer year;

    /** 季度 */
    private String season;

    /** 制作公司 */
    private String studio;

    /** 地区 */
    private String region;

    /** 内容来源: platform / user */
    private String submissionSource;

    /** 投稿用户 ID，平台内容为空 */
    private Long uploaderId;

    /** 投稿审核状态: pending / approved / rejected */
    private String auditStatus;

    /** 审核拒绝原因 */
    private String auditReason;

    /** 审核管理员 ID */
    private Long auditorId;

    /** 投稿时间 */
    private LocalDateTime submitTime;

    /** 审核时间 */
    private LocalDateTime auditTime;

    @TableLogic
    private Integer deleted;

    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createTime;

    @TableField(fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime updateTime;
}
