package com.whitebear.anime.aspect;

import com.alibaba.fastjson2.JSON;
import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import java.util.Locale;
import java.util.Map;

/**
 * 接口日志切面
 * 自动记录所有 Controller 方法的请求和响应日志
 *
 * @author WhiteBear
 */
@Slf4j
@Aspect
@Component
public class LogAspect {

    /** 切点: 所有 com.whitebear.anime.controller 包下的 public 方法 */
    @Pointcut("execution(public * com.whitebear.anime.controller..*.*(..))")
    public void controllerLog() {}

    /**
     * 环绕通知 —— 记录请求参数、响应结果、耗时
     */
    @Around("controllerLog()")
    public Object logAround(ProceedingJoinPoint joinPoint) throws Throwable {
        long startTime = System.currentTimeMillis();

        // 获取请求信息
        ServletRequestAttributes attributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        String requestUrl = "";
        String method = "";
        String ip = "";
        if (attributes != null) {
            HttpServletRequest request = attributes.getRequest();
            requestUrl = request.getRequestURI();
            method = request.getMethod();
            ip = getClientIp(request);
        }

        // 获取方法签名和执行参数
        String className = joinPoint.getSignature().getDeclaringType().getSimpleName();
        String methodName = joinPoint.getSignature().getName();
        String args = serializeArgs(joinPoint.getArgs());

        log.info("[请求] {} {} {} | {}.{} | 参数: {}",
                ip, method, requestUrl, className, methodName,
                args.length() > 500 ? args.substring(0, 500) + "..." : args);

        // 执行目标方法
        Object result;
        try {
            result = joinPoint.proceed();
        } catch (Throwable e) {
            log.error("[异常] {} {} {}", method, requestUrl, e.getMessage());
            throw e;
        }

        long elapsed = System.currentTimeMillis() - startTime;
        log.info("[响应] {} {} | 耗时: {}ms", method, requestUrl, elapsed);

        return result;
    }

    static String serializeArgs(Object[] args) {
        try {
            Object jsonTree = JSON.toJSON(args);
            redactSensitiveValues(jsonTree);
            return JSON.toJSONString(jsonTree);
        } catch (Exception exception) {
            return "[参数无法序列化]";
        }
    }

    @SuppressWarnings("unchecked")
    private static void redactSensitiveValues(Object value) {
        if (value instanceof Map<?, ?> map) {
            for (Map.Entry<?, ?> entry : map.entrySet()) {
                String key = String.valueOf(entry.getKey()).toLowerCase(Locale.ROOT);
                if (isSensitiveKey(key)) {
                    ((Map<Object, Object>) map).put(entry.getKey(), "***");
                } else {
                    redactSensitiveValues(entry.getValue());
                }
            }
        } else if (value instanceof Iterable<?> iterable) {
            iterable.forEach(LogAspect::redactSensitiveValues);
        }
    }

    private static boolean isSensitiveKey(String key) {
        return key.contains("password") || key.contains("secret") || key.contains("token")
                || key.contains("authorization") || key.contains("apikey") || key.contains("api-key");
    }

    /**
     * 获取客户端真实 IP
     */
    private String getClientIp(HttpServletRequest request) {
        String ip = request.getHeader("X-Forwarded-For");
        if (ip == null || ip.isEmpty() || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("X-Real-IP");
        }
        if (ip == null || ip.isEmpty() || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getRemoteAddr();
        }
        // 多个 IP 时取第一个
        if (ip != null && ip.contains(",")) {
            ip = ip.split(",")[0].trim();
        }
        return ip;
    }
}
