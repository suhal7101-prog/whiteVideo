package com.whitebear.anime.model.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

/**
 * 发送弹幕 DTO
 *
 * @author WhiteBear
 */
@Data
@Schema(description = "发送弹幕请求")
public class DanmakuDTO {

    @NotNull(message = "动漫ID不能为空")
    @Schema(description = "动漫 ID")
    private Long animeId;

    @Schema(description = "剧集 ID")
    private Long episodeId;

    @NotBlank(message = "弹幕内容不能为空")
    @Schema(description = "弹幕内容")
    private String content;

    @NotNull(message = "弹幕时间点不能为空")
    @Schema(description = "弹幕时间点（秒）")
    private Double timestamp;

    @Schema(description = "弹幕颜色", example = "#FFFFFF")
    private String color;

    @Schema(description = "弹幕类型: scroll/top/bottom", example = "scroll")
    private String type;
}
