package com.whitebear.anime.controller;

import com.whitebear.anime.service.AdvertisementImageService;
import lombok.RequiredArgsConstructor;
import org.springframework.core.io.Resource;
import org.springframework.http.CacheControl;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.concurrent.TimeUnit;

@RestController
@RequestMapping("/api/advertisement-images")
@RequiredArgsConstructor
public class AdvertisementImageController {

    private final AdvertisementImageService advertisementImageService;

    @GetMapping("/{fileName:.+}")
    public ResponseEntity<Resource> getImage(@PathVariable String fileName) {
        Resource resource = advertisementImageService.getResource(fileName);
        return ResponseEntity.ok()
                .contentType(MediaType.parseMediaType(advertisementImageService.contentType(fileName)))
                .cacheControl(CacheControl.maxAge(1, TimeUnit.DAYS).cachePublic())
                .body(resource);
    }
}
