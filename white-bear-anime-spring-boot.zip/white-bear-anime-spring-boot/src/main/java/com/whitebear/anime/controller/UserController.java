package com.whitebear.anime.controller;

import com.whitebear.anime.model.Result;
import com.whitebear.anime.model.dto.*;
import com.whitebear.anime.service.UserService;
import com.whitebear.anime.service.FileService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.MediaType;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpRange;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.io.InputStream;
import java.util.Map;

/**
 * 用户控制器
 * 匹配前端 API: /api/user/*
 *
 * @author WhiteBear
 */
@Tag(name = "用户模块", description = "登录、注册、个人信息、追番、历史记录")
@RestController
@RequestMapping("/api/user")
@RequiredArgsConstructor
public class UserController {

    private final UserService userService;
    private final FileService fileService;
    private final com.whitebear.anime.service.VideoUploadService videoUploadService;

    @Operation(summary = "用户登录")
    @PostMapping("/login")
    public Result<?> login(@Valid @RequestBody LoginDTO loginDTO) {
        return userService.login(loginDTO);
    }

    @Operation(summary = "用户注册")
    @PostMapping("/register")
    public Result<?> register(@Valid @RequestBody RegisterDTO registerDTO) {
        return userService.register(registerDTO);
    }

    @Operation(summary = "获取个人信息")
    @GetMapping("/profile")
    public Result<?> getProfile() {
        return userService.getProfile();
    }

    @Operation(summary = "更新个人信息")
    @PutMapping("/profile")
    public Result<?> updateProfile(@RequestBody UpdateProfileDTO dto) {
        return userService.updateProfile(dto);
    }

    @Operation(summary = "修改密码")
    @PutMapping("/password")
    public Result<?> changePassword(@Valid @RequestBody ChangePasswordDTO dto) {
        return userService.changePassword(dto);
    }

    @Operation(summary = "申请成为创作者")
    @PostMapping("/creator/apply")
    public Result<?> applyCreator(@Valid @RequestBody CreatorApplyDTO dto) {
        return userService.applyCreator(dto);
    }

    @Operation(summary = "提交动漫投稿")
    @PostMapping("/video-submissions")
    public Result<?> submitVideo(@Valid @RequestBody VideoDTO dto) {
        return userService.submitVideo(dto);
    }

    @Operation(summary = "投稿时搜索已有动漫资料")
    @GetMapping("/video-submissions/search")
    public Result<?> searchSubmissionAnime(@RequestParam String title) {
        return userService.searchSubmissionAnime(title);
    }

    @Operation(summary = "上传投稿视频")
    @PostMapping(value = "/submission-video", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public Result<?> uploadSubmissionVideo(@RequestPart("file") MultipartFile file) throws Exception {
        if (!userService.canCurrentUserSubmit()) {
            return Result.forbidden("仅管理员或已申请成功的创作者可以上传视频");
        }
        var uploaded = videoUploadService.upload(file);
        return Result.ok(Map.of(
                "url", uploaded.url(),
                "name", uploaded.originalName(),
                "size", uploaded.size()
        ));
    }

    @Operation(summary = "播放已上传的投稿视频")
    @GetMapping("/submission-video/{fileName:.+}")
    public ResponseEntity<?> getSubmissionVideo(
            @PathVariable String fileName,
            @RequestHeader(value = HttpHeaders.RANGE, required = false) String rangeHeader) throws Exception {
        Resource resource = videoUploadService.getResource(fileName);
        long contentLength = resource.contentLength();
        String contentType = videoUploadService.contentType(fileName);
        if (rangeHeader == null || rangeHeader.isBlank()) {
            return ResponseEntity.ok()
                    .header(HttpHeaders.ACCEPT_RANGES, "bytes")
                    .header(HttpHeaders.CONTENT_TYPE, contentType)
                    .contentLength(contentLength)
                    .body(resource);
        }

        HttpRange range = HttpRange.parseRanges(rangeHeader).get(0);
        long start = range.getRangeStart(contentLength);
        // 限制单次分段大小，既兼容浏览器拖动播放，也避免把大视频整段读入内存。
        long end = Math.min(range.getRangeEnd(contentLength), start + 2L * 1024 * 1024 - 1);
        int regionLength = Math.toIntExact(end - start + 1);
        byte[] region;
        try (InputStream input = resource.getInputStream()) {
            input.skipNBytes(start);
            region = input.readNBytes(regionLength);
        }
        return ResponseEntity.status(HttpStatus.PARTIAL_CONTENT)
                .header(HttpHeaders.ACCEPT_RANGES, "bytes")
                .header(HttpHeaders.CONTENT_TYPE, contentType)
                .header(HttpHeaders.CONTENT_RANGE, "bytes " + start + "-" + end + "/" + contentLength)
                .contentLength(region.length)
                .body(region);
    }

    @Operation(summary = "找回密码")
    @PostMapping("/forgot-pwd")
    public Result<?> forgotPassword(@Valid @RequestBody ForgotPasswordDTO dto) {
        return userService.forgotPassword(dto.getEmail());
    }

    @Operation(summary = "使用一次性令牌重置密码")
    @PostMapping("/reset-password")
    public Result<?> resetPassword(@Valid @RequestBody ResetPasswordDTO dto) {
        return userService.resetPassword(dto);
    }

    @Operation(summary = "上传头像")
    @PostMapping(value = "/avatar", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public Result<?> uploadAvatar(@RequestPart("file") MultipartFile file) throws Exception {
        validateImage(file, 5 * 1024 * 1024);
        return Result.ok(Map.of("url", fileService.uploadAvatar(file)));
    }

    @Operation(summary = "获取追番列表")
    @GetMapping("/favorites")
    public Result<?> getFavorites() {
        return userService.getFavorites();
    }

    @Operation(summary = "添加追番")
    @PostMapping("/favorites")
    public Result<?> addFavorite(@RequestBody Map<String, Object> body) {
        // 前端传来的是 { animeId: xxx }
        Long animeId = Long.valueOf(body.get("animeId").toString());
        return userService.addFavorite(animeId);
    }

    @Operation(summary = "取消追番")
    @DeleteMapping("/favorites/{animeId}")
    public Result<?> removeFavorite(@PathVariable Long animeId) {
        return userService.removeFavorite(animeId);
    }

    @Operation(summary = "获取观看历史")
    @GetMapping("/history")
    public Result<?> getHistory() {
        return userService.getHistory();
    }

    @Operation(summary = "清空当前用户观看历史")
    @DeleteMapping("/history")
    public Result<?> clearHistory() {
        return userService.clearHistory();
    }

    @Operation(summary = "查询视频追番和点赞状态")
    @PostMapping("/video-actions/state")
    public Result<?> getVideoActionState(@RequestBody VideoActionDTO dto) {
        return userService.getVideoActionState(dto);
    }

    @Operation(summary = "追番/取消追番")
    @PostMapping("/video-actions/favorite")
    public Result<?> toggleVideoFavorite(@RequestBody VideoActionDTO dto) {
        return userService.toggleVideoFavorite(dto);
    }

    @Operation(summary = "视频点赞/取消点赞")
    @PostMapping("/video-actions/like")
    public Result<?> toggleVideoLike(@RequestBody VideoActionDTO dto) {
        return userService.toggleVideoLike(dto);
    }

    @Operation(summary = "获取点赞过的视频")
    @GetMapping("/video-likes")
    public Result<?> getLikedVideos() {
        return userService.getLikedVideos();
    }

    @Operation(summary = "获取活跃用户")
    @GetMapping("/top")
    public Result<?> getTopUsers(@RequestParam(defaultValue = "5") int limit) {
        return userService.getTopUsers(limit);
    }

    @Operation(summary = "获取用户公开主页")
    @GetMapping("/public/{username}")
    public Result<?> getPublicProfile(@PathVariable String username) {
        return userService.getPublicProfile(username);
    }

    @Operation(summary = "关注用户")
    @PutMapping("/follows/{targetUserId}")
    public Result<?> followUser(@PathVariable Long targetUserId) {
        return userService.followUser(targetUserId);
    }

    @Operation(summary = "取消关注用户")
    @DeleteMapping("/follows/{targetUserId}")
    public Result<?> unfollowUser(@PathVariable Long targetUserId) {
        return userService.unfollowUser(targetUserId);
    }

    private void validateImage(MultipartFile file, long maxSize) {
        if (file == null || file.isEmpty()) throw new IllegalArgumentException("请选择图片文件");
        if (file.getSize() > maxSize) throw new IllegalArgumentException("图片大小超过限制");
        if (file.getContentType() == null || !file.getContentType().startsWith("image/")) {
            throw new IllegalArgumentException("仅支持图片文件");
        }
    }
}
