package com.whitebear.anime.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.whitebear.anime.model.entity.BannerEffect;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface BannerEffectMapper extends BaseMapper<BannerEffect> {
    @Select("SELECT * FROM wb_banner_effect WHERE deleted = 0 ORDER BY sort_order ASC, id ASC")
    List<BannerEffect> selectAllOrdered();

    @Select("SELECT * FROM wb_banner_effect WHERE deleted = 0 AND status = 'active' " +
            "AND target_page = #{targetPage} ORDER BY sort_order ASC, id ASC")
    List<BannerEffect> selectActive(@Param("targetPage") String targetPage);
}
