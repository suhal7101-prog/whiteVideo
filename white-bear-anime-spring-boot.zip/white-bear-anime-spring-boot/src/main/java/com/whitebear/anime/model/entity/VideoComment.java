package com.whitebear.anime.model.entity;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableLogic;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/** 播放器视频评论。 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@TableName("wb_video_comment")
public class VideoComment {

    @TableId(type = IdType.AUTO)
    private Long id;

    /** 视频编号；sourceType=db 时为本地编号，source 时为资源站编号。 */
    private Long videoId;

    /** 视频编号来源：db / source。 */
    private String sourceType;

    private Long userId;

    /** 被回复的评论编号。 */
    private Long parentId;

    private String content;

    private Integer likes;

    @TableLogic
    private Integer deleted;

    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createTime;
}
