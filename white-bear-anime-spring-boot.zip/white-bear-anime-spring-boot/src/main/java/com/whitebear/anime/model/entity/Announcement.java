package com.whitebear.anime.model.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * 公告实体
 *
 * @author WhiteBear
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@TableName("wb_announcement")
public class Announcement {

    @TableId(type = IdType.AUTO)
    private Long id;

    /** 公告标题 */
    private String title;

    /** 公告内容 */
    private String content;

    /** 是否置顶 */
    private Integer pinned;

    /** published / draft */
    private String status;

    /** 发布管理员 ID */
    private Long publisherId;

    /** 实际发布时间 */
    private LocalDateTime publishTime;

    @TableLogic
    private Integer deleted;

    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createTime;

    @TableField(fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime updateTime;
}
