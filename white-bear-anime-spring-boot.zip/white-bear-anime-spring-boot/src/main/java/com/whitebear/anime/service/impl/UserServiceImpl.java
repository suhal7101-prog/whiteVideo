package com.whitebear.anime.service.impl;

import cn.hutool.core.bean.BeanUtil;
import com.alibaba.fastjson2.JSON;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.whitebear.anime.mapper.*;
import com.whitebear.anime.model.Result;
import com.whitebear.anime.model.dto.*;
import com.whitebear.anime.model.entity.*;
import com.whitebear.anime.security.JwtUtils;
import com.whitebear.anime.security.SecurityUtils;
import com.whitebear.anime.service.UserService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Base64;
import java.util.HexFormat;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.ThreadLocalRandom;

/**
 * 用户服务实现类
 *
 * @author WhiteBear
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class UserServiceImpl implements UserService {

    private final UserMapper userMapper;
    private final FavoriteMapper favoriteMapper;
    private final WatchHistoryMapper watchHistoryMapper;
    private final VideoMapper videoMapper;
    private final EpisodeMapper episodeMapper;
    private final LikeMapper likeMapper;
    private final PostMapper postMapper;
    private final OperationLogMapper operationLogMapper;
    private final UserFollowMapper userFollowMapper;
    private final PasswordEncoder passwordEncoder;
    private final JwtUtils jwtUtils;
    private final ObjectProvider<JavaMailSender> mailSenderProvider;

    private final ConcurrentMap<String, PasswordResetRequest> passwordResetRequests = new ConcurrentHashMap<>();

    @Value("${spring.mail.host:}")
    private String mailHost;

    @Value("${spring.mail.username:}")
    private String mailUsername;

    @Value("${white-bear.frontend-url:http://localhost:5174}")
    private String frontendUrl;

    /**
     * 用户登录
     * 1. 校验邮箱是否存在
     * 2. 校验密码是否正确（BCrypt 对比）
     * 3. 生成 JWT Token
     * 4. 返回 Token + 用户信息
     */
    @Override
    public Result<Map<String, Object>> login(LoginDTO loginDTO) {
        // 查询用户
        User user = userMapper.findByEmail(loginDTO.getEmail());
        if (user == null) {
            return Result.error(400, "账号不存在");
        }

        // 检查账号状态
        if ("banned".equals(user.getStatus())) {
            return Result.error(403, "账号已被禁用，请联系管理员");
        }

        // 验证密码
        if (!passwordEncoder.matches(loginDTO.getPassword(), user.getPassword())) {
            return Result.error(400, "密码错误");
        }

        // 更新最后登录时间
        user.setLastLogin(LocalDateTime.now());
        userMapper.updateById(user);

        // 生成 JWT Token
        String token = jwtUtils.generateToken(user.getId(), user.getEmail(), user.getRole());

        // 构建用户信息（不返回密码）
        Map<String, Object> userInfo = new HashMap<>();
        userInfo.put("username", user.getUsername());
        userInfo.put("email", user.getEmail());
        userInfo.put("avatar", user.getAvatar());
        userInfo.put("nickname", user.getNickname() != null ? user.getNickname() : user.getUsername());
        userInfo.put("role", user.getRole());
        userInfo.put("bio", user.getBio());
        userInfo.put("creatorApplyStatus", user.getCreatorApplyStatus());
        userInfo.put("creatorApplyMessage", user.getCreatorApplyMessage());
        userInfo.put("creatorApplyReason", user.getCreatorApplyReason());

        // 返回 Token + 用户信息
        Map<String, Object> result = new HashMap<>();
        result.put("token", token);
        result.put("userInfo", userInfo);

        log.info("[登录] 用户 {} 登录成功", loginDTO.getEmail());
        return Result.ok("登录成功", result);
    }

    /**
     * 用户注册
     * 1. 校验邮箱和用户名是否已存在
     * 2. BCrypt 加密密码
     * 3. 保存用户
     */
    @Override
    @Transactional
    public Result<Void> register(RegisterDTO registerDTO) {
        // 校验邮箱
        User existingUser = userMapper.findByEmail(registerDTO.getEmail());
        if (existingUser != null) {
            return Result.error(400, "该邮箱已被注册");
        }

        // 校验用户名
        LambdaQueryWrapper<User> wrapper = Wrappers.<User>lambdaQuery()
                .eq(User::getUsername, registerDTO.getUsername());
        if (userMapper.selectCount(wrapper) > 0) {
            return Result.error(400, "该用户名已被使用");
        }

        // 构建用户对象
        User user = User.builder()
                .username(registerDTO.getUsername())
                .email(registerDTO.getEmail())
                .password(passwordEncoder.encode(registerDTO.getPassword()))
                .nickname(registerDTO.getUsername())
                .role("user")
                .status("active")
                .registerDate(LocalDateTime.now())
                .favoriteCount(0)
                .build();

        userMapper.insert(user);
        log.info("[注册] 新用户 {} 注册成功", registerDTO.getEmail());
        return Result.success("注册成功");
    }

    /**
     * 获取当前登录用户的个人信息
     */
    @Override
    public Result<User> getProfile() {
        Long userId = SecurityUtils.getCurrentUserId();
        if (userId == null) {
            return Result.unauthorized("请先登录");
        }
        User user = userMapper.selectById(userId);
        if (user == null) {
            return Result.notFound("用户不存在");
        }
        // 脱敏：不返回密码
        user.setPassword(null);
        return Result.ok(user);
    }

    @Override
    @Transactional
    public Result<Object> applyCreator(CreatorApplyDTO dto) {
        Long userId = SecurityUtils.getCurrentUserId();
        if (userId == null) return Result.unauthorized("请先登录");

        User user = userMapper.selectById(userId);
        if (user == null) return Result.notFound("用户不存在");

        String role = user.getRole();
        if ("admin".equals(role)) {
            return creatorApplicationResult(user, "管理员默认拥有创作者权限", true);
        }
        if ("creator".equals(role)) {
            return creatorApplicationResult(user, "您已经是创作者", true);
        }
        if ("pending".equals(user.getCreatorApplyStatus())) {
            return creatorApplicationResult(user, "创作者申请正在审核中", true);
        }

        user.setCreatorApplyStatus("pending");
        user.setCreatorApplyMessage(dto.getMessage().trim());
        user.setCreatorApplyReason(null);
        user.setCreatorApplyTime(LocalDateTime.now());
        user.setCreatorAuditTime(null);
        user.setCreatorAuditorId(null);
        userMapper.updateById(user);
        writeOperationLog(userId, "申请创作者", "用户#" + userId);
        log.info("[创作者] 用户 ID={} 已提交申请", userId);
        return creatorApplicationResult(user, "创作者申请已提交，请等待管理员审核", false);
    }

    private Result<Object> creatorApplicationResult(User user, String message, boolean alreadyApplied) {
        Map<String, Object> data = new LinkedHashMap<>();
        data.put("role", user.getRole());
        data.put("creator", "creator".equals(user.getRole()) || "admin".equals(user.getRole()));
        data.put("alreadyApplied", alreadyApplied);
        data.put("status", user.getCreatorApplyStatus() == null ? "approved" : user.getCreatorApplyStatus());
        if (user.getCreatorApplyMessage() != null) data.put("applicationMessage", user.getCreatorApplyMessage());
        if (user.getCreatorApplyReason() != null) data.put("reason", user.getCreatorApplyReason());
        return Result.ok(message, data);
    }

    @Override
    @Transactional
    public Result<Object> submitVideo(VideoDTO dto) {
        Long userId = SecurityUtils.getCurrentUserId();
        if (userId == null) return Result.unauthorized("请先登录");

        User user = userMapper.selectById(userId);
        if (user == null) return Result.notFound("用户不存在");
        boolean admin = "admin".equals(user.getRole());
        if (!admin && !"creator".equals(user.getRole())) {
            return Result.error(403, "仅管理员或已申请成功的创作者可以投稿");
        }
        if (dto.getVideoUrl() == null || dto.getVideoUrl().isBlank()) {
            return Result.badRequest("请先上传视频文件");
        }
        long calculatedEpisode = videoMapper.selectNextSubmissionEpisode(dto.getTitle().trim());
        int episodeNumber = (int) Math.min(9999L, Math.max(1L, calculatedEpisode));

        String auditStatus = admin ? "approved" : "pending";
        Video video = Video.builder()
                .title(dto.getTitle().trim())
                .cover(dto.getCover())
                .category(dto.getCategory().trim())
                .description(dto.getDescription())
                .status(dto.getStatus() == null || dto.getStatus().isBlank() ? "连载中" : dto.getStatus())
                .rating(dto.getRating() == null ? BigDecimal.ZERO : BigDecimal.valueOf(dto.getRating()))
                .views(ThreadLocalRandom.current().nextLong(500, 901))
                .likes(ThreadLocalRandom.current().nextLong(500, 901))
                .episodes(episodeNumber)
                .tags(dto.getTags())
                .year(dto.getYear())
                .region(dto.getRegion() == null || dto.getRegion().isBlank() ? "CN" : dto.getRegion())
                .submissionSource("user")
                .uploaderId(userId)
                .auditStatus(auditStatus)
                .auditorId(admin ? userId : null)
                .submitTime(LocalDateTime.now())
                .auditTime(admin ? LocalDateTime.now() : null)
                .deleted(0)
                .build();
        videoMapper.insert(video);

        Episode firstEpisode = Episode.builder()
                .videoId(video.getId())
                .episodeNum(episodeNumber)
                .title("第" + episodeNumber + "集")
                .videoUrl(dto.getVideoUrl().trim())
                .quality("1080P")
                .fileSize(dto.getVideoFileSize())
                .deleted(0)
                .build();
        episodeMapper.insert(firstEpisode);
        writeOperationLog(userId, "动漫投稿", "视频#" + video.getId() + " " + video.getTitle());
        log.info("[投稿] 用户 ID={} 投稿视频 ID={}, 状态={}", userId, video.getId(), auditStatus);

        Map<String, Object> data = new LinkedHashMap<>();
        data.put("id", video.getId());
        data.put("auditStatus", auditStatus);
        data.put("approved", admin);
        return Result.ok(admin ? "投稿发布成功" : "投稿成功，等待管理员审核", data);
    }

    @Override
    public Result<Object> searchSubmissionAnime(String title) {
        if (!canCurrentUserSubmit()) {
            return Result.error(403, "仅管理员或已申请成功的创作者可以搜索投稿资料");
        }
        if (title == null || title.isBlank()) {
            return Result.badRequest("请输入动漫名称");
        }

        String keyword = title.trim();
        Map<String, Video> uniqueTitles = new LinkedHashMap<>();
        for (Video video : videoMapper.searchSubmissionCandidates(keyword)) {
            if (video.getTitle() != null && !video.getTitle().isBlank()) {
                uniqueTitles.putIfAbsent(video.getTitle().trim(), video);
            }
        }

        List<Map<String, Object>> list = uniqueTitles.values().stream().map(video -> {
            Map<String, Object> item = new LinkedHashMap<>();
            String existingTitle = video.getTitle().trim();
            item.put("id", video.getId());
            item.put("title", existingTitle);
            item.put("cover", video.getCover());
            item.put("category", video.getCategory());
            item.put("description", video.getDescription());
            item.put("status", video.getStatus());
            item.put("tags", video.getTags());
            item.put("year", video.getYear());
            item.put("region", video.getRegion());
            item.put("existingCount", videoMapper.countSubmissionVideosByTitle(existingTitle));
            item.put("nextEpisode", Math.max(1L, videoMapper.selectNextSubmissionEpisode(existingTitle)));
            return item;
        }).collect(Collectors.toList());

        return Result.ok(Map.of("list", list, "total", list.size(), "keyword", keyword));
    }

    @Override
    public boolean canCurrentUserSubmit() {
        Long userId = SecurityUtils.getCurrentUserId();
        if (userId == null) return false;
        User user = userMapper.selectById(userId);
        return user != null && ("admin".equals(user.getRole()) || "creator".equals(user.getRole()));
    }

    /**
     * 更新个人信息（昵称、头像、简介）
     */
    @Override
    public Result<Void> updateProfile(UpdateProfileDTO dto) {
        Long userId = SecurityUtils.getCurrentUserId();
        if (userId == null) {
            return Result.unauthorized("请先登录");
        }

        User user = userMapper.selectById(userId);
        if (user == null) {
            return Result.notFound("用户不存在");
        }
        if (dto.getNickname() != null) user.setNickname(dto.getNickname());
        if (dto.getAvatar() != null) user.setAvatar(dto.getAvatar());
        if (dto.getBio() != null) user.setBio(dto.getBio());

        userMapper.updateById(user);
        log.info("[个人信息] 用户 ID={} 更新个人信息", userId);
        return Result.success("更新成功");
    }

    /**
     * 修改密码
     */
    @Override
    public Result<Void> changePassword(ChangePasswordDTO dto) {
        Long userId = SecurityUtils.getCurrentUserId();
        if (userId == null) {
            return Result.unauthorized("请先登录");
        }

        User user = userMapper.selectById(userId);

        // 验证旧密码
        if (!passwordEncoder.matches(dto.getOldPassword(), user.getPassword())) {
            return Result.error(400, "旧密码不正确");
        }

        // 更新为新密码
        user.setPassword(passwordEncoder.encode(dto.getNewPassword()));
        userMapper.updateById(user);

        log.info("[修改密码] 用户 ID={} 修改密码成功", userId);
        return Result.success("密码修改成功");
    }

    /**
     * 找回密码（发送重置邮件）
     */
    @Override
    public Result<Void> forgotPassword(String email) {
        if (mailHost == null || mailHost.isBlank()) {
            return Result.error(503, "邮件服务尚未配置，请联系管理员");
        }

        User user = userMapper.findByEmail(email);
        if (user != null) {
            byte[] randomBytes = new byte[32];
            new SecureRandom().nextBytes(randomBytes);
            String token = Base64.getUrlEncoder().withoutPadding().encodeToString(randomBytes);
            String tokenHash = hashResetToken(token);
            passwordResetRequests.put(tokenHash,
                    new PasswordResetRequest(user.getId(), System.currentTimeMillis() + 15 * 60_000));

            String resetUrl = frontendUrl.replaceAll("/+$", "") + "/reset-password?token=" + token;
            SimpleMailMessage message = new SimpleMailMessage();
            if (mailUsername != null && !mailUsername.isBlank()) {
                message.setFrom(mailUsername);
            }
            message.setTo(user.getEmail());
            message.setSubject("白熊动漫密码重置");
            message.setText("请在 15 分钟内打开以下链接重置密码：\n" + resetUrl
                    + "\n\n如果不是您本人操作，请忽略此邮件。");

            try {
                JavaMailSender mailSender = mailSenderProvider.getIfAvailable();
                if (mailSender == null) {
                    passwordResetRequests.remove(tokenHash);
                    return Result.error(503, "邮件服务尚未配置，请联系管理员");
                }
                mailSender.send(message);
            } catch (RuntimeException exception) {
                passwordResetRequests.remove(tokenHash);
                log.error("[找回密码] 重置邮件发送失败: {}", exception.getMessage());
                return Result.error(503, "重置邮件发送失败，请稍后再试");
            }
        }

        log.info("[找回密码] 已处理密码重置请求");
        return Result.success("如果该邮箱已注册，重置链接将在几分钟内送达");
    }

    @Override
    public Result<Void> resetPassword(ResetPasswordDTO dto) {
        String tokenHash = hashResetToken(dto.getToken());
        PasswordResetRequest request = passwordResetRequests.remove(tokenHash);
        if (request == null || request.expiresAt < System.currentTimeMillis()) {
            return Result.badRequest("重置链接无效或已过期");
        }

        User user = userMapper.selectById(request.userId);
        if (user == null || "banned".equals(user.getStatus())) {
            return Result.badRequest("重置链接无效或已过期");
        }
        user.setPassword(passwordEncoder.encode(dto.getNewPassword()));
        userMapper.updateById(user);

        log.info("[找回密码] 用户 ID={} 已完成密码重置", user.getId());
        return Result.success("密码重置成功");
    }

    private String hashResetToken(String token) {
        try {
            byte[] digest = MessageDigest.getInstance("SHA-256")
                    .digest(token.getBytes(StandardCharsets.UTF_8));
            return HexFormat.of().formatHex(digest);
        } catch (NoSuchAlgorithmException exception) {
            throw new IllegalStateException("当前运行时不支持 SHA-256", exception);
        }
    }

    private record PasswordResetRequest(Long userId, long expiresAt) {}

    /**
     * 获取追番列表
     */
    @Override
    public Result<Object> getFavorites() {
        Long userId = SecurityUtils.getCurrentUserId();
        if (userId == null) {
            return Result.unauthorized("请先登录");
        }

        List<Favorite> favorites = favoriteMapper.selectByUserId(userId);
        List<Long> animeIds = favorites.stream()
                .map(Favorite::getAnimeId)
                .collect(Collectors.toList());

        // 查询动漫详情
        List<Video> videos = animeIds.stream()
                .map(videoMapper::selectById)
                .collect(Collectors.toList());

        return Result.ok(Map.of("list", videos, "total", videos.size()));
    }

    /**
     * 添加追番
     */
    @Override
    @Transactional
    public Result<Void> addFavorite(Long animeId) {
        Long userId = SecurityUtils.getCurrentUserId();
        if (userId == null) {
            return Result.unauthorized("请先登录");
        }

        // 检查是否已追番
        if (favoriteMapper.countByUserAndAnime(userId, animeId) > 0) {
            return Result.error(400, "已经在追番列表中");
        }

        Favorite favorite = Favorite.builder()
                .userId(userId)
                .animeId(animeId)
                .build();
        favoriteMapper.insert(favorite);

        // 更新用户追番数
        User user = userMapper.selectById(userId);
        user.setFavoriteCount((user.getFavoriteCount() != null ? user.getFavoriteCount() : 0) + 1);
        userMapper.updateById(user);

        writeOperationLog(userId, "追番", videoTarget(animeId));

        log.info("[追番] 用户 ID={} 添加追番 动漫ID={}", userId, animeId);
        return Result.success("追番成功");
    }

    /**
     * 取消追番
     */
    @Override
    @Transactional
    public Result<Void> removeFavorite(Long animeId) {
        Long userId = SecurityUtils.getCurrentUserId();
        if (userId == null) {
            return Result.unauthorized("请先登录");
        }

        int rows = favoriteMapper.deleteByUserAndAnime(userId, animeId);
        if (rows == 0) {
            return Result.error(400, "追番记录不存在");
        }

        // 更新用户追番数
        User user = userMapper.selectById(userId);
        user.setFavoriteCount(Math.max(0, (user.getFavoriteCount() != null ? user.getFavoriteCount() : 0) - 1));
        userMapper.updateById(user);

        writeOperationLog(userId, "取消追番", videoTarget(animeId));

        log.info("[取消追番] 用户 ID={} 取消追番 动漫ID={}", userId, animeId);
        return Result.success("已取消追番");
    }

    /**
     * 获取观看历史
     */
    @Override
    public Result<Object> getHistory() {
        Long userId = SecurityUtils.getCurrentUserId();
        if (userId == null) {
            return Result.unauthorized("请先登录");
        }

        List<WatchHistory> histories = watchHistoryMapper.selectByUserId(userId, 50);

        // 组装返回数据（关联动漫信息）
        List<Map<String, Object>> list = histories.stream().map(h -> {
            Video video = videoMapper.selectById(h.getAnimeId());
            Map<String, Object> item = new HashMap<>();
            item.put("animeId", h.getAnimeId());
            item.put("episodeId", h.getEpisodeId());
            item.put("currentTime", h.getCurrentTime());
            item.put("duration", h.getDuration());
            item.put("watchedAt", h.getWatchedAt());
            if (video != null) {
                item.put("title", video.getTitle());
                item.put("cover", video.getCover());
                item.put("sourceVodId", video.getSourceVodId());
                item.put("playUrl", video.getSourceVodId() != null
                        ? "/play/" + video.getSourceVodId()
                        : "/play/" + video.getId() + "?source=db");
            }
            return item;
        }).collect(Collectors.toList());

        return Result.ok(Map.of("list", list));
    }

    @Override
    public Result<Void> clearHistory() {
        Long userId = SecurityUtils.getCurrentUserId();
        if (userId == null) return Result.unauthorized("请先登录");
        watchHistoryMapper.deleteByUserId(userId);
        return Result.success("观看历史已清空");
    }

    @Override
    public Result<Object> getVideoActionState(VideoActionDTO dto) {
        Long userId = SecurityUtils.getCurrentUserId();
        if (userId == null) return Result.unauthorized("请先登录");

        Video video = resolveVideo(dto, false);
        if (video == null) {
            return Result.ok(Map.of("videoId", 0L, "favorited", false, "liked", false, "likes", 0L));
        }
        return Result.ok(videoActionState(userId, video));
    }

    @Override
    @Transactional
    public Result<Object> toggleVideoFavorite(VideoActionDTO dto) {
        Long userId = SecurityUtils.getCurrentUserId();
        if (userId == null) return Result.unauthorized("请先登录");

        Video video = resolveVideo(dto, true);
        if (video == null) return Result.badRequest("无法识别该视频");

        boolean favorited = favoriteMapper.countByUserAndAnime(userId, video.getId()) > 0;
        if (favorited) removeFavorite(video.getId());
        else addFavorite(video.getId());

        Map<String, Object> data = videoActionState(userId, video);
        return Result.ok(favorited ? "已取消追番" : "追番成功", data);
    }

    @Override
    @Transactional
    public Result<Object> toggleVideoLike(VideoActionDTO dto) {
        Long userId = SecurityUtils.getCurrentUserId();
        if (userId == null) return Result.unauthorized("请先登录");

        Video video = resolveVideo(dto, true);
        if (video == null) return Result.badRequest("无法识别该视频");

        boolean liked = likeMapper.countByUserAndTarget(userId, video.getId(), "video") > 0;
        if (liked) {
            likeMapper.deleteByUserAndTarget(userId, video.getId(), "video");
            videoMapper.decrementLikes(video.getId());
            writeOperationLog(userId, "取消视频点赞", videoTarget(video.getId()));
        } else {
            likeMapper.insert(Like.builder().userId(userId).targetId(video.getId()).type("video").build());
            videoMapper.incrementLikes(video.getId());
            writeOperationLog(userId, "视频点赞", videoTarget(video.getId()));
        }

        Video refreshed = videoMapper.selectById(video.getId());
        Map<String, Object> data = videoActionState(userId, refreshed != null ? refreshed : video);
        return Result.ok(liked ? "已取消点赞" : "点赞成功", data);
    }

    @Override
    public Result<Object> getLikedVideos() {
        Long userId = SecurityUtils.getCurrentUserId();
        if (userId == null) return Result.unauthorized("请先登录");

        List<Map<String, Object>> list = likeMapper.selectTargetIdsByUserAndType(userId, "video").stream()
                .map(videoMapper::selectById)
                .filter(java.util.Objects::nonNull)
                .map(this::toVideoCard)
                .collect(Collectors.toList());
        return Result.ok(Map.of("list", list, "total", list.size()));
    }

    private Video resolveVideo(VideoActionDTO dto, boolean createWhenMissing) {
        if (dto == null) return null;
        Video video = null;
        if (dto.getVideoId() != null && dto.getVideoId() > 0) {
            video = videoMapper.selectById(dto.getVideoId());
        }
        if (video == null && dto.getSourceVodId() != null && dto.getSourceVodId() > 0) {
            video = videoMapper.findBySourceVodId(dto.getSourceVodId());
        }
        if (video == null && dto.getTitle() != null && !dto.getTitle().isBlank()) {
            video = videoMapper.findByTitle(dto.getTitle().trim());
        }
        if (video != null || !createWhenMissing || dto.getTitle() == null || dto.getTitle().isBlank()) {
            return video;
        }

        String title = dto.getTitle().trim();
        if (title.length() > 256) title = title.substring(0, 256);
        Video created = Video.builder()
                .sourceVodId(dto.getSourceVodId())
                .title(title)
                .cover(dto.getCover())
                .category(dto.getCategory())
                .description(dto.getDescription())
                .status(dto.getStatus() == null || dto.getStatus().isBlank() ? "连载中" : dto.getStatus())
                .rating(BigDecimal.ZERO)
                .views(0L)
                .likes(0L)
                .episodes(dto.getEpisodes() == null ? 0 : dto.getEpisodes())
                .year(dto.getYear())
                .deleted(0)
                .build();
        videoMapper.insert(created);
        return created;
    }

    private Map<String, Object> videoActionState(Long userId, Video video) {
        Map<String, Object> data = new LinkedHashMap<>();
        data.put("videoId", video.getId());
        data.put("sourceVodId", video.getSourceVodId());
        data.put("favorited", favoriteMapper.countByUserAndAnime(userId, video.getId()) > 0);
        data.put("liked", likeMapper.countByUserAndTarget(userId, video.getId(), "video") > 0);
        data.put("likes", video.getLikes() == null ? 0L : video.getLikes());
        return data;
    }

    private Map<String, Object> toVideoCard(Video video) {
        Map<String, Object> item = new LinkedHashMap<>();
        item.put("id", video.getId());
        item.put("sourceVodId", video.getSourceVodId());
        item.put("title", video.getTitle());
        item.put("cover", video.getCover());
        item.put("category", video.getCategory());
        item.put("likes", video.getLikes() == null ? 0L : video.getLikes());
        item.put("playUrl", video.getSourceVodId() != null
                ? "/play/" + video.getSourceVodId()
                : "/play/" + video.getId() + "?source=db");
        return item;
    }

    private String videoTarget(Long videoId) {
        Video video = videoMapper.selectById(videoId);
        return video == null ? "视频#" + videoId : "视频#" + videoId + " " + video.getTitle();
    }

    private void writeOperationLog(Long userId, String action, String target) {
        User user = userMapper.selectById(userId);
        String safeTarget = target == null ? "" : (target.length() > 256 ? target.substring(0, 256) : target);
        operationLogMapper.insert(OperationLog.builder()
                .userId(userId)
                .username(user != null ? user.getUsername() : SecurityUtils.getCurrentEmail())
                .action(action)
                .target(safeTarget)
                .build());
    }

    @Override
    public Result<Object> getTopUsers(int limit) {
        int safeLimit = Math.max(1, Math.min(limit, 20));
        List<Map<String, Object>> list = userMapper.selectTopUsers(safeLimit).stream()
                .map(this::toPublicUser)
                .collect(Collectors.toList());
        return Result.ok(Map.of("list", list));
    }

    @Override
    public Result<Object> getPublicProfile(String username) {
        User user = userMapper.findByUsername(username);
        if (user == null) {
            return Result.notFound("用户不存在");
        }
        return Result.ok(toPublicUser(user));
    }

    @Override
    @Transactional
    public Result<Object> followUser(Long targetUserId) {
        Long currentUserId = SecurityUtils.getCurrentUserId();
        if (currentUserId == null) return Result.unauthorized("请先登录");
        if (currentUserId.equals(targetUserId)) return Result.badRequest("不能关注自己");

        User targetUser = userMapper.selectById(targetUserId);
        if (targetUser == null || "banned".equals(targetUser.getStatus())) {
            return Result.notFound("用户不存在");
        }

        if (userFollowMapper.countRelationship(currentUserId, targetUserId) == 0) {
            try {
                userFollowMapper.insert(UserFollow.builder()
                        .followerId(currentUserId)
                        .followingId(targetUserId)
                        .build());
            } catch (DuplicateKeyException ignored) {
                // 并发重复关注由唯一索引保证幂等。
            }
        }
        return Result.ok("关注成功", buildUserStats(targetUserId, currentUserId));
    }

    @Override
    @Transactional
    public Result<Object> unfollowUser(Long targetUserId) {
        Long currentUserId = SecurityUtils.getCurrentUserId();
        if (currentUserId == null) return Result.unauthorized("请先登录");
        if (currentUserId.equals(targetUserId)) return Result.badRequest("不能取消关注自己");

        User targetUser = userMapper.selectById(targetUserId);
        if (targetUser == null) return Result.notFound("用户不存在");

        userFollowMapper.deleteRelationship(currentUserId, targetUserId);
        return Result.ok("已取消关注", buildUserStats(targetUserId, currentUserId));
    }

    private Map<String, Object> toPublicUser(User user) {
        Map<String, Object> item = new HashMap<>();
        item.put("id", user.getId());
        item.put("username", user.getUsername());
        item.put("nickname", user.getNickname());
        item.put("avatar", user.getAvatar());
        item.put("bio", user.getBio());
        item.put("role", user.getRole());
        item.put("registerDate", user.getRegisterDate());
        item.put("lastLogin", user.getLastLogin());
        item.put("favoriteCount", user.getFavoriteCount());
        item.putAll(buildUserStats(user.getId(), SecurityUtils.getCurrentUserId()));
        return item;
    }

    private Map<String, Object> buildUserStats(Long profileUserId, Long viewerUserId) {
        Map<String, Object> stats = new LinkedHashMap<>();
        stats.put("postCount", postMapper.countApprovedByAuthor(profileUserId));
        stats.put("receivedLikes", postMapper.sumApprovedLikesByAuthor(profileUserId));
        stats.put("followingCount", userFollowMapper.countFollowing(profileUserId));
        stats.put("followerCount", userFollowMapper.countFollowers(profileUserId));

        boolean isSelf = viewerUserId != null && viewerUserId.equals(profileUserId);
        boolean isFollowing = !isSelf && viewerUserId != null
                && userFollowMapper.countRelationship(viewerUserId, profileUserId) > 0;
        stats.put("isSelf", isSelf);
        stats.put("isFollowing", isFollowing);
        return stats;
    }
}
