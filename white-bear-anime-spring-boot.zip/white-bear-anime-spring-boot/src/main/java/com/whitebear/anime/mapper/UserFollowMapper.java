package com.whitebear.anime.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.whitebear.anime.model.entity.UserFollow;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

@Mapper
public interface UserFollowMapper extends BaseMapper<UserFollow> {

    @Select("SELECT COUNT(*) FROM wb_user_follow WHERE follower_id = #{followerId} AND following_id = #{followingId}")
    long countRelationship(@Param("followerId") Long followerId,
                           @Param("followingId") Long followingId);

    @Select("SELECT COUNT(*) FROM wb_user_follow WHERE follower_id = #{userId}")
    long countFollowing(@Param("userId") Long userId);

    @Select("SELECT COUNT(*) FROM wb_user_follow WHERE following_id = #{userId}")
    long countFollowers(@Param("userId") Long userId);

    @Delete("DELETE FROM wb_user_follow WHERE follower_id = #{followerId} AND following_id = #{followingId}")
    int deleteRelationship(@Param("followerId") Long followerId,
                           @Param("followingId") Long followingId);
}
