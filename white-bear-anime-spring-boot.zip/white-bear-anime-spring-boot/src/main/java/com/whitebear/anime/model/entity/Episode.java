package com.whitebear.anime.model.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * 剧集实体
 *
 * @author WhiteBear
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@TableName("wb_episode")
public class Episode {

    @TableId(type = IdType.AUTO)
    private Long id;

    /** 所属视频 ID */
    private Long videoId;

    /** 集数序号 */
    private Integer episodeNum;

    /** 剧集标题 */
    private String title;

    /** 时长（秒） */
    private Integer duration;

    /** 视频播放地址 */
    private String videoUrl;

    /** 清晰度: 4K / 1080p / 720p / 480p */
    private String quality;

    /** 文件大小（字节） */
    private Long fileSize;

    @TableLogic
    private Integer deleted;

    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createTime;

    @TableField(fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime updateTime;
}
