package com.whitebear.anime.controller;

import com.whitebear.anime.model.Result;
import com.whitebear.anime.service.RankingSyncService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.*;

import java.util.*;

/**
 * 排行榜控制器
 *
 * @author WhiteBear
 */
@Tag(name = "排行榜", description = "视频排行 Top10")
@RestController
@RequiredArgsConstructor
@RequestMapping("/api/ranking")
public class RankingController {

    private final JdbcTemplate db;
    private final RankingSyncService rankingSyncService;

    @Operation(summary = "获取动态综合评分 Top10")
    @GetMapping("/top10")
    public Result<Map<String, Object>> getTop10() {
        List<Map<String, Object>> list = db.queryForList(
            "SELECT id, source_vod_id AS sourceVodId, title, cover, category, description, " +
                    "status, tags, `year`, rating, " +
                    "COALESCE(views, 0) AS views, COALESCE(likes, 0) AS likes, " +
                    "(COALESCE(rating, 0) * 10000 + COALESCE(views, 0) + COALESCE(likes, 0) * 10) AS rankingScore " +
                    "FROM wb_video WHERE deleted = 0 AND audit_status = 'approved' AND source_vod_id IS NOT NULL " +
                    "ORDER BY rankingScore DESC, rating DESC, id ASC LIMIT 10"
        );

        double highestScore = list.isEmpty()
                ? 0
                : ((Number) list.get(0).get("rankingScore")).doubleValue();
        for (Map<String, Object> item : list) {
            double rawScore = ((Number) item.get("rankingScore")).doubleValue();
            double dynamicScore = highestScore == 0
                    ? 0
                    : Math.round((5 + 5 * rawScore / highestScore) * 10) / 10.0;
            item.put("dynamicScore", dynamicScore);
        }

        Map<String, Object> data = new LinkedHashMap<>();
        data.put("list", list);
        data.put("total", list.size());
        return Result.ok(data);
    }

    @Operation(summary = "获取全部视频的真实浏览量与点赞量")
    @GetMapping("/metrics")
    public Result<Map<String, Object>> getMetrics() {
        List<Map<String, Object>> list = db.queryForList(
            "SELECT source_vod_id AS sourceVodId, " +
                    "COALESCE(views, 0) AS views, COALESCE(likes, 0) AS likes " +
                    "FROM wb_video WHERE deleted = 0 AND audit_status = 'approved' AND source_vod_id IS NOT NULL"
        );

        Map<String, Object> data = new LinkedHashMap<>();
        data.put("list", list);
        data.put("total", list.size());
        return Result.ok(data);
    }

    @Operation(summary = "批量刷新排名 (从 Python 服务器同步)")
    @PostMapping("/refresh")
    @PreAuthorize("hasRole('ADMIN')")
    public Result<?> refresh() {
        try {
            return Result.ok("Python 视频同步完成", rankingSyncService.syncFromPython());
        } catch (Exception exception) {
            return Result.error("Python 视频同步失败: " + exception.getMessage());
        }
    }

}
