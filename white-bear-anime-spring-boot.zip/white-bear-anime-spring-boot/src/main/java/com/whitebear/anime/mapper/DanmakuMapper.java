package com.whitebear.anime.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.whitebear.anime.model.entity.Danmaku;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * 弹幕 Mapper
 *
 * @author WhiteBear
 */
@Mapper
public interface DanmakuMapper extends BaseMapper<Danmaku> {

    /** 根据动漫和剧集查询弹幕（按时间排序） */
    @Select("SELECT * FROM wb_danmaku WHERE anime_id = #{animeId} AND " +
            "(episode_id = #{episodeId} OR episode_id IS NULL) " +
            "ORDER BY timestamp ASC")
    List<Danmaku> selectByAnimeAndEpisode(@Param("animeId") Long animeId,
                                           @Param("episodeId") Long episodeId);

    /** 查询动漫的所有弹幕 */
    @Select("SELECT * FROM wb_danmaku WHERE anime_id = #{animeId} ORDER BY timestamp ASC")
    List<Danmaku> selectByAnimeId(@Param("animeId") Long animeId);
}
