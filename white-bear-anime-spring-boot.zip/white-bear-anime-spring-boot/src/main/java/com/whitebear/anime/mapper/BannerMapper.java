package com.whitebear.anime.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.whitebear.anime.model.entity.Banner;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * 轮播图 Mapper
 *
 * @author WhiteBear
 */
@Mapper
public interface BannerMapper extends BaseMapper<Banner> {

    /** 查询启用的轮播图（按排序） */
    @Select("SELECT * FROM wb_banner WHERE active = 1 AND deleted = 0 ORDER BY sort_order ASC")
    List<Banner> selectActiveBanners();
}
