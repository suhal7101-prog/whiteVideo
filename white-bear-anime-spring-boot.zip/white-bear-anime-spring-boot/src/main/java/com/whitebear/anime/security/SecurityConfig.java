package com.whitebear.anime.security;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.whitebear.anime.model.Result;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import java.nio.charset.StandardCharsets;

/**
 * Spring Security 安全配置类
 * 配置: JWT 无状态认证、路径权限控制、CORS、CSRF 禁用
 *
 * @author WhiteBear
 */
@Configuration
@EnableWebSecurity
@EnableMethodSecurity  // 启用 @PreAuthorize 方法级权限控制
@RequiredArgsConstructor
public class SecurityConfig {

    private final JwtAuthenticationFilter jwtAuthenticationFilter;
    private final ObjectMapper objectMapper;

    /**
     * 密码加密器 —— BCrypt 算法
     * 用于注册时加密密码、登录时对比密码
     */
    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    /**
     * 认证管理器 —— 供 Controller 层登录时使用
     */
    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration config) throws Exception {
        return config.getAuthenticationManager();
    }

    /**
     * Spring Security 过滤器链配置
     */
    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
                // ---- 禁用 CSRF（前后端分离 + JWT 无状态，不需要） ----
                .csrf(AbstractHttpConfigurer::disable)
                .cors(Customizer.withDefaults())

                // ---- 无状态会话（不创建 HttpSession） ----
                .sessionManagement(session -> session
                        .sessionCreationPolicy(SessionCreationPolicy.STATELESS))

                // ---- 请求路径权限控制 ----
                .authorizeHttpRequests(auth -> auth
                        // ===== 公开接口（无需登录） =====
                        // 用户模块
                        .requestMatchers("/api/user/login", "/api/user/register", "/api/user/reset-password").permitAll()
                        .requestMatchers(HttpMethod.GET, "/api/user/top", "/api/user/public/**").permitAll()
                        .requestMatchers(HttpMethod.GET, "/api/user/submission-video/**").permitAll()
                        .requestMatchers(HttpMethod.POST, "/api/user/forgot-pwd").permitAll()

                        // 动漫/视频模块（浏览无需登录）
                        .requestMatchers(HttpMethod.GET, "/api/anime/**").permitAll()
                        .requestMatchers(HttpMethod.GET, "/api/catalog/**").permitAll()
                        .requestMatchers(HttpMethod.POST, "/api/catalog/play").permitAll()
                        .requestMatchers(HttpMethod.POST, "/api/catalog/play-by-title").permitAll()
                        .requestMatchers(HttpMethod.POST, "/api/catalog/play-by-source").permitAll()
                        .requestMatchers(HttpMethod.GET, "/api/bilibili/**").permitAll()

                        // 排行榜模块（浏览无需登录）
                        .requestMatchers(HttpMethod.GET, "/api/ranking/**").permitAll()

                        // 广告展示（浏览无需登录）
                        .requestMatchers(HttpMethod.GET, "/api/advertisements").permitAll()
                        .requestMatchers(HttpMethod.GET, "/api/advertisement-images/**").permitAll()
                        .requestMatchers(HttpMethod.GET, "/api/banner-effects/active").permitAll()

                        // 社区模块（查看无需登录）
                        .requestMatchers(HttpMethod.GET, "/api/community/posts").permitAll()
                        .requestMatchers(HttpMethod.GET, "/api/community/post/**").permitAll()
                        .requestMatchers(HttpMethod.GET, "/api/community/image/**").permitAll()
                        .requestMatchers(HttpMethod.GET, "/api/community/danmaku/**").permitAll()
                        .requestMatchers(HttpMethod.GET, "/api/video-comments", "/api/video-comments/**").permitAll()

                        // AI 调用会消耗外部服务额度，必须登录
                        .requestMatchers("/api/ai/**").authenticated()

                        // Swagger / Knife4j 接口文档
                        .requestMatchers(
                                "/doc.html", "/swagger-ui/**", "/swagger-resources/**",
                                "/v3/api-docs/**", "/webjars/**"
                        ).permitAll()

                        // WebSocket 握手端点
                        .requestMatchers("/ws/**").permitAll()

                        // ===== 管理后台接口（仅管理员） =====
                        .requestMatchers("/api/admin/**").hasRole("ADMIN")

                        // ===== 其他所有接口需要登录认证 =====
                        .anyRequest().authenticated()
                )

                // ---- 将 JWT 过滤器添加到 UsernamePasswordAuthenticationFilter 之前 ----
                .exceptionHandling(exceptions -> exceptions
                        .authenticationEntryPoint((request, response, exception) -> {
                            response.setStatus(401);
                            response.setContentType("application/json");
                            response.setCharacterEncoding(StandardCharsets.UTF_8.name());
                            objectMapper.writeValue(response.getWriter(), Result.unauthorized("登录已过期或尚未登录"));
                        })
                        .accessDeniedHandler((request, response, exception) -> {
                            response.setStatus(403);
                            response.setContentType("application/json");
                            response.setCharacterEncoding(StandardCharsets.UTF_8.name());
                            objectMapper.writeValue(response.getWriter(), Result.forbidden("权限不足"));
                        }))
                .addFilterBefore(jwtAuthenticationFilter, UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }
}
