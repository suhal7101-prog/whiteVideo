package com.whitebear.anime.service;

import com.whitebear.anime.config.MinioConfig;
import io.minio.*;
import io.minio.errors.*;
import io.minio.http.Method;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

/**
 * MinIO 文件存储服务
 * 功能: 上传文件到 MinIO、生成访问链接
 *
 * @author WhiteBear
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class FileService {

    private final MinioClient minioClient;
    private final MinioConfig minioConfig;

    /**
     * 上传头像
     * @param file 头像文件
     * @return 头像访问 URL
     */
    public String uploadAvatar(MultipartFile file) throws Exception {
        return upload(file, minioConfig.getBucket().getAvatar(), "avatar/");
    }

    /**
     * 上传封面图片
     * @param file 封面文件
     * @return 封面访问 URL
     */
    public String uploadCover(MultipartFile file) throws Exception {
        return upload(file, minioConfig.getBucket().getCover(), "cover/");
    }

    /**
     * 上传帖子图片
     * @param file 图片文件
     * @return 图片访问 URL
     */
    public String uploadImage(MultipartFile file) throws Exception {
        return upload(file, minioConfig.getBucket().getImage(), "image/");
    }

    /**
     * 上传视频文件
     * @param file 视频文件
     * @return 视频访问 URL
     */
    public String uploadVideo(MultipartFile file) throws Exception {
        return upload(file, minioConfig.getBucket().getVideo(), "video/");
    }

    /**
     * 通用文件上传方法
     * @param file   上传的文件
     * @param bucket 存储桶名称
     * @param prefix 文件路径前缀
     * @return 文件访问 URL
     */
    private String upload(MultipartFile file, String bucket, String prefix) throws Exception {
        if (!minioConfig.isConfigured()) {
            throw new IllegalStateException("MinIO 尚未配置，请设置 MINIO_ACCESS_KEY 和 MINIO_SECRET_KEY");
        }
        // 确保存储桶存在
        ensureBucketExists(bucket);

        // 生成唯一文件名: UUID + 原始扩展名
        String originalName = file.getOriginalFilename();
        String ext = "";
        if (originalName != null && originalName.contains(".")) {
            ext = originalName.substring(originalName.lastIndexOf("."));
        }
        String objectName = prefix + UUID.randomUUID().toString().replace("-", "") + ext;

        // 上传文件
        minioClient.putObject(
                PutObjectArgs.builder()
                        .bucket(bucket)
                        .object(objectName)
                        .stream(file.getInputStream(), file.getSize(), -1)
                        .contentType(file.getContentType())
                        .build()
        );

        log.info("[MinIO] 文件上传成功: {}/{}", bucket, objectName);

        // 返回文件访问 URL（使用 MinIO endpoint + bucket + object）
        return minioConfig.getEndpoint() + "/" + bucket + "/" + objectName;
    }

    /**
     * 获取文件的预签名 URL（用于私有桶的临时访问）
     * @param objectName 对象名称（完整路径）
     * @param bucket     存储桶名称
     * @param expiryHours 过期时间（小时）
     * @return 预签名 URL
     */
    public String getPresignedUrl(String objectName, String bucket, int expiryHours) throws Exception {
        return minioClient.getPresignedObjectUrl(
                GetPresignedObjectUrlArgs.builder()
                        .method(Method.GET)
                        .bucket(bucket)
                        .object(objectName)
                        .expiry(expiryHours, TimeUnit.HOURS)
                        .build()
        );
    }

    /**
     * 删除文件
     * @param objectName 对象名称
     * @param bucket     存储桶名称
     */
    public void deleteFile(String objectName, String bucket) throws Exception {
        minioClient.removeObject(
                RemoveObjectArgs.builder()
                        .bucket(bucket)
                        .object(objectName)
                        .build()
        );
        log.info("[MinIO] 文件删除成功: {}/{}", bucket, objectName);
    }

    /**
     * 确保存储桶存在（不存在则创建）
     */
    private void ensureBucketExists(String bucket) throws Exception {
        boolean found = minioClient.bucketExists(
                BucketExistsArgs.builder().bucket(bucket).build()
        );
        if (!found) {
            minioClient.makeBucket(
                    MakeBucketArgs.builder().bucket(bucket).build()
            );
            log.info("[MinIO] 存储桶创建成功: {}", bucket);
        }
    }
}
