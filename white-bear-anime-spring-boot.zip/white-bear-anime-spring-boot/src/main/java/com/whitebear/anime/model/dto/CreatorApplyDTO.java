package com.whitebear.anime.model.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Data;

/** 用户申请成为创作者时填写的信息。 */
@Data
@Schema(description = "创作者申请请求")
public class CreatorApplyDTO {

    @NotBlank(message = "请填写申请理由")
    @Size(max = 500, message = "申请理由不能超过500个字符")
    @Schema(description = "创作方向、经验及申请理由")
    private String message;
}
