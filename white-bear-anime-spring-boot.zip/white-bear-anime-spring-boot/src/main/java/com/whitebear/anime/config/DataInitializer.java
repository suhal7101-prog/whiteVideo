package com.whitebear.anime.config;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.security.SecureRandom;
import java.time.LocalDateTime;
import java.util.Base64;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;

/**
 * 数据初始化器 — 兼容 H2 和 MySQL
 *
 * @author WhiteBear
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class DataInitializer implements CommandLineRunner {

    private final JdbcTemplate db;
    private final PasswordEncoder enc;

    @Value("${white-bear.seed.enabled:false}")
    private boolean seedEnabled;

    @Value("${white-bear.seed.admin-email:admin@whitebear.com}")
    private String adminEmail;

    @Value("${white-bear.seed.admin-password:}")
    private String adminPassword;

    @Value("${white-bear.seed.test-password:}")
    private String testPassword;

    @Value("${white-bear.seed.disable-legacy-accounts:false}")
    private boolean disableLegacyAccounts;

    @Override
    public void run(String... args) {
        log.info("========== 白熊动漫平台初始化 ==========");

        createTables();
        migrateCommunityTags();
        initBannerEffects();
        if (seedEnabled) {
            initUsers();
            initVideos();
            initBanners();
            initPosts();
            initAnnouncements();
            initAdvertisements();
        } else {
            log.info("示例数据初始化已关闭，可通过 SEED_DATA_ENABLED=true 显式启用");
        }
        repairCommunityDemoData();
        normalizeVideoLikeCounts();
        migrateLegacyAdvertisementImages();
        if (disableLegacyAccounts) {
            disableLegacySeedAccounts();
        }

        log.info("========== 初始化完成 ==========");
    }

    /**
     * 修复并补齐社区话题互动数据：评论数来自真实评论行，评论用户必须是现有有效用户；
     * 每条已审核话题至少 24 条评论，点赞总数保持在 100-300，重复启动不会重复追加。
     */
    private void repairCommunityDemoData() {
        List<Long> activeUserIds = db.queryForList(
                "SELECT id FROM wb_user WHERE deleted = 0 AND status = 'active' ORDER BY id ASC",
                Long.class
        );
        if (activeUserIds.isEmpty()) {
            return;
        }

        List<Long> postsToRepair = db.queryForList(
                "SELECT p.id FROM wb_post p LEFT JOIN wb_user u " +
                        "ON u.id = p.author_id AND u.deleted = 0 AND u.status = 'active' " +
                        "WHERE p.deleted = 0 AND p.status = 'approved' AND (" +
                        "u.id IS NULL OR COALESCE(p.likes, 0) < 100 OR COALESCE(p.likes, 0) > 300 OR " +
                        "(SELECT COUNT(*) FROM wb_comment c WHERE c.post_id = p.id AND c.deleted = 0) < 24 OR " +
                        "COALESCE(p.comments, 0) <> (SELECT COUNT(*) FROM wb_comment c " +
                        "WHERE c.post_id = p.id AND c.deleted = 0))",
                Long.class
        );

        List<Long> orphanPostIds = db.queryForList(
                "SELECT p.id FROM wb_post p LEFT JOIN wb_user u " +
                        "ON u.id = p.author_id AND u.deleted = 0 AND u.status = 'active' " +
                        "WHERE p.deleted = 0 AND u.id IS NULL",
                Long.class
        );
        for (Long postId : orphanPostIds) {
            Long replacementAuthorId = activeUserIds.get((int) Math.floorMod(postId, activeUserIds.size()));
            db.update("UPDATE wb_post SET author_id = ? WHERE id = ?", replacementAuthorId, postId);
        }

        final int targetCommentCount = 24;
        List<String> commentTexts = List.of(
                "这个分享很用心，细节也讲得很清楚。",
                "刚好也在追这一部，看到这里很有共鸣。",
                "画面和配色都很舒服，期待更多作品。",
                "这个角度很有意思，之前还真没注意到。",
                "内容整理得不错，已经收藏了。",
                "同感，这一段确实是整部作品的亮点。",
                "看得出来花了不少时间，支持一下。",
                "人物神态抓得很好，很有原作的感觉。",
                "谢谢分享，评论区也可以继续聊聊细节。",
                "这个作品最近讨论度很高，我也很喜欢。",
                "细节处理得很棒，尤其是光影部分。",
                "看完又想去重温一遍原作了。",
                "很喜欢这种认真交流作品的帖子。",
                "观点很真诚，没有为了热度硬夸。",
                "这一幕我当时也反复看了好几遍。",
                "节奏把握得不错，读起来很顺畅。",
                "希望后面还能看到同系列的分享。",
                "确实不错，已经推荐给一起追番的朋友了。",
                "最喜欢的是角色之间的互动，很自然。",
                "内容有自己的想法，不是简单复述剧情。",
                "这个分析补充了我之前忽略的地方。",
                "支持原创分享，社区就需要这样的内容。",
                "制作质量和表达都在线，点赞支持。",
                "期待楼主继续更新后续内容。"
        );

        for (Long postId : postsToRepair) {
            Integer currentCommentCount = db.queryForObject(
                    "SELECT COUNT(*) FROM wb_comment WHERE post_id = ? AND deleted = 0",
                    Integer.class, postId
            );
            int existing = currentCommentCount == null ? 0 : currentCommentCount;
            for (int index = existing; index < targetCommentCount; index++) {
                Long commenterId = activeUserIds.get((int) Math.floorMod(postId + index, activeUserIds.size()));
                int commentLikes = 2 + (int) Math.floorMod(postId * 5 + index * 7L, 17L);
                db.update("INSERT INTO wb_comment(post_id,user_id,content,likes,deleted,create_time) " +
                                "VALUES(?,?,?,?,0,?)",
                        postId, commenterId, commentTexts.get(index % commentTexts.size()), commentLikes,
                        LocalDateTime.now().minusMinutes((long) (targetCommentCount - index) * 37)
                );
            }

            Integer realCommentCount = db.queryForObject(
                    "SELECT COUNT(*) FROM wb_comment WHERE post_id = ? AND deleted = 0",
                    Integer.class, postId
            );
            Integer currentLikes = db.queryForObject(
                    "SELECT likes FROM wb_post WHERE id = ?", Integer.class, postId
            );
            int normalizedLikes = currentLikes != null && currentLikes >= 100 && currentLikes <= 300
                    ? currentLikes
                    : 100 + (int) Math.floorMod(postId * 47L, 201L);
            db.update("UPDATE wb_post SET likes = ?, comments = ? WHERE id = ?",
                    normalizedLikes, realCommentCount == null ? 0 : realCommentCount, postId);
        }

        if (!postsToRepair.isEmpty() || !orphanPostIds.isEmpty()) {
            log.info("社区数据修复完成：作者 {} 条，热门帖子 {} 条（每帖至少 {} 条真实评论）",
                    orphanPostIds.size(), postsToRepair.size(), targetCommentCount);
        }
    }

    private void normalizeVideoLikeCounts() {
        List<Long> videoIds = db.queryForList(
                "SELECT id FROM wb_video WHERE deleted = 0 AND (likes IS NULL OR likes < 500 OR likes > 900)",
                Long.class
        );
        for (Long videoId : videoIds) {
            db.update(
                    "UPDATE wb_video SET likes = ? WHERE id = ?",
                    ThreadLocalRandom.current().nextLong(500, 901), videoId
            );
        }
        if (!videoIds.isEmpty()) {
            log.info("视频点赞量补齐完成（500-900）：{} 条", videoIds.size());
        }
    }

    private void createTables() {
        db.execute("CREATE TABLE IF NOT EXISTS wb_user (" +
                "id BIGINT AUTO_INCREMENT PRIMARY KEY, username VARCHAR(64) NOT NULL, email VARCHAR(128) NOT NULL," +
                "password VARCHAR(256) NOT NULL, avatar VARCHAR(512), nickname VARCHAR(64), bio VARCHAR(512)," +
                "role VARCHAR(32) DEFAULT 'user', status VARCHAR(32) DEFAULT 'active'," +
                "creator_apply_status VARCHAR(16), creator_apply_message VARCHAR(500), creator_apply_reason VARCHAR(500)," +
                "creator_apply_time TIMESTAMP NULL, creator_audit_time TIMESTAMP NULL, creator_auditor_id BIGINT," +
                "register_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP, last_login TIMESTAMP," +
                "favorite_count INT DEFAULT 0, deleted TINYINT DEFAULT 0," +
                "create_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP, update_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP)");
        safeSchemaChange("ALTER TABLE wb_user ADD COLUMN creator_apply_status VARCHAR(16)");
        safeSchemaChange("ALTER TABLE wb_user ADD COLUMN creator_apply_message VARCHAR(500)");
        safeSchemaChange("ALTER TABLE wb_user ADD COLUMN creator_apply_reason VARCHAR(500)");
        safeSchemaChange("ALTER TABLE wb_user ADD COLUMN creator_apply_time TIMESTAMP NULL");
        safeSchemaChange("ALTER TABLE wb_user ADD COLUMN creator_audit_time TIMESTAMP NULL");
        safeSchemaChange("ALTER TABLE wb_user ADD COLUMN creator_auditor_id BIGINT");
        db.update("UPDATE wb_user SET creator_apply_status = 'approved' " +
                "WHERE role = 'creator' AND (creator_apply_status IS NULL OR creator_apply_status = '')");
        safeIndex("CREATE UNIQUE INDEX idx_user_email ON wb_user(email)");
        safeIndex("CREATE UNIQUE INDEX idx_user_username ON wb_user(username)");
        safeIndex("CREATE INDEX idx_user_creator_apply ON wb_user(creator_apply_status, deleted)");

        db.execute("CREATE TABLE IF NOT EXISTS wb_video (" +
                "id BIGINT AUTO_INCREMENT PRIMARY KEY, title VARCHAR(256) NOT NULL, cover VARCHAR(512)," +
                "source_vod_id BIGINT," +
                "category VARCHAR(64), description TEXT, status VARCHAR(32) DEFAULT 'serializing'," +
                "rating DECIMAL(3,1) DEFAULT 0.0, views BIGINT DEFAULT 0, likes BIGINT DEFAULT 0," +
                "episodes INT DEFAULT 0, tags VARCHAR(512), `year` INT, season VARCHAR(32)," +
                "studio VARCHAR(128), region VARCHAR(32) DEFAULT 'CN'," +
                "submission_source VARCHAR(16) DEFAULT 'platform', uploader_id BIGINT," +
                "audit_status VARCHAR(16) DEFAULT 'approved', audit_reason VARCHAR(500)," +
                "auditor_id BIGINT, submit_time TIMESTAMP NULL, audit_time TIMESTAMP NULL," +
                "deleted TINYINT DEFAULT 0," +
                "create_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP, update_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP)");
        safeSchemaChange("ALTER TABLE wb_video ADD COLUMN source_vod_id BIGINT");
        safeSchemaChange("ALTER TABLE wb_video ADD COLUMN views BIGINT DEFAULT 0");
        safeSchemaChange("ALTER TABLE wb_video ADD COLUMN likes BIGINT DEFAULT 0");
        safeSchemaChange("ALTER TABLE wb_video ADD COLUMN submission_source VARCHAR(16) DEFAULT 'platform'");
        safeSchemaChange("ALTER TABLE wb_video ADD COLUMN uploader_id BIGINT");
        safeSchemaChange("ALTER TABLE wb_video ADD COLUMN audit_status VARCHAR(16) DEFAULT 'approved'");
        safeSchemaChange("ALTER TABLE wb_video ADD COLUMN audit_reason VARCHAR(500)");
        safeSchemaChange("ALTER TABLE wb_video ADD COLUMN auditor_id BIGINT");
        safeSchemaChange("ALTER TABLE wb_video ADD COLUMN submit_time TIMESTAMP NULL");
        safeSchemaChange("ALTER TABLE wb_video ADD COLUMN audit_time TIMESTAMP NULL");
        db.update("UPDATE wb_video SET submission_source = 'platform' " +
                "WHERE submission_source IS NULL OR submission_source = ''");
        db.update("UPDATE wb_video SET audit_status = 'approved' " +
                "WHERE audit_status IS NULL OR audit_status = ''");
        safeIndex("CREATE UNIQUE INDEX idx_video_source_vod_id ON wb_video(source_vod_id)");
        safeIndex("CREATE INDEX idx_video_submission_audit ON wb_video(submission_source, audit_status, deleted)");

        db.execute("CREATE TABLE IF NOT EXISTS wb_episode (" +
                "id BIGINT AUTO_INCREMENT PRIMARY KEY, video_id BIGINT NOT NULL, episode_num INT NOT NULL," +
                "title VARCHAR(256) NOT NULL, duration INT, video_url VARCHAR(1024)," +
                "quality VARCHAR(64) DEFAULT '1080p', file_size BIGINT, deleted TINYINT DEFAULT 0," +
                "create_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP, update_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP)");

        db.execute("CREATE TABLE IF NOT EXISTS wb_banner (" +
                "id BIGINT AUTO_INCREMENT PRIMARY KEY, title VARCHAR(256) NOT NULL, img VARCHAR(512) NOT NULL," +
                "anime_id BIGINT, sort_order INT DEFAULT 0, active TINYINT DEFAULT 1, deleted TINYINT DEFAULT 0," +
                "create_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP, update_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP)");

        db.execute("CREATE TABLE IF NOT EXISTS wb_post (" +
                "id BIGINT AUTO_INCREMENT PRIMARY KEY, title VARCHAR(256) NOT NULL, content TEXT NOT NULL," +
                "author_id BIGINT NOT NULL, tag VARCHAR(64), images TEXT, likes INT DEFAULT 0," +
                "comments INT DEFAULT 0, views INT DEFAULT 0, shares INT DEFAULT 0," +
                "status VARCHAR(32) DEFAULT 'approved', deleted TINYINT DEFAULT 0," +
                "create_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP, update_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP)");

        db.execute("CREATE TABLE IF NOT EXISTS wb_comment (" +
                "id BIGINT AUTO_INCREMENT PRIMARY KEY, post_id BIGINT NOT NULL, user_id BIGINT NOT NULL," +
                "parent_id BIGINT, content TEXT NOT NULL, images TEXT, likes INT DEFAULT 0, deleted TINYINT DEFAULT 0," +
                "create_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP)");
        safeSchemaChange("ALTER TABLE wb_comment ADD COLUMN images TEXT");

        db.execute("CREATE TABLE IF NOT EXISTS wb_video_comment (" +
                "id BIGINT AUTO_INCREMENT PRIMARY KEY, video_id BIGINT NOT NULL, source_type VARCHAR(16) NOT NULL," +
                "user_id BIGINT NOT NULL, parent_id BIGINT, content TEXT NOT NULL, likes INT DEFAULT 0," +
                "deleted TINYINT DEFAULT 0, create_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP)");
        safeIndex("CREATE INDEX idx_video_comment_video ON wb_video_comment(video_id, source_type, deleted, create_time)");
        safeIndex("CREATE INDEX idx_video_comment_parent ON wb_video_comment(parent_id)");

        db.execute("CREATE TABLE IF NOT EXISTS wb_like (" +
                "id BIGINT AUTO_INCREMENT PRIMARY KEY, user_id BIGINT NOT NULL, target_id BIGINT NOT NULL," +
                "`type` VARCHAR(32) NOT NULL, create_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP)");
        safeIndex("CREATE UNIQUE INDEX idx_like_unique ON wb_like(user_id, target_id, `type`)");

        db.execute("CREATE TABLE IF NOT EXISTS wb_favorite (" +
                "id BIGINT AUTO_INCREMENT PRIMARY KEY, user_id BIGINT NOT NULL, anime_id BIGINT NOT NULL," +
                "create_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP)");
        safeIndex("CREATE UNIQUE INDEX idx_fav_unique ON wb_favorite(user_id, anime_id)");

        db.execute("CREATE TABLE IF NOT EXISTS wb_user_follow (" +
                "id BIGINT AUTO_INCREMENT PRIMARY KEY, follower_id BIGINT NOT NULL, following_id BIGINT NOT NULL," +
                "create_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP)");
        safeIndex("CREATE UNIQUE INDEX idx_user_follow_unique ON wb_user_follow(follower_id, following_id)");
        safeIndex("CREATE INDEX idx_user_follow_following ON wb_user_follow(following_id)");

        db.execute("CREATE TABLE IF NOT EXISTS wb_watch_history (" +
                "id BIGINT AUTO_INCREMENT PRIMARY KEY, user_id BIGINT NOT NULL, anime_id BIGINT NOT NULL," +
                "episode_id BIGINT, `current_time` INT DEFAULT 0, duration INT DEFAULT 0," +
                "watched_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, create_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP," +
                "update_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP)");

        db.execute("CREATE TABLE IF NOT EXISTS wb_danmaku (" +
                "id BIGINT AUTO_INCREMENT PRIMARY KEY, anime_id BIGINT NOT NULL, episode_id BIGINT," +
                "user_id BIGINT NOT NULL, content VARCHAR(512) NOT NULL, `timestamp` DOUBLE NOT NULL," +
                "color VARCHAR(16) DEFAULT '#FFFFFF', `type` VARCHAR(16) DEFAULT 'scroll'," +
                "font_size VARCHAR(16) DEFAULT 'normal', create_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP)");

        db.execute("CREATE TABLE IF NOT EXISTS wb_announcement (" +
                "id BIGINT AUTO_INCREMENT PRIMARY KEY, title VARCHAR(256) NOT NULL, content TEXT NOT NULL," +
                "pinned TINYINT DEFAULT 0, status VARCHAR(16) DEFAULT 'published', publisher_id BIGINT," +
                "publish_time TIMESTAMP, deleted TINYINT DEFAULT 0," +
                "create_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP, update_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP)");

        db.execute("CREATE TABLE IF NOT EXISTS wb_advertisement (" +
                "id BIGINT AUTO_INCREMENT PRIMARY KEY, title VARCHAR(128) NOT NULL, description VARCHAR(500)," +
                "image_url VARCHAR(512) NOT NULL, target_url VARCHAR(512), position VARCHAR(64) DEFAULT 'home_top'," +
                "status VARCHAR(16) DEFAULT 'active', start_time TIMESTAMP NULL, end_time TIMESTAMP NULL," +
                "sort_order INT DEFAULT 0, deleted TINYINT DEFAULT 0," +
                "create_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP, update_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP)");
        safeIndex("CREATE INDEX idx_advertisement_status_position ON wb_advertisement(status, position)");

        db.execute("CREATE TABLE IF NOT EXISTS wb_banner_effect (" +
                "id BIGINT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(128) NOT NULL," +
                "theme_key VARCHAR(64) NOT NULL, date_key VARCHAR(32) NOT NULL," +
                "data_url VARCHAR(512) NOT NULL, asset_base_url VARCHAR(512), preview_url VARCHAR(1024)," +
                "target_page VARCHAR(32) DEFAULT 'ai', status VARCHAR(16) DEFAULT 'active'," +
                "layer_count INT DEFAULT 0, has_video TINYINT DEFAULT 0, sort_order INT DEFAULT 0," +
                "deleted TINYINT DEFAULT 0, create_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP," +
                "update_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP)");
        safeIndex("CREATE UNIQUE INDEX idx_banner_effect_theme ON wb_banner_effect(theme_key)");
        safeIndex("CREATE INDEX idx_banner_effect_active ON wb_banner_effect(target_page, status, deleted)");
        safeSchemaChange("ALTER TABLE wb_announcement ADD COLUMN status VARCHAR(16) DEFAULT 'published'");
        safeSchemaChange("ALTER TABLE wb_announcement ADD COLUMN publisher_id BIGINT");
        safeSchemaChange("ALTER TABLE wb_announcement ADD COLUMN publish_time TIMESTAMP");
        db.update("UPDATE wb_announcement SET status = 'published' WHERE status IS NULL OR status = ''");

        db.execute("CREATE TABLE IF NOT EXISTS wb_announcement_read (" +
                "id BIGINT AUTO_INCREMENT PRIMARY KEY, user_id BIGINT NOT NULL, announcement_id BIGINT NOT NULL," +
                "read_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP)");
        safeIndex("CREATE UNIQUE INDEX idx_announcement_read_unique ON wb_announcement_read(user_id, announcement_id)");
        safeIndex("CREATE INDEX idx_announcement_read_user ON wb_announcement_read(user_id)");

        db.execute("CREATE TABLE IF NOT EXISTS wb_operation_log (" +
                "id BIGINT AUTO_INCREMENT PRIMARY KEY, user_id BIGINT, username VARCHAR(64)," +
                "action VARCHAR(256) NOT NULL, target VARCHAR(256), ip VARCHAR(64)," +
                "create_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP)");

        db.execute("CREATE TABLE IF NOT EXISTS wb_play_stats (" +
                "id BIGINT AUTO_INCREMENT PRIMARY KEY, video_id BIGINT NOT NULL, episode_id BIGINT," +
                "user_id BIGINT, ip VARCHAR(64), play_date DATE NOT NULL, play_count INT DEFAULT 1," +
                "create_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP)");

        log.info("18张表创建完成");
    }

    private void initBannerEffects() {
        List<BannerEffectSeed> effects = List.of(
                new BannerEffectSeed("夏日幻想·远景", "2023-08-21-a", "2023-08-21",
                        "/banner/2023-08-21-a/data.json", "", "https://pic.imgdb.cn/item/64d89f131ddac507ccdb7db2.webp", 16, 0),
                new BannerEffectSeed("夏日幻想·街景", "2023-08-21-b", "2023-08-21",
                        "/banner/2023-08-21-b/data.json", "", "https://pic.imgdb.cn/item/64e08056661c6c8e540748c5.webp", 15, 0),
                new BannerEffectSeed("海上明月", "2023-10-01", "2023-10-01",
                        "/banner/2023-10-01/data.json", "/banner/2023-10-01", "/banner/2023-10-01/39f5846ccf601e178afe37eef2e9759d38078d56.png@1c.webp", 18, 1),
                new BannerEffectSeed("秋日松鼠", "2023-10-26", "2023-10-26",
                        "/banner/2023-10-26/data.json", "/banner/2023-10-26", "/banner/2023-10-26/0876da4f3ec73ff180fc87b46b6d1bcf4d52030a.png@1c.webp", 17, 0),
                new BannerEffectSeed("秋叶风筝", "2023-11-17", "2023-11-17",
                        "/banner/2023-11-17/data.json", "/banner/2023-11-17", "/banner/2023-11-17/b51d0d75b1b27b669e456aa36bdf3b46f658a531.png@1c.webp", 20, 0),
                new BannerEffectSeed("雪原世界", "2023-12-12", "2023-12-12",
                        "/banner/2023-12-12/data.json", "/banner/2023-12-12", "/banner/2023-12-12/cb5b4ca963e3a1a6d3917182561844b24a05fc20.png@1c.webp", 21, 1),
                new BannerEffectSeed("冬日特辑", "2024-02-01", "2024-02-01",
                        "/banner/2024-02-01/data.json", "/banner/2024-02-01", "/banner/2024-02-01/01b79b5b5b38d7305a0ca1780c24662cc5a59f18.png@1c.webp", 20, 1),
                new BannerEffectSeed("花草夏日", "2024-06-06", "2024-06-06",
                        "/banner/2024-06-06/data.json", "/banner/2024-06-06", "/banner/2024-06-06/17a1bcfacfc51f000cad0611dca32020b18db6f5.png@1c.webp", 24, 1),
                new BannerEffectSeed("海洋机场", "2024-06-26", "2024-06-26",
                        "/banner/2024-06-26/data.json", "/banner/2024-06-26", "/banner/2024-06-26/75ec2d45ce8c942a1f7379d4641171da4d90ab0d.png@1c.webp", 21, 1),
                new BannerEffectSeed("魔法高架", "2024-09-26", "2024-09-26",
                        "/banner/2024-09-26/data.json", "/banner/2024-09-26", "/banner/2024-09-26/18e14b236c8c0478b9f126b53dc149718c8277d6.png@1c.webp", 22, 1),
                new BannerEffectSeed("云端列车", "2024-12-26", "2024-12-26",
                        "/banner/2024-12-26/data.json", "/banner/2024-12-26", "/banner/2024-12-26/477fb7a2f5e2cc1b2aa00c679c8ab168b47ff1b9.png@1c.webp", 22, 0),
                new BannerEffectSeed("春日飞舞", "2025-04-05", "2025-04-05",
                        "/banner/2025-04-05/data.json", "/banner/2025-04-05", "/banner/2025-04-05/5598c26a3d090ba7cdf1d99de1e7d76561d56e78.png@1c.webp", 18, 1),
                new BannerEffectSeed("清凉夏日", "2025-06-15", "2025-06-15",
                        "/banner/2025-06-15/data.json", "/banner/2025-06-15", "/banner/2025-06-15/081110f6c4c54ab35e31cf0eb7bd0b129ee4135c.png@1c.webp", 27, 1),
                new BannerEffectSeed("流星沙滩", "2025-09-10", "2025-09-10",
                        "/banner/2025-09-10/data.json", "/banner/2025-09-10", "/banner/2025-09-10/90240f707cb4a015bbf8bbd13e018b3f664087ce.png@1c.webp", 23, 1),
                new BannerEffectSeed("冬木站台", "2026-01-09", "2026-01-09",
                        "/banner/2026-01-09/data.json", "/banner/2026-01-09", "/banner/2026-01-09/48bee957f95b7bc5f0e1b7fc14b25a4cca26901a.png@1c.webp", 33, 1),
                new BannerEffectSeed("骑行春日", "2026-04-27", "2026-04-27",
                        "/banner/2026-04-27/data.json", "/banner/2026-04-27", "/banner/2026-04-27/7ba90052bb0a7d52ff2e2651c58325176823dab7.png@1c.webp", 32, 0),
                new BannerEffectSeed("田野列车", "2026-07-27", "2026-07-27",
                        "/banner/2026-07-27/data.json", "/banner/2026-07-27", "/banner/2026-07-27/7ba90052bb0a7d52ff2e2651c58325176823dab7.png@1c.webp", 32, 0)
        );
        int order = 1;
        for (BannerEffectSeed effect : effects) {
            Integer count = db.queryForObject(
                    "SELECT COUNT(*) FROM wb_banner_effect WHERE theme_key = ?", Integer.class, effect.themeKey());
            if (count == null || count == 0) {
                db.update("INSERT INTO wb_banner_effect(name,theme_key,date_key,data_url,asset_base_url," +
                                "preview_url,target_page,status,layer_count,has_video,sort_order,deleted) " +
                                "VALUES(?,?,?,?,?,?,'ai','active',?,?,?,0)",
                        effect.name(), effect.themeKey(), effect.dateKey(), effect.dataUrl(), effect.assetBaseUrl(),
                        effect.previewUrl(), effect.layerCount(), effect.hasVideo(), order);
            }
            order++;
        }
    }

    private record BannerEffectSeed(String name, String themeKey, String dateKey, String dataUrl,
                                    String assetBaseUrl, String previewUrl, int layerCount, int hasVideo) {}

    /** 创建索引（兼容不支持 IF NOT EXISTS 的数据库） */
    private void safeIndex(String sql) {
        try { db.execute(sql); } catch (Exception ignored) {}
    }

    /** 为已存在的开发数据库补充字段。重复执行时由数据库拒绝，初始化继续。 */
    private void safeSchemaChange(String sql) {
        try { db.execute(sql); } catch (Exception ignored) {}
    }

    private void initUsers() {
        Integer count = db.queryForObject("SELECT COUNT(*) FROM wb_user", Integer.class);
        if (count != null && count > 0) return;

        if (adminPassword == null || adminPassword.length() < 12 || testPassword == null || testPassword.length() < 12) {
            throw new IllegalStateException("启用示例数据时，SEED_ADMIN_PASSWORD 和 SEED_TEST_PASSWORD 均须至少 12 位");
        }

        String pwd1 = enc.encode(adminPassword);
        String pwd2 = enc.encode(testPassword);
        db.update("INSERT INTO wb_user(username,email,password,nickname,avatar,role,status,register_date) VALUES(?,?,?,?,?,?,?,CURRENT_TIMESTAMP)",
                "admin", adminEmail, pwd1, "白熊管理员", "https://picsum.photos/seed/admin/200", "admin", "active");
        db.update("INSERT INTO wb_user(username,email,password,nickname,avatar,role,status,register_date) VALUES(?,?,?,?,?,?,?,CURRENT_TIMESTAMP)",
                "test", "test@whitebear.com", pwd2, "白熊粉丝", "https://picsum.photos/seed/me/200", "user", "active");
        log.info("用户创建完成: admin / test");
    }

    private void initAnnouncements() {
        Long publisherId = null;
        List<Long> adminIds = db.queryForList(
                "SELECT id FROM wb_user WHERE role = 'admin' AND deleted = 0 ORDER BY id ASC LIMIT 1", Long.class);
        if (!adminIds.isEmpty()) publisherId = adminIds.get(0);

        insertAnnouncementIfMissing("新用户送额度",
                "新用户加售后群免费送5刀额度体验，售后群QQ：784593651",
                1, publisherId, java.time.LocalDateTime.now().minusHours(6));
        insertAnnouncementIfMissing("邀请充值返利上线 & 售后群开通",
                "邀请好友注册并完成充值即可获得返利，售后服务群现已同步开放。",
                0, publisherId, java.time.LocalDateTime.now().minusDays(1));
        insertAnnouncementIfMissing("意见反馈通道已开通",
                "使用过程中遇到问题，可通过社区反馈通道提交意见与建议。",
                0, publisherId, java.time.LocalDateTime.now().minusDays(2));
        insertAnnouncementIfMissing("中转明细",
                "视频数据中转与同步明细现已开放查看。",
                0, publisherId, java.time.LocalDateTime.now().minusDays(3));
    }

    private void insertAnnouncementIfMissing(String title, String content, int pinned,
                                             Long publisherId, java.time.LocalDateTime publishTime) {
        Integer count = db.queryForObject(
                "SELECT COUNT(*) FROM wb_announcement WHERE title = ?", Integer.class, title);
        if (count != null && count > 0) return;
        db.update("INSERT INTO wb_announcement(title,content,pinned,status,publisher_id,publish_time,deleted) " +
                        "VALUES(?,?,?,'published',?,?,0)",
                title, content, pinned, publisherId, publishTime);
        log.info("公告数据写入: {}", title);
    }

    private void initAdvertisements() {
        insertAdvertisementIfMissing("不会安装我帮你", "快速安装与配置服务",
                "/api/advertisement-images/O1CN01kHq5H524of5nRgOXs_!!2207239727438.jpg_q50.jpg_.png",
                "https://www.taobao.com/", "nav_top", 0, 0, 365);
        insertAdvertisementIfMissing("新番导览专场", "发现最新更新的动漫作品",
                "/api/advertisement-images/O1CN01gjg1hY23QYWwW4Ju4_!!375997250.jpg_q50.jpg_.png",
                "/discover", "home_top", 1, 0, 45);
        insertAdvertisementIfMissing("社区创作征集", "分享你的动漫观后感与同人创作",
                "/api/advertisement-images/O1CN01kHq5H524of5nRgOXs_!!2207239727438.jpg_q50.jpg_.png",
                "/community", "community_sidebar", 2, 0, 30);
        insertAdvertisementIfMissing("AI 动漫助手", "用 AI 问答、推荐与追番助手发现好番",
                "/api/advertisement-images/O1CN01NiwXic289Dgx8pMFD_!!2218721907889.png_.png",
                "/ai", "ai_sidebar", 3, 0, 60);
        insertAdvertisementIfMissing("暂停时刻推荐", "休息一下，发现更多精彩动漫",
                "/api/advertisement-images/O1CN01OIEpxb1Dkq7Bjjha1_!!2671610255.jpg_q50.jpg_.png",
                "/discover", "player_pause", 4, 0, 60);

    }

    private void migrateLegacyAdvertisementImages() {
        migrateLegacyAdvertisementImage("新番导览专场",
                "/api/advertisement-images/O1CN01gjg1hY23QYWwW4Ju4_!!375997250.jpg_q50.jpg_.png");
        migrateLegacyAdvertisementImage("社区创作征集",
                "/api/advertisement-images/O1CN01kHq5H524of5nRgOXs_!!2207239727438.jpg_q50.jpg_.png");
        migrateLegacyAdvertisementImage("AI 动漫助手",
                "/api/advertisement-images/O1CN01NiwXic289Dgx8pMFD_!!2218721907889.png_.png");
        migrateLegacyAdvertisementImage("暂停时刻推荐",
                "/api/advertisement-images/O1CN01OIEpxb1Dkq7Bjjha1_!!2671610255.jpg_q50.jpg_.png");
    }

    private void migrateLegacyAdvertisementImage(String title, String imageUrl) {
        db.update("UPDATE wb_advertisement SET image_url = ? WHERE title = ? " +
                "AND image_url LIKE '/banner/2026-07-27/%'", imageUrl, title);
    }

    private void insertAdvertisementIfMissing(String title, String description, String imageUrl,
                                              String targetUrl, String position, int sortOrder,
                                              int startOffsetDays, int durationDays) {
        Integer count = db.queryForObject(
                "SELECT COUNT(*) FROM wb_advertisement WHERE title = ?", Integer.class, title);
        if (count != null && count > 0) return;
        java.time.LocalDateTime start = java.time.LocalDateTime.now().plusDays(startOffsetDays);
        db.update("INSERT INTO wb_advertisement(title,description,image_url,target_url,position,status," +
                        "start_time,end_time,sort_order,deleted) VALUES(?,?,?,?,?,'active',?,?,?,0)",
                title, description, imageUrl, targetUrl, position, start, start.plusDays(durationDays), sortOrder);
        log.info("广告数据写入: {}", title);
    }

    private void disableLegacySeedAccounts() {
        List<Map<String, Object>> legacyUsers = db.queryForList(
                "SELECT id, username, password FROM wb_user WHERE deleted = 0 AND username IN ('admin', 'test')");
        for (Map<String, Object> user : legacyUsers) {
            String username = String.valueOf(user.get("username"));
            String encodedPassword = String.valueOf(user.get("password"));
            String legacyPassword = "admin".equals(username) ? "admin123" : "123456";
            if (!enc.matches(legacyPassword, encodedPassword)) {
                continue;
            }

            byte[] randomBytes = new byte[32];
            new SecureRandom().nextBytes(randomBytes);
            String replacement = Base64.getUrlEncoder().withoutPadding().encodeToString(randomBytes);
            db.update("UPDATE wb_user SET password = ?, status = 'banned', update_time = CURRENT_TIMESTAMP WHERE id = ?",
                    enc.encode(replacement), user.get("id"));
            log.warn("检测到旧版示例账号 {}，已禁用并随机化其密码", username);
        }
    }

    private void initVideos() {
        Integer count = db.queryForObject("SELECT COUNT(*) FROM wb_video", Integer.class);
        if (count != null && count > 0) return;

        db.update("INSERT INTO wb_video(title,cover,category,description,status,rating,views,likes,episodes,tags,`year`,region) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
                "斗罗大陆II绝世唐门", "https://picsum.photos/seed/anime1/400/225", "热血", "唐门重建一万年后，霍雨浩开启传奇之旅。", "连载中", 9.2, 1520000L, 89000L, 52, "热血,战斗,玄幻", 2023, "中国");
        db.update("INSERT INTO wb_video(title,cover,category,description,status,rating,views,likes,episodes,tags,`year`,region) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
                "开心锤锤世界", "https://picsum.photos/seed/anime2/400/225", "搞笑", "爆笑日常，锤锤带你体验无穷欢乐。", "连载中", 8.8, 980000L, 56000L, 120, "搞笑,日常", 2022, "中国");
        db.update("INSERT INTO wb_video(title,cover,category,description,status,rating,views,likes,episodes,tags,`year`,region) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
                "从今天开始当城主", "https://picsum.photos/seed/anime3/400/225", "奇幻", "穿越异世界成为城主。", "已完结", 8.5, 650000L, 42000L, 24, "奇幻,冒险", 2023, "中国");
        db.update("INSERT INTO wb_video(title,cover,category,description,status,rating,views,likes,episodes,tags,`year`,region) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
                "破防临界线", "https://picsum.photos/seed/anime4/400/225", "科幻", "虚拟与现实交错的世界。", "连载中", 8.9, 720000L, 38000L, 36, "科幻,战斗", 2024, "中国");
        db.update("INSERT INTO wb_video(title,cover,category,description,status,rating,views,likes,episodes,tags,`year`,region) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
                "夏日恋歌", "https://picsum.photos/seed/anime5/400/225", "恋爱", "夏天海边小镇的青春物语。", "已完结", 8.7, 430000L, 31000L, 13, "恋爱,青春", 2023, "中国");
        log.info("视频数据完成 (5部)");
    }

    private void initBanners() {
        Integer count = db.queryForObject("SELECT COUNT(*) FROM wb_banner", Integer.class);
        if (count != null && count > 0) return;

        db.update("INSERT INTO wb_banner(title,img,anime_id,sort_order,active) VALUES(?,?,?,?,?)",
                "斗罗大陆II", "https://picsum.photos/seed/banner1/1200/500", 1L, 1, 1);
        db.update("INSERT INTO wb_banner(title,img,anime_id,sort_order,active) VALUES(?,?,?,?,?)",
                "开心锤锤世界", "https://picsum.photos/seed/banner2/1200/500", 2L, 2, 1);
        db.update("INSERT INTO wb_banner(title,img,anime_id,sort_order,active) VALUES(?,?,?,?,?)",
                "破防临界线", "https://picsum.photos/seed/banner3/1200/500", 4L, 3, 1);
        log.info("轮播图完成 (3张)");
    }

    private void initPosts() {
        Integer count = db.queryForObject("SELECT COUNT(*) FROM wb_post", Integer.class);
        if (count != null && count > 0) return;

        List<Long> authors = db.queryForList(
                "SELECT id FROM wb_user WHERE deleted = 0 AND status = 'active' ORDER BY id ASC",
                Long.class
        );
        if (authors.isEmpty()) {
            log.warn("没有可用用户，跳过社区示例帖子初始化");
            return;
        }
        Long authorId = authors.size() > 1 ? authors.get(1) : authors.get(0);

        db.update("INSERT INTO wb_post(title,content,author_id,tag,likes,comments,views,status) VALUES(?,?,?,?,?,?,?,?)",
                "【分享】斗罗大陆II观后感", "国漫之光！每一帧都是壁纸。", authorId, "分享", 186, 24, 5600, "approved");
        db.update("INSERT INTO wb_post(title,content,author_id,tag,likes,comments,views,status) VALUES(?,?,?,?,?,?,?,?)",
                "【分享】锤锤创作", "花了三天画的锤锤角色图！", authorId, "分享", 194, 24, 3200, "approved");
        db.update("INSERT INTO wb_post(title,content,author_id,tag,likes,comments,views,status) VALUES(?,?,?,?,?,?,?,?)",
                "【推荐】本季必看国漫", "这季国漫质量相当不错！", authorId, "推荐", 241, 24, 1800, "approved");
        log.info("帖子数据完成 (3条)");
    }

    private void migrateCommunityTags() {
        db.update("UPDATE wb_post SET tag='分享', " +
                "title=REPLACE(REPLACE(REPLACE(title, '【讨论】', '【分享】'), '【同人画】', '【分享】'), '【同人】', '【分享】') " +
                "WHERE tag IN ('讨论', '同人')");
    }
}
