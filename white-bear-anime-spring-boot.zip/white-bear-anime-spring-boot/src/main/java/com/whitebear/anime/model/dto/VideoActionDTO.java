package com.whitebear.anime.model.dto;

import lombok.Data;

/** 前台视频追番、点赞等用户行为的统一视频定位信息。 */
@Data
public class VideoActionDTO {
    /** 本地 wb_video 主键（数据库视频使用）。 */
    private Long videoId;
    /** Python 资源站视频 ID。 */
    private Long sourceVodId;
    private String title;
    private String cover;
    private String category;
    private String description;
    private String status;
    private Integer episodes;
    private Integer year;
}
