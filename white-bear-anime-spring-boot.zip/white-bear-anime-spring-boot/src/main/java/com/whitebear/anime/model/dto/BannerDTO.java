package com.whitebear.anime.model.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

/**
 * 轮播图 DTO
 *
 * @author WhiteBear
 */
@Data
@Schema(description = "轮播图请求 DTO")
public class BannerDTO {

    @NotBlank(message = "标题不能为空")
    @Schema(description = "标题")
    private String title;

    @NotBlank(message = "图片URL不能为空")
    @Schema(description = "图片 URL")
    private String img;

    @Schema(description = "关联动漫 ID")
    private Long animeId;

    @Schema(description = "排序号")
    private Integer sortOrder;

    @Schema(description = "是否启用")
    private Integer active;
}
