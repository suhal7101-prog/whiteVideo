package com.whitebear.anime.model.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
public class BannerEffectDTO {
    @NotBlank(message = "效果图名称不能为空")
    @Size(max = 128, message = "效果图名称不能超过128个字符")
    private String name;
    private String targetPage;
    private String status;
    private Integer sortOrder;
}
