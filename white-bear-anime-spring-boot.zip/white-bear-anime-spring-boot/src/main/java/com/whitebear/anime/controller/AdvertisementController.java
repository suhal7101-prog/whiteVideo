package com.whitebear.anime.controller;

import com.whitebear.anime.mapper.AdvertisementMapper;
import com.whitebear.anime.model.Result;
import com.whitebear.anime.model.entity.Advertisement;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Tag(name = "前台广告")
@RestController
@RequestMapping("/api/advertisements")
@RequiredArgsConstructor
public class AdvertisementController {

    private final AdvertisementMapper advertisementMapper;

    @Operation(summary = "查询当前有效广告")
    @GetMapping
    public Result<List<Advertisement>> getActiveAdvertisements(
            @RequestParam(required = false) String position) {
        String normalizedPosition = position == null ? null : position.trim();
        return Result.ok(advertisementMapper.selectActive(normalizedPosition));
    }
}
