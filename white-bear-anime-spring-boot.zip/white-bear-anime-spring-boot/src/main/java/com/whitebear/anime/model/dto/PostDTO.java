package com.whitebear.anime.model.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

import java.util.List;

/**
 * 发布帖子 DTO
 *
 * @author WhiteBear
 */
@Data
@Schema(description = "发布帖子请求")
public class PostDTO {

    @NotBlank(message = "标题不能为空")
    @Schema(description = "帖子标题")
    private String title;

    @NotBlank(message = "内容不能为空")
    @Schema(description = "帖子内容")
    private String content;

    @Schema(description = "标签")
    @NotBlank(message = "请选择内容标签")
    private String tag;

    @Schema(description = "图片 URL 列表")
    private List<String> images;
}
