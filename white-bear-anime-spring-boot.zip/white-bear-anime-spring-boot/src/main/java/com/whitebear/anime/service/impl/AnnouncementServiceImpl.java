package com.whitebear.anime.service.impl;

import com.whitebear.anime.mapper.AnnouncementMapper;
import com.whitebear.anime.mapper.AnnouncementReadMapper;
import com.whitebear.anime.model.Result;
import com.whitebear.anime.model.entity.Announcement;
import com.whitebear.anime.security.SecurityUtils;
import com.whitebear.anime.service.AnnouncementService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class AnnouncementServiceImpl implements AnnouncementService {

    private final AnnouncementMapper announcementMapper;
    private final AnnouncementReadMapper announcementReadMapper;

    @Override
    public Result<Object> getMyAnnouncements() {
        Long userId = SecurityUtils.getCurrentUserId();
        if (userId == null) return Result.unauthorized("请先登录");

        List<Map<String, Object>> list = announcementMapper.selectPublishedForUser(userId);
        long unreadCount = list.stream()
                .filter(item -> !booleanValue(item.get("isRead")))
                .count();
        return Result.ok(Map.of("list", list, "unreadCount", unreadCount, "total", list.size()));
    }

    @Override
    @Transactional
    public Result<Void> markRead(Long announcementId) {
        Long userId = SecurityUtils.getCurrentUserId();
        if (userId == null) return Result.unauthorized("请先登录");

        Announcement announcement = announcementMapper.selectById(announcementId);
        if (announcement == null || !"published".equals(announcement.getStatus())) {
            return Result.notFound("公告不存在或尚未发布");
        }
        announcementReadMapper.markRead(userId, announcementId);
        return Result.success("已标记为已读");
    }

    private boolean booleanValue(Object value) {
        if (value instanceof Boolean bool) return bool;
        if (value instanceof Number number) return number.intValue() != 0;
        return "true".equalsIgnoreCase(String.valueOf(value)) || "1".equals(String.valueOf(value));
    }
}
