package com.whitebear.anime.security;

import com.whitebear.anime.model.Result;
import com.whitebear.anime.mapper.UserMapper;
import com.whitebear.anime.model.entity.User;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Collections;

/**
 * JWT 认证过滤器 —— 在每次请求时解析 Token 并设置认证信息
 *
 * @author WhiteBear
 */
@Component
@RequiredArgsConstructor
public class JwtAuthenticationFilter extends OncePerRequestFilter {

    private final JwtUtils jwtUtils;
    private final UserMapper userMapper;

    /** JSON 序列化工具 */
    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();

    @Override
    protected void doFilterInternal(
            HttpServletRequest request,
            HttpServletResponse response,
            FilterChain filterChain) throws ServletException, IOException {

        // 从请求头中提取 Token
        String token = extractToken(request);

        if (StringUtils.hasText(token) && jwtUtils.validateToken(token)) {
            // 解析 Token 中的用户信息
            Long userId = jwtUtils.getUserId(token);
            User user = userMapper.selectById(userId);
            if (user == null || "banned".equals(user.getStatus())) {
                filterChain.doFilter(request, response);
                return;
            }

            // 构建 Spring Security 认证信息
            // 前端存储的 role 字段: "user" / "admin"
            // 转换为 Spring Security 权限: "ROLE_USER" / "ROLE_ADMIN"
            String authority = "ROLE_" + user.getRole().toUpperCase();
            UsernamePasswordAuthenticationToken authentication =
                    new UsernamePasswordAuthenticationToken(
                            user.getEmail(),     // principal
                            token,               // credentials
                            Collections.singletonList(new SimpleGrantedAuthority(authority))
                    );
            // 将用户 ID 存入 details 中，方便后续获取
            authentication.setDetails(userId);

            // 设置到 Security 上下文
            SecurityContextHolder.getContext().setAuthentication(authentication);
        }

        filterChain.doFilter(request, response);
    }

    /**
     * 从请求头中提取 Bearer Token
     */
    private String extractToken(HttpServletRequest request) {
        String bearerToken = request.getHeader("Authorization");
        if (StringUtils.hasText(bearerToken) && bearerToken.startsWith("Bearer ")) {
            return bearerToken.substring(7); // 去掉 "Bearer " 前缀
        }
        return null;
    }

    /**
     * 返回 JSON 格式的 401 未授权响应
     */
    private void writeUnauthorizedResponse(HttpServletResponse response, String message) throws IOException {
        response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
        response.setContentType(MediaType.APPLICATION_JSON_VALUE);
        response.setCharacterEncoding(StandardCharsets.UTF_8.name());
        Result<Void> result = Result.unauthorized(message);
        OBJECT_MAPPER.writeValue(response.getWriter(), result);
    }
}
