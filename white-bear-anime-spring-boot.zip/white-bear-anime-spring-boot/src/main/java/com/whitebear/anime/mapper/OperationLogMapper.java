package com.whitebear.anime.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.whitebear.anime.model.entity.OperationLog;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * 操作日志 Mapper
 *
 * @author WhiteBear
 */
@Mapper
public interface OperationLogMapper extends BaseMapper<OperationLog> {

    /** 查询最新日志 */
    @Select("SELECT * FROM wb_operation_log ORDER BY create_time DESC LIMIT #{limit}")
    List<OperationLog> selectRecent(@Param("limit") int limit);
}
