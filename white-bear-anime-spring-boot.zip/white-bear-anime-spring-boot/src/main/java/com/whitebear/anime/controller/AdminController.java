package com.whitebear.anime.controller;

import com.whitebear.anime.model.Result;
import com.whitebear.anime.model.dto.AuditPostDTO;
import com.whitebear.anime.model.dto.AnnouncementDTO;
import com.whitebear.anime.model.dto.BannerDTO;
import com.whitebear.anime.model.dto.VideoDTO;
import com.whitebear.anime.model.dto.VideoAuditDTO;
import com.whitebear.anime.model.dto.CreatorAuditDTO;
import com.whitebear.anime.model.dto.AdvertisementDTO;
import com.whitebear.anime.model.dto.BannerEffectDTO;
import com.whitebear.anime.service.AdminService;
import com.whitebear.anime.service.AdvertisementImageService;
import com.whitebear.anime.service.BannerEffectService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.MediaType;
import org.springframework.web.multipart.MultipartFile;

import java.util.Map;

/**
 * 管理后台控制器
 * 匹配前端 API: /api/admin/*
 *
 * @author WhiteBear
 */
@Tag(name = "管理后台", description = "用户管理、视频管理、内容管理、数据统计")
@RestController
@RequestMapping("/api/admin")
@RequiredArgsConstructor
@PreAuthorize("hasRole('ADMIN')")  // 控制器级别权限控制
public class AdminController {

    private final AdminService adminService;
    private final AdvertisementImageService advertisementImageService;
    private final BannerEffectService bannerEffectService;

    // ==================== 用户管理 ====================

    @Operation(summary = "获取用户列表")
    @GetMapping("/users")
    public Result<?> getUsers(
            @RequestParam(defaultValue = "1") Integer page,
            @RequestParam(defaultValue = "10") Integer size,
            @RequestParam(required = false) String keyword,
            @RequestParam(required = false) String role,
            @RequestParam(required = false) String status) {
        return adminService.getUsers(page, size, keyword, role, status);
    }

    @Operation(summary = "编辑用户信息")
    @PutMapping("/user/{id}")
    public Result<?> updateUser(@PathVariable Long id, @RequestBody Map<String, Object> data) {
        return adminService.updateUser(id, data);
    }

    @Operation(summary = "删除用户")
    @DeleteMapping("/user/{id}")
    public Result<?> deleteUser(@PathVariable Long id) {
        return adminService.deleteUser(id);
    }

    @Operation(summary = "重置用户密码")
    @PutMapping("/user/{id}/password")
    public Result<?> resetPassword(@PathVariable Long id, @RequestBody Map<String, String> body) {
        return adminService.resetPassword(id, body.get("password"));
    }

    @Operation(summary = "获取创作者申请列表")
    @GetMapping("/creator-applications")
    public Result<?> getCreatorApplications(
            @RequestParam(defaultValue = "1") Integer page,
            @RequestParam(defaultValue = "10") Integer size,
            @RequestParam(required = false) String keyword,
            @RequestParam(defaultValue = "pending") String applyStatus) {
        return adminService.getCreatorApplications(page, size, keyword, applyStatus);
    }

    @Operation(summary = "审核创作者申请")
    @PutMapping("/creator-application/{userId}/audit")
    public Result<?> auditCreatorApplication(@PathVariable Long userId,
                                             @Valid @RequestBody CreatorAuditDTO dto) {
        return adminService.auditCreatorApplication(userId, dto);
    }

    // ==================== 视频管理 ====================

    @Operation(summary = "获取视频列表")
    @GetMapping("/videos")
    public Result<?> getVideos(
            @RequestParam(defaultValue = "1") Integer page,
            @RequestParam(defaultValue = "10") Integer size,
            @RequestParam(required = false) String keyword,
            @RequestParam(required = false) String category) {
        return adminService.getVideos(page, size, keyword, category);
    }

    @Operation(summary = "新增视频")
    @PostMapping("/video")
    public Result<?> createVideo(@Valid @RequestBody VideoDTO dto) {
        return adminService.createVideo(dto);
    }

    @Operation(summary = "编辑视频")
    @PutMapping("/video/{id}")
    public Result<?> updateVideo(@PathVariable Long id, @Valid @RequestBody VideoDTO dto) {
        return adminService.updateVideo(id, dto);
    }

    @Operation(summary = "删除视频")
    @DeleteMapping("/video/{id}")
    public Result<?> deleteVideo(@PathVariable Long id) {
        return adminService.deleteVideo(id);
    }

    @Operation(summary = "获取用户投稿视频列表")
    @GetMapping("/video-submissions")
    public Result<?> getVideoSubmissions(
            @RequestParam(defaultValue = "1") Integer page,
            @RequestParam(defaultValue = "10") Integer size,
            @RequestParam(required = false) String keyword,
            @RequestParam(defaultValue = "pending") String auditStatus) {
        return adminService.getVideoSubmissions(page, size, keyword, auditStatus);
    }

    @Operation(summary = "审核用户投稿视频")
    @PutMapping("/video-submission/{id}/audit")
    public Result<?> auditVideoSubmission(@PathVariable Long id,
                                          @Valid @RequestBody VideoAuditDTO dto) {
        return adminService.auditVideoSubmission(id, dto);
    }

    // ==================== 内容管理 ====================

    @Operation(summary = "获取轮播图列表")
    @GetMapping("/banners")
    public Result<?> getBanners() {
        return adminService.getBanners();
    }

    @Operation(summary = "新增轮播图")
    @PostMapping("/banner")
    public Result<?> createBanner(@Valid @RequestBody BannerDTO dto) {
        return adminService.createBanner(dto);
    }

    @Operation(summary = "编辑轮播图")
    @PutMapping("/banner/{id}")
    public Result<?> updateBanner(@PathVariable Long id, @RequestBody BannerDTO dto) {
        return adminService.updateBanner(id, dto);
    }

    @Operation(summary = "获取待审核帖子")
    @GetMapping("/posts/pending")
    public Result<?> getPendingPosts(
            @RequestParam(defaultValue = "1") Integer page,
            @RequestParam(defaultValue = "10") Integer size) {
        return adminService.getPendingPosts(page, size);
    }

    @Operation(summary = "审核帖子")
    @PutMapping("/post/{id}/audit")
    public Result<?> auditPost(@PathVariable Long id, @Valid @RequestBody AuditPostDTO dto) {
        return adminService.auditPost(id, dto.getStatus());
    }

    @Operation(summary = "获取公告管理列表")
    @GetMapping("/announcements")
    public Result<?> getAnnouncements() {
        return adminService.getAnnouncements();
    }

    @Operation(summary = "发布或保存公告")
    @PostMapping("/announcement")
    public Result<?> createAnnouncement(@Valid @RequestBody AnnouncementDTO dto) {
        return adminService.createAnnouncement(dto);
    }

    @Operation(summary = "编辑公告")
    @PutMapping("/announcement/{id}")
    public Result<?> updateAnnouncement(@PathVariable Long id, @Valid @RequestBody AnnouncementDTO dto) {
        return adminService.updateAnnouncement(id, dto);
    }

    @Operation(summary = "删除公告")
    @DeleteMapping("/announcement/{id}")
    public Result<?> deleteAnnouncement(@PathVariable Long id) {
        return adminService.deleteAnnouncement(id);
    }

    // ==================== 广告管理 ====================

    @Operation(summary = "获取广告列表")
    @GetMapping("/advertisements")
    public Result<?> getAdvertisements() {
        return adminService.getAdvertisements();
    }

    @Operation(summary = "获取广告图片库")
    @GetMapping("/advertisement/images")
    public Result<?> getAdvertisementImages() throws Exception {
        return Result.ok(advertisementImageService.listImages());
    }

    @Operation(summary = "上传广告图片")
    @PostMapping(value = "/advertisement/image", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public Result<?> uploadAdvertisementImage(@RequestPart("file") MultipartFile file) throws Exception {
        return Result.ok(advertisementImageService.upload(file));
    }

    @Operation(summary = "新增广告")
    @PostMapping("/advertisement")
    public Result<?> createAdvertisement(@Valid @RequestBody AdvertisementDTO dto) {
        return adminService.createAdvertisement(dto);
    }

    @Operation(summary = "编辑广告")
    @PutMapping("/advertisement/{id}")
    public Result<?> updateAdvertisement(@PathVariable Long id, @Valid @RequestBody AdvertisementDTO dto) {
        return adminService.updateAdvertisement(id, dto);
    }

    @Operation(summary = "删除广告")
    @DeleteMapping("/advertisement/{id}")
    public Result<?> deleteAdvertisement(@PathVariable Long id) {
        return adminService.deleteAdvertisement(id);
    }

    // ==================== 效果图管理 ====================

    @Operation(summary = "获取效果图列表")
    @GetMapping("/banner-effects")
    public Result<?> getBannerEffects() {
        return bannerEffectService.getAdminEffects();
    }

    @Operation(summary = "编辑效果图")
    @PutMapping("/banner-effect/{id}")
    public Result<?> updateBannerEffect(@PathVariable Long id,
                                        @Valid @RequestBody BannerEffectDTO dto) {
        return bannerEffectService.updateEffect(id, dto);
    }

    // ==================== 数据统计 ====================

    @Operation(summary = "概览统计")
    @GetMapping("/stats/overview")
    public Result<?> getStatsOverview() {
        return adminService.getStatsOverview();
    }

    @Operation(summary = "播放统计")
    @GetMapping("/stats/play")
    public Result<?> getPlayStats(@RequestParam(defaultValue = "week") String period) {
        return adminService.getPlayStats(period);
    }

    @Operation(summary = "用户活跃度")
    @GetMapping("/stats/user")
    public Result<?> getUserStats(@RequestParam(defaultValue = "week") String period) {
        return adminService.getUserStats(period);
    }

    @Operation(summary = "视频排行")
    @GetMapping("/stats/ranking")
    public Result<?> getRankingStats(@RequestParam(defaultValue = "week") String period) {
        return adminService.getRankingStats(period);
    }
}
