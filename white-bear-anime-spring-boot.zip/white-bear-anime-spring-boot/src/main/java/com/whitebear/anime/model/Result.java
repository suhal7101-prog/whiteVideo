package com.whitebear.anime.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * 统一 API 响应结果封装类
 * 前端 axios 拦截器解析格式: { code: 200, data: {...}, message: 'success' }
 *
 * @author WhiteBear
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Result<T> implements Serializable {

    /** 状态码: 200-成功, 400-参数错误, 401-未授权, 403-无权限, 500-服务端错误 */
    private Integer code;

    /** 响应消息 */
    private String message;

    /** 响应数据 */
    private T data;

    // ==================== 静态工厂方法 ====================

    /** 成功 - 无数据 */
    public static <T> Result<T> ok() {
        return new Result<>(200, "success", null);
    }

    /** 成功 - 带数据 */
    public static <T> Result<T> ok(T data) {
        return new Result<>(200, "success", data);
    }

    /** 成功 - 自定义消息 */
    public static <T> Result<T> ok(String message, T data) {
        return new Result<>(200, message, data);
    }

    /** 失败 - 通用错误 */
    public static <T> Result<T> error(String message) {
        return new Result<>(500, message, null);
    }

    /** 失败 - 自定义状态码 */
    public static <T> Result<T> error(Integer code, String message) {
        return new Result<>(code, message, null);
    }

    /** 参数错误 */
    public static <T> Result<T> badRequest(String message) {
        return new Result<>(400, message, null);
    }

    /** 未授权 / Token 过期 */
    public static <T> Result<T> unauthorized(String message) {
        return new Result<>(401, message, null);
    }

    /** 权限不足 */
    public static <T> Result<T> forbidden(String message) {
        return new Result<>(403, message, null);
    }

    /** 资源不存在 */
    public static <T> Result<T> notFound(String message) {
        return new Result<>(404, message, null);
    }

    /** 成功 - 仅返回消息（用于 Void 类型） */
    public static Result<Void> success(String message) {
        return new Result<>(200, message, null);
    }
}
