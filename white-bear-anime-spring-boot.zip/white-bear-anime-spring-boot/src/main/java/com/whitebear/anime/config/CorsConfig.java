package com.whitebear.anime.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * CORS 跨域配置
 * 允许配置的前端来源访问后端 localhost:8088
 *
 * @author WhiteBear
 */
@Configuration
public class CorsConfig implements WebMvcConfigurer {

    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/**")                        // 所有路径
                .allowedOriginPatterns("*")               // 允许所有来源
                .allowedMethods("GET", "POST", "PUT", "DELETE", "OPTIONS", "PATCH")
                .allowedHeaders("*")                       // 允许所有请求头
                .allowCredentials(true)                    // 允许携带 Cookie
                .maxAge(3600);                             // 预检请求缓存 1 小时
    }
}
