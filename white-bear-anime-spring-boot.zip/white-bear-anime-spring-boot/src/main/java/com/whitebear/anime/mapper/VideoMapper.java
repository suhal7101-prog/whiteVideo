package com.whitebear.anime.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.whitebear.anime.model.entity.Video;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;
import java.util.Map;

/**
 * 视频/动漫 Mapper
 *
 * @author WhiteBear
 */
@Mapper
public interface VideoMapper extends BaseMapper<Video> {

    @Select("SELECT * FROM wb_video WHERE deleted = 0 AND title = #{title} ORDER BY id ASC LIMIT 1")
    Video findByTitle(@Param("title") String title);

    @Select("SELECT * FROM wb_video WHERE deleted = 0 AND source_vod_id = #{sourceVodId} ORDER BY id ASC LIMIT 1")
    Video findBySourceVodId(@Param("sourceVodId") Long sourceVodId);

    /** 查询热门视频（按播放量排序） */
    @Select("SELECT * FROM wb_video WHERE deleted = 0 AND audit_status = 'approved' ORDER BY views DESC LIMIT #{limit}")
    List<Video> selectHotVideos(@Param("limit") int limit);

    /** 搜索视频 */
    @Select("SELECT * FROM wb_video WHERE deleted = 0 AND audit_status = 'approved' AND title LIKE CONCAT('%', #{keyword}, '%') ORDER BY views DESC")
    List<Video> searchByKeyword(@Param("keyword") String keyword);

    /** 根据分类查询 */
    @Select("SELECT * FROM wb_video WHERE deleted = 0 AND audit_status = 'approved' AND category = #{category} ORDER BY views DESC")
    List<Video> selectByCategory(@Param("category") String category);

    /** 投稿页按标题搜索可复用的已有动漫资料。 */
    @Select("SELECT * FROM wb_video WHERE deleted = 0 AND audit_status <> 'rejected' " +
            "AND title LIKE CONCAT('%', #{title}, '%') " +
            "ORDER BY CASE WHEN title = #{title} THEN 0 ELSE 1 END, views DESC, id ASC LIMIT 10")
    List<Video> searchSubmissionCandidates(@Param("title") String title);

    @Select("SELECT COUNT(*) FROM wb_video WHERE deleted = 0 AND audit_status <> 'rejected' AND title = #{title}")
    long countSubmissionVideosByTitle(@Param("title") String title);

    /** 兼容整部动漫数据和逐集投稿数据，取现有最大集数加一。 */
    @Select("SELECT GREATEST(COUNT(DISTINCT v.id), COALESCE(MAX(v.episodes), 0), " +
            "COALESCE(MAX(e.episode_num), 0)) + 1 " +
            "FROM wb_video v LEFT JOIN wb_episode e ON e.video_id = v.id AND e.deleted = 0 " +
            "WHERE v.deleted = 0 AND v.audit_status <> 'rejected' AND v.title = #{title}")
    long selectNextSubmissionEpisode(@Param("title") String title);

    /** 播放量 +1 */
    @Update("UPDATE wb_video SET views = views + 1 WHERE id = #{id}")
    int incrementViews(@Param("id") Long id);

    @Update("UPDATE wb_video SET likes = likes + 1 WHERE id = #{id}")
    int incrementLikes(@Param("id") Long id);

    @Update("UPDATE wb_video SET likes = likes - 1 WHERE id = #{id} AND likes > 0")
    int decrementLikes(@Param("id") Long id);

    /** 统计总视频数 */
    @Select("SELECT COUNT(*) FROM wb_video WHERE deleted = 0")
    Long countTotalVideos();

    /** 查询播放排行 Top N */
    @Select("SELECT v.*, COALESCE(SUM(ps.play_count), 0) AS total_plays " +
            "FROM wb_video v LEFT JOIN wb_play_stats ps ON v.id = ps.video_id " +
            "WHERE v.deleted = 0 GROUP BY v.id ORDER BY total_plays DESC, v.views DESC LIMIT #{limit}")
    List<Video> selectTopByPlays(@Param("limit") int limit);

    /**
     * 管理后台热度排行。
     * 排序使用界面实际展示的累计浏览量和点赞量，避免与本地播放明细口径混用。
     */
    @Select("SELECT * FROM wb_video WHERE deleted = 0 " +
            "ORDER BY (COALESCE(views, 0) + COALESCE(likes, 0) * 10) DESC, " +
            "COALESCE(views, 0) DESC, id ASC LIMIT #{limit}")
    List<Video> selectTopByHeat(@Param("limit") int limit);

    /** 从现有视频数据中读取分类，避免前端硬编码。 */
    @Select("SELECT category AS name, COUNT(*) AS videoCount FROM wb_video " +
            "WHERE deleted = 0 AND category IS NOT NULL AND category <> '' " +
            "GROUP BY category ORDER BY videoCount DESC, category ASC")
    List<Map<String, Object>> selectCategories();

    /** 管理后台查询用户投稿，关联投稿用户信息。 */
    @Select({"<script>",
            "SELECT v.id, v.title, v.source_vod_id AS sourceVodId, v.cover, v.category, ",
            "v.description, v.status, v.rating, v.views, v.likes, v.episodes, v.tags, ",
            "v.`year`, v.season, v.studio, v.region, ",
            "v.submission_source AS submissionSource, v.uploader_id AS uploaderId, ",
            "v.audit_status AS auditStatus, v.audit_reason AS auditReason, ",
            "v.auditor_id AS auditorId, v.submit_time AS submitTime, v.audit_time AS auditTime, ",
            "v.create_time AS createTime, v.update_time AS updateTime, ",
            "(SELECT e.video_url FROM wb_episode e WHERE e.video_id = v.id AND e.deleted = 0 " +
                    "ORDER BY e.episode_num ASC, e.id ASC LIMIT 1) AS videoUrl, ",
            "(SELECT e.episode_num FROM wb_episode e WHERE e.video_id = v.id AND e.deleted = 0 " +
                    "ORDER BY e.episode_num ASC, e.id ASC LIMIT 1) AS episodeNumber, ",
            "(SELECT e.file_size FROM wb_episode e WHERE e.video_id = v.id AND e.deleted = 0 " +
                    "ORDER BY e.episode_num ASC, e.id ASC LIMIT 1) AS videoFileSize, ",
            "u.username AS uploaderUsername, u.nickname AS uploaderNickname ",
            "FROM wb_video v LEFT JOIN wb_user u ON u.id = v.uploader_id ",
            "WHERE v.deleted = 0 AND v.submission_source = 'user' ",
            "<if test='auditStatus != null and auditStatus != \"\" and auditStatus != \"all\"'>",
            "AND v.audit_status = #{auditStatus} ",
            "</if>",
            "<if test='keyword != null and keyword != \"\"'>",
            "AND (v.title LIKE CONCAT('%', #{keyword}, '%') ",
            "OR u.username LIKE CONCAT('%', #{keyword}, '%') ",
            "OR u.nickname LIKE CONCAT('%', #{keyword}, '%')) ",
            "</if>",
            "ORDER BY CASE v.audit_status WHEN 'pending' THEN 0 WHEN 'rejected' THEN 1 ELSE 2 END, ",
            "COALESCE(v.submit_time, v.create_time) DESC, v.id DESC ",
            "LIMIT #{size} OFFSET #{offset}",
            "</script>"})
    List<Map<String, Object>> selectVideoSubmissions(@Param("offset") int offset,
                                                      @Param("size") int size,
                                                      @Param("keyword") String keyword,
                                                      @Param("auditStatus") String auditStatus);

    @Select({"<script>",
            "SELECT COUNT(*) FROM wb_video v LEFT JOIN wb_user u ON u.id = v.uploader_id ",
            "WHERE v.deleted = 0 AND v.submission_source = 'user' ",
            "<if test='auditStatus != null and auditStatus != \"\" and auditStatus != \"all\"'>",
            "AND v.audit_status = #{auditStatus} ",
            "</if>",
            "<if test='keyword != null and keyword != \"\"'>",
            "AND (v.title LIKE CONCAT('%', #{keyword}, '%') ",
            "OR u.username LIKE CONCAT('%', #{keyword}, '%') ",
            "OR u.nickname LIKE CONCAT('%', #{keyword}, '%')) ",
            "</if>",
            "</script>"})
    long countVideoSubmissions(@Param("keyword") String keyword,
                               @Param("auditStatus") String auditStatus);
}
