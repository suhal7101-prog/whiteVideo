package com.whitebear.anime.model.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@TableName("wb_user_follow")
public class UserFollow {

    @TableId(type = IdType.AUTO)
    private Long id;

    /** 发起关注的用户。 */
    private Long followerId;

    /** 被关注的用户。 */
    private Long followingId;

    private LocalDateTime createTime;
}
