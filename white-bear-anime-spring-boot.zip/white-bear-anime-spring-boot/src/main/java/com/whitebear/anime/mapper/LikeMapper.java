package com.whitebear.anime.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.whitebear.anime.model.entity.Like;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * 点赞 Mapper
 *
 * @author WhiteBear
 */
@Mapper
public interface LikeMapper extends BaseMapper<Like> {

    /** 检查用户是否已点赞 */
    @Select("SELECT COUNT(*) FROM wb_like WHERE user_id = #{userId} AND target_id = #{targetId} AND type = #{type}")
    int countByUserAndTarget(@Param("userId") Long userId,
                             @Param("targetId") Long targetId,
                             @Param("type") String type);

    /** 删除点赞记录 */
    @org.apache.ibatis.annotations.Delete("DELETE FROM wb_like WHERE user_id = #{userId} AND target_id = #{targetId} AND type = #{type}")
    int deleteByUserAndTarget(@Param("userId") Long userId,
                              @Param("targetId") Long targetId,
                              @Param("type") String type);

    @Select("SELECT target_id FROM wb_like WHERE user_id = #{userId} AND type = #{type} ORDER BY create_time DESC")
    List<Long> selectTargetIdsByUserAndType(@Param("userId") Long userId, @Param("type") String type);
}
