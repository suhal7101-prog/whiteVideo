package com.whitebear.anime.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.whitebear.anime.model.entity.Comment;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

/**
 * 评论 Mapper
 *
 * @author WhiteBear
 */
@Mapper
public interface CommentMapper extends BaseMapper<Comment> {

    /** 查询帖子的所有评论（按时间排序） */
    @Select("SELECT * FROM wb_comment WHERE post_id = #{postId} AND deleted = 0 ORDER BY create_time ASC")
    List<Comment> selectByPostId(@Param("postId") Long postId);

    /** 查询帖子的真实评论数 */
    @Select("SELECT COUNT(*) FROM wb_comment WHERE post_id = #{postId} AND deleted = 0")
    long countByPostId(@Param("postId") Long postId);

    /** 点赞数 +1 */
    @Update("UPDATE wb_comment SET likes = likes + 1 WHERE id = #{id}")
    int incrementLikes(@Param("id") Long id);

    /** 点赞数 -1 */
    @Update("UPDATE wb_comment SET likes = likes - 1 WHERE id = #{id} AND likes > 0")
    int decrementLikes(@Param("id") Long id);
}
