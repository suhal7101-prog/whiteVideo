-- ============================================================
--  白熊动漫平台 - 数据库初始化脚本
--  MySQL 8.0 + 表前缀 wb_
-- ============================================================

-- 创建数据库
CREATE DATABASE IF NOT EXISTS `white_bear_anime`
    DEFAULT CHARACTER SET utf8mb4
    DEFAULT COLLATE utf8mb4_unicode_ci;

USE `white_bear_anime`;

-- ==================== 1. 用户表 ====================
DROP TABLE IF EXISTS `wb_user`;
CREATE TABLE `wb_user` (
    `id`            BIGINT          NOT NULL AUTO_INCREMENT  COMMENT '用户ID',
    `username`      VARCHAR(64)     NOT NULL                 COMMENT '用户名',
    `email`         VARCHAR(128)    NOT NULL                 COMMENT '邮箱',
    `password`      VARCHAR(256)    NOT NULL                 COMMENT '加密密码',
    `avatar`        VARCHAR(512)    DEFAULT NULL             COMMENT '头像URL',
    `nickname`      VARCHAR(64)     DEFAULT NULL             COMMENT '昵称',
    `bio`           VARCHAR(512)    DEFAULT NULL             COMMENT '个人简介',
    `role`          VARCHAR(32)     NOT NULL DEFAULT 'user'  COMMENT '角色: user/admin/moderator',
    `status`        VARCHAR(32)     NOT NULL DEFAULT 'active' COMMENT '状态: active/banned',
    `register_date` DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '注册时间',
    `last_login`    DATETIME        DEFAULT NULL             COMMENT '最后登录时间',
    `favorite_count` INT            NOT NULL DEFAULT 0       COMMENT '追番数',
    `deleted`       TINYINT(1)      NOT NULL DEFAULT 0       COMMENT '逻辑删除: 0-未删除, 1-已删除',
    `create_time`   DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `update_time`   DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_email` (`email`),
    UNIQUE KEY `uk_username` (`username`),
    KEY `idx_role` (`role`),
    KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户表';

-- ==================== 2. 视频/动漫主表 ====================
DROP TABLE IF EXISTS `wb_video`;
CREATE TABLE `wb_video` (
    `id`            BIGINT          NOT NULL AUTO_INCREMENT  COMMENT '视频ID',
    `title`         VARCHAR(256)    NOT NULL                 COMMENT '标题',
    `cover`         VARCHAR(512)    DEFAULT NULL             COMMENT '封面图片URL',
    `category`      VARCHAR(64)     DEFAULT NULL             COMMENT '分类: 热血/恋爱/科幻/奇幻/日常/悬疑/搞笑/治愈/战斗/校园/冒险/美食',
    `description`   TEXT            DEFAULT NULL             COMMENT '简介/描述',
    `status`        VARCHAR(32)     NOT NULL DEFAULT '连载中' COMMENT '状态: 连载中/已完结',
    `rating`        DECIMAL(3,1)    DEFAULT 0.0              COMMENT '评分 0.0~10.0',
    `views`         BIGINT          NOT NULL DEFAULT 0       COMMENT '播放量',
    `likes`         BIGINT          NOT NULL DEFAULT 0       COMMENT '点赞数',
    `episodes`      INT             NOT NULL DEFAULT 0       COMMENT '总集数',
    `tags`          VARCHAR(512)    DEFAULT NULL             COMMENT '标签, 逗号分隔',
    `year`          INT             DEFAULT NULL             COMMENT '播出年份',
    `season`        VARCHAR(32)     DEFAULT NULL             COMMENT '季度: 春/夏/秋/冬',
    `studio`        VARCHAR(128)    DEFAULT NULL             COMMENT '制作公司',
    `region`        VARCHAR(32)     DEFAULT '中国'           COMMENT '地区',
    `deleted`       TINYINT(1)      NOT NULL DEFAULT 0       COMMENT '逻辑删除',
    `create_time`   DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `update_time`   DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (`id`),
    KEY `idx_category` (`category`),
    KEY `idx_status` (`status`),
    KEY `idx_views` (`views`),
    KEY `idx_year` (`year`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='视频/动漫主表';

-- ==================== 3. 剧集表 ====================
DROP TABLE IF EXISTS `wb_episode`;
CREATE TABLE `wb_episode` (
    `id`            BIGINT          NOT NULL AUTO_INCREMENT  COMMENT '剧集ID',
    `video_id`      BIGINT          NOT NULL                 COMMENT '所属视频ID',
    `episode_num`   INT             NOT NULL                 COMMENT '集数序号',
    `title`         VARCHAR(256)    NOT NULL                 COMMENT '剧集标题',
    `duration`      INT             DEFAULT NULL             COMMENT '时长(秒)',
    `video_url`     VARCHAR(1024)   DEFAULT NULL             COMMENT '视频播放地址',
    `quality`       VARCHAR(64)     DEFAULT '1080p'          COMMENT '清晰度: 4K/1080p/720p/480p',
    `file_size`     BIGINT          DEFAULT NULL             COMMENT '文件大小(字节)',
    `deleted`       TINYINT(1)      NOT NULL DEFAULT 0       COMMENT '逻辑删除',
    `create_time`   DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `update_time`   DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (`id`),
    KEY `idx_video_id` (`video_id`),
    KEY `idx_video_episode` (`video_id`, `episode_num`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='剧集表';

-- ==================== 4. 轮播图表 ====================
DROP TABLE IF EXISTS `wb_banner`;
CREATE TABLE `wb_banner` (
    `id`            BIGINT          NOT NULL AUTO_INCREMENT  COMMENT '轮播图ID',
    `title`         VARCHAR(256)    NOT NULL                 COMMENT '标题',
    `img`           VARCHAR(512)    NOT NULL                 COMMENT '图片URL',
    `anime_id`      BIGINT          DEFAULT NULL             COMMENT '关联动漫ID',
    `sort_order`    INT             NOT NULL DEFAULT 0       COMMENT '排序号',
    `active`        TINYINT(1)      NOT NULL DEFAULT 1       COMMENT '是否启用: 0-停用, 1-启用',
    `deleted`       TINYINT(1)      NOT NULL DEFAULT 0       COMMENT '逻辑删除',
    `create_time`   DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `update_time`   DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (`id`),
    KEY `idx_active_sort` (`active`, `sort_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='轮播图表';

-- ==================== 广告管理表 ====================
DROP TABLE IF EXISTS `wb_advertisement`;
CREATE TABLE `wb_advertisement` (
    `id`            BIGINT          NOT NULL AUTO_INCREMENT,
    `title`         VARCHAR(128)    NOT NULL,
    `description`   VARCHAR(500)    DEFAULT NULL,
    `image_url`     VARCHAR(512)    NOT NULL,
    `target_url`    VARCHAR(512)    DEFAULT NULL,
    `position`      VARCHAR(64)     NOT NULL DEFAULT 'home_top',
    `status`        VARCHAR(16)     NOT NULL DEFAULT 'active',
    `start_time`    DATETIME        DEFAULT NULL,
    `end_time`      DATETIME        DEFAULT NULL,
    `sort_order`    INT             NOT NULL DEFAULT 0,
    `deleted`       TINYINT(1)      NOT NULL DEFAULT 0,
    `create_time`   DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `update_time`   DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_advertisement_status_position` (`status`, `position`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='广告管理表';

-- ==================== 5. 社区帖子表 ====================
DROP TABLE IF EXISTS `wb_post`;
CREATE TABLE `wb_post` (
    `id`            BIGINT          NOT NULL AUTO_INCREMENT  COMMENT '帖子ID',
    `title`         VARCHAR(256)    NOT NULL                 COMMENT '标题',
    `content`       TEXT            NOT NULL                 COMMENT '内容',
    `author_id`     BIGINT          NOT NULL                 COMMENT '作者用户ID',
    `tag`           VARCHAR(64)     DEFAULT NULL             COMMENT '标签: 分享/追番/推荐/漫评/资讯',
    `images`        TEXT            DEFAULT NULL             COMMENT '图片URL列表, JSON数组',
    `likes`         INT             NOT NULL DEFAULT 0       COMMENT '点赞数',
    `comments`      INT             NOT NULL DEFAULT 0       COMMENT '评论数',
    `views`         INT             NOT NULL DEFAULT 0       COMMENT '浏览量',
    `shares`        INT             NOT NULL DEFAULT 0       COMMENT '分享数',
    `status`        VARCHAR(32)     NOT NULL DEFAULT 'approved' COMMENT '状态: pending/approved/rejected',
    `deleted`       TINYINT(1)      NOT NULL DEFAULT 0       COMMENT '逻辑删除',
    `create_time`   DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `update_time`   DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (`id`),
    KEY `idx_author` (`author_id`),
    KEY `idx_tag` (`tag`),
    KEY `idx_status` (`status`),
    KEY `idx_likes` (`likes`),
    KEY `idx_create_time` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='社区帖子表';

-- ==================== 6. 评论表 ====================
DROP TABLE IF EXISTS `wb_comment`;
CREATE TABLE `wb_comment` (
    `id`            BIGINT          NOT NULL AUTO_INCREMENT  COMMENT '评论ID',
    `post_id`       BIGINT          NOT NULL                 COMMENT '所属帖子ID',
    `user_id`       BIGINT          NOT NULL                 COMMENT '评论用户ID',
      `parent_id`     BIGINT          DEFAULT NULL             COMMENT '父评论ID(回复)',
      `content`       TEXT            NOT NULL                 COMMENT '评论内容',
      `images`        TEXT            DEFAULT NULL             COMMENT '评论图片URL列表(JSON数组)',
      `likes`         INT             NOT NULL DEFAULT 0       COMMENT '点赞数',
    `deleted`       TINYINT(1)      NOT NULL DEFAULT 0       COMMENT '逻辑删除',
    `create_time`   DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    PRIMARY KEY (`id`),
    KEY `idx_post_id` (`post_id`),
    KEY `idx_user_id` (`user_id`),
    KEY `idx_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='评论表';

-- ==================== 播放器视频评论表 ====================
DROP TABLE IF EXISTS `wb_video_comment`;
CREATE TABLE `wb_video_comment` (
    `id`            BIGINT          NOT NULL AUTO_INCREMENT COMMENT '评论ID',
    `video_id`      BIGINT          NOT NULL COMMENT '视频ID',
    `source_type`   VARCHAR(16)     NOT NULL COMMENT '视频来源: db/source',
    `user_id`       BIGINT          NOT NULL COMMENT '评论用户ID',
    `parent_id`     BIGINT          DEFAULT NULL COMMENT '父评论ID',
    `content`       TEXT            NOT NULL COMMENT '评论内容',
    `likes`         INT             NOT NULL DEFAULT 0 COMMENT '点赞数',
    `deleted`       TINYINT(1)      NOT NULL DEFAULT 0 COMMENT '逻辑删除',
    `create_time`   DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '评论时间',
    PRIMARY KEY (`id`),
    KEY `idx_video_comment_video` (`video_id`, `source_type`, `deleted`, `create_time`),
    KEY `idx_video_comment_parent` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='播放器视频评论表';

-- ==================== 7. 点赞表 ====================
DROP TABLE IF EXISTS `wb_like`;
CREATE TABLE `wb_like` (
    `id`            BIGINT          NOT NULL AUTO_INCREMENT  COMMENT '点赞ID',
    `user_id`       BIGINT          NOT NULL                 COMMENT '用户ID',
    `target_id`     BIGINT          NOT NULL                 COMMENT '目标ID',
    `type`          VARCHAR(32)     NOT NULL                 COMMENT '目标类型: post/comment',
    `create_time`   DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_user_target` (`user_id`, `target_id`, `type`),
    KEY `idx_target` (`target_id`, `type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='点赞表';

-- ==================== 8. 追番/收藏表 ====================
DROP TABLE IF EXISTS `wb_favorite`;
CREATE TABLE `wb_favorite` (
    `id`            BIGINT          NOT NULL AUTO_INCREMENT  COMMENT '收藏ID',
    `user_id`       BIGINT          NOT NULL                 COMMENT '用户ID',
    `anime_id`      BIGINT          NOT NULL                 COMMENT '动漫ID',
    `create_time`   DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '收藏时间',
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_user_anime` (`user_id`, `anime_id`),
    KEY `idx_user_id` (`user_id`),
    KEY `idx_anime_id` (`anime_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='追番/收藏表';

-- ==================== 用户关注关系表 ====================
DROP TABLE IF EXISTS `wb_user_follow`;
CREATE TABLE `wb_user_follow` (
    `id`            BIGINT          NOT NULL AUTO_INCREMENT COMMENT '关注关系ID',
    `follower_id`   BIGINT          NOT NULL COMMENT '关注者用户ID',
    `following_id`  BIGINT          NOT NULL COMMENT '被关注用户ID',
    `create_time`   DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '关注时间',
    PRIMARY KEY (`id`),
    UNIQUE KEY `idx_user_follow_unique` (`follower_id`, `following_id`),
    KEY `idx_user_follow_following` (`following_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户关注关系表';

-- ==================== 9. 观看历史表 ====================
DROP TABLE IF EXISTS `wb_watch_history`;
CREATE TABLE `wb_watch_history` (
    `id`            BIGINT          NOT NULL AUTO_INCREMENT  COMMENT '历史ID',
    `user_id`       BIGINT          NOT NULL                 COMMENT '用户ID',
    `anime_id`      BIGINT          NOT NULL                 COMMENT '动漫ID',
    `episode_id`    BIGINT          DEFAULT NULL             COMMENT '剧集ID',
    `current_time`  INT             NOT NULL DEFAULT 0       COMMENT '当前播放时间(秒)',
    `duration`      INT             NOT NULL DEFAULT 0       COMMENT '总时长(秒)',
    `watched_at`    DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '观看时间',
    `create_time`   DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `update_time`   DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (`id`),
    KEY `idx_user_id` (`user_id`),
    KEY `idx_user_anime` (`user_id`, `anime_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='观看历史表';

-- ==================== 10. 弹幕表 ====================
DROP TABLE IF EXISTS `wb_danmaku`;
CREATE TABLE `wb_danmaku` (
    `id`            BIGINT          NOT NULL AUTO_INCREMENT  COMMENT '弹幕ID',
    `anime_id`      BIGINT          NOT NULL                 COMMENT '动漫ID',
    `episode_id`    BIGINT          DEFAULT NULL             COMMENT '剧集ID',
    `user_id`       BIGINT          NOT NULL                 COMMENT '用户ID',
    `content`       VARCHAR(512)    NOT NULL                 COMMENT '弹幕内容',
    `timestamp`     DOUBLE          NOT NULL                 COMMENT '弹幕时间点(秒)',
    `color`         VARCHAR(16)     DEFAULT '#FFFFFF'        COMMENT '弹幕颜色',
    `type`          VARCHAR(16)     DEFAULT 'scroll'         COMMENT '弹幕类型: scroll/top/bottom',
    `font_size`     VARCHAR(16)     DEFAULT 'normal'         COMMENT '字体大小: small/normal/large',
    `create_time`   DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    PRIMARY KEY (`id`),
    KEY `idx_anime_episode_time` (`anime_id`, `episode_id`, `timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='弹幕表';

-- ==================== 11. 公告表 ====================
DROP TABLE IF EXISTS `wb_announcement`;
CREATE TABLE `wb_announcement` (
    `id`            BIGINT          NOT NULL AUTO_INCREMENT  COMMENT '公告ID',
    `title`         VARCHAR(256)    NOT NULL                 COMMENT '公告标题',
    `content`       TEXT            NOT NULL                 COMMENT '公告内容',
    `pinned`        TINYINT(1)      NOT NULL DEFAULT 0       COMMENT '是否置顶',
    `status`        VARCHAR(16)     NOT NULL DEFAULT 'published' COMMENT '状态: published/draft',
    `publisher_id`  BIGINT          DEFAULT NULL             COMMENT '发布管理员ID',
    `publish_time`  DATETIME        DEFAULT NULL             COMMENT '实际发布时间',
    `deleted`       TINYINT(1)      NOT NULL DEFAULT 0       COMMENT '逻辑删除',
    `create_time`   DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '发布时间',
    `update_time`   DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (`id`),
    KEY `idx_pinned_time` (`pinned`, `create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='公告表';

CREATE TABLE `wb_announcement_read` (
    `id`              BIGINT      NOT NULL AUTO_INCREMENT COMMENT '读取记录ID',
    `user_id`         BIGINT      NOT NULL COMMENT '用户ID',
    `announcement_id` BIGINT      NOT NULL COMMENT '公告ID',
    `read_time`       DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '读取时间',
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_user_announcement` (`user_id`, `announcement_id`),
    KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户公告已读记录表';

-- ==================== 12. 操作日志表 ====================
DROP TABLE IF EXISTS `wb_operation_log`;
CREATE TABLE `wb_operation_log` (
    `id`            BIGINT          NOT NULL AUTO_INCREMENT  COMMENT '日志ID',
    `user_id`       BIGINT          DEFAULT NULL             COMMENT '操作人ID',
    `username`      VARCHAR(64)     DEFAULT NULL             COMMENT '操作人用户名',
    `action`        VARCHAR(256)    NOT NULL                 COMMENT '操作描述',
    `target`        VARCHAR(256)    DEFAULT NULL             COMMENT '操作对象',
    `ip`            VARCHAR(64)     DEFAULT NULL             COMMENT 'IP地址',
    `create_time`   DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '操作时间',
    PRIMARY KEY (`id`),
    KEY `idx_user_id` (`user_id`),
    KEY `idx_create_time` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='操作日志表';

-- ==================== 13. 播放统计表 ====================
DROP TABLE IF EXISTS `wb_play_stats`;
CREATE TABLE `wb_play_stats` (
    `id`            BIGINT          NOT NULL AUTO_INCREMENT  COMMENT '统计ID',
    `video_id`      BIGINT          NOT NULL                 COMMENT '视频ID',
    `episode_id`    BIGINT          DEFAULT NULL             COMMENT '剧集ID',
    `user_id`       BIGINT          DEFAULT NULL             COMMENT '用户ID',
    `ip`            VARCHAR(64)     DEFAULT NULL             COMMENT 'IP地址',
    `play_date`     DATE            NOT NULL                 COMMENT '播放日期',
    `play_count`    INT             NOT NULL DEFAULT 1       COMMENT '播放次数',
    `create_time`   DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    PRIMARY KEY (`id`),
    KEY `idx_video_date` (`video_id`, `play_date`),
    KEY `idx_play_date` (`play_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='播放统计表';

-- ==================== 初始数据 ====================
DROP TABLE IF EXISTS `wb_banner_effect`;
CREATE TABLE `wb_banner_effect` (
    `id`             BIGINT       NOT NULL AUTO_INCREMENT,
    `name`           VARCHAR(128) NOT NULL,
    `theme_key`      VARCHAR(64)  NOT NULL,
    `date_key`       VARCHAR(32)  NOT NULL,
    `data_url`       VARCHAR(512) NOT NULL,
    `asset_base_url` VARCHAR(512) DEFAULT NULL,
    `preview_url`    VARCHAR(1024) DEFAULT NULL,
    `target_page`    VARCHAR(32)  NOT NULL DEFAULT 'ai',
    `status`         VARCHAR(16)  NOT NULL DEFAULT 'active',
    `layer_count`    INT          NOT NULL DEFAULT 0,
    `has_video`      TINYINT(1)   NOT NULL DEFAULT 0,
    `sort_order`     INT          NOT NULL DEFAULT 0,
    `deleted`        TINYINT(1)   NOT NULL DEFAULT 0,
    `create_time`    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `update_time`    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_banner_effect_theme` (`theme_key`),
    KEY `idx_banner_effect_active` (`target_page`, `status`, `deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='AI动态效果图管理';

-- 用户账号不在 SQL 中创建。需要示例数据时，必须通过环境变量显式启用并提供强密码。

-- 插入示例视频数据
INSERT INTO `wb_video` (`title`, `cover`, `category`, `description`, `status`, `rating`, `views`, `likes`, `episodes`, `tags`, `year`, `region`)
VALUES
('斗罗大陆II绝世唐门', 'https://picsum.photos/seed/anime1/400/225', '热血', '唐门重建一万年后，霍雨浩在史莱克学院开启传奇之旅。', '连载中', 9.2, 1520000, 89000, 52, '热血,战斗,玄幻', 2023, '中国'),
('开心锤锤世界', 'https://picsum.photos/seed/anime2/400/225', '搞笑', '爆笑日常，锤锤带你体验无穷欢乐。', '连载中', 8.8, 980000, 56000, 120, '搞笑,日常,泡面番', 2022, '中国'),
('从今天开始当城主', 'https://picsum.photos/seed/anime3/400/225', '奇幻', '穿越异世界成为城主，展开冒险与建设之旅。', '已完结', 8.5, 650000, 42000, 24, '奇幻,冒险,异世界', 2023, '中国'),
('破防临界线', 'https://picsum.photos/seed/anime4/400/225', '科幻', '在虚拟与现实交错的世界中，守护最后的防线。', '连载中', 8.9, 720000, 38000, 36, '科幻,战斗,机甲', 2024, '中国'),
('夏日恋歌', 'https://picsum.photos/seed/anime5/400/225', '恋爱', '夏天海边小镇的青春恋爱物语。', '已完结', 8.7, 430000, 31000, 13, '恋爱,青春,治愈', 2023, '中国');

-- 插入示例剧集
INSERT INTO `wb_episode` (`video_id`, `episode_num`, `title`, `duration`, `video_url`, `quality`)
VALUES
(1, 1, '第一集 新的开始', 1320, 'https://example.com/video/1/ep1.m3u8', '1080p'),
(1, 2, '第二集 入学测试', 1380, 'https://example.com/video/1/ep2.m3u8', '1080p'),
(2, 1, '第一集 锤锤来了', 300, 'https://example.com/video/2/ep1.m3u8', '1080p'),
(3, 1, '第一集 穿越异世界', 1440, 'https://example.com/video/3/ep1.m3u8', '1080p'),
(4, 1, '第一集 临界点', 1500, 'https://example.com/video/4/ep1.m3u8', '1080p');

-- 插入示例轮播图
INSERT INTO `wb_banner` (`title`, `img`, `anime_id`, `sort_order`, `active`)
VALUES
('斗罗大陆II绝世唐门', 'https://picsum.photos/seed/banner1/1200/500', 1, 1, 1),
('开心锤锤世界', 'https://picsum.photos/seed/banner2/1200/500', 2, 2, 1),
('破防临界线', 'https://picsum.photos/seed/banner3/1200/500', 4, 3, 1);

-- 插入示例帖子
INSERT INTO `wb_post` (`title`, `content`, `author_id`, `tag`, `likes`, `comments`, `views`, `status`)
VALUES
('【分享】斗罗大陆II绝世唐门观后感', '刚看完最新一集，MAPPA级别的制作！每一帧都是壁纸。', 2, '分享', 1280, 256, 5600, 'approved'),
('【分享】绘制的锤锤', '花了三天时间画的锤锤角色图！希望大家喜欢~', 2, '分享', 856, 128, 3200, 'approved'),
('【推荐】本季最值得看的5部国漫', '这季国漫质量相当不错！推荐几部必看作品。', 2, '推荐', 432, 89, 1800, 'approved');

-- 插入示例评论
INSERT INTO `wb_comment` (`post_id`, `user_id`, `content`, `likes`)
VALUES
(1, 1, '说得太好了！这季制作真的精良', 12),
(1, 2, '同感，期待后续剧情', 8),
(2, 1, '画得真棒！关注了', 15);
