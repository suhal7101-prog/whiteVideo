-- H2 示例数据（首页测试用）
SET MODE MySQL;

-- 示例视频数据（5条）
INSERT INTO wb_video (title, cover, category, description, status, rating, views, likes, episodes, tags, year, region) VALUES
('斗罗大陆II绝世唐门', 'https://picsum.photos/seed/anime1/800/450', '热血', '唐门重建一万年后，霍雨浩在史莱克学院开启传奇之旅。', '连载中', 9.2, 1520000, 89000, 52, '热血,战斗,玄幻', 2023, '中国'),
('开心锤锤世界', 'https://picsum.photos/seed/anime2/800/450', '搞笑', '爆笑日常，锤锤带你体验无穷欢乐。', '连载中', 8.8, 980000, 56000, 120, '搞笑,日常,泡面番', 2022, '中国'),
('从今天开始当城主', 'https://picsum.photos/seed/anime3/800/450', '奇幻', '穿越异世界成为城主，展开冒险与建设之旅。', '已完结', 8.5, 650000, 42000, 24, '奇幻,冒险,异世界', 2023, '中国'),
('破防临界线', 'https://picsum.photos/seed/anime4/800/450', '科幻', '在虚拟与现实交错的世界中，守护最后的防线。', '连载中', 8.9, 720000, 38000, 36, '科幻,战斗,机甲', 2024, '中国'),
('夏日恋歌', 'https://picsum.photos/seed/anime5/800/450', '恋爱', '夏天海边小镇的青春恋爱物语。', '已完结', 8.7, 430000, 31000, 13, '恋爱,青春,治愈', 2023, '中国');

-- 示例剧集
INSERT INTO wb_episode (video_id, episode_num, title, duration, video_url, quality) VALUES
(1, 1, '第一集 新的开始', 1320, 'https://example.com/video/1/ep1.m3u8', '1080p'),
(1, 2, '第二集 入学测试', 1380, 'https://example.com/video/1/ep2.m3u8', '1080p'),
(2, 1, '第一集 锤锤来了', 300, 'https://example.com/video/2/ep1.m3u8', '1080p');

-- 示例轮播图（关联动漫ID）
INSERT INTO wb_banner (title, img, anime_id, sort_order, active) VALUES
('斗罗大陆II绝世唐门', 'https://picsum.photos/seed/banner1/1200/500', 1, 1, 1),
('开心锤锤世界', 'https://picsum.photos/seed/banner2/1200/500', 2, 2, 1),
('破防临界线', 'https://picsum.photos/seed/banner3/1200/500', 4, 3, 1);

-- 示例帖子
INSERT INTO wb_post (title, content, author_id, tag, likes, comments, views, status) VALUES
('【分享】斗罗大陆II观后感', '刚看完最新一集，MAPPA级别的制作！每一帧都是壁纸。', 2, '分享', 1280, 256, 5600, 'approved'),
('【分享】锤锤创作', '花了三天画的锤锤角色图！', 2, '分享', 856, 128, 3200, 'approved');
