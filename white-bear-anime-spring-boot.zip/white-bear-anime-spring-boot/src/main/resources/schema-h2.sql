-- ============================================================
--  白熊动漫平台 - H2 数据库初始化
--  兼容模式已在 JDBC URL 中配置 (MODE=MySQL;DATABASE_TO_UPPER=FALSE)
-- ============================================================

-- 用户表
CREATE TABLE IF NOT EXISTS wb_user (
    id            BIGINT AUTO_INCREMENT PRIMARY KEY,
    username      VARCHAR(64)   NOT NULL,
    email         VARCHAR(128)  NOT NULL,
    password      VARCHAR(256)  NOT NULL,
    avatar        VARCHAR(512)  DEFAULT NULL,
    nickname      VARCHAR(64)   DEFAULT NULL,
    bio           VARCHAR(512)  DEFAULT NULL,
    role          VARCHAR(32)   NOT NULL DEFAULT 'user',
    status        VARCHAR(32)   NOT NULL DEFAULT 'active',
    register_date DATETIME      DEFAULT CURRENT_TIMESTAMP,
    last_login    DATETIME      DEFAULT NULL,
    favorite_count INT          DEFAULT 0,
    deleted       TINYINT       DEFAULT 0,
    create_time   DATETIME      DEFAULT CURRENT_TIMESTAMP,
    update_time   DATETIME      DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (email),
    UNIQUE (username)
);

-- 视频/动漫主表
CREATE TABLE IF NOT EXISTS wb_video (
    id            BIGINT AUTO_INCREMENT PRIMARY KEY,
    title         VARCHAR(256)  NOT NULL,
    cover         VARCHAR(512)  DEFAULT NULL,
    category      VARCHAR(64)   DEFAULT NULL,
    description   TEXT          DEFAULT NULL,
    status        VARCHAR(32)   DEFAULT '连载中',
    rating        DECIMAL(3,1)  DEFAULT 0.0,
    views         BIGINT        DEFAULT 0,
    likes         BIGINT        DEFAULT 0,
    episodes      INT           DEFAULT 0,
    tags          VARCHAR(512)  DEFAULT NULL,
    `year`        INT           DEFAULT NULL,
    season        VARCHAR(32)   DEFAULT NULL,
    studio        VARCHAR(128)  DEFAULT NULL,
    region        VARCHAR(32)   DEFAULT '中国',
    deleted       TINYINT       DEFAULT 0,
    create_time   DATETIME      DEFAULT CURRENT_TIMESTAMP,
    update_time   DATETIME      DEFAULT CURRENT_TIMESTAMP
);

-- 剧集表
CREATE TABLE IF NOT EXISTS wb_episode (
    id            BIGINT AUTO_INCREMENT PRIMARY KEY,
    video_id      BIGINT        NOT NULL,
    episode_num   INT           NOT NULL,
    title         VARCHAR(256)  NOT NULL,
    duration      INT           DEFAULT NULL,
    video_url     VARCHAR(1024) DEFAULT NULL,
    quality       VARCHAR(64)   DEFAULT '1080p',
    file_size     BIGINT        DEFAULT NULL,
    deleted       TINYINT       DEFAULT 0,
    create_time   DATETIME      DEFAULT CURRENT_TIMESTAMP,
    update_time   DATETIME      DEFAULT CURRENT_TIMESTAMP
);

-- 轮播图表
CREATE TABLE IF NOT EXISTS wb_banner (
    id            BIGINT AUTO_INCREMENT PRIMARY KEY,
    title         VARCHAR(256)  NOT NULL,
    img           VARCHAR(512)  NOT NULL,
    anime_id      BIGINT        DEFAULT NULL,
    sort_order    INT           DEFAULT 0,
    active        TINYINT       DEFAULT 1,
    deleted       TINYINT       DEFAULT 0,
    create_time   DATETIME      DEFAULT CURRENT_TIMESTAMP,
    update_time   DATETIME      DEFAULT CURRENT_TIMESTAMP
);

-- 社区帖子表
CREATE TABLE IF NOT EXISTS wb_post (
    id            BIGINT AUTO_INCREMENT PRIMARY KEY,
    title         VARCHAR(256)  NOT NULL,
    content       TEXT          NOT NULL,
    author_id     BIGINT        NOT NULL,
    tag           VARCHAR(64)   DEFAULT NULL,
    images        TEXT          DEFAULT NULL,
    likes         INT           DEFAULT 0,
    comments      INT           DEFAULT 0,
    views         INT           DEFAULT 0,
    shares        INT           DEFAULT 0,
    status        VARCHAR(32)   DEFAULT 'approved',
    deleted       TINYINT       DEFAULT 0,
    create_time   DATETIME      DEFAULT CURRENT_TIMESTAMP,
    update_time   DATETIME      DEFAULT CURRENT_TIMESTAMP
);

-- 评论表
CREATE TABLE IF NOT EXISTS wb_comment (
    id            BIGINT AUTO_INCREMENT PRIMARY KEY,
    post_id       BIGINT        NOT NULL,
    user_id       BIGINT        NOT NULL,
    parent_id     BIGINT        DEFAULT NULL,
    content       TEXT          NOT NULL,
    images        TEXT          DEFAULT NULL,
    likes         INT           DEFAULT 0,
    deleted       TINYINT       DEFAULT 0,
    create_time   DATETIME      DEFAULT CURRENT_TIMESTAMP
);

-- 播放器视频评论表
CREATE TABLE IF NOT EXISTS wb_video_comment (
    id            BIGINT AUTO_INCREMENT PRIMARY KEY,
    video_id      BIGINT        NOT NULL,
    source_type   VARCHAR(16)   NOT NULL,
    user_id       BIGINT        NOT NULL,
    parent_id     BIGINT        DEFAULT NULL,
    content       TEXT          NOT NULL,
    likes         INT           DEFAULT 0,
    deleted       TINYINT       DEFAULT 0,
    create_time   DATETIME      DEFAULT CURRENT_TIMESTAMP
);

-- 点赞表
CREATE TABLE IF NOT EXISTS wb_like (
    id            BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id       BIGINT        NOT NULL,
    target_id     BIGINT        NOT NULL,
    `type`        VARCHAR(32)   NOT NULL,
    create_time   DATETIME      DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (user_id, target_id, `type`)
);

-- 追番/收藏表
CREATE TABLE IF NOT EXISTS wb_favorite (
    id            BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id       BIGINT        NOT NULL,
    anime_id      BIGINT        NOT NULL,
    create_time   DATETIME      DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (user_id, anime_id)
);

-- 观看历史表
CREATE TABLE IF NOT EXISTS wb_watch_history (
    id            BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id       BIGINT        NOT NULL,
    anime_id      BIGINT        NOT NULL,
    episode_id    BIGINT        DEFAULT NULL,
    `current_time` INT          DEFAULT 0,
    duration      INT           DEFAULT 0,
    watched_at    DATETIME      DEFAULT CURRENT_TIMESTAMP,
    create_time   DATETIME      DEFAULT CURRENT_TIMESTAMP,
    update_time   DATETIME      DEFAULT CURRENT_TIMESTAMP
);

-- 弹幕表
CREATE TABLE IF NOT EXISTS wb_danmaku (
    id            BIGINT AUTO_INCREMENT PRIMARY KEY,
    anime_id      BIGINT        NOT NULL,
    episode_id    BIGINT        DEFAULT NULL,
    user_id       BIGINT        NOT NULL,
    content       VARCHAR(512)  NOT NULL,
    `timestamp`   DOUBLE        NOT NULL,
    color         VARCHAR(16)   DEFAULT '#FFFFFF',
    `type`        VARCHAR(16)   DEFAULT 'scroll',
    font_size     VARCHAR(16)   DEFAULT 'normal',
    create_time   DATETIME      DEFAULT CURRENT_TIMESTAMP
);

-- 公告表
CREATE TABLE IF NOT EXISTS wb_announcement (
    id            BIGINT AUTO_INCREMENT PRIMARY KEY,
    title         VARCHAR(256)  NOT NULL,
    content       TEXT          NOT NULL,
    pinned        TINYINT       DEFAULT 0,
    status        VARCHAR(16)   DEFAULT 'published',
    publisher_id  BIGINT        DEFAULT NULL,
    publish_time  DATETIME      DEFAULT NULL,
    deleted       TINYINT       DEFAULT 0,
    create_time   DATETIME      DEFAULT CURRENT_TIMESTAMP,
    update_time   DATETIME      DEFAULT CURRENT_TIMESTAMP
);

-- 用户关注关系表
CREATE TABLE IF NOT EXISTS wb_user_follow (
    id            BIGINT AUTO_INCREMENT PRIMARY KEY,
    follower_id   BIGINT        NOT NULL,
    following_id  BIGINT        NOT NULL,
    create_time   DATETIME      DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (follower_id, following_id)
);
CREATE INDEX IF NOT EXISTS idx_user_follow_following ON wb_user_follow(following_id);

-- 广告管理表
CREATE TABLE IF NOT EXISTS wb_advertisement (
    id            BIGINT AUTO_INCREMENT PRIMARY KEY,
    title         VARCHAR(128)  NOT NULL,
    description   VARCHAR(500)  DEFAULT NULL,
    image_url     VARCHAR(512)  NOT NULL,
    target_url    VARCHAR(512)  DEFAULT NULL,
    position      VARCHAR(64)   DEFAULT 'home_top',
    status        VARCHAR(16)   DEFAULT 'active',
    start_time    DATETIME      DEFAULT NULL,
    end_time      DATETIME      DEFAULT NULL,
    sort_order    INT           DEFAULT 0,
    deleted       TINYINT       DEFAULT 0,
    create_time   DATETIME      DEFAULT CURRENT_TIMESTAMP,
    update_time   DATETIME      DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS wb_banner_effect (
    id             BIGINT AUTO_INCREMENT PRIMARY KEY,
    name           VARCHAR(128) NOT NULL,
    theme_key      VARCHAR(64)  NOT NULL UNIQUE,
    date_key       VARCHAR(32)  NOT NULL,
    data_url       VARCHAR(512) NOT NULL,
    asset_base_url VARCHAR(512),
    preview_url    VARCHAR(1024),
    target_page    VARCHAR(32)  DEFAULT 'ai',
    status         VARCHAR(16)  DEFAULT 'active',
    layer_count    INT          DEFAULT 0,
    has_video      TINYINT      DEFAULT 0,
    sort_order     INT          DEFAULT 0,
    deleted        TINYINT      DEFAULT 0,
    create_time    DATETIME     DEFAULT CURRENT_TIMESTAMP,
    update_time    DATETIME     DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS wb_announcement_read (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id         BIGINT   NOT NULL,
    announcement_id BIGINT   NOT NULL,
    read_time       DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (user_id, announcement_id)
);

-- 操作日志表
CREATE TABLE IF NOT EXISTS wb_operation_log (
    id            BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id       BIGINT        DEFAULT NULL,
    username      VARCHAR(64)   DEFAULT NULL,
    action        VARCHAR(256)  NOT NULL,
    target        VARCHAR(256)  DEFAULT NULL,
    ip            VARCHAR(64)   DEFAULT NULL,
    create_time   DATETIME      DEFAULT CURRENT_TIMESTAMP
);

-- 播放统计表
CREATE TABLE IF NOT EXISTS wb_play_stats (
    id            BIGINT AUTO_INCREMENT PRIMARY KEY,
    video_id      BIGINT        NOT NULL,
    episode_id    BIGINT        DEFAULT NULL,
    user_id       BIGINT        DEFAULT NULL,
    ip            VARCHAR(64)   DEFAULT NULL,
    play_date     DATE          NOT NULL,
    play_count    INT           DEFAULT 1,
    create_time   DATETIME      DEFAULT CURRENT_TIMESTAMP
);
