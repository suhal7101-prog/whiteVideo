@echo off
setlocal
set JAVA_HOME=C:\Program Files\Java\jdk-17.0.19
set PATH=%JAVA_HOME%\bin;%PATH%
cd /d "%~dp0" || exit /b 1
call C:\Users\ASUS\maven\bin\mvn.cmd package
if errorlevel 1 (
  echo BUILD FAILED
  exit /b 1
)
echo BUILD DONE
pause
