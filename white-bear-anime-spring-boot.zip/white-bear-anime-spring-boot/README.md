# White Bear Anime Backend

Requires JDK 17, Maven 3.9+, MySQL, and MinIO for file uploads.

Set runtime secrets before starting:

```powershell
$env:DB_USERNAME = 'white_bear'
$env:DB_PASSWORD = '<database-password>'
$env:JWT_SECRET = '<at-least-32-random-bytes>'
$env:MINIO_ACCESS_KEY = '<minio-access-key>'
$env:MINIO_SECRET_KEY = '<minio-secret-key>'
```

Password recovery also requires `MAIL_HOST`, `MAIL_PORT`, `MAIL_USERNAME`, `MAIL_PASSWORD`, and optionally `FRONTEND_URL`.

Sample data is disabled by default. To enable it for a local database, set `SEED_DATA_ENABLED=true`, `SEED_ADMIN_PASSWORD`, and `SEED_TEST_PASSWORD`; both passwords must contain at least 12 characters.

Run tests and start the service:

```powershell
.\build.bat
.\start.bat
```
