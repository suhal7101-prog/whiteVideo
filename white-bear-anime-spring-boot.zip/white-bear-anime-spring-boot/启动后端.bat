@echo off
setlocal
set JAVA_HOME=C:\Program Files\Java\jdk-17.0.19
set PATH=%JAVA_HOME%\bin;%PATH%
if not defined DB_USERNAME set DB_USERNAME=root
if not defined DB_PASSWORD set DB_PASSWORD=root
if not defined JWT_SECRET set JWT_SECRET=WhiteBearAnime2026LocalDevelopmentSecretKeyOnly
cd /d "%~dp0" || exit /b 1

echo ============================================
echo   白熊动漫平台 Spring Boot 启动
echo   端口: 8088
echo   API文档:   http://localhost:8088/doc.html
echo ============================================
echo.

call C:\Users\ASUS\maven\bin\mvn.cmd spring-boot:run

echo.
echo 服务已停止，按任意键退出
pause
