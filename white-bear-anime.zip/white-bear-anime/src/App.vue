<!--
  白熊动漫平台 —— 根组件

  两套布局：
  - default: 前台页面（顶部导航 + 内容 + 底部版权，登录/注册页隐藏底部）
  - admin:   管理后台（AdminLayout，左侧导航 + 右侧内容）
-->
<template>
  <div id="app">
    <!-- ===== 前台布局 (default) ===== -->
    <template v-if="currentLayout === 'default'">
      <header class="app-header-wrapper">
        <div class="app-header">
          <!-- Logo -->
          <div class="logo" @click="$router.push('/')">
            🐻 白熊动漫
          </div>

          <!-- 主导航链接 -->
          <nav class="main-nav">
            <router-link to="/" class="nav-item" active-class="nav-active">首页</router-link>
            <router-link to="/discover" class="nav-item" active-class="nav-active">浏览</router-link>
            <router-link to="/community" class="nav-item" active-class="nav-active">社区</router-link>
            <router-link to="/ai" class="nav-item" active-class="nav-active">AI</router-link>
          </nav>

          <!-- 右侧：搜索 + 用户操作 -->
          <div class="nav-actions">
            <div class="searchBox" v-if="route.path !== '/discover'">
              <input
                class="searchInput"
                v-model="searchKeyword"
                type="text"
                placeholder="搜索动漫..."
                @keydown.enter="doSearch"
              />
              <button class="searchButton" @click="doSearch">
                <svg xmlns="http://www.w3.org/2000/svg" width="29" height="29" viewBox="0 0 29 29" fill="none">
                  <g clip-path="url(#clip0_2_17)">
                    <path d="M23.7953 23.9182L19.0585 19.1814M19.0585 19.1814C19.8188 18.4211 20.4219 17.5185 20.8333 16.5251C21.2448 15.5318 21.4566 14.4671 21.4566 13.3919C21.4566 12.3167 21.2448 11.252 20.8333 10.2587C20.4219 9.2653 19.8188 8.36271 19.0585 7.60242C18.2982 6.84214 17.3956 6.23905 16.4022 5.82759C15.4089 5.41612 14.3442 5.20435 13.269 5.20435C12.1938 5.20435 11.1291 5.41612 10.1358 5.82759C9.1424 6.23905 8.23981 6.84214 7.47953 7.60242C5.94407 9.13789 5.08145 11.2204 5.08145 13.3919C5.08145 15.5634 5.94407 17.6459 7.47953 19.1814C9.01499 20.7168 11.0975 21.5794 13.269 21.5794C15.4405 21.5794 17.523 20.7168 19.0585 19.1814Z" stroke="white" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>
                  </g>
                </svg>
              </button>
            </div>

            <template v-if="!isLoggedIn">
              <el-button class="nav-btn-login" round @click="$router.push('/login')">
                登录
              </el-button>
            </template>

            <template v-else>
              <el-dropdown trigger="click" @command="handleUserCommand">
                <span class="user-dropdown-trigger">
                  <el-avatar :size="32" :src="userAvatar" />
                  <span class="user-name">{{ username }}</span>
                  <el-icon><ArrowDown /></el-icon>
                </span>
                <template #dropdown>
                  <el-dropdown-menu>
                    <el-dropdown-item command="profile">
                      <el-icon><User /></el-icon> 个人中心
                    </el-dropdown-item>
                    <el-dropdown-item v-if="isAdmin" command="admin">
                      <el-icon><Setting /></el-icon> 管理后台
                    </el-dropdown-item>
                    <el-dropdown-item command="logout" divided>
                      <el-icon><SwitchButton /></el-icon> 退出登录
                    </el-dropdown-item>
                  </el-dropdown-menu>
                </template>
              </el-dropdown>
            </template>

            <button
              v-if="canSubmit"
              class="submission-button"
              type="button"
              title="投稿"
              aria-label="进入动漫投稿"
              @click="$router.push('/submit')"
            >
              <svg viewBox="0 0 24 24" aria-hidden="true">
                <path d="M5 18.2V20h14v-1.8M12 16V4m0 0L7.8 8.2M12 4l4.2 4.2" />
                <path d="M8.5 13.8h7" />
              </svg>
            </button>

            <button
              v-if="isLoggedIn"
              class="announcement-button"
              type="button"
              title="公告"
              :aria-label="`查看公告，${unreadCount} 条未读`"
              @click="openAnnouncementCenter"
            >
              <el-icon><Message /></el-icon>
              <span v-if="unreadCount" class="announcement-badge">
                {{ unreadCount > 99 ? '99+' : unreadCount }}
              </span>
            </button>
          </div>

          <div class="mobile-menu-btn" @click="mobileMenuOpen = !mobileMenuOpen">
            <span></span><span></span><span></span>
          </div>
        </div>

        <!-- 后台“顶部导航栏”广告位：位于全站主导航正下方。 -->
        <div v-if="navAdvertisementVisible" class="nav-advertisement-wrap">
          <AdvertisementSlot
            position="nav_top"
            variant="navigation"
            @close="navAdvertisementVisible = false"
            @unavailable="navAdvertisementVisible = false"
          />
        </div>

        <div class="mobile-menu" v-show="mobileMenuOpen">
          <router-link to="/" @click="mobileMenuOpen = false">🏠 首页</router-link>
          <router-link to="/discover" @click="mobileMenuOpen = false">🎬 浏览</router-link>
          <router-link to="/community" @click="mobileMenuOpen = false">💬 社区</router-link>
          <router-link to="/ai" @click="mobileMenuOpen = false">🤖 AI助手</router-link>
          <router-link v-if="canSubmit" to="/submit" @click="mobileMenuOpen = false">⬆️ 投稿</router-link>
          <button
            v-if="isLoggedIn"
            class="mobile-announcement-link"
            type="button"
            @click="openAnnouncementCenter"
          >
            <span><el-icon><Message /></el-icon> 公告</span>
            <span v-if="unreadCount" class="mobile-announcement-badge">{{ unreadCount }}</span>
          </button>
          <router-link v-if="isLoggedIn" to="/profile" @click="mobileMenuOpen = false">👤 个人中心</router-link>
        </div>
      </header>

      <div class="app-body">
        <router-view v-slot="{ Component }">
          <transition name="page-fade" mode="out-in">
            <component :is="Component" />
          </transition>
        </router-view>
      </div>

      <!-- 登录/注册页不显示底部版权 -->
      <footer v-if="!isAuthPage" class="app-footer">
        <div class="footer-content">
          <p>© 2026 白熊动漫 · 用爱发电 · 为二次元而生 🐻✨</p>
        </div>
      </footer>
    </template>

    <!-- ===== 管理后台布局 (admin)：左侧导航 + 右侧内容 ===== -->
    <template v-else-if="currentLayout === 'admin'">
      <router-view v-slot="{ Component }">
        <transition name="page-fade" mode="out-in">
          <component :is="Component" />
        </transition>
      </router-view>
    </template>

    <!-- ===== 兜底 ===== -->
    <router-view v-else v-slot="{ Component }">
      <transition name="page-fade" mode="out-in">
        <component :is="Component" />
      </transition>
    </router-view>

    <el-dialog
      v-model="announcementDialogOpen"
      class="announcement-dialog"
      :show-close="false"
      :close-on-click-modal="true"
      align-center
      @closed="selectedAnnouncement = null"
    >
      <section v-if="!selectedAnnouncement" class="announcement-list-view" aria-label="公告列表">
        <header class="announcement-list-header">
          <div class="announcement-heading">
            <span class="announcement-heading-icon"><el-icon><Bell /></el-icon></span>
            <h2>公告</h2>
          </div>
          <button class="announcement-close-icon" type="button" aria-label="关闭公告" @click="closeAnnouncementDialog">
            <el-icon><Close /></el-icon>
          </button>
        </header>

        <div class="announcement-list">
          <button
            v-for="notice in announcements"
            :key="notice.id"
            class="announcement-row"
            :class="{ unread: !notice.read }"
            type="button"
            @click="openAnnouncement(notice)"
          >
            <span class="announcement-row-icon"><el-icon><CircleCheck /></el-icon></span>
            <span class="announcement-row-copy">
              <strong>{{ notice.title }}</strong>
              <small>{{ notice.time }}</small>
            </span>
            <span v-if="!notice.read" class="announcement-row-unread" aria-label="未读" />
            <el-icon class="announcement-row-arrow"><ArrowRight /></el-icon>
          </button>
        </div>
      </section>

      <article v-else class="announcement-detail-view">
        <header class="announcement-detail-header">
          <div class="announcement-detail-labels">
            <span class="announcement-detail-icon"><el-icon><InfoFilled /></el-icon></span>
            <span class="announcement-detail-tag">公告</span>
          </div>
          <button class="announcement-close-icon" type="button" aria-label="关闭公告详情" @click="closeAnnouncementDialog">
            <el-icon><Close /></el-icon>
          </button>
          <h2>{{ selectedAnnouncement.title }}</h2>
          <div class="announcement-detail-meta">
            <span><el-icon><Clock /></el-icon>{{ selectedAnnouncement.time }} · {{ selectedAnnouncement.date }}</span>
            <span><el-icon><View /></el-icon>已读</span>
          </div>
        </header>

        <div class="announcement-detail-content">
          <p>{{ selectedAnnouncement.content }}</p>
        </div>

        <footer class="announcement-detail-footer">
          <span><el-icon><InfoFilled /></el-icon>您已阅读此公告</span>
          <button type="button" @click="closeAnnouncementDialog">关闭</button>
        </footer>
      </article>
    </el-dialog>
  </div>
</template>

<script setup>
/**
 * 根组件逻辑

 * 三套布局：
 * - default: 前台（顶部导航 + 内容 + 底部）
 * - admin:   后台（AdminLayout）
 * - blank:   登录/注册（无导航栏）
 */
import { ref, computed, watch } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import dayjs from 'dayjs'
import { useUserStore } from '@/stores/user'
import { useAppStore } from '@/stores/app'
import { announcementApi } from '@/api/modules/announcement'
import AdvertisementSlot from '@/components/common/AdvertisementSlot.vue'

const router = useRouter()
const route = useRoute()
const userStore = useUserStore()
const appStore = useAppStore()

// ===== 当前布局判断 =====
const currentLayout = computed(() => {
  const matched = route.matched || []
  for (const record of matched) {
    if (record.meta && record.meta.layout) {
      return record.meta.layout
    }
  }
  return 'default'
})

// ===== 登录/注册页判断（隐藏底部版权） =====
const isAuthPage = computed(() => {
  return route.name === 'Login' || route.name === 'Register'
})

// ===== 搜索 =====
const searchKeyword = ref('')

function doSearch() {
  const kw = searchKeyword.value.trim()
  if (kw) {
    appStore.setSearchKeyword(kw)
    router.push(`/discover?keyword=${encodeURIComponent(kw)}`)
  }
}

function onClearSearch() {
  if (router.currentRoute.value.path === '/discover') {
    router.push('/discover')
  }
}

// ===== 用户状态（后续接入 Pinia store） =====
const isAdmin = computed(() => userStore.isAdmin)
const canSubmit = computed(() => userStore.canSubmit)
const isLoggedIn = computed(() => userStore.isLoggedIn)
const username = computed(() => userStore.username)
const userAvatar = computed(() => userStore.avatar)
const navAdvertisementVisible = ref(true)

const announcements = ref([])
const unreadCount = computed(() => announcements.value.filter(notice => !notice.read).length)
const announcementDialogOpen = ref(false)
const selectedAnnouncement = ref(null)

async function fetchAnnouncements() {
  if (!isLoggedIn.value) {
    announcements.value = []
    return
  }
  try {
    const result = await announcementApi.getMyAnnouncements()
    announcements.value = (result?.list || []).map(item => {
      const publishTime = item.publishTime || item.createTime
      return {
        ...item,
        read: toBoolean(item.isRead),
        time: formatRelativeTime(publishTime),
        date: publishTime ? dayjs(publishTime).format('YYYY/MM/DD HH:mm:ss') : '-'
      }
    })
  } catch (error) {
    console.error('[App] 公告加载失败:', error)
    announcements.value = []
  }
}

async function openAnnouncementCenter() {
  if (!isLoggedIn.value) return
  selectedAnnouncement.value = null
  announcementDialogOpen.value = true
  mobileMenuOpen.value = false
  await fetchAnnouncements()
}

async function openAnnouncement(notice) {
  selectedAnnouncement.value = notice
  if (!notice.read) {
    notice.read = true
    try {
      await announcementApi.markRead(notice.id)
    } catch (error) {
      notice.read = false
      console.error('[App] 公告已读状态保存失败:', error)
    }
  }
}

function closeAnnouncementDialog() {
  announcementDialogOpen.value = false
}

function toBoolean(value) {
  return value === true || value === 1 || value === '1' || value === 'true'
}

function formatRelativeTime(value) {
  if (!value) return ''
  const published = dayjs(value)
  if (!published.isValid()) return ''
  const minutes = Math.max(0, dayjs().diff(published, 'minute'))
  if (minutes < 1) return '刚刚'
  if (minutes < 60) return `${minutes}分钟前`
  const hours = Math.floor(minutes / 60)
  if (hours < 24) return `${hours}小时前`
  const days = Math.floor(hours / 24)
  return `${days}天前`
}

watch(isLoggedIn, loggedIn => {
  if (loggedIn) fetchAnnouncements()
  else announcements.value = []
}, { immediate: true })

// ===== 用户下拉菜单 =====
function handleUserCommand(command) {
  switch (command) {
    case 'profile':
      router.push('/profile')
      break
    case 'admin':
      router.push('/admin/dashboard')
      break
    case 'logout':
      userStore.logout()
      router.push('/')
      break
  }
}

// ===== 移动端菜单 =====
const mobileMenuOpen = ref(false)
</script>

<style>
/* ===== 全局重置 ===== */
* { margin: 0; padding: 0; box-sizing: border-box; }

html, body, #app {
  height: 100%;
  overflow: hidden;
}

body {
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'PingFang SC', 'Microsoft YaHei', sans-serif;
  background: #f5f7fa;
}

#app {
  display: flex;
  flex-direction: column;
  height: 100vh;
}

/* ===== 页面切换动画 ===== */
.page-fade-enter-active,
.page-fade-leave-active {
  transition: opacity 0.2s ease, transform 0.2s ease;
}
.page-fade-enter-from {
  opacity: 0;
  transform: translateY(8px);
}
.page-fade-leave-to {
  opacity: 0;
  transform: translateY(-8px);
}

/* ===== 顶部导航栏外层 ===== */
.app-header-wrapper {
  background: #fff;
  box-shadow: 0 2px 12px rgba(0,0,0,0.06);
  flex-shrink: 0;
  z-index: 100;
  position: sticky;
  top: 0;
}

/* ===== 顶部导航栏内层 ===== */
.app-header {
  max-width: 1280px;
  margin: 0 auto;
  padding: 0 16px;
  display: flex;
  align-items: center;
  gap: 24px;
  height: 64px;
}
.nav-advertisement-wrap {
  max-width: 1280px;
  margin: 0 auto;
  padding: 0 16px 10px;
  box-sizing: border-box;
}

/* Logo */
.logo {
  font-size: 24px;
  font-weight: 800;
  cursor: pointer;
  background: linear-gradient(135deg, #667eea, #764ba2);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
  white-space: nowrap;
  flex-shrink: 0;
  transition: transform 0.2s;
}

/* ===== 主导航 ===== */
.main-nav {
  display: flex;
  align-items: center;
  gap: 4px;
  margin-left: 24px;
  margin-right: auto;
}

.nav-item {
  display: flex;
  align-items: center;
  gap: 4px;
  padding: 6px 16px;
  border-radius: 20px;
  font-size: 14px;
  font-weight: 500;
  color: #555;
  text-decoration: none;
  transition: all 0.25s ease;
  white-space: nowrap;
}
.nav-item:hover {
  background: rgba(102,126,234,0.08);
  color: #667eea;
}
.nav-item.nav-active {
  background: linear-gradient(135deg, rgba(102,126,234,0.12), rgba(118,75,162,0.06));
  color: #667eea;
  font-weight: 600;
}
.nav-icon { font-size: 15px; }

/* ===== 右侧操作区 ===== */
.nav-actions {
  display: flex;
  gap: 10px;
  align-items: center;
  flex-shrink: 0;
}

/* 搜索框 (浅色版) */
.searchBox {
  display: flex;
  max-width: 220px;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  background: #f0f2f5;
  border-radius: 50px;
  position: relative;
  border: 2px solid #e4e7ed;
  transition: border-color 0.3s ease, box-shadow 0.3s ease;
}
.searchBox:focus-within {
  border-color: #667eea;
  box-shadow: 0 0 0 4px rgba(102, 126, 234, 0.12);
}
.searchInput {
  border: none;
  background: none;
  outline: none;
  color: #2d3436;
  font-size: 13px;
  padding: 10px 40px 10px 16px;
  width: 100%;
}
.searchInput::placeholder {
  color: #a0a4a8;
}
.searchButton {
  color: white;
  position: absolute;
  right: 4px;
  width: 34px;
  height: 34px;
  border-radius: 50%;
  background: linear-gradient(135deg, #667eea, #764ba2);
  border: 0;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  transition: none;
  cursor: pointer;
  flex-shrink: 0;
}
.searchButton:hover {
  background: linear-gradient(135deg, #5a6fd6, #6a3f9e);
  box-shadow: 0 6px 20px rgba(102, 126, 234, 0.35);
}
.searchButton:active {
  box-shadow: none;
}
.searchButton svg {
  width: 18px;
  height: 18px;
}
.searchButton svg path {
  stroke: #ffffff;
}

/* 登录/注册按钮 */
.nav-btn-login {
  border-color: #667eea !important;
  color: #667eea !important;
}
.nav-btn-login:hover {
  background: rgba(102,126,234,0.08) !important;
}

/* 投稿与公告入口 */
.submission-button,
.announcement-button {
  position: relative;
  width: 36px;
  height: 36px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  padding: 0;
  border: 1px solid #e2e6ee;
  border-radius: 50%;
  color: #596275;
  background: #fff;
  cursor: pointer;
  transition: color 0.2s, border-color 0.2s, background 0.2s;
}
.submission-button svg {
  width: 20px;
  height: 20px;
  fill: none;
  stroke: currentColor;
  stroke-width: 1.9;
  stroke-linecap: round;
  stroke-linejoin: round;
}
.announcement-button .el-icon { font-size: 19px; }
.announcement-badge {
  position: absolute;
  top: -6px;
  right: -6px;
  min-width: 19px;
  height: 19px;
  padding: 0 5px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  border: 2px solid #fff;
  border-radius: 10px;
  background: #e5484d;
  color: #fff;
  font-size: 11px;
  font-weight: 700;
  line-height: 1;
  box-shadow: 0 2px 7px rgba(229,72,77,0.35);
}
.submission-button:hover,
.announcement-button:hover {
  color: #667eea;
  border-color: #b8c2f5;
  background: #f4f6ff;
}
.submission-button:focus-visible,
.announcement-button:focus-visible {
  outline: 3px solid rgba(102,126,234,0.2);
  outline-offset: 2px;
}

.announcement-dialog.el-dialog {
  width: min(760px, calc(100vw - 32px));
  padding: 0;
  overflow: hidden;
  border-radius: 22px;
  background: #fff;
  box-shadow: 0 24px 70px rgba(18,25,43,0.24);
}
.announcement-dialog .el-dialog__header { display: none; }
.announcement-dialog .el-dialog__body { padding: 0; }
.announcement-list-view, .announcement-detail-view { color: #202636; background: #fff; }
.announcement-list-header {
  min-height: 92px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 20px 22px;
  background: #f6f8ff;
}
.announcement-heading { display: flex; align-items: center; gap: 12px; }
.announcement-heading h2 { margin: 0; font-size: 26px; letter-spacing: 0; }
.announcement-heading-icon,
.announcement-detail-icon {
  width: 42px;
  height: 42px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  border-radius: 10px;
  color: #fff;
  background: #4568f2;
  box-shadow: 0 8px 18px rgba(69,104,242,0.25);
  font-size: 20px;
}
.announcement-close-icon {
  width: 44px;
  height: 44px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  padding: 0;
  border: 0;
  border-radius: 10px;
  color: #70798b;
  background: rgba(255,255,255,0.72);
  cursor: pointer;
  font-size: 21px;
}
.announcement-close-icon:hover { color: #30384b; background: #fff; }
.announcement-list { max-height: calc(100vh - 230px); overflow-y: auto; }
.announcement-row {
  position: relative;
  width: 100%;
  min-height: 91px;
  display: grid;
  grid-template-columns: 50px minmax(0, 1fr) 8px 24px;
  align-items: center;
  gap: 18px;
  padding: 16px 22px;
  border: 0;
  border-bottom: 1px solid #edf0f4;
  color: inherit;
  background: #fff;
  text-align: left;
  cursor: pointer;
}
.announcement-row:last-child { border-bottom: 0; }
.announcement-row:hover { background: #f8f9fc; }
.announcement-row-icon {
  width: 50px;
  height: 50px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  border-radius: 14px;
  color: #a6afbf;
  background: #f1f3f6;
  font-size: 21px;
}
.announcement-row.unread .announcement-row-icon { color: #5875f5; background: #edf0ff; }
.announcement-row-copy { min-width: 0; display: flex; flex-direction: column; gap: 6px; }
.announcement-row-copy strong {
  overflow: hidden;
  color: #273044;
  font-size: 17px;
  font-weight: 500;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.announcement-row-copy small { color: #7f889a; font-size: 13px; }
.announcement-row-unread {
  width: 7px;
  height: 7px;
  border-radius: 50%;
  background: #e5484d;
}
.announcement-row-arrow { color: #9aa4b4; font-size: 22px; }

.announcement-detail-header {
  position: relative;
  padding: 23px 40px 30px;
  background: #f6f8ff;
}
.announcement-detail-labels {
  display: flex;
  align-items: center;
  gap: 10px;
  margin-bottom: 17px;
}
.announcement-detail-tag {
  padding: 5px 10px;
  border-radius: 8px;
  color: #3559df;
  background: #e9eeff;
  font-size: 13px;
}
.announcement-detail-header .announcement-close-icon { position: absolute; top: 23px; right: 40px; }
.announcement-detail-header h2 { margin: 0 0 14px; padding-right: 56px; font-size: 28px; }
.announcement-detail-meta { display: flex; align-items: center; gap: 20px; color: #667085; font-size: 14px; }
.announcement-detail-meta span,
.announcement-detail-footer span { display: inline-flex; align-items: center; gap: 6px; }
.announcement-detail-content { min-height: 130px; padding: 38px 40px; }
.announcement-detail-content p {
  margin: 0;
  padding-left: 24px;
  border-left: 5px solid #6957ef;
  color: #414b60;
  font-size: 17px;
  line-height: 1.85;
}
.announcement-detail-footer {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 25px 40px;
  border-top: 1px solid #edf0f4;
  color: #7a8497;
  font-size: 13px;
}
.announcement-detail-footer button {
  min-width: 86px;
  height: 42px;
  border: 1px solid #d5dae3;
  border-radius: 10px;
  color: #414a5d;
  background: #fff;
  cursor: pointer;
  font-size: 14px;
}
.announcement-detail-footer button:hover { border-color: #9aa9ed; color: #4568f2; }

/* 用户下拉 */
.user-dropdown-trigger {
  display: flex;
  align-items: center;
  gap: 8px;
  cursor: pointer;
  padding: 4px 8px;
  border-radius: 24px;
  transition: background 0.2s;
}
.user-dropdown-trigger:hover {
  background: #f5f7fa;
}
.user-name {
  font-size: 14px;
  font-weight: 500;
  color: #333;
  max-width: 80px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

/* ===== 移动端汉堡按钮 ===== */
.mobile-menu-btn {
  display: none;
  flex-direction: column;
  gap: 5px;
  cursor: pointer;
  padding: 8px;
}
.mobile-menu-btn span {
  display: block;
  width: 22px;
  height: 2px;
  background: #555;
  border-radius: 2px;
  transition: all 0.3s ease;
}

/* 移动端下拉菜单 */
.mobile-menu {
  display: none;
  flex-direction: column;
  padding: 8px 20px 16px;
  background: #fff;
  border-top: 1px solid #f0f0f0;
}
.mobile-menu a {
  padding: 12px 0;
  font-size: 15px;
  color: #555;
  text-decoration: none;
  border-bottom: 1px solid #f5f5f5;
}
.mobile-menu a:last-child { border-bottom: none; }
.mobile-announcement-link {
  width: 100%;
  min-height: 45px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 12px 0;
  border: 0;
  border-bottom: 1px solid #f5f5f5;
  color: #555;
  background: #fff;
  font: inherit;
  font-size: 15px;
  text-align: left;
  cursor: pointer;
}
.mobile-announcement-link > span:first-child { display: inline-flex; align-items: center; gap: 6px; }
.mobile-announcement-badge {
  min-width: 20px;
  height: 20px;
  padding: 0 6px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  border-radius: 10px;
  color: #fff;
  background: #e5484d;
  font-size: 11px;
  font-weight: 700;
}

/* ===== 主体 ===== */
.app-body {
  flex: 1;
  overflow-y: auto;
  background: #f5f7fa;
  min-height: 0;
}

/* ===== 底部版权 ===== */
.app-footer {
  text-align: center;
  padding: 16px 0;
  background: #fff;
  flex-shrink: 0;
  border-top: 1px solid #f0f0f0;
}
.footer-content { max-width: 1280px; margin: 0 auto; padding: 0 20px; }
.footer-links {
  display: flex;
  justify-content: center;
  gap: 24px;
  margin-bottom: 8px;
}
.footer-links span {
  font-size: 13px;
  color: #999;
  cursor: pointer;
  transition: color 0.2s;
}
.footer-links span:hover { color: #667eea; }

.app-footer p {
  margin: 0;
  color: #bbb;
  font-size: 12px;
}

/* ===== 响应式 ===== */
@media (max-width: 900px) {
  .main-nav, .searchBox, .nav-actions .el-button {
    display: none;
  }
  .submission-button, .announcement-button { display: none; }
  .mobile-menu-btn { display: flex; }
  .mobile-menu { display: flex; }
  .app-header { height: 56px; padding: 0 16px; }
  .logo { font-size: 18px; }
  .nav-actions { gap: 6px; }
  .user-dropdown-trigger .user-name { display: none; }
  .nav-advertisement-wrap { padding: 0 12px 8px; }
}

@media (max-width: 480px) {
  .app-header { height: 48px; padding: 0 12px; }
  .logo { font-size: 16px; }
  .announcement-dialog.el-dialog { width: calc(100vw - 20px); border-radius: 18px; }
  .announcement-list-header { min-height: 76px; padding: 15px 16px; }
  .announcement-heading h2 { font-size: 22px; }
  .announcement-heading-icon { width: 38px; height: 38px; }
  .announcement-close-icon { width: 38px; height: 38px; }
  .announcement-row { min-height: 79px; grid-template-columns: 42px minmax(0, 1fr) 7px 20px; gap: 12px; padding: 13px 15px; }
  .announcement-row-icon { width: 42px; height: 42px; border-radius: 12px; }
  .announcement-row-copy strong { font-size: 14px; }
  .announcement-detail-header { padding: 18px 20px 24px; }
  .announcement-detail-header .announcement-close-icon { top: 18px; right: 20px; }
  .announcement-detail-header h2 { font-size: 23px; }
  .announcement-detail-meta { align-items: flex-start; flex-direction: column; gap: 8px; font-size: 12px; }
  .announcement-detail-content { min-height: 110px; padding: 28px 20px; }
  .announcement-detail-content p { padding-left: 16px; font-size: 14px; }
  .announcement-detail-footer { padding: 18px 20px; }
  .footer-links { gap: 12px; }
  .footer-links span { font-size: 11px; }
}
</style>
