/**
 * 路由配置 —— 白熊动漫平台
 *
 * 路由结构：
 * - /                 首页
 * - /play/:id         视频播放页
 * - /discover         动漫浏览/搜索
 * - /anime/:id        动漫详情页
 * - /community        社区广场
 * - /community/:id    帖子详情
 * - /ai                AI 智能助手
 * - /login            登录
 * - /register         注册
 *
 * 后台管理使用 Spring Boot (Knife4j 文档: http://localhost:8088/doc.html)
 */
import { createRouter, createWebHistory } from 'vue-router'
import { storage } from '@/utils/storage'
import { ElMessage } from 'element-plus'

// ===== 路由懒加载（提升首屏性能） =====
const Home = () => import('@/views/Home.vue')
const Player = () => import('@/views/Player.vue')
const Login = () => import('@/views/Login.vue')
const Register = () => import('@/views/Register.vue')
const ForgotPassword = () => import('@/views/ForgotPassword.vue')
const ResetPassword = () => import('@/views/ResetPassword.vue')
const Discover = () => import('@/views/Discover.vue')
const AnimeDetail = () => import('@/views/AnimeDetail.vue')
const Community = () => import('@/views/Community.vue')
const PostDetail = () => import('@/views/PostDetail.vue')
const AiAssistant = () => import('@/views/AiAssistant.vue')
const UserProfile = () => import('@/views/UserProfile.vue')
const Profile = () => import('@/views/Profile.vue')
const VideoSubmission = () => import('@/views/VideoSubmission.vue')

// 管理后台（独立布局）
const AdminLayout = () => import('@/views/admin/AdminLayout.vue')
const AdminDashboard = () => import('@/views/admin/Dashboard.vue')
const AdminUserManagement = () => import('@/views/admin/UserManagement.vue')
const AdminCreatorAuditManagement = () => import('@/views/admin/CreatorAuditManagement.vue')
const AdminVideoManagement = () => import('@/views/admin/VideoManagement.vue')
const AdminVideoAuditManagement = () => import('@/views/admin/VideoAuditManagement.vue')
const AdminContentManagement = () => import('@/views/admin/ContentManagement.vue')
const AdminAdvertisements = () => import('@/views/admin/AdvertisementManagement.vue')
const AdminRanking = () => import('@/views/admin/Ranking.vue')
const AdminAnnouncements = () => import('@/views/admin/AnnouncementManagement.vue')
const AdminBannerEffects = () => import('@/views/admin/BannerEffectManagement.vue')

// ===== 路由表 =====
const routes = [
  // -------- 前台页面 --------
  {
    path: '/',
    name: 'Home',
    component: Home,
    meta: { title: '🐻 白熊动漫 - 首页', layout: 'default' }
  },
  {
    path: '/play/:id',
    name: 'Player',
    component: Player,
    meta: { title: '🎬 视频播放', layout: 'default' }
  },
  {
    path: '/discover',
    name: 'Discover',
    component: Discover,
    meta: { title: '🔍 动漫浏览', layout: 'default' }
  },
  {
    path: '/anime/:id',
    name: 'AnimeDetail',
    component: AnimeDetail,
    meta: { title: '📖 动漫详情', layout: 'default' }
  },
  {
    path: '/community',
    name: 'Community',
    component: Community,
    meta: { title: '💬 社区广场', layout: 'default' }
  },
  {
    path: '/community/:id',
    name: 'PostDetail',
    component: PostDetail,
    meta: { title: '📝 帖子详情', layout: 'default' }
  },
  {
    path: '/ai',
    name: 'AiAssistant',
    component: AiAssistant,
    meta: { title: '🤖 AI 智能助手', requiresAuth: true, layout: 'default' }
  },
  {
    path: '/profile',
    name: 'Profile',
    component: Profile,
    meta: { title: '👤 个人中心', requiresAuth: true, layout: 'default' }
  },
  {
    path: '/submit',
    name: 'VideoSubmission',
    component: VideoSubmission,
    meta: { title: '⬆️ 动漫投稿', requiresAuth: true, requiresCreator: true, layout: 'default' }
  },
  {
    path: '/home/:name',
    name: 'UserHome',
    component: UserProfile,
    meta: { title: '🏠 个人主页', layout: 'default' }
  },

  // -------- 登录/注册（前台布局，含顶部导航） --------
  {
    path: '/login',
    name: 'Login',
    component: Login,
    meta: { title: '🔑 登录', layout: 'default' }
  },
  {
    path: '/register',
    name: 'Register',
    component: Register,
    meta: { title: '📝 注册', layout: 'default' }
  },
  {
    path: '/forgot-password',
    name: 'ForgotPassword',
    component: ForgotPassword,
    meta: { title: '找回密码', layout: 'default' }
  },
  {
    path: '/reset-password',
    name: 'ResetPassword',
    component: ResetPassword,
    meta: { title: '重置密码', layout: 'default' }
  },

  // -------- 管理后台（独立 AdminLayout，左侧导航+右侧内容） --------
  {
    path: '/admin',
    component: AdminLayout,
    meta: { requiresAuth: true, requiresAdmin: true, layout: 'admin' },
    children: [
      {
        path: '',
        redirect: '/admin/dashboard'
      },
      {
        path: 'dashboard',
        name: 'AdminDashboard',
        component: AdminDashboard,
        meta: { title: '📊 仪表盘', requiresAuth: true, requiresAdmin: true }
      },
      {
        path: 'users',
        redirect: '/admin/users/list'
      },
      {
        path: 'users/list',
        name: 'AdminUsers',
        component: AdminUserManagement,
        meta: { title: '👥 用户数据', adminTitle: '用户数据', requiresAuth: true, requiresAdmin: true }
      },
      {
        path: 'users/creator-audit',
        name: 'AdminCreatorAudit',
        component: AdminCreatorAuditManagement,
        meta: { title: '🛡️ 创作者审核', adminTitle: '创作者审核', requiresAuth: true, requiresAdmin: true }
      },
      {
        path: 'videos',
        redirect: '/admin/videos/list'
      },
      {
        path: 'videos/list',
        name: 'AdminVideos',
        component: AdminVideoManagement,
        meta: { title: '🎬 动漫视频', adminTitle: '动漫视频', requiresAuth: true, requiresAdmin: true }
      },
      {
        path: 'videos/audit',
        name: 'AdminVideoAudit',
        component: AdminVideoAuditManagement,
        meta: { title: '🛡️ 动漫审核', adminTitle: '动漫审核', requiresAuth: true, requiresAdmin: true }
      },
      {
        path: 'content',
        name: 'AdminContent',
        component: AdminContentManagement,
        meta: { title: '📝 社区管理', requiresAuth: true, requiresAdmin: true }
      },
      {
        path: 'advertisements',
        name: 'AdminAdvertisements',
        component: AdminAdvertisements,
        meta: { title: '📣 广告管理', requiresAuth: true, requiresAdmin: true }
      },
      {
        path: 'statistics',
        redirect: '/admin/advertisements'
      },
      {
        path: 'ranking',
        name: 'AdminRanking',
        component: AdminRanking,
        meta: { title: '🏆 排行榜管理', requiresAuth: true, requiresAdmin: true }
      },
      {
        path: 'announcements',
        name: 'AdminAnnouncements',
        component: AdminAnnouncements,
        meta: { title: '📢 公告管理', requiresAuth: true, requiresAdmin: true }
      },
      {
        path: 'banner-effects',
        name: 'AdminBannerEffects',
        component: AdminBannerEffects,
        meta: { title: '🖼️ 效果图管理', requiresAuth: true, requiresAdmin: true }
      }
    ]
  },

  // -------- 404 --------
  {
    path: '/:pathMatch(.*)*',
    name: 'NotFound',
    component: () => import('@/views/NotFound.vue'),
    meta: { title: '404 - 页面未找到', layout: 'default' }
  }
]

// ===== 创建路由实例 =====
const router = createRouter({
  history: createWebHistory(),
  routes,
  // 路由切换时滚动到顶部
  scrollBehavior() {
    return { top: 0 }
  }
})

// ===== 全局路由守卫 =====
router.beforeEach((to, from, next) => {
  // 设置页面标题
  document.title = to.meta.title || '🐻 白熊动漫'

  let token = storage.get('token')
  let userInfo = storage.get('userInfo')

  if (token && isJwtExpired(token)) {
    storage.remove('token')
    storage.remove('userInfo')
    token = ''
    userInfo = null
  }

  // 需要登录的页面，未登录则跳转到登录页
  if (to.meta.requiresAuth && !token) {
    ElMessage.warning('请先登录')
    next({ name: 'Login', query: { redirect: to.fullPath } })
    return
  }

  // 需要管理员权限的页面
  if (to.meta.requiresAdmin) {
    if (!userInfo || userInfo.role !== 'admin') {
      ElMessage.error('权限不足')
      next({ name: 'Home' })
      return
    }
  }

  // 投稿页只允许管理员或已申请成功的创作者进入
  if (to.meta.requiresCreator) {
    const role = userInfo?.role
    if (role !== 'admin' && role !== 'creator') {
      ElMessage.warning('请先在个人中心申请成为创作者')
      next({ name: 'Profile', query: { tab: 'creator' } })
      return
    }
  }

  // 已登录用户访问登录/注册页，直接跳转首页
  if (token && (to.name === 'Login' || to.name === 'Register' || to.name === 'ForgotPassword')) {
    next({ name: 'Home' })
    return
  }

  next()
})

export default router

function isJwtExpired(token) {
  try {
    const payload = token.split('.')[1]
    const normalized = payload.replace(/-/g, '+').replace(/_/g, '/')
    const padded = normalized.padEnd(Math.ceil(normalized.length / 4) * 4, '=')
    const bytes = Uint8Array.from(atob(padded), char => char.charCodeAt(0))
    const claims = JSON.parse(new TextDecoder().decode(bytes))
    return !claims.exp || claims.exp * 1000 <= Date.now()
  } catch {
    return true
  }
}
