import request from '@/api/request'

export const announcementApi = {
  getMyAnnouncements() {
    return request.get('/announcements', { cancelDuplicate: false })
  },

  markRead(id) {
    return request.post(`/announcements/${id}/read`)
  }
}
