/**
 * 社区相关 API 接口
 *
 * 后端接口规划：
 * GET    /api/community/posts        - 帖子列表
 * GET    /api/community/post/:id     - 帖子详情
 * POST   /api/community/post         - 发布帖子
 * DELETE /api/community/post/:id     - 删除帖子
 * POST   /api/community/comment      - 发表评论
 * POST   /api/community/like         - 点赞
 * POST   /api/community/share        - 分享
 * POST   /api/community/danmaku      - 发送弹幕
 * GET    /api/community/danmaku/:id  - 获取弹幕
 */
import request from '@/api/request'

export const communityApi = {
  /** 获取帖子列表 */
  getPosts(params = {}) {
    return request.get('/community/posts', { params })
  },

  /** 获取帖子详情 */
  getPostDetail(id) {
    return request.get(`/community/post/${id}`)
  },

  /** 发布帖子 */
  createPost(data) {
    return request.post('/community/post', data)
  },

  /** 上传帖子图片 */
  uploadImage(file) {
    const formData = new FormData()
    formData.append('file', file)
    return request.post('/community/image', formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
      timeout: 30000
    })
  },

  /** 删除帖子 */
  deletePost(id) {
    return request.delete(`/community/post/${id}`)
  },

  /** 发表评论/回复 */
  addComment(data) {
    return request.post('/community/comment', data)
  },

  /** 点赞（帖子或评论） */
  toggleLike(targetId, type = 'post') {
    return request.post('/community/like', { targetId, type })
  },

  /** 获取播放器评论 */
  getVideoComments(videoId, sourceType) {
    return request.get('/video-comments', { params: { videoId, sourceType } })
  },

  /** 发表播放器评论或回复 */
  addVideoComment(data) {
    return request.post('/video-comments', data)
  },

  /** 点赞/取消点赞播放器评论 */
  toggleVideoCommentLike(commentId) {
    return request.post(`/video-comments/${commentId}/like`)
  },

  /** 分享 */
  share(targetId) {
    return request.post('/community/share', { targetId })
  },

  /** 获取弹幕列表 */
  getDanmaku(animeId, episodeId, timestamp) {
    return request.get(`/community/danmaku/${animeId}`, {
      params: { episodeId, timestamp }
    })
  },

  /** 发送弹幕 */
  sendDanmaku(data) {
    return request.post('/community/danmaku', data)
  }
}
