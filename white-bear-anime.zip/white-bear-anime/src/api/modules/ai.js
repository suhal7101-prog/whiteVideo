/**
 * AI 相关 API 接口（扩展预留）
 *
 * 后端接口规划（基于 RAG 检索增强生成 + DeepSeek API）：
 * POST   /api/ai/chat              - AI 对话（动漫知识问答）
 * POST   /api/ai/recommend         - AI 个性化推荐
 * POST   /api/ai/agent             - AI 追番助手（Agent 智能代理）
 * POST   /api/ai/character         - 角色信息查询
 * GET    /api/ai/search            - RAG 知识库检索
 *
 * 技术栈规划：
 * - 检索增强生成（RAG）：结合 Chroma 向量数据库进行动漫知识检索
 * - DeepSeek API：大模型对话与推理
 * - Agent 框架：LangChain / 自研 Agent 实现追番自动化
 *
 * 当前状态：已接入 Spring Boot AI 接口
 */
import request from '@/api/request'

export const aiApi = {
  /**
   * AI 对话 - 动漫知识问答
   * @param {string} question - 用户问题
   * @param {Array} history - 对话历史 [{role, content}, ...]
   */
  chat(question, history = []) {
    return request.post('/ai/chat', { question, history }, { timeout: 120000 })
  },

  /**
   * AI 个性化推荐
   * @param {Object} preferences - 用户偏好
   */
  getRecommendations(preferences = {}) {
    return request.post('/ai/recommend', preferences)
  },

  /**
   * AI 追番助手 - Agent 指令
   * @param {string} command - 语音/文字指令
   */
  agentCommand(command) {
    return request.post('/ai/agent', { command }, { timeout: 120000 })
  },

  /**
   * 角色信息查询
   * @param {string} characterName - 角色名称
   */
  queryCharacter(characterName) {
    return request.post('/ai/character', { characterName })
  },

  /**
   * RAG 知识库检索
   * @param {string} query - 检索查询
   */
  searchKnowledge(query) {
    return request.get('/ai/search', { params: { query } })
  }
}
