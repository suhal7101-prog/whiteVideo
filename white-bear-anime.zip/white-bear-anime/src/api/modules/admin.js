/**
 * 管理后台 API 接口
 *
 * 后端接口规划：
 * -- 用户管理 --
 * GET    /api/admin/users           - 用户列表
 * PUT    /api/admin/user/:id        - 编辑用户
 * DELETE /api/admin/user/:id        - 删除用户
 * -- 视频管理 --
 * GET    /api/admin/videos          - 视频列表
 * POST   /api/admin/video           - 新增视频
 * PUT    /api/admin/video/:id       - 编辑视频
 * DELETE /api/admin/video/:id       - 删除视频
 * -- 内容管理 --
 * GET    /api/admin/banners         - 轮播图列表
 * POST   /api/admin/banner          - 新增轮播图
 * PUT    /api/admin/banner/:id      - 编辑轮播图
 * GET    /api/admin/posts/pending   - 待审核帖子
 * PUT    /api/admin/post/:id/audit  - 审核帖子
 * -- 数据统计 --
 * GET    /api/admin/stats/overview  - 概览统计
 * GET    /api/admin/stats/play      - 播放统计
 * GET    /api/admin/stats/user      - 用户活跃度
 * GET    /api/admin/stats/ranking   - 视频排行
 */
import request from '@/api/request'

export const adminApi = {
  // ===== 用户管理 =====
  getUsers(params) {
    return request.get('/admin/users', { params })
  },
  updateUser(id, data) {
    return request.put(`/admin/user/${id}`, data)
  },
  deleteUser(id) {
    return request.delete(`/admin/user/${id}`)
  },
  resetPassword(id, password) {
    return request.put(`/admin/user/${id}/password`, { password })
  },
  getCreatorApplications(params) {
    return request.get('/admin/creator-applications', { params })
  },
  auditCreatorApplication(id, data) {
    return request.put(`/admin/creator-application/${id}/audit`, data)
  },

  // ===== 视频管理 =====
  getVideos(params) {
    return request.get('/admin/videos', { params })
  },
  createVideo(data) {
    return request.post('/admin/video', data)
  },
  updateVideo(id, data) {
    return request.put(`/admin/video/${id}`, data)
  },
  deleteVideo(id) {
    return request.delete(`/admin/video/${id}`)
  },
  getVideoSubmissions(params) {
    return request.get('/admin/video-submissions', { params })
  },
  auditVideoSubmission(id, data) {
    return request.put(`/admin/video-submission/${id}/audit`, data)
  },

  // ===== 内容管理 =====
  getBanners() {
    return request.get('/admin/banners')
  },
  createBanner(data) {
    return request.post('/admin/banner', data)
  },
  updateBanner(id, data) {
    return request.put(`/admin/banner/${id}`, data)
  },
  getPendingPosts(params) {
    return request.get('/admin/posts/pending', { params })
  },
  auditPost(id, status) {
    return request.put(`/admin/post/${id}/audit`, { status })
  },
  getAnnouncements() {
    return request.get('/admin/announcements')
  },
  createAnnouncement(data) {
    return request.post('/admin/announcement', data)
  },
  updateAnnouncement(id, data) {
    return request.put(`/admin/announcement/${id}`, data)
  },
  deleteAnnouncement(id) {
    return request.delete(`/admin/announcement/${id}`)
  },
  getAdvertisements() {
    return request.get('/admin/advertisements')
  },
  getAdvertisementImages() {
    return request.get('/admin/advertisement/images')
  },
  uploadAdvertisementImage(file) {
    const formData = new FormData()
    formData.append('file', file)
    return request.post('/admin/advertisement/image', formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
      timeout: 30000
    })
  },
  createAdvertisement(data) {
    return request.post('/admin/advertisement', data)
  },
  updateAdvertisement(id, data) {
    return request.put(`/admin/advertisement/${id}`, data)
  },
  deleteAdvertisement(id) {
    return request.delete(`/admin/advertisement/${id}`)
  },
  getBannerEffects() {
    return request.get('/admin/banner-effects')
  },
  updateBannerEffect(id, data) {
    return request.put(`/admin/banner-effect/${id}`, data)
  },

  // ===== 数据统计 =====
  getStatsOverview() {
    return request.get('/admin/stats/overview')
  },
  getPlayStats(params) {
    return request.get('/admin/stats/play', { params })
  },
  getUserStats(params) {
    return request.get('/admin/stats/user', { params })
  },
  getRankingStats(params) {
    return request.get('/admin/stats/ranking', { params })
  }
}
