/**
 * 用户相关 API 接口（登录/注册页面不动，这里留作扩展用）
 *
 * 后端接口规划：
 * POST   /api/user/login          - 登录
 * POST   /api/user/register       - 注册
 * GET    /api/user/profile        - 获取个人信息
 * PUT    /api/user/profile        - 修改个人信息
 * PUT    /api/user/password       - 修改密码
 * POST   /api/user/forgot-pwd     - 找回密码
 * GET    /api/user/favorites      - 追番列表
 * POST   /api/user/favorites      - 添加追番
 * DELETE /api/user/favorites/:id  - 取消追番
 * GET    /api/user/history        - 观看历史
 */
import request from '@/api/request'

export const userApi = {
  /** 登录 */
  login(data) {
    return request.post('/user/login', data)
  },

  /** 注册 */
  register(data) {
    return request.post('/user/register', data)
  },

  /** 获取个人信息 */
  getProfile() {
    return request.get('/user/profile')
  },

  /** 更新个人信息 */
  updateProfile(data) {
    return request.put('/user/profile', data)
  },

  /** 修改密码 */
  changePassword(data) {
    return request.put('/user/password', data)
  },

  /** 申请成为创作者 */
  applyCreator(message) {
    return request.post('/user/creator/apply', { message })
  },

  /** 提交动漫投稿 */
  submitVideo(data) {
    return request.post('/user/video-submissions', data)
  },

  /** 投稿页搜索已有动漫资料 */
  searchSubmissionAnime(title) {
    return request.get('/user/video-submissions/search', { params: { title } })
  },

  /** 上传投稿视频 */
  uploadSubmissionVideo(file, onProgress) {
    const formData = new FormData()
    formData.append('file', file)
    return request.post('/user/submission-video', formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
      timeout: 10 * 60 * 1000,
      onUploadProgress(event) {
        if (event.total && typeof onProgress === 'function') {
          onProgress(Math.min(100, Math.round((event.loaded * 100) / event.total)))
        }
      }
    })
  },

  /** 找回密码 */
  forgotPassword(email) {
    return request.post('/user/forgot-pwd', { email })
  },

  /** 使用邮件中的一次性令牌重置密码 */
  resetPassword(token, newPassword) {
    return request.post('/user/reset-password', { token, newPassword })
  },

  /** 上传头像 */
  uploadAvatar(file) {
    const formData = new FormData()
    formData.append('file', file)
    return request.post('/user/avatar', formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
      timeout: 30000
    })
  },

  /** 获取追番列表 */
  getFavorites() {
    return request.get('/user/favorites')
  },

  /** 添加追番 */
  addFavorite(animeId) {
    return request.post('/user/favorites', { animeId })
  },

  /** 取消追番 */
  removeFavorite(animeId) {
    return request.delete(`/user/favorites/${animeId}`)
  },

  /** 获取观看历史 */
  getHistory() {
    return request.get('/user/history')
  },

  clearHistory() {
    return request.delete('/user/history')
  },

  /** 查询当前视频的追番和点赞状态 */
  getVideoActionState(data) {
    return request.post('/user/video-actions/state', data)
  },

  /** 追番/取消追番 */
  toggleVideoFavorite(data) {
    return request.post('/user/video-actions/favorite', data)
  },

  /** 视频点赞/取消点赞 */
  toggleVideoLike(data) {
    return request.post('/user/video-actions/like', data)
  },

  /** 获取点赞过的视频 */
  getLikedVideos() {
    return request.get('/user/video-likes')
  },

  /** 关注用户 */
  followUser(userId) {
    return request.put(`/user/follows/${userId}`)
  },

  /** 取消关注用户 */
  unfollowUser(userId) {
    return request.delete(`/user/follows/${userId}`)
  }
}
