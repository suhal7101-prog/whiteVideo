import request from '@/api/request'

export const advertisementApi = {
  getActive(position) {
    return request.get('/advertisements', { params: { position } })
  }
}
