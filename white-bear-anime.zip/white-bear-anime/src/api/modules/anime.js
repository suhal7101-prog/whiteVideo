/**
 * 动漫相关 API — Bilibili 数据源
 * 后端代理: server/main.py (FastAPI + bili 库)
 */
import request from '@/api/request'

export const animeApi = {
  /** 获取视频信息 */
  getVideoInfo(bvid) {
    return request.get(`/bilibili/video/${bvid}`)
  },

  /** 获取视频弹幕 */
  getDanmaku(bvid) {
    return request.get(`/bilibili/danmaku/${bvid}`)
  },

  /** 搜索视频 */
  search(keyword, page = 1) {
    return request.get('/bilibili/search', { params: { keyword, page } })
  },

  /** 排行榜 */
  getRanking(rid = '0', day = 3) {
    return request.get('/bilibili/ranking', { params: { rid, day } })
  },

  /** 用户信息 */
  getUserInfo(uid) {
    return request.get(`/bilibili/user/${uid}`)
  }
}
