/**
 * Axios 实例封装 —— 跨域请求 + 拦截器
 *
 * 功能扩展点：
 * 1. 请求/响应拦截器统一处理 Token、错误提示
 * 2. 支持取消重复请求（可配置）
 * 3. 日后接入 WebSocket 实时通信
 * 4. AI 模块可通过此实例调用 DeepSeek/RAG 接口
 *
 * 跨域说明：后端需配置 CORS 或通过 vite.config.js 代理
 * Vite 按模块将 /api 代理到 Spring Boot 8088 或 FastAPI 8082
 * WebSocket 通过 /ws 代理到 Spring Boot 8088
 */
import axios from 'axios'
import { ElMessage } from 'element-plus'
import { storage } from '@/utils/storage'

// ===== 创建 Axios 实例 =====
const request = axios.create({
  // 基础URL使用 vite proxy 代理，避免跨域问题
  baseURL: '/api',
  // 超时时间 15 秒
  timeout: 15000,
  // 跨域请求时携带 cookie（如需 session 认证）
  withCredentials: true,
  headers: {
    'Content-Type': 'application/json;charset=UTF-8'
  }
})

// ===== 用于取消重复请求的 Map =====
const pendingRequests = new Map()
let authRedirecting = false

function handleUnauthorized(message = '登录已过期，请重新登录') {
  storage.remove('token')
  storage.remove('userInfo')
  if (authRedirecting) return

  authRedirecting = true
  ElMessage.error(message)
  const current = window.location.pathname + window.location.search + window.location.hash
  const loginUrl = `/login?redirect=${encodeURIComponent(current)}`
  setTimeout(() => window.location.replace(loginUrl), 500)
}

/**
 * 生成请求唯一标识
 * @param {Object} config - axios 请求配置
 * @returns {string} 请求标识
 */
function getRequestKey(config) {
  const { method, url, params, data } = config
  return [method, url, JSON.stringify(params), JSON.stringify(data)].join('&')
}

/**
 * 添加请求到 pending 队列（取消重复请求）
 * @param {Object} config - axios 请求配置
 */
function addPendingRequest(config) {
  const key = getRequestKey(config)
  // 如果已有相同请求在进行中，取消它
  if (pendingRequests.has(key)) {
    const cancel = pendingRequests.get(key)
    cancel(key)
    pendingRequests.delete(key)
  }
  // 将新的取消函数存入
  config.cancelToken = new axios.CancelToken((cancel) => {
    pendingRequests.set(key, cancel)
  })
}

/**
 * 从 pending 队列移除请求
 * @param {Object} config - axios 请求配置
 */
function removePendingRequest(config) {
  const key = getRequestKey(config)
  if (pendingRequests.has(key)) {
    pendingRequests.delete(key)
  }
}

// ===== 请求拦截器 =====
request.interceptors.request.use(
  (config) => {
    // 从本地存储获取 Token（登录后保存）
    const token = storage.get('token')
    if (token) {
      // Bearer Token 认证方式
      config.headers['Authorization'] = `Bearer ${token}`
    }

    // 可选：取消重复请求（GET 请求默认启用）
    if (config.cancelDuplicate !== false && config.method === 'get') {
      addPendingRequest(config)
    }

    return config
  },
  (error) => {
    console.error('[Request] 请求错误:', error)
    return Promise.reject(error)
  }
)

// ===== 响应拦截器 =====
request.interceptors.response.use(
  (response) => {
    // 请求完成，从 pending 队列移除
    removePendingRequest(response.config)

    // 后端统一返回格式: { code: 200, data: {...}, message: 'success' }
    const res = response.data

    // 如果后端直接返回了文件流或非标准格式，直接返回
    if (res === undefined || res === null || typeof res !== 'object') {
      return response
    }

    // 业务状态码判断
    if (res.code === 200 || res.code === 0) {
      return res.data !== undefined ? res.data : res
    }

    // Token 过期，跳转登录
    if (res.code === 401) {
      handleUnauthorized(res.message)
      return Promise.reject(new Error(res.message || '认证失败'))
    }

    // 其他业务错误
    ElMessage.error(res.message || '请求失败')
    return Promise.reject(new Error(res.message || '请求失败'))
  },
  (error) => {
    // 请求完成（即使是错误），从 pending 队列移除
    if (error.config) {
      removePendingRequest(error.config)
    }

    // 取消请求不提示错误
    if (axios.isCancel(error)) {
      console.log('[Request] 请求已取消:', error.message)
      return Promise.reject(error)
    }

    // 网络错误处理
    if (!error.response) {
      ElMessage.error('网络连接失败，请检查网络')
      return Promise.reject(error)
    }

    if (error.response.status === 401) {
      handleUnauthorized(error.response.data?.message)
    }

    return Promise.reject(error)
  }
)

export default request
