function finiteNumber(value, fallback = 0) {
  const result = Number(value)
  return Number.isFinite(result) ? result : fallback
}

function optionalNumber(value) {
  if (value === null || value === undefined || value === '') return undefined
  const result = Number(value)
  return Number.isFinite(result) ? result : undefined
}

export function resolveBannerSource(source, baseUrl = '') {
  const value = String(source || '').trim()
  if (!value) return ''
  if (/^(https?:)?\/\//i.test(value) || value.startsWith('/')) return value

  const filename = value.replace(/\\/g, '/').split('/').pop()
  const base = String(baseUrl || '').replace(/\/$/, '')
  return base ? `${base}/${filename}` : value
}

export function normalizeBannerLayers(layers, options = {}) {
  if (!Array.isArray(layers)) return []
  const baseUrl = options.baseUrl || ''

  return layers.map((layer, index) => {
    const tagName = String(layer.tagName || layer.type || 'img').toLowerCase()
    const opacity = Array.isArray(layer.opacity) && layer.opacity.length === 2
      ? layer.opacity.map((value, opacityIndex) => finiteNumber(value, opacityIndex === 0 ? 1 : 1))
      : [1, 1]
    const fallbackMatrix = [1, 0, 0, 1, 0, 0]
    const transform = Array.isArray(layer.transform) && layer.transform.length === 6
      ? layer.transform.map((value, matrixIndex) => finiteNumber(value, fallbackMatrix[matrixIndex]))
      : fallbackMatrix

    return {
      ...layer,
      tagName,
      src: resolveBannerSource(layer.src || layer.url, baseUrl),
      opacity,
      transform,
      width: optionalNumber(layer.width),
      height: optionalNumber(layer.height),
      a: finiteNumber(layer.a, 0.01),
      deg: finiteNumber(layer.deg),
      g: finiteNumber(layer.g),
      f: finiteNumber(layer.f),
      blur: finiteNumber(layer.blur),
      zIndex: finiteNumber(layer.zIndex, index + 1),
    }
  })
}
