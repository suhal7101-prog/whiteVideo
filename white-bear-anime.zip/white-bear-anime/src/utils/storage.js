/**
 * 本地存储工具类
 * 封装 localStorage/sessionStorage 操作，统一异常处理
 * 为日后扩展 IndexedDB 或加密存储预留接口
 */
const STORAGE_PREFIX = 'white_bear_'

export const storage = {
  /**
   * 设置本地存储
   * @param {string} key - 键名
   * @param {any} value - 值（自动JSON序列化）
   */
  set(key, value) {
    try {
      const serialized = JSON.stringify(value)
      localStorage.setItem(STORAGE_PREFIX + key, serialized)
    } catch (e) {
      console.warn('[Storage] 写入失败:', key, e)
    }
  },

  /**
   * 获取本地存储
   * @param {string} key - 键名
   * @param {any} defaultValue - 默认值
   * @returns {any} 解析后的值或默认值
   */
  get(key, defaultValue = null) {
    try {
      const raw = localStorage.getItem(STORAGE_PREFIX + key)
      return raw ? JSON.parse(raw) : defaultValue
    } catch (e) {
      console.warn('[Storage] 读取失败:', key, e)
      return defaultValue
    }
  },

  /**
   * 移除指定键
   * @param {string} key - 键名
   */
  remove(key) {
    try {
      localStorage.removeItem(STORAGE_PREFIX + key)
    } catch (e) {
      console.warn('[Storage] 删除失败:', key, e)
    }
  },

  /** 清空所有白熊动漫相关的存储 */
  clear() {
    try {
      Object.keys(localStorage)
        .filter(k => k.startsWith(STORAGE_PREFIX))
        .forEach(k => localStorage.removeItem(k))
    } catch (e) {
      console.warn('[Storage] 清空失败:', e)
    }
  }
}

// ===== 播放进度专用存储 =====
export const progressStorage = {
  /** 保存播放进度 */
  save(animeId, episodeId, currentTime, duration) {
    const all = storage.get('play_progress', {})
    all[animeId] = {
      episodeId,
      currentTime,
      duration,
      updatedAt: new Date().toISOString()
    }
    storage.set('play_progress', all)
  },

  /** 获取播放进度 */
  get(animeId) {
    const all = storage.get('play_progress', {})
    return all[animeId] || null
  },

  /** 获取所有进度 */
  getAll() {
    return storage.get('play_progress', {})
  }
}

// ===== 观看历史专用存储（最多保存100条） =====
export const historyStorage = {
  save(item) {
    const list = storage.get('watch_history', [])
    // 去重：如果已存在则移除旧记录
    const idx = list.findIndex(h => h.animeId === item.animeId)
    if (idx > -1) list.splice(idx, 1)
    list.unshift({ ...item, watchedAt: new Date().toISOString() })
    // 最多保留100条
    if (list.length > 100) list.length = 100
    storage.set('watch_history', list)
  },

  getAll() {
    return storage.get('watch_history', [])
  },

  clear() {
    storage.remove('watch_history')
  }
}
