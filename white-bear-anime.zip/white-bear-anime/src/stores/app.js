/**
 * 全局应用状态管理 (Pinia Store)
 *
 * 管理：全局加载状态、侧边栏、主题、搜索关键词
 */
import { defineStore } from 'pinia'
import { ref } from 'vue'

export const useAppStore = defineStore('app', () => {
  // ===== 状态 =====
  /** 全局加载状态 */
  const globalLoading = ref(false)
  /** 搜索关键词 */
  const searchKeyword = ref('')
  /** 是否为暗色模式（日后扩展） */
  const isDarkMode = ref(false)
  /** 当前页面标题 */
  const pageTitle = ref('白熊动漫')

  // ===== 方法 =====
  /** 设置全局加载 */
  function setLoading(val) {
    globalLoading.value = val
  }

  /** 设置搜索关键词 */
  function setSearchKeyword(keyword) {
    searchKeyword.value = keyword
  }

  /** 切换暗色模式 */
  function toggleDarkMode() {
    isDarkMode.value = !isDarkMode.value
    document.documentElement.classList.toggle('dark', isDarkMode.value)
  }

  /** 设置页面标题 */
  function setPageTitle(title) {
    pageTitle.value = title
  }

  return {
    globalLoading,
    searchKeyword,
    isDarkMode,
    pageTitle,
    setLoading,
    setSearchKeyword,
    toggleDarkMode,
    setPageTitle
  }
})
