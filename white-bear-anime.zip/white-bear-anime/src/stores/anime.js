/**
 * 动漫数据状态管理 (Pinia Store)
 *
 * 管理：动漫列表、详情、排行榜、分类、搜索
 */
import { defineStore } from 'pinia'
import { ref, computed } from 'vue'

export const useAnimeStore = defineStore('anime', () => {
  // ===== 状态 =====
  /** 当前浏览的动漫列表 */
  const animeList = ref([])
  /** 当前动漫详情 */
  const currentAnime = ref(null)
  /** 排行榜数据 */
  const rankings = ref({ hot: [], new: [], score: [] })
  /** 分类列表 */
  const categories = ref([
    { id: 1, name: '热血', icon: '🔥', color: '#f5576c' },
    { id: 2, name: '恋爱', icon: '💕', color: '#f093fb' },
    { id: 3, name: '科幻', icon: '🚀', color: '#4facfe' },
    { id: 4, name: '奇幻', icon: '✨', color: '#a18cd1' },
    { id: 5, name: '日常', icon: '🌸', color: '#fbc2eb' },
    { id: 6, name: '悬疑', icon: '🔍', color: '#43e97b' },
    { id: 7, name: '搞笑', icon: '😂', color: '#f6d365' },
    { id: 8, name: '治愈', icon: '🌿', color: '#84fab0' },
    { id: 9, name: '战斗', icon: '⚔️', color: '#fa709a' },
    { id: 10, name: '校园', icon: '🏫', color: '#a1c4fd' },
    { id: 11, name: '冒险', icon: '🗺️', color: '#ffecd2' },
    { id: 12, name: '美食', icon: '🍜', color: '#ff9a9e' }
  ])
  /** 加载状态 */
  const loading = ref(false)

  // ===== 方法 =====
  /** 设置动漫列表 */
  function setAnimeList(list) {
    animeList.value = list
  }

  /** 追加动漫列表（分页加载） */
  function appendAnimeList(list) {
    animeList.value.push(...list)
  }

  /** 设置当前动漫详情 */
  function setCurrentAnime(anime) {
    currentAnime.value = anime
  }

  /** 设置排行榜 */
  function setRankings(type, data) {
    rankings.value[type] = data
  }

  return {
    animeList,
    currentAnime,
    rankings,
    categories,
    loading,
    setAnimeList,
    appendAnimeList,
    setCurrentAnime,
    setRankings
  }
})
