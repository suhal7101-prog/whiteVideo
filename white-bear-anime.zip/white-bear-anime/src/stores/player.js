/**
 * 播放器状态管理 (Pinia Store)
 *
 * 管理：播放历史、播放进度、清晰度偏好、弹幕开关状态
 * 本地持久化：播放进度通过 storage 工具保存
 */
import { defineStore } from 'pinia'
import { ref, computed } from 'vue'
import { progressStorage, historyStorage } from '@/utils/storage'

export const usePlayerStore = defineStore('player', () => {
  // ===== 状态 =====
  /** 当前播放的动漫ID */
  const currentAnimeId = ref(null)
  /** 当前播放的剧集ID */
  const currentEpisodeId = ref(null)
  /** 当前播放进度（秒） */
  const currentTime = ref(0)
  /** 视频总时长（秒） */
  const duration = ref(0)
  /** 当前选择的清晰度 */
  const quality = ref('1080P')
  /** 弹幕开关 */
  const danmakuEnabled = ref(true)
  /** 弹幕不透明度 */
  const danmakuOpacity = ref(0.8)
  /** 弹幕密度（1-10） */
  const danmakuDensity = ref(5)
  /** 可用的清晰度列表 */
  const availableQualities = ref(['360P', '480P', '720P', '1080P', '4K'])
  /** 播放速率 */
  const playbackRate = ref(1.0)

  // ===== 计算属性 =====
  /** 播放进度百分比 */
  const progressPercent = computed(() => {
    if (!duration.value) return 0
    return Math.round((currentTime.value / duration.value) * 100)
  })

  /** 是否已看完 */
  const isFinished = computed(() => progressPercent.value >= 95)

  // ===== 方法 =====
  /** 设置当前播放信息 */
  function setCurrentPlay(animeId, episodeId) {
    currentAnimeId.value = animeId
    currentEpisodeId.value = episodeId
    // 尝试恢复播放进度
    const saved = progressStorage.get(animeId)
    if (saved && saved.episodeId === episodeId) {
      currentTime.value = saved.currentTime || 0
      return saved.currentTime || 0
    }
    currentTime.value = 0
    return 0
  }

  /** 更新播放进度 */
  function updateProgress(time, dur) {
    currentTime.value = time
    duration.value = dur || duration.value
    // 每5秒保存一次进度
    if (currentAnimeId.value && currentEpisodeId.value) {
      progressStorage.save(currentAnimeId.value, currentEpisodeId.value, time, duration.value)
    }
  }

  /** 保存观看历史 */
  function saveHistory(animeInfo) {
    if (!currentAnimeId.value) return
    historyStorage.save({
      animeId: currentAnimeId.value,
      episodeId: currentEpisodeId.value,
      title: animeInfo?.title || '',
      cover: animeInfo?.cover || '',
      episodeTitle: animeInfo?.episodeTitle || '',
      progress: progressPercent.value,
      currentTime: currentTime.value,
      duration: duration.value
    })
  }

  /** 切换清晰度 */
  function switchQuality(q) {
    quality.value = q
  }

  /** 切换弹幕开关 */
  function toggleDanmaku() {
    danmakuEnabled.value = !danmakuEnabled.value
  }

  /** 设置弹幕不透明度 */
  function setDanmakuOpacity(opacity) {
    danmakuOpacity.value = Math.max(0.1, Math.min(1, opacity))
  }

  /** 设置弹幕密度 */
  function setDanmakuDensity(density) {
    danmakuDensity.value = Math.max(1, Math.min(10, density))
  }

  /** 设置播放速率 */
  function setPlaybackRate(rate) {
    playbackRate.value = rate
  }

  /** 重置播放器状态 */
  function reset() {
    currentAnimeId.value = null
    currentEpisodeId.value = null
    currentTime.value = 0
    duration.value = 0
  }

  return {
    currentAnimeId,
    currentEpisodeId,
    currentTime,
    duration,
    quality,
    danmakuEnabled,
    danmakuOpacity,
    danmakuDensity,
    availableQualities,
    playbackRate,
    progressPercent,
    isFinished,
    setCurrentPlay,
    updateProgress,
    saveHistory,
    switchQuality,
    toggleDanmaku,
    setDanmakuOpacity,
    setDanmakuDensity,
    setPlaybackRate,
    reset
  }
})
