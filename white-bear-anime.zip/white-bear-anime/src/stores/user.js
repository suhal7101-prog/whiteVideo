/**
 * 用户状态管理 (Pinia Store)
 *
 * 管理：登录状态、用户信息、Token
 * 注意：登录/注册页面不做改动，本 Store 供其他页面使用
 */
import { defineStore } from 'pinia'
import { ref, computed } from 'vue'
import { storage } from '@/utils/storage'

export const useUserStore = defineStore('user', () => {
  // ===== 状态 =====
  const token = ref(storage.get('token', ''))
  const userInfo = ref(storage.get('userInfo', null))
  const isLoggedIn = computed(() => !!token.value)

  // ===== 用户信息 =====
  /** 用户名 */
  const username = computed(() => userInfo.value?.username || '未登录')
  /** 邮箱 */
  const email = computed(() => userInfo.value?.email || '')
  /** 头像 */
  const avatar = computed(() => userInfo.value?.avatar || 'https://picsum.photos/seed/default-avatar/100')
  /** 角色：user / creator / admin */
  const role = computed(() => userInfo.value?.role || 'user')
  /** 是否为管理员 */
  const isAdmin = computed(() => role.value === 'admin')
  /** 是否为已申请成功的创作者 */
  const isCreator = computed(() => role.value === 'creator')
  /** 是否拥有投稿权限 */
  const canSubmit = computed(() => isAdmin.value || isCreator.value)

  // ===== 方法 =====
  /** 设置登录状态 */
  function setLogin(t, info) {
    token.value = t
    userInfo.value = info
    storage.set('token', t)
    storage.set('userInfo', info)
  }

  /** 退出登录 */
  function logout() {
    token.value = ''
    userInfo.value = null
    storage.remove('token')
    storage.remove('userInfo')
  }

  /** 更新用户信息 */
  function updateInfo(info) {
    userInfo.value = { ...userInfo.value, ...info }
    storage.set('userInfo', userInfo.value)
  }

  return {
    token,
    userInfo,
    isLoggedIn,
    username,
    email,
    avatar,
    role,
    isAdmin,
    isCreator,
    canSubmit,
    setLogin,
    logout,
    updateInfo
  }
})
