/**
 * 认证组合函数 —— 统一登录检查，未登录提示并跳转登录页
 *
 * 使用方式：
 *   import { useAuth } from '@/composables/useAuth'
 *   const { requireAuth } = useAuth()
 *
 *   function handleLike() {
 *     if (!requireAuth()) return
 *     // ... 执行点赞逻辑
 *   }
 */
import { useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import { useUserStore } from '@/stores/user'

export function useAuth() {
  const router = useRouter()
  const userStore = useUserStore()

  /**
   * 检查登录状态，未登录提示并跳转登录页
   * @returns {boolean} true=已登录, false=已跳转登录页
   */
  function requireAuth() {
    if (userStore.isLoggedIn) {
      return true
    }
    ElMessage.warning('请先登录')
    const currentPath = router.currentRoute.value.fullPath
    router.push({ name: 'Login', query: { redirect: currentPath } })
    return false
  }

  return { requireAuth }
}
