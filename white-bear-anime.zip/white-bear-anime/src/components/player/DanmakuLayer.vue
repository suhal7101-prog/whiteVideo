<!--
  弹幕层组件 —— 仿 Bilibili 弹幕效果
  功能：弹幕滚动显示、弹幕开关、不透明度调节、密度控制
  日后可扩展：彩色弹幕、顶部/底部弹幕、弹幕举报
-->
<template>
  <div
    ref="danmakuContainer"
    class="danmaku-container"
    :style="{ opacity: opacity }"
    v-show="enabled"
  >
    <!-- 弹幕轨道：每个轨道承载滚动弹幕 -->
    <div
      v-for="(track, idx) in tracks"
      :key="idx"
      class="danmaku-track"
      :style="{ top: idx * trackHeight + 'px', height: trackHeight + 'px' }"
    ></div>

    <!-- 弹幕消息提示 -->
    <div v-if="showTip" class="danmaku-tip" :key="tipKey">
      {{ currentTip }}
    </div>
  </div>
</template>

<script setup>
/**
 * 弹幕渲染引擎
 *
 * 原理：
 * 1. 将可视区域分为若干轨道
 * 2. 每条弹幕从右向左滚动，随机分配到空闲轨道
 * 3. 通过 CSS animation 实现滚动效果
 * 4. 弹幕密度控制每秒最多发送 N 条
 */
import { ref, watch, onMounted, onUnmounted, nextTick, computed } from 'vue'

const props = defineProps({
  /** 弹幕是否启用 */
  enabled: { type: Boolean, default: true },
  /** 弹幕不透明度 (0.1 - 1.0) */
  opacity: { type: Number, default: 0.8 },
  /** 弹幕密度 (1-10)，对应每秒最大弹幕数 */
  density: { type: Number, default: 5 },
  /** 弹幕数据列表 */
  danmakuList: { type: Array, default: () => [] },
  /** 轨道高度（px） */
  trackHeight: { type: Number, default: 36 },
  /** 弹幕字体大小（px） */
  fontSize: { type: Number, default: 16 }
})

const emit = defineEmits(['send'])

// ===== DOM 引用 =====
const danmakuContainer = ref(null)

// ===== 响应式状态 =====
const tracks = ref([])            // 轨道数组
const tipKey = ref(0)             // 提示动画的 key
const showTip = ref(false)        // 是否显示发送提示
const currentTip = ref('')        // 当前提示内容

// ===== 轨道计算 =====
const containerHeight = ref(360)

/** 计算轨道数量 */
const trackCount = computed(() => {
  if (!containerHeight.value || !props.trackHeight) return 8
  return Math.max(4, Math.floor(containerHeight.value / props.trackHeight))
})

/** 轨道占用状态（true = 空闲，false = 被占用） */
const trackBusy = ref([])

// ===== 弹幕队列 =====
let danmakuQueue = []
let animationTimer = null

/**
 * 初始化轨道
 */
function initTracks() {
  const count = trackCount.value
  tracks.value = Array.from({ length: count }, () => ({}))
  trackBusy.value = Array.from({ length: count }, () => true)
}

/**
 * 获取一条空闲轨道索引
 * @returns {number} 轨道索引，-1 表示全部繁忙
 */
function getFreeTrack() {
  const freeIndices = trackBusy.value
    .map((busy, idx) => (busy ? idx : -1))
    .filter(idx => idx >= 0)
  if (freeIndices.length === 0) return -1
  // 随机选择一条空闲轨道
  return freeIndices[Math.floor(Math.random() * freeIndices.length)]
}

/**
 * 创建并发射一条弹幕元素
 * @param {Object} dm - 弹幕数据 { text, color, type }
 */
function createDanmakuElement(dm) {
  if (!danmakuContainer.value) return

  const trackIdx = getFreeTrack()
  if (trackIdx < 0) return // 所有轨道都在忙，丢弃此弹幕

  // 标记轨道为繁忙
  trackBusy.value[trackIdx] = false

  // 创建弹幕 DOM 元素
  const el = document.createElement('div')
  el.className = 'danmaku-item'
  el.textContent = dm.text
  el.style.cssText = `
    position: absolute;
    top: ${trackIdx * props.trackHeight}px;
    right: -100%;
    font-size: ${dm.fontSize || props.fontSize}px;
    color: ${dm.color || '#ffffff'};
    white-space: nowrap;
    text-shadow: 1px 0 2px rgba(0,0,0,0.7), 0 1px 2px rgba(0,0,0,0.7);
    font-weight: ${dm.bold ? '700' : '400'};
    pointer-events: none;
    z-index: 5;
    line-height: ${props.trackHeight}px;
    animation: danmaku-scroll ${dm.duration || 8}s linear forwards;
    will-change: transform;
  `

  danmakuContainer.value.appendChild(el)

  // 动画结束后清理
  el.addEventListener('animationend', () => {
    el.remove()
    // 释放轨道
    trackBusy.value[trackIdx] = true
  })
}

/**
 * 处理弹幕队列：按密度限制速率发射
 */
function processQueue() {
  if (animationTimer) clearInterval(animationTimer)

  // 根据密度计算发射间隔（ms）
  const interval = Math.max(80, 1000 / props.density)
  let index = 0

  animationTimer = setInterval(() => {
    if (!props.enabled) return

    // 从队列中取出一条弹幕
    if (danmakuQueue.length > 0) {
      const dm = danmakuQueue.shift()
      createDanmakuElement(dm)
    }

    // 如果队列清空且没有定时输入，停止处理
    if (danmakuQueue.length === 0 && index > 10) {
      clearInterval(animationTimer)
      animationTimer = null
    }
    index++
  }, interval)
}

/**
 * 发送一条弹幕（用户输入）
 * @param {string} text - 弹幕内容
 */
function sendDanmaku(text) {
  if (!text || !text.trim()) return
  const dm = {
    text: text.trim(),
    color: getRandomColor(),
    duration: 6 + Math.random() * 3,
    fontSize: props.fontSize
  }
  danmakuQueue.push(dm)
  if (!animationTimer) processQueue()

  // 显示发送提示
  currentTip.value = text.trim()
  showTip.value = true
  tipKey.value++
  setTimeout(() => { showTip.value = false }, 2000)

  emit('send', dm)
}

/**
 * 生成随机弹幕颜色（浅色系，在深色背景上可见）
 */
function getRandomColor() {
  const colors = [
    '#ffffff', '#ffcc00', '#66ccff', '#ff6666',
    '#66ff99', '#ff99cc', '#99ccff', '#ffcc99',
    '#99ffcc', '#cc99ff'
  ]
  return colors[Math.floor(Math.random() * colors.length)]
}

// ===== 监听弹幕列表变化 =====
watch(() => props.danmakuList, (newList) => {
  if (newList && newList.length > 0) {
    danmakuQueue.push(...newList)
    if (!animationTimer) processQueue()
  }
}, { deep: true })

// ===== 监听容器高度 =====
onMounted(() => {
  nextTick(() => {
    if (danmakuContainer.value) {
      containerHeight.value = danmakuContainer.value.clientHeight || 360
      initTracks()
    }
  })

  // 窗口大小变化时重新计算
  const resizeObserver = new ResizeObserver(() => {
    if (danmakuContainer.value) {
      containerHeight.value = danmakuContainer.value.clientHeight || 360
      initTracks()
    }
  })
  if (danmakuContainer.value) {
    resizeObserver.observe(danmakuContainer.value)
  }

  onUnmounted(() => {
    resizeObserver.disconnect()
    if (animationTimer) clearInterval(animationTimer)
  })
})

// 暴露方法给父组件
defineExpose({ sendDanmaku })
</script>

<style scoped>
/* ===== 弹幕容器 ===== */
.danmaku-container {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  overflow: hidden;
  pointer-events: none;
  z-index: 20;
}

/* ===== 弹幕轨道 ===== */
.danmaku-track {
  position: absolute;
  left: 0;
  width: 100%;
  pointer-events: none;
}

/* ===== 弹幕滚动动画 ===== */
@keyframes danmaku-scroll {
  0% {
    transform: translateX(0);
  }
  100% {
    transform: translateX(calc(-100vw - 100%));
  }
}

/* ===== 弹幕发送提示 ===== */
.danmaku-tip {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  background: rgba(0, 0, 0, 0.7);
  color: #fff;
  padding: 8px 24px;
  border-radius: 24px;
  font-size: 14px;
  z-index: 25;
  pointer-events: none;
  animation: tip-fade 2s ease forwards;
}

@keyframes tip-fade {
  0% { opacity: 0; transform: translate(-50%, -50%) scale(0.8); }
  10% { opacity: 1; transform: translate(-50%, -50%) scale(1); }
  80% { opacity: 1; transform: translate(-50%, -50%) scale(1); }
  100% { opacity: 0; transform: translate(-50%, -60%) scale(0.9); }
}
</style>
