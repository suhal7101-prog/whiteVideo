<!--
  BiliPlayer v3.0 — 沉浸式播放器
  设计原则 (Agentic AI & Generative UX):
  - Outcome-Oriented: 聚焦观看体验，控件按需出现
  - Progressive Disclosure: 悬浮显示控件，离开隐藏
  - Trust Calibration: 缓冲/错误状态可视化
  - Generative UI: 控件根据上下文自适应 (播放/暂停/结束)
-->
<template>
  <div
    class="bp"
    ref="wrapRef"
    @mouseenter="ui.show = true"
    @mouseleave="ui.show = false"
    @mousemove="onMove"
  >
    <!-- 视频核心 -->
    <div class="bp-video" ref="vidRef" @click="togglePlay">
      <video
        ref="vRef"
        class="video-js"
        crossorigin="anonymous"
        playsinline webkit-playsinline
        :poster="poster"
      ></video>

      <!-- 弹幕 -->
      <DanmakuLayer ref="dmRef" :enabled="dm.on" :opacity="dm.opacity" :density="dm.density" :danmakuList="dmPool" />

      <!-- 自定义加载动画 (仅首次加载时覆盖视频上方) -->
      <div class="bp-loader-overlay" v-if="ui.loading">
        <LoaderSpin path="rgba(255,255,255,0.2)" dot="#7c5ce7" duration="2.5s" />
        <p class="bp-loader-text">正在缓冲…</p>
      </div>

      <AdvertisementSlot
        v-if="pauseAdVisible"
        position="player_pause"
        variant="overlay"
        @click.stop
        @close="pauseAdVisible = false"
      />

      <!-- 中央播放按钮 (仅用户主动暂停时显示) -->
      <div class="bp-big-btn" v-if="ui.show && !ui.playing && !ui.loading && ui.everPlayed && !pauseAdVisible" @click.stop="togglePlay">
        <svg viewBox="0 0 24 24" fill="white" width="64" height="64"><path d="M8 5v14l11-7z"/></svg>
      </div>


      <!-- 悬浮控件层 -->
      <div class="bp-ctrl" :class="{ visible: ui.show }">

        <!-- 顶部 -->
        <div class="bp-top">
          <span class="bp-top-title">{{ title }}</span>
        </div>

        <!-- 底部 -->
        <div class="bp-bot">
          <!-- 进度条 (hover 预览时间) -->
          <div class="bp-bar" ref="barRef"
            @click="seekBar"
            @mousemove="onBarHover"
            @mouseleave="hoverTime = null"
          >
            <div class="bp-bar-track">
              <div class="bp-bar-loaded" :style="{ width: ui.buffered + '%' }"></div>
              <div class="bp-bar-played" :style="{ width: ui.percent + '%' }"></div>
              <div
                class="bp-bar-thumb"
                :class="{ 'bp-bar-thumb--active': dragging }"
                :style="{ left: ui.percent + '%' }"
                @mousedown.stop="startDrag"
                @touchstart.prevent.stop="startDrag"
              ></div>
            </div>
            <!-- 悬浮时间气泡 -->
            <div class="bp-bar-bubble" v-if="hoverTime && !dragging" :style="{ left: hoverX + '%' }">
              {{ fmt(hoverTime) }}
            </div>
          </div>

          <!-- 操作行 -->
          <div class="bp-row">
            <div class="bp-row-l">
              <button class="bp-btn-icon" @click.stop="togglePlay" :aria-label="ui.playing ? '暂停' : '播放'">
                <svg v-if="ui.playing" viewBox="0 0 24 24" fill="currentColor" width="22" height="22"><path d="M6 19h4V5H6v14zm8-14v14h4V5h-4z"/></svg>
                <svg v-else viewBox="0 0 24 24" fill="currentColor" width="22" height="22"><path d="M8 5v14l11-7z"/></svg>
              </button>
              <button class="bp-btn-icon" @click.stop="$emit('next')" aria-label="下一集">
                <svg viewBox="0 0 24 24" fill="currentColor" width="20" height="20"><path d="M6 18l8.5-6L6 6v12zM16 6v12h2V6h-2z"/></svg>
              </button>
              <span class="bp-time-text">{{ fmt(ui.current) }} / {{ fmt(ui.duration) }}</span>
              <span class="bp-tag" @click.stop="cycleSpeed">倍速 {{ speed }}x</span>
            </div>
            <div class="bp-row-r">
              <button class="bp-btn-icon" v-if="pipSupported" @click.stop="togglePIP" aria-label="画中画">
                <svg viewBox="0 0 24 24" fill="currentColor" width="20" height="20"><path d="M19 7h-8v6h8V7zm2-4H3c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h18c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 16.01H3V4.99h18v14.02z"/></svg>
              </button>
              <button class="bp-btn-icon" @click.stop="toggleFullscreen" aria-label="全屏">
                <svg viewBox="0 0 24 24" fill="currentColor" width="20" height="20"><path d="M7 14H5v5h5v-2H7v-3zm-2-4h2V7h3V5H5v5zm12 7h-3v2h5v-5h-2v3zM14 5v2h3v3h2V5h-5z"/></svg>
              </button>
            </div>
          </div>

        </div>
      </div>

    </div>
  </div>
</template>

<script setup>
import { ref, reactive, computed, watch, onMounted, onUnmounted } from 'vue'
import { ElMessage } from 'element-plus'
import videojs from 'video.js'
import '@videojs/http-streaming'
import 'video.js/dist/video-js.css'
import DanmakuLayer from './DanmakuLayer.vue'
import LoaderSpin from '@/components/common/LoaderSpin.vue'
import AdvertisementSlot from '@/components/common/AdvertisementSlot.vue'
import { communityApi } from '@/api/modules/community'
import { usePlayerStore } from '@/stores/player'

const props = defineProps({
  sources: { type: Array, default: () => [] },
  poster: { type: String, default: '' },
  animeId: { type: [Number,String], default: null },
  episodeId: { type: [Number,String], default: null },
  title: { type: String, default: '' },
})
const emit = defineEmits(['ended','danmakuSent','next'])

const store = usePlayerStore()
const wrapRef = ref(null)
const vidRef = ref(null)
const vRef = ref(null)
const barRef = ref(null)
const dmRef = ref(null)
let player = null

const ui = reactive({
  show: false, playing: false, paused: true,
  loading: false, everPlayed: false, error: false,
  current: 0, duration: 0, percent: 0, buffered: 0,
})
const dm = reactive({ on: true, text: '', opacity: 0.8, density: 5 })
const hoverTime = ref(null)
const hoverX = ref(0)
const speed = ref(1)
const dmPool = ref([])
const pipSupported = ref(false)
const pauseAdVisible = ref(false)

const speeds = [0.5, 0.75, 1, 1.25, 1.5, 2]

function fmt(s) { if (!s||!isFinite(s)) return '0:00'; const m=Math.floor(s/60), sec=Math.floor(s%60); return `${m}:${String(sec).padStart(2,'0')}` }

// ===== 自定义加载动画 + 超时保护 =====
let _loadTimer = null
let _loadShowTime = 0
let _seeking = false   // 是否由用户拖动进度条触发的 seek

function _showLoader() {
  ui.loading = true
  _loadShowTime = Date.now()
  _loadTimer = setTimeout(() => {
    if (ui.loading && !ui.playing) {
      _hideLoader()
    }
  }, 10000)
}

function _hideLoader() {
  // 最小显示 300ms，避免闪烁
  const elapsed = Date.now() - _loadShowTime
  if (elapsed < 300) {
    setTimeout(_hideLoader, 300 - elapsed)
    return
  }
  ui.loading = false
  if (_loadTimer) { clearTimeout(_loadTimer); _loadTimer = null }

  // 拖动进度条后缓冲完毕 → 自动播放
  if (_seeking && player && !player.paused()) {
    // 已在播放中，清标记
  } else if (_seeking && player) {
    _seeking = false
    const p = player.play()
    if (p) p.catch(() => {})
  }
}

// ===== 播放控制 =====
function togglePlay() {
  if (!player) return
  const p = player.paused() ? player.play() : player.pause()
  if (p) p.catch(() => {})
}

let _retryIdx = 0
function retry() {
  ui.error = false
  if (!player || !props.sources?.length) return
  const srcs = props.sources
  const idx = _retryIdx % srcs.length
  _retryIdx++
  _showLoader()
  loadSource([srcs[idx]])
  player.one('canplay', () => {
    _retryIdx = 0
    player.muted(true)
    const playPromise = player.play()
    if (playPromise) {
      playPromise.then(() => { player.muted(false) }).catch(() => {})
    }
  })
}

// ===== 时间更新 (Video.js 事件驱动) =====
function onTick() {
  if (!player) return
  ui.current = player.currentTime() || 0
  ui.duration = player.duration() || 0
  ui.percent = ui.duration ? (ui.current / ui.duration) * 100 : 0
  // Video.js 8.x: bufferedPercent() 返回 0-1
  const bp = player.bufferedPercent() || 0
  ui.buffered = bp <= 1 ? bp * 100 : bp
}
function onMeta() {
  ui.duration = player?.duration() || 0
}
function onEnd() { ui.playing = false; ui.paused = true; pauseAdVisible.value = false; emit('ended') }

// ===== 进度条 (鼠标 + 触屏) =====
let dragging = false

function _getPct(e) {
  if (!barRef.value) return 0
  const rect = barRef.value.getBoundingClientRect()
  const clientX = e.touches ? e.touches[0].clientX : e.clientX
  return Math.max(0, Math.min(1, (clientX - rect.left) / rect.width))
}

function startDrag(e) {
  e.preventDefault()
  dragging = true
  document.addEventListener('mousemove', onDrag)
  document.addEventListener('mouseup', stopDrag)
  document.addEventListener('touchmove', onDrag, { passive: false })
  document.addEventListener('touchend', stopDrag)
}

function onDrag(e) {
  if (!dragging || !player) return
  e.preventDefault()
  const pct = _getPct(e)
  ui.percent = pct * 100
  ui.current = pct * ui.duration
}

function stopDrag(e) {
  if (!dragging || !player) return
  dragging = false
  document.removeEventListener('mousemove', onDrag)
  document.removeEventListener('mouseup', stopDrag)
  document.removeEventListener('touchmove', onDrag)
  document.removeEventListener('touchend', stopDrag)
  const pct = _getPct(e)
  player.currentTime(pct * ui.duration)
}

function seekBar(e) {
  if (!player) return
  const pct = _getPct(e)
  player.currentTime(pct * ui.duration)
}

function onBarHover(e) {
  if (!barRef.value || dragging) return
  const rect = barRef.value.getBoundingClientRect()
  const clientX = e.touches ? e.touches[0].clientX : e.clientX
  hoverX.value = ((clientX - rect.left) / rect.width) * 100
  hoverTime.value = (hoverX.value / 100) * ui.duration
}

// ===== 倍速 =====
function cycleSpeed() {
  if (!player) return
  const i = (speeds.indexOf(speed.value) + 1) % speeds.length
  speed.value = speeds[i]
  player.playbackRate(speed.value)
  store.setPlaybackRate(speed.value)
  ElMessage({ message: `${speed.value}x 倍速`, duration: 1000, showClose: false, customClass: 'bp-toast' })
}

// ===== 弹幕 =====
async function sendDm() {
  const t = dm.text.trim()
  if (!t || !dmRef.value) return
  dmRef.value.sendDanmaku(t)
  emit('danmakuSent', { text: t })
  dm.text = ''
  try {
    await communityApi.sendDanmaku({
      animeId: props.animeId,
      episodeId: props.episodeId,
      content: t,
      timestamp: ui.current || 0,
      color: '#FFFFFF',
      type: 'scroll'
    })
  } catch (error) {
    console.warn('[BiliPlayer] 弹幕保存失败:', error.message)
  }
}

async function loadDanmaku() {
  if (!props.animeId) {
    dmPool.value = []
    return
  }
  try {
    const result = await communityApi.getDanmaku(props.animeId, props.episodeId)
    dmPool.value = (result?.list || []).map(item => ({
      id: item.id,
      text: item.content,
      color: item.color || '#FFFFFF',
      timestamp: item.timestamp || 0,
      duration: 8
    }))
  } catch (error) {
    console.warn('[BiliPlayer] 弹幕加载失败:', error.message)
    dmPool.value = []
  }
}

// ===== 全屏 / 画中画 =====
function toggleFullscreen() {
  if (document.fullscreenElement) document.exitFullscreen()
  else wrapRef.value?.requestFullscreen()
}

async function togglePIP() {
  try {
    if (document.pictureInPictureElement) {
      await document.exitPictureInPicture()
      return
    }
    const videoEl = player?.tech()?.el() || vRef.value
    if (!videoEl || typeof videoEl.requestPictureInPicture !== 'function') return

    if ('mediaSession' in navigator) {
      try {
        navigator.mediaSession.metadata = new MediaMetadata({
          title: props.title || '白熊动漫',
          artist: '',
        })
      } catch {}
    }

    await videoEl.requestPictureInPicture()
  } catch (e) {
    ElMessage({ message: '画中画不可用', type: 'warning', duration: 1500 })
  }
}

// ===== 键盘 =====
function onKey(e) {
  if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return
  if (!player) return
  switch (e.key) {
    case ' ': e.preventDefault(); togglePlay(); break
    case 'ArrowLeft': player.currentTime(Math.max(0, player.currentTime() - 5)); break
    case 'ArrowRight': player.currentTime(Math.min(ui.duration, player.currentTime() + 5)); break
    case 'ArrowUp': player.volume(Math.min(1, player.volume() + 0.1)); break
    case 'ArrowDown': player.volume(Math.max(0, player.volume() - 0.1)); break
    case 'm': player.muted(!player.muted()); break
    case 'f': toggleFullscreen(); break
  }
}

// ===== 鼠标移动计时 (3s后隐藏控件) =====
let hideTimer = null
function onMove() {
  ui.show = true
  if (hideTimer) clearTimeout(hideTimer)
  if (ui.playing) hideTimer = setTimeout(() => { ui.show = false }, 3000)
}

// ===== 源切换处理 (必须放在 onMounted 外面) =====
function loadSource(srcs) {
  if (!player || !srcs?.length) return
  _retryIdx = 0
  _seeking = false
  const src = srcs[0]
  ui.error = false
  ui.everPlayed = false
  _showLoader()

  player.reset()
  player.src({ type: src.type || 'application/x-mpegURL', src: src.url || '' })
  player.load()

  // 缓冲完成后自动播放 (muted 绕过浏览器 autoplay 限制)
  player.one('canplay', () => {
    player.muted(true)
    const playPromise = player.play()
    if (playPromise) {
      playPromise.then(() => { player.muted(false) }).catch(() => {})
    }
  })
}

watch(() => props.sources, (srcs) => {
  loadSource(srcs)
}, { deep: true })

watch(() => [props.animeId, props.episodeId], loadDanmaku)

// ===== 初始化 =====
onMounted(() => {
  pipSupported.value = document.pictureInPictureEnabled || false
  window.addEventListener('keydown', onKey)
  loadDanmaku()

  if (vRef.value) {
    player = videojs(vRef.value, {
      controls: false, autoplay: false, preload: 'auto', fluid: true,
      playbackRates: speeds, language: 'zh-CN',
      html5: {
        vhs: { overrideNative: true },
        nativeVideoTracks: false,
        nativeAudioTracks: false,
        nativeTextTracks: false,
      }
    })

    // ===== Video.js 事件 =====
    player.on('timeupdate', onTick)
    player.on('loadedmetadata', onMeta)
    player.on('durationchange', onMeta)
    player.on('play', () => { ui.playing = true; ui.paused = false; ui.everPlayed = true; pauseAdVisible.value = false })
    player.on('pause', () => {
      ui.playing = false
      ui.paused = true
      if (ui.everPlayed) pauseAdVisible.value = true
    })
    player.on('ended', onEnd)

    // 自定义加载动画: 显示
    player.on('loadstart', () => { _showLoader() })
    player.on('waiting',   () => { ui.playing = false; _showLoader() })
    player.on('seeking',   () => { _seeking = true; _showLoader() })

    // 自定义加载动画: 隐藏
    player.on('playing', () => { _seeking = false; ui.playing = true;  _hideLoader() })
    player.on('canplay', () => { _hideLoader() })
    player.on('seeked',  () => { _hideLoader() })

    // 错误处理
    player.on('error', () => { _loadShowTime = 0; _hideLoader() })

    // 如果初始化时已有 sources，加载
    if (props.sources?.length) {
      loadSource(props.sources)
    }
  }
})

onUnmounted(() => {
  _hideLoader()
  window.removeEventListener('keydown', onKey)
  if (player) { player.dispose(); player = null }
})
</script>

<style scoped>
/* ================================================================
   BiliPlayer v3.0 — Immersive
   ================================================================ */
.bp { position: relative; width: 100%; background: #000; border-radius: 10px; overflow: hidden; }
.bp-video { position: relative; width: 100%; aspect-ratio: 16/9; background: #000; cursor: pointer; }
.bp-video :deep(.video-js) { width: 100%; height: 100%; display: block; }

/* ===== 禁用 Video.js 默认 loading spinner ===== */
.bp-video :deep(.vjs-loading-spinner) {
  display: none !important;
}

/* ===== 自定义加载动画 ===== */
.bp-loader-overlay {
  position: absolute; inset: 0; z-index: 6;
  display: flex; flex-direction: column;
  align-items: center; justify-content: center; gap: 12px;
  background: rgba(0,0,0,.35);
  pointer-events: none;
}
.bp-loader-text {
  color: rgba(255,255,255,.6);
  font-size: 13px;
  margin: 0;
}

/* 大播放按钮 */
.bp-big-btn {
  position: absolute; inset: 0; z-index: 5;
  display: flex; align-items: center; justify-content: center;
  pointer-events: none;
}
.bp-big-btn svg { filter: drop-shadow(0 2px 12px rgba(0,0,0,.5)); }

/* 控件层 */
.bp-ctrl {
  position: absolute; inset: 0; z-index: 10;
  display: flex; flex-direction: column; justify-content: space-between;
  opacity: 0; transition: opacity .25s ease;
  pointer-events: none;
}
.bp-ctrl.visible { opacity: 1; pointer-events: auto; }

/* 顶部 */
.bp-top {
  display: flex; align-items: center; gap: 16px;
  padding: 14px 16px;
  background: linear-gradient(180deg, rgba(0,0,0,.55) 0%, transparent 100%);
}
.bp-top-title { font-size: 13px; color: #fff; text-shadow: 0 1px 3px rgba(0,0,0,.7); flex: 1; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.bp-top-time  { font-size: 12px; color: rgba(255,255,255,.7); font-variant-numeric: tabular-nums; flex-shrink: 0; }

/* 底部 */
.bp-bot {
  padding: 0 12px 10px;
  background: linear-gradient(0deg, rgba(0,0,0,.6) 0%, transparent 100%);
}

/* 进度条 */
.bp-bar { padding: 8px 0; cursor: pointer; position: relative; }
.bp-bar-track { position: relative; height: 4px; border-radius: 2px; background: rgba(255,255,255,.2); }
.bp-bar-loaded { position: absolute; left: 0; top: 0; height: 100%; border-radius: 2px; background: rgba(255,255,255,.3); }
.bp-bar-played { position: absolute; left: 0; top: 0; height: 100%; border-radius: 2px; background: var(--ds-accent, #7c5ce7); }
.bp-bar:hover .bp-bar-track { height: 6px; }
.bp-bar:hover .bp-bar-played { background: var(--ds-accent-hover, #9475f0); }
.bp-bar-thumb {
  display: none; position: absolute; top: 50%; transform: translate(-50%,-50%);
  width: 14px; height: 14px; border-radius: 50%; background: #fff;
  box-shadow: 0 1px 4px rgba(0,0,0,.4); z-index: 2;
}
.bp-bar:hover .bp-bar-thumb,
.bp-bar-thumb--active { display: block; }

/* 悬浮时间气泡 */
.bp-bar-bubble {
  position: absolute; top: -28px; transform: translateX(-50%);
  background: rgba(0,0,0,.85); color: #fff; padding: 2px 8px;
  border-radius: 4px; font-size: 11px; white-space: nowrap;
  pointer-events: none; z-index: 5;
}

/* 操作行 */
.bp-row     { display: flex; justify-content: space-between; align-items: center; padding: 4px 0; }
.bp-row-l,
.bp-row-r   { display: flex; align-items: center; gap: 8px; }

.bp-btn-icon {
  display: flex; align-items: center; justify-content: center;
  width: 32px; height: 32px; border: none; border-radius: 4px;
  background: transparent; color: #fff; cursor: pointer;
  transition: background .15s;
}
.bp-btn-icon:hover { background: rgba(255,255,255,.1); }

.bp-time-text {
  font-size: 12px; color: rgba(255,255,255,.8);
  font-variant-numeric: tabular-nums; white-space: nowrap;
  user-select: none;
}

.bp-tag {
  font-size: 12px; color: rgba(255,255,255,.7); padding: 3px 10px;
  border-radius: 4px; cursor: pointer; transition: all .15s;
}
.bp-tag:hover { color: #fff; background: rgba(255,255,255,.1); }

/* 弹幕行 */
.bp-dm-row { display: flex; gap: 8px; padding: 4px 0; }
.bp-dm-inp  {
  flex: 1; padding: 6px 14px; border-radius: 18px; border: 1px solid rgba(255,255,255,.15);
  background: rgba(255,255,255,.06); color: #fff; font-size: 12px; outline: none;
  transition: border-color .2s;
}
.bp-dm-inp::placeholder { color: rgba(255,255,255,.4); }
.bp-dm-inp:focus { border-color: rgba(255,255,255,.35); }
.bp-dm-send {
  padding: 5px 16px; border-radius: 16px; border: none;
  background: rgba(255,255,255,.12); color: #fff; font-size: 12px;
  cursor: pointer; transition: background .15s; flex-shrink: 0;
}
.bp-dm-send:hover:not(:disabled) { background: rgba(255,255,255,.25); }
.bp-dm-send:disabled { opacity: .35; cursor: default; }

/* 响应式 */
@media (max-width: 768px) {
  .bp-bot { padding: 0 8px 6px; }
  .bp-top { padding: 10px 12px; }
  .bp-tag { font-size: 11px; padding: 2px 8px; }
  .bp-btn-icon { width: 28px; height: 28px; }
  .bp-dm-row { display: none; }
}
</style>

<style>
/* 倍速 toast (unscoped — ElMessage 挂载在 body) */
.bp-toast {
  background: rgba(0,0,0,.82) !important;
  border: none !important;
  color: #fff !important;
  padding: 6px 16px !important;
  border-radius: 20px !important;
  font-size: 13px !important;
  min-width: auto !important;
}
.bp-toast .el-message__icon { display: none; }
</style>
