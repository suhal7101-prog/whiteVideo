<!--
  页面顶部标题栏组件
  用于各二级页面顶部
-->
<template>
  <div class="page-header" :style="{ background: bgGradient }">
    <div class="page-header-content">
      <h1 class="page-title">
        <span class="page-icon" v-if="icon">{{ icon }}</span>
        {{ title }}
      </h1>
      <p class="page-desc" v-if="desc">{{ desc }}</p>
      <slot name="extra" />
    </div>
  </div>
</template>

<script setup>
defineProps({
  title: { type: String, required: true },
  icon: { type: String, default: '' },
  desc: { type: String, default: '' },
  bgGradient: {
    type: String,
    default: 'var(--ds-gradient-brand, linear-gradient(135deg, #7c5ce7 0%, #a855f7 100%))'
  }
})
</script>

<style scoped>
.page-header {
  padding: 40px 0;
  color: #fff;
  border-radius: 0 0 24px 24px;
  margin-bottom: 24px;
}
.page-header-content {
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 20px;
}
.page-title {
  font-size: 28px;
  font-weight: 700;
  margin: 0 0 8px;
  display: flex;
  align-items: center;
  gap: 10px;
}
.page-icon { font-size: 32px; }
.page-desc {
  font-size: 15px;
  opacity: 0.9;
  margin: 0;
  line-height: 1.6;
}
@media (max-width: 768px) {
  .page-header { padding: 24px 0; border-radius: 0 0 16px 16px; }
  .page-title { font-size: 22px; }
  .page-desc { font-size: 13px; }
}
</style>
