<template>
  <div class="relative" style="width: 550px; height: 400px;">
    <div
      ref="purpleRef"
      class="absolute bottom-0 transition-all duration-700 ease-in-out"
      :style="purpleStyle"
    >
      <div
        class="absolute flex gap-8 transition-all duration-700 ease-in-out"
        :style="purpleEyesStyle"
      >
        <EyeBall
          :size="18"
          :pupilSize="7"
          :maxDistance="5"
          eyeColor="white"
          pupilColor="#2D2D2D"
          :isBlinking="isPurpleBlinking"
          :forceLookX="purpleForceLookX"
          :forceLookY="purpleForceLookY"
        />
        <EyeBall
          :size="18"
          :pupilSize="7"
          :maxDistance="5"
          eyeColor="white"
          pupilColor="#2D2D2D"
          :isBlinking="isPurpleBlinking"
          :forceLookX="purpleForceLookX"
          :forceLookY="purpleForceLookY"
        />
      </div>
    </div>

    <div
      ref="blackRef"
      class="absolute bottom-0 transition-all duration-700 ease-in-out"
      :style="blackStyle"
    >
      <div
        class="absolute flex gap-6 transition-all duration-700 ease-in-out"
        :style="blackEyesStyle"
      >
        <EyeBall
          :size="16"
          :pupilSize="6"
          :maxDistance="4"
          eyeColor="white"
          pupilColor="#2D2D2D"
          :isBlinking="isBlackBlinking"
          :forceLookX="blackForceLookX"
          :forceLookY="blackForceLookY"
        />
        <EyeBall
          :size="16"
          :pupilSize="6"
          :maxDistance="4"
          eyeColor="white"
          pupilColor="#2D2D2D"
          :isBlinking="isBlackBlinking"
          :forceLookX="blackForceLookX"
          :forceLookY="blackForceLookY"
        />
      </div>
    </div>

    <div
      ref="orangeRef"
      class="absolute bottom-0 transition-all duration-700 ease-in-out"
      :style="orangeStyle"
    >
      <div
        class="absolute flex gap-8 transition-all duration-200 ease-out"
        :style="orangeEyesStyle"
      >
        <Pupil :size="12" :maxDistance="5" pupilColor="#2D2D2D" :forceLookX="orangeForceLookX" :forceLookY="orangeForceLookY" />
        <Pupil :size="12" :maxDistance="5" pupilColor="#2D2D2D" :forceLookX="orangeForceLookX" :forceLookY="orangeForceLookY" />
      </div>
    </div>

    <div
      ref="yellowRef"
      class="absolute bottom-0 transition-all duration-700 ease-in-out"
      :style="yellowStyle"
    >
      <div
        class="absolute flex gap-6 transition-all duration-200 ease-out"
        :style="yellowEyesStyle"
      >
        <Pupil :size="12" :maxDistance="5" pupilColor="#2D2D2D" :forceLookX="yellowForceLookX" :forceLookY="yellowForceLookY" />
        <Pupil :size="12" :maxDistance="5" pupilColor="#2D2D2D" :forceLookX="yellowForceLookX" :forceLookY="yellowForceLookY" />
      </div>
      <div
        class="absolute w-20 h-[4px] bg-[#2D2D2D] rounded-full transition-all duration-200 ease-out"
        :style="yellowMouthStyle"
      />
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted, onUnmounted, watch } from 'vue'
import EyeBall from './EyeBall.vue'
import Pupil from './Pupil.vue'

const props = defineProps({
  isTyping: {
    type: Boolean,
    default: false
  },
  showPassword: {
    type: Boolean,
    default: false
  },
  passwordLength: {
    type: Number,
    default: 0
  }
})

const mouseX = ref(0)
const mouseY = ref(0)
const isPurpleBlinking = ref(false)
const isBlackBlinking = ref(false)
const isLookingAtEachOther = ref(false)
const isPurplePeeking = ref(false)

const purpleRef = ref(null)
const blackRef = ref(null)
const yellowRef = ref(null)
const orangeRef = ref(null)

let purpleBlinkTimeout = null
let blackBlinkTimeout = null
let typingTimer = null
let peekTimeout = null

const handleMouseMove = (e) => {
  mouseX.value = e.clientX
  mouseY.value = e.clientY
}

const getRandomBlinkInterval = () => Math.random() * 4000 + 3000

const schedulePurpleBlink = () => {
  if (purpleBlinkTimeout) clearTimeout(purpleBlinkTimeout)
  purpleBlinkTimeout = setTimeout(() => {
    isPurpleBlinking.value = true
    setTimeout(() => {
      isPurpleBlinking.value = false
      schedulePurpleBlink()
    }, 150)
  }, getRandomBlinkInterval())
}

const scheduleBlackBlink = () => {
  if (blackBlinkTimeout) clearTimeout(blackBlinkTimeout)
  blackBlinkTimeout = setTimeout(() => {
    isBlackBlinking.value = true
    setTimeout(() => {
      isBlackBlinking.value = false
      scheduleBlackBlink()
    }, 150)
  }, getRandomBlinkInterval())
}

const schedulePeek = () => {
  if (peekTimeout) clearTimeout(peekTimeout)
  peekTimeout = setTimeout(() => {
    isPurplePeeking.value = true
    setTimeout(() => {
      isPurplePeeking.value = false
    }, 800)
  }, Math.random() * 3000 + 2000)
}

watch(() => props.isTyping, (newVal) => {
  if (newVal) {
    isLookingAtEachOther.value = true
    if (typingTimer) clearTimeout(typingTimer)
    typingTimer = setTimeout(() => {
      isLookingAtEachOther.value = false
    }, 800)
  } else {
    isLookingAtEachOther.value = false
    if (typingTimer) clearTimeout(typingTimer)
  }
})

watch([() => props.passwordLength, () => props.showPassword, isPurplePeeking], ([len, show, peeking]) => {
  if (len > 0 && show && !peeking) {
    schedulePeek()
  } else {
    isPurplePeeking.value = false
    if (peekTimeout) clearTimeout(peekTimeout)
  }
})

onMounted(() => {
  window.addEventListener('mousemove', handleMouseMove)
  schedulePurpleBlink()
  scheduleBlackBlink()
})

onUnmounted(() => {
  window.removeEventListener('mousemove', handleMouseMove)
  if (purpleBlinkTimeout) clearTimeout(purpleBlinkTimeout)
  if (blackBlinkTimeout) clearTimeout(blackBlinkTimeout)
  if (typingTimer) clearTimeout(typingTimer)
  if (peekTimeout) clearTimeout(peekTimeout)
})

const calculatePosition = (el) => {
  if (!el) return { faceX: 0, faceY: 0, bodySkew: 0 }

  const rect = el.getBoundingClientRect()
  const centerX = rect.left + rect.width / 2
  const centerY = rect.top + rect.height / 3

  const deltaX = mouseX.value - centerX
  const deltaY = mouseY.value - centerY

  const faceX = Math.max(-15, Math.min(15, deltaX / 20))
  const faceY = Math.max(-10, Math.min(10, deltaY / 30))
  const bodySkew = Math.max(-6, Math.min(6, -deltaX / 120))

  return { faceX, faceY, bodySkew }
}

const isHidingPassword = computed(() => props.passwordLength > 0 && !props.showPassword)

const purplePos = computed(() => calculatePosition(purpleRef.value))
const blackPos = computed(() => calculatePosition(blackRef.value))
const yellowPos = computed(() => calculatePosition(yellowRef.value))
const orangePos = computed(() => calculatePosition(orangeRef.value))

const purpleForceLookX = computed(() => {
  if (props.passwordLength > 0 && props.showPassword) {
    return isPurplePeeking.value ? 4 : -4
  }
  return isLookingAtEachOther.value ? 3 : undefined
})

const purpleForceLookY = computed(() => {
  if (props.passwordLength > 0 && props.showPassword) {
    return isPurplePeeking.value ? 5 : -4
  }
  return isLookingAtEachOther.value ? 4 : undefined
})

const blackForceLookX = computed(() => {
  if (props.passwordLength > 0 && props.showPassword) return -4
  return isLookingAtEachOther.value ? 0 : undefined
})

const blackForceLookY = computed(() => {
  if (props.passwordLength > 0 && props.showPassword) return -4
  return isLookingAtEachOther.value ? -4 : undefined
})

const orangeForceLookX = computed(() => props.passwordLength > 0 && props.showPassword ? -5 : undefined)
const orangeForceLookY = computed(() => props.passwordLength > 0 && props.showPassword ? -4 : undefined)
const yellowForceLookX = computed(() => props.passwordLength > 0 && props.showPassword ? -5 : undefined)
const yellowForceLookY = computed(() => props.passwordLength > 0 && props.showPassword ? -4 : undefined)

const purpleStyle = computed(() => ({
  left: '70px',
  width: '180px',
  height: (props.isTyping || isHidingPassword.value) ? '440px' : '400px',
  backgroundColor: '#6C3FF5',
  borderRadius: '10px 10px 0 0',
  zIndex: 1,
  transform: (props.passwordLength > 0 && props.showPassword)
    ? 'skewX(0deg)'
    : (props.isTyping || isHidingPassword.value)
      ? `skewX(${purplePos.value.bodySkew - 12}deg) translateX(40px)`
      : `skewX(${purplePos.value.bodySkew}deg)`,
  transformOrigin: 'bottom center'
}))

const purpleEyesStyle = computed(() => ({
  left: (props.passwordLength > 0 && props.showPassword) ? '20px' : isLookingAtEachOther.value ? '55px' : `${45 + purplePos.value.faceX}px`,
  top: (props.passwordLength > 0 && props.showPassword) ? '35px' : isLookingAtEachOther.value ? '65px' : `${40 + purplePos.value.faceY}px`
}))

const blackStyle = computed(() => ({
  left: '240px',
  width: '120px',
  height: '310px',
  backgroundColor: '#2D2D2D',
  borderRadius: '8px 8px 0 0',
  zIndex: 2,
  transform: (props.passwordLength > 0 && props.showPassword)
    ? 'skewX(0deg)'
    : isLookingAtEachOther.value
      ? `skewX(${blackPos.value.bodySkew * 1.5 + 10}deg) translateX(20px)`
      : (props.isTyping || isHidingPassword.value)
        ? `skewX(${blackPos.value.bodySkew * 1.5}deg)`
        : `skewX(${blackPos.value.bodySkew}deg)`,
  transformOrigin: 'bottom center'
}))

const blackEyesStyle = computed(() => ({
  left: (props.passwordLength > 0 && props.showPassword) ? '10px' : isLookingAtEachOther.value ? '32px' : `${26 + blackPos.value.faceX}px`,
  top: (props.passwordLength > 0 && props.showPassword) ? '28px' : isLookingAtEachOther.value ? '12px' : `${32 + blackPos.value.faceY}px`
}))

const orangeStyle = computed(() => ({
  left: '0px',
  width: '240px',
  height: '200px',
  zIndex: 3,
  backgroundColor: '#FF9B6B',
  borderRadius: '120px 120px 0 0',
  transform: (props.passwordLength > 0 && props.showPassword) ? 'skewX(0deg)' : `skewX(${orangePos.value.bodySkew}deg)`,
  transformOrigin: 'bottom center'
}))

const orangeEyesStyle = computed(() => ({
  left: (props.passwordLength > 0 && props.showPassword) ? '50px' : `${82 + orangePos.value.faceX}px`,
  top: (props.passwordLength > 0 && props.showPassword) ? '85px' : `${90 + orangePos.value.faceY}px`
}))

const yellowStyle = computed(() => ({
  left: '310px',
  width: '140px',
  height: '230px',
  backgroundColor: '#E8D754',
  borderRadius: '70px 70px 0 0',
  zIndex: 4,
  transform: (props.passwordLength > 0 && props.showPassword) ? 'skewX(0deg)' : `skewX(${yellowPos.value.bodySkew}deg)`,
  transformOrigin: 'bottom center'
}))

const yellowEyesStyle = computed(() => ({
  left: (props.passwordLength > 0 && props.showPassword) ? '20px' : `${52 + yellowPos.value.faceX}px`,
  top: (props.passwordLength > 0 && props.showPassword) ? '35px' : `${40 + yellowPos.value.faceY}px`
}))

const yellowMouthStyle = computed(() => ({
  left: (props.passwordLength > 0 && props.showPassword) ? '10px' : `${40 + yellowPos.value.faceX}px`,
  top: (props.passwordLength > 0 && props.showPassword) ? '88px' : `${88 + yellowPos.value.faceY}px`
}))
</script>
