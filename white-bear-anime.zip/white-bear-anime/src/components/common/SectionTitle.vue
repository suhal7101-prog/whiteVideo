<!--
  区块标题组件
  用于首页和各页面的标题分区
-->
<template>
  <div class="section-title" :class="{ 'has-link': !!linkText }">
    <div class="title-left">
      <span class="title-icon" v-if="icon">{{ icon }}</span>
      <h3 class="title-text">{{ title }}</h3>
      <span class="title-desc" v-if="desc">{{ desc }}</span>
    </div>
    <router-link v-if="linkText && linkTo" :to="linkTo" class="title-link">
      {{ linkText }} <span class="arrow">›</span>
    </router-link>
    <span v-else-if="linkText" class="title-link" @click="$emit('more')">
      {{ linkText }} <span class="arrow">›</span>
    </span>
  </div>
</template>

<script setup>
defineProps({
  title: { type: String, required: true },
  icon: { type: String, default: '' },
  desc: { type: String, default: '' },
  linkText: { type: String, default: '' },
  linkTo: { type: [String, Object], default: '' }
})
defineEmits(['more'])
</script>

<style scoped>
.section-title {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 8px 0 16px;
}
.title-left {
  display: flex;
  align-items: center;
  gap: 10px;
}
.title-icon {
  font-size: 24px;
}
.title-text {
  font-size: 20px;
  font-weight: 700;
  color: #1a1a2e;
  margin: 0;
}
.title-desc {
  font-size: 13px;
  color: #999;
  margin-left: 8px;
}
.title-link {
  font-size: 14px;
  color: #667eea;
  cursor: pointer;
  text-decoration: none;
  display: flex;
  align-items: center;
  gap: 2px;
  transition: all 0.2s;
}
.title-link:hover {
  color: #764ba2;
  transform: translateX(2px);
}
.title-link .arrow {
  font-size: 18px;
  font-weight: 700;
}
</style>
