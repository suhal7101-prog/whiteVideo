<!--
  AnimeCard — 动漫卡片组件 v2.0

  状态矩阵:
  ┌──────────┬──────────────────────────────────────┐
  │ Default  │ 3:4 封面 + 评分徽章 + 集数标签          │
  │ Hover    │ 上浮 6px + glow 阴影 + zoom 1.08       │
  │ Focus    │ ring-2 靛紫环                          │
  │ Active   │ scale(0.97)                            │
  └──────────┴──────────────────────────────────────┘

  Token: src/assets/styles/design-tokens.css v2.0
-->
<template>
  <article
    class="ac"
    tabindex="0"
    role="link"
    :aria-label="`动漫详情: ${data.title}`"
    @click="$emit('click', data)"
    @keydown.enter="$emit('click', data)"
    @keydown.space.prevent="$emit('click', data)"
  >
    <!-- 原有内容 -->
    <div class="ac-content">
      <div class="ac-cover">
        <img
          :src="data.cover || fallbackCover"
          :alt="data.title"
          loading="lazy"
        />
        <span class="ac-score" v-if="data.score">⭐ {{ data.score }}</span>
        <span class="ac-ep" v-if="data.episodeCount">
          {{ data.status === '完结' ? '全' : '更至' }}{{ data.episodeCount }}集
        </span>
        <div class="ac-overlay" aria-hidden="true">
          <div class="ac-overlay-info">
            <span v-if="data.views">▶ {{ fmt(data.views) }}</span>
            <span v-if="data.danmakuCount">💬 {{ fmt(data.danmakuCount) }}</span>
          </div>
        </div>
      </div>
      <div class="ac-body">
        <h4 class="ac-title" :title="data.title">{{ data.title }}</h4>
        <div class="ac-tags" v-if="data.tags && data.tags.length">
          <el-tag
            v-for="tag in data.tags.slice(0, 3)"
            :key="tag"
            size="small"
            effect="plain"
            round
          >{{ tag }}</el-tag>
        </div>
      </div>
    </div>

    <!-- 悬停简介层 -->
    <div class="ac-hover-desc">
      <p>{{ data.desc || data.description || '暂无简介' }}</p>
    </div>
  </article>
</template>

<script setup>
defineProps({ data: { type: Object, required: true } })
defineEmits(['click'])

const fallbackCover = 'https://picsum.photos/seed/default-anime/400/560'

const fmt = (n) => {
  if (!n) return '0'
  if (n >= 10000) return (n / 10000).toFixed(1) + '万'
  return String(n)
}
</script>

<style scoped>
/* ================================================================
   AnimeCard — Light Theme · Token-driven
   ================================================================ */

/* ---- 卡片容器 ---- */
.ac {
  position: relative;
  cursor: pointer;
  border-radius: var(--ds-radius-md, 10px);
  overflow: hidden;
  background: var(--ds-surface-1, #fff);
  box-shadow: var(--ds-shadow-sm, 0 1px 3px rgba(0,0,0,.08));
  transition:
    transform var(--ds-duration-base, 200ms) var(--ds-ease-decelerate),
    box-shadow var(--ds-duration-base, 200ms) var(--ds-ease-decelerate);
  outline: none;
}

.ac-content { position: relative; z-index: 1; }

/* Hover */
.ac:hover {
  transform: translateY(-6px);
  box-shadow:
    var(--ds-shadow-lg, 0 8px 24px rgba(0,0,0,.14)),
    var(--ds-shadow-glow, 0 0 24px rgba(124,92,231,.12));
}
.ac:hover .ac-cover img { transform: scale(1.08); }
.ac:hover .ac-overlay   { opacity: 1; }

/* ===== 双角展开动画 ===== */
.ac::before,
.ac::after {
  position: absolute;
  content: "";
  width: 22%;
  height: 22%;
  background: transparent;
  transition: all 0.5s cubic-bezier(0.4, 0, 0.2, 1);
  z-index: 2;
  pointer-events: none;
}
.ac::before {
  top: 0; right: 0;
  border-radius: 0 10px 0 100%;
}
.ac::after {
  bottom: 0; left: 0;
  border-radius: 0 100% 0 10px;
}
.ac:hover::before,
.ac:hover::after {
  width: 100%;
  height: 100%;
  border-radius: 10px;
  background: linear-gradient(135deg, rgba(102, 126, 234, 0.85), rgba(118, 75, 162, 0.85));
  backdrop-filter: blur(12px);
  -webkit-backdrop-filter: blur(12px);
}

/* 悬停简介文字 */
.ac-hover-desc {
  position: absolute;
  inset: 0;
  z-index: 3;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 20px;
  color: #fff;
  font-size: 13px;
  line-height: 1.7;
  text-align: center;
  opacity: 0;
  transition: opacity 0.3s ease 0.15s;
  pointer-events: none;
}
.ac-hover-desc p {
  margin: 0;
  display: -webkit-box;
  -webkit-line-clamp: 8;
  -webkit-box-orient: vertical;
  overflow: hidden;
}
.ac:hover .ac-hover-desc {
  opacity: 1;
  transition-delay: 0.25s;
}

/* Focus */
.ac:focus-visible {
  outline: 2.5px solid var(--ds-accent, #7c5ce7);
  outline-offset: 2px;
}

/* Active */
.ac:active {
  transform: scale(0.97);
  box-shadow: var(--ds-shadow-xs, 0 1px 2px rgba(0,0,0,.04));
  transition-duration: 80ms;
}

/* ================================================================
   封面 3:4
   ================================================================ */
.ac-cover {
  position: relative;
  aspect-ratio: 3 / 4;
  overflow: hidden;
  background: var(--ds-surface-3, #f0f1fa);
}
.ac-cover img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  display: block;
  transition: transform var(--ds-duration-slow, 350ms) var(--ds-ease-decelerate);
}

/* 右上 评分 */
.ac-score {
  position: absolute;
  top: 8px;
  right: 8px;
  background: rgba(0, 0, 0, 0.68);
  color: var(--ds-gold, #f5a623);
  padding: 3px 10px;
  border-radius: 12px;
  font-size: var(--ds-text-xs, 0.75rem);
  font-weight: 600;
}

/* 左下 集数 */
.ac-ep {
  position: absolute;
  bottom: 8px;
  left: 8px;
  background: var(--ds-gradient-brand, linear-gradient(135deg, #7c5ce7, #a855f7));
  color: #fff;
  padding: 3px 10px;
  border-radius: 10px;
  font-size: 11px;
  font-weight: 500;
}

/* 悬浮数据层 */
.ac-overlay {
  position: absolute;
  inset: 0;
  display: flex;
  align-items: flex-end;
  padding: 8px 12px;
  background: linear-gradient(0deg, rgba(0,0,0,0.65) 0%, transparent 40%);
  opacity: 0;
  transition: opacity var(--ds-duration-base, 200ms) ease;
}
.ac-overlay-info {
  display: flex;
  gap: 12px;
  color: #fff;
  font-size: var(--ds-text-xs, 0.75rem);
}

/* ================================================================
   信息区
   ================================================================ */
.ac-body {
  padding: 10px 12px;
}

.ac-title {
  font-size: var(--ds-text-sm, 0.8125rem);
  font-weight: var(--ds-font-semibold, 600);
  color: var(--ds-text-primary, #1a1a2e);
  margin: 0 0 6px;
  line-height: var(--ds-leading-normal, 1.5);
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}

.ac-tags {
  display: flex;
  gap: 4px;
  flex-wrap: wrap;
}
</style>
