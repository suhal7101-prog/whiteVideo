<template>
  <el-avatar
    :size="size"
    :src="avatarSrc"
    :style="fallbackStyle"
    class="user-avatar"
    @error="handleError"
  >
    <span class="user-avatar__initial">{{ initial }}</span>
  </el-avatar>
</template>

<script setup>
import { computed, ref, watch } from 'vue'

const props = defineProps({
  src: { type: String, default: '' },
  name: { type: String, default: '用户' },
  userId: { type: [String, Number], default: '' },
  size: { type: [String, Number], default: 40 },
})

const loadFailed = ref(false)

watch(() => props.src, () => {
  loadFailed.value = false
})

const avatarSrc = computed(() => {
  const value = String(props.src || '').trim()
  return value && !loadFailed.value ? value : ''
})

const initial = computed(() => {
  const value = String(props.name || '用户').trim()
  return Array.from(value)[0] || '用'
})

const fallbackStyle = computed(() => {
  const seed = `${props.userId || ''}-${props.name || ''}`
  let hash = 0
  for (const char of seed) hash = (hash * 31 + char.codePointAt(0)) >>> 0
  const palette = ['#667eea', '#7c5ce7', '#4f8fd8', '#43a38b', '#d77a61', '#b56abd']
  return {
    backgroundColor: palette[hash % palette.length],
    color: '#fff',
  }
})

function handleError() {
  loadFailed.value = true
}
</script>

<style scoped>
.user-avatar {
  flex: none;
  font-weight: 600;
}

.user-avatar__initial {
  font-size: .9em;
  line-height: 1;
}
</style>
