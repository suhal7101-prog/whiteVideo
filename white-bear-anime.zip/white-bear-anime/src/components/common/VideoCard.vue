<template>
  <div class="video-card" @click="$emit('click', data)">
    <div class="video-cover">
      <img :src="data.cover" :alt="data.title" />
      <span v-if="data.duration" class="video-duration">{{ data.duration }}</span>
      <span v-if="data.badge" class="video-badge" :class="data.badgeType">{{ data.badge }}</span>
    </div>
    <div class="video-info">
      <h4 class="video-title">{{ data.title }}</h4>
      <div class="video-meta">
        <span class="video-author">{{ data.author }}</span>
        <span class="video-views">{{ data.views }}</span>
      </div>
    </div>
  </div>
</template>

<script setup>
defineProps({
  data: {
    type: Object,
    required: true
  }
})
defineEmits(['click'])
</script>

<style scoped>
.video-card {
  cursor: pointer;
  border-radius: 12px;
  overflow: hidden;
  background: #fff;
  transition: all 0.3s ease;
}
.video-card:hover {
  transform: translateY(-4px);
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.10);
}
.video-cover {
  position: relative;
  aspect-ratio: 16 / 9;
  overflow: hidden;
  background: #1a1a2e;
}
.video-cover img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}
.video-duration {
  position: absolute;
  bottom: 8px;
  right: 8px;
  background: rgba(0, 0, 0, 0.75);
  color: #fff;
  padding: 2px 8px;
  border-radius: 4px;
  font-size: 12px;
}
.video-badge {
  position: absolute;
  top: 8px;
  left: 8px;
  padding: 2px 10px;
  border-radius: 12px;
  font-size: 11px;
  font-weight: 600;
}
.video-badge.hot {
  background: linear-gradient(135deg, #f093fb, #f5576c);
  color: #fff;
}
.video-badge.new {
  background: linear-gradient(135deg, #4facfe, #00f2fe);
  color: #fff;
}
.video-badge.recommend {
  background: linear-gradient(135deg, #43e97b, #38f9d7);
  color: #fff;
}
.video-info {
  padding: 10px 12px;
}
.video-title {
  font-size: 14px;
  font-weight: 600;
  color: #333;
  margin: 0 0 4px 0;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
  line-height: 1.4;
  min-height: 38px;
}
.video-meta {
  display: flex;
  justify-content: space-between;
  font-size: 12px;
  color: #999;
}
.video-author {
  color: #667eea;
}
</style>