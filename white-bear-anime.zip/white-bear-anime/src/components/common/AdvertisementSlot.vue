<template>
  <section
    v-if="advertisement && !closed"
    class="ad-slot"
    :class="[`ad-slot--${variant}`, { 'ad-slot--text-only': !advertisement.imageUrl }]"
    role="complementary"
    aria-label="广告"
    @click="openAdvertisement"
  >
    <div v-if="advertisement.imageUrl" class="ad-media">
      <img
        class="ad-image"
        :src="advertisement.imageUrl"
        :alt="advertisement.title"
      />
    </div>

    <button class="ad-close" type="button" aria-label="关闭广告" title="关闭广告" @click.stop="closeAdvertisement">
      <el-icon><Close /></el-icon>
    </button>

    <div class="ad-content">
      <span class="ad-label">精选推广</span>
      <h3>{{ advertisement.title }}</h3>
      <p>{{ displayDescription }}</p>
      <span class="ad-slogan">{{ displaySlogan }}</span>
      <span v-if="advertisement.targetUrl" class="ad-link">
        立即了解 <span aria-hidden="true">→</span>
      </span>
    </div>
  </section>
</template>

<script setup>
import { computed, onMounted, ref } from 'vue'
import { useRouter } from 'vue-router'
import { Close } from '@element-plus/icons-vue'
import { advertisementApi } from '@/api/modules/advertisement'

const props = defineProps({
  position: { type: String, required: true },
  variant: { type: String, default: 'horizontal' }
})
const emit = defineEmits(['close', 'unavailable'])
const router = useRouter()
const advertisement = ref(null)
const closed = ref(false)

const fallbackCopy = {
  nav_top: {
    description: '精选内容正在推荐',
    slogan: '顶部导航推广'
  },
  home_top: {
    description: '发现近期值得关注的精彩内容',
    slogan: '精选内容，为你的兴趣多一种选择'
  },
  community_sidebar: {
    description: '分享灵感，遇见更多同好',
    slogan: '让每一次创作都被看见'
  },
  ai_sidebar: {
    description: '让智能工具成为你的得力助手',
    slogan: '更高效地发现、整理与创作'
  },
  player_pause: {
    description: '精彩稍后继续，先看看这份精选推荐',
    slogan: '短暂休息，也能发现新的惊喜'
  }
}

const displayDescription = computed(() => advertisement.value?.description?.trim()
  || fallbackCopy[props.position]?.description
  || '为你精选值得关注的内容')

const displaySlogan = computed(() => fallbackCopy[props.position]?.slogan
  || '现在了解，发现更多可能')

async function loadAdvertisement() {
  try {
    const list = await advertisementApi.getActive(props.position)
    advertisement.value = Array.isArray(list) ? list[0] || null : null
    if (!advertisement.value) emit('unavailable')
  } catch (error) {
    console.warn(`[AdvertisementSlot] ${props.position} 广告加载失败:`, error)
    emit('unavailable')
  }
}

function closeAdvertisement() {
  closed.value = true
  emit('close')
}

function openAdvertisement() {
  const target = advertisement.value?.targetUrl
  if (!target) return
  if (target.startsWith('/') && !target.startsWith('//')) router.push(target)
  else window.open(target, '_blank', 'noopener,noreferrer')
}

onMounted(loadAdvertisement)
</script>

<style scoped>
.ad-slot {
  position: relative;
  min-height: 112px;
  overflow: hidden;
  border: 1px solid #e7e9ee;
  border-radius: 6px;
  background: #fff;
  color: #222733;
  cursor: pointer;
}
.ad-content {
  min-height: inherit;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 24px 58px 22px;
  text-align: center;
}
.ad-image {
  position: absolute;
  inset: 0;
  display: block;
  width: 100%;
  height: 100%;
  object-fit: cover;
}
.ad-label {
  margin-bottom: 7px;
  padding: 1px 5px;
  border: 1px solid #b6bbc5;
  border-radius: 3px;
  color: #8a909c;
  font-size: 10px;
  line-height: 16px;
}
.ad-content h3 {
  margin: 0;
  color: #252a35;
  font-size: 17px;
  line-height: 1.45;
  letter-spacing: 0;
}
.ad-content p {
  margin: 5px 0 0;
  color: #868d9a;
  font-size: 13px;
  line-height: 1.5;
}
.ad-link {
  margin-top: 9px;
  color: #3b78ff;
  font-size: 12px;
}
.ad-close {
  position: absolute;
  top: 0;
  right: 0;
  z-index: 2;
  display: grid;
  width: 30px;
  height: 30px;
  place-items: center;
  padding: 0;
  border: 0;
  border-bottom: 1px solid #eeeeef;
  border-left: 1px solid #eeeeef;
  border-radius: 0;
  background: #fff;
  color: #292d35;
  cursor: pointer;
  transition: background-color .15s ease, color .15s ease;
}
.ad-close .el-icon { width: 15px; height: 15px; font-size: 15px; }
.ad-close:hover,
.ad-close:focus-visible { background: #ff4d57; color: #fff; }
.ad-slot--compact { min-height: 168px; }
.ad-slot--compact .ad-content { padding-inline: 38px; }
.ad-slot--sidebar {
  width: 100%;
  min-height: 0;
  aspect-ratio: 1 / 1;
  border-radius: 12px;
  background: #f6f7fa;
  box-shadow: 0 5px 18px rgba(28, 35, 60, .08);
}
.ad-slot--sidebar .ad-image {
  object-fit: contain;
  background: #fff;
}
.ad-slot--featured {
  display: grid;
  grid-template-columns: minmax(250px, 34%) minmax(0, 1fr);
  height: clamp(220px, 24vw, 250px);
  min-height: 0;
  border-radius: 14px;
  background: linear-gradient(135deg, #fff 0%, #f6f7ff 100%);
  box-shadow: 0 7px 24px rgba(35, 42, 76, .09);
}
.ad-slot--featured .ad-image {
  position: relative;
  inset: auto;
  min-height: 0;
  object-fit: contain;
  background: #fff;
}
.ad-slot--featured .ad-content {
  height: 100%;
  min-height: 0;
  align-items: flex-start;
  box-sizing: border-box;
  padding: 30px 48px 28px 30px;
  text-align: left;
}
.ad-slot--featured .ad-content h3 { font-size: 21px; }
.ad-slot--featured .ad-content p { max-width: 420px; font-size: 14px; }
.ad-slot--featured .ad-link { margin-top: 14px; font-weight: 600; }
.ad-slot--overlay {
  position: absolute;
  top: 50%;
  left: 50%;
  z-index: 20;
  width: clamp(300px, 38%, 360px);
  aspect-ratio: 16 / 9;
  transform: translate(-50%, -50%);
  min-height: 0;
  border: 1px solid #e7e9ee;
  border-radius: 5px;
  box-shadow: 0 8px 28px rgba(0, 0, 0, 0.24);
}
.ad-slot--overlay .ad-content {
  height: 100%;
  min-height: 0;
  box-sizing: border-box;
  padding: 22px 50px 18px;
}
.ad-slot--overlay .ad-image {
  object-fit: contain;
  background: #fff;
}
@media (max-width: 600px) {
  .ad-content { padding: 20px 50px 18px; }
  .ad-content h3 { font-size: 15px; }
  .ad-slot--featured {
    grid-template-columns: 44% minmax(0, 1fr);
    height: 160px;
    min-height: 0;
  }
  .ad-slot--featured .ad-image { min-height: 0; }
  .ad-slot--featured .ad-content {
    min-height: 0;
    padding: 20px 34px 18px 16px;
  }
  .ad-slot--featured .ad-content h3 { font-size: 16px; }
  .ad-slot--featured .ad-content p {
    display: -webkit-box;
    overflow: hidden;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 2;
    font-size: 12px;
  }
  .ad-slot--featured .ad-link { margin-top: 8px; }
  .ad-slot--overlay { width: min(320px, calc(100% - 32px)); }
  .ad-slot--overlay .ad-content p { max-width: 240px; }
}

/* 2026 广告卡片：统一为左图右文，并让关闭操作在所有展示位保持一致。 */
.ad-slot {
  isolation: isolate;
  display: grid;
  grid-template-columns: minmax(132px, 42%) minmax(0, 1fr);
  min-height: 148px;
  overflow: hidden;
  border: 1px solid rgba(116, 95, 210, .16);
  border-radius: 16px;
  background:
    radial-gradient(circle at 92% 10%, rgba(124, 92, 231, .12), transparent 34%),
    linear-gradient(145deg, #ffffff 0%, #f8f7ff 58%, #f1efff 100%);
  box-shadow: 0 10px 30px rgba(40, 31, 87, .10);
  color: #28243d;
  transition: border-color .2s ease, box-shadow .2s ease, transform .2s ease;
}
.ad-slot:not(.ad-slot--overlay):hover {
  transform: translateY(-2px);
  border-color: rgba(109, 78, 220, .34);
  box-shadow: 0 16px 38px rgba(40, 31, 87, .15);
}
.ad-slot--text-only { grid-template-columns: 1fr; }
.ad-media {
  position: relative;
  z-index: 0;
  display: flex;
  min-width: 0;
  height: 100%;
  overflow: hidden;
  align-items: center;
  justify-content: flex-start;
  border-right: 1px solid rgba(116, 95, 210, .12);
  background: #fff;
}
.ad-image,
.ad-slot--featured .ad-image,
.ad-slot--overlay .ad-image,
.ad-slot--sidebar .ad-image {
  position: relative;
  inset: auto;
  display: block;
  width: 100%;
  height: 100%;
  min-height: 0;
  object-fit: contain;
  object-position: left center;
  background: #fff;
}
.ad-content,
.ad-slot--featured .ad-content,
.ad-slot--overlay .ad-content {
  position: relative;
  z-index: 1;
  display: flex;
  width: 100%;
  height: 100%;
  min-width: 0;
  min-height: 0;
  box-sizing: border-box;
  flex-direction: column;
  align-items: flex-start;
  justify-content: center;
  padding: 24px 52px 22px 24px;
  text-align: left;
}
.ad-label {
  margin: 0 0 9px;
  padding: 3px 9px;
  border: 1px solid rgba(111, 79, 218, .22);
  border-radius: 999px;
  background: rgba(122, 92, 230, .09);
  color: #6f4fda;
  font-size: 10px;
  font-weight: 700;
  line-height: 16px;
  letter-spacing: .08em;
}
.ad-content h3,
.ad-slot--featured .ad-content h3,
.ad-slot--overlay .ad-content h3 {
  display: -webkit-box;
  overflow: hidden;
  margin: 0;
  color: #252039;
  font-size: clamp(16px, 1.7vw, 22px);
  font-weight: 750;
  line-height: 1.28;
  letter-spacing: -.01em;
  -webkit-box-orient: vertical;
  -webkit-line-clamp: 2;
}
.ad-content p,
.ad-slot--featured .ad-content p,
.ad-slot--overlay .ad-content p {
  display: -webkit-box;
  overflow: hidden;
  max-width: 460px;
  margin: 8px 0 0;
  color: #6f6a80;
  font-size: 13px;
  line-height: 1.55;
  -webkit-box-orient: vertical;
  -webkit-line-clamp: 2;
}
.ad-slogan {
  display: -webkit-box;
  overflow: hidden;
  margin-top: 8px;
  color: #918aa5;
  font-size: 11px;
  line-height: 1.45;
  -webkit-box-orient: vertical;
  -webkit-line-clamp: 1;
}
.ad-slogan::before {
  display: inline-block;
  width: 5px;
  height: 5px;
  margin: 0 7px 1px 0;
  border-radius: 50%;
  background: #8b67ed;
  box-shadow: 0 0 0 3px rgba(139, 103, 237, .12);
  content: '';
}
.ad-link,
.ad-slot--featured .ad-link {
  display: inline-flex;
  margin-top: 13px;
  align-items: center;
  gap: 6px;
  color: #6e4ad9;
  font-size: 12px;
  font-weight: 750;
  transition: gap .18s ease, color .18s ease;
}
.ad-slot:hover .ad-link { gap: 10px; color: #5530c4; }
.ad-close {
  position: absolute;
  top: 10px;
  right: 10px;
  z-index: 4;
  display: grid;
  width: 34px;
  height: 34px;
  place-items: center;
  padding: 0;
  border: 1px solid rgba(86, 78, 112, .14);
  border-radius: 50%;
  background: rgba(255, 255, 255, .88);
  box-shadow: 0 6px 18px rgba(28, 23, 52, .14);
  color: #5d576d;
  cursor: pointer;
  backdrop-filter: blur(10px);
  transition: transform .18s ease, color .18s ease, background .18s ease, box-shadow .18s ease;
}
.ad-close .el-icon {
  width: 16px;
  height: 16px;
  font-size: 16px;
  transition: transform .18s ease;
}
.ad-close:hover,
.ad-close:focus-visible {
  outline: none;
  background: linear-gradient(135deg, #ff6a78, #ec4055);
  box-shadow: 0 8px 20px rgba(226, 54, 79, .28);
  color: #fff;
  transform: scale(1.08);
}
.ad-close:hover .el-icon { transform: rotate(90deg); }
.ad-close:active { transform: scale(.94); }
.ad-close:focus-visible { outline: 3px solid rgba(111, 79, 218, .22); outline-offset: 2px; }

.ad-slot--compact {
  grid-template-columns: minmax(138px, 48%) minmax(0, 1fr);
  min-height: 168px;
}
.ad-slot--compact .ad-content { padding: 20px 44px 18px 18px; }
.ad-slot--compact .ad-content h3 { font-size: 16px; }
.ad-slot--compact .ad-content p { font-size: 12px; }
.ad-slot--compact .ad-slogan { display: none; }
.ad-slot--sidebar {
  grid-template-columns: minmax(138px, 48%) minmax(0, 1fr);
  width: 100%;
  min-height: 168px;
  aspect-ratio: auto;
  border-radius: 16px;
  background:
    radial-gradient(circle at 100% 0%, rgba(124, 92, 231, .13), transparent 36%),
    linear-gradient(145deg, #fff, #f5f3ff);
}
.ad-slot--sidebar .ad-content { padding: 20px 44px 18px 18px; }
.ad-slot--sidebar .ad-content h3 { font-size: 16px; }
.ad-slot--sidebar .ad-content p { font-size: 12px; }
.ad-slot--sidebar .ad-slogan { display: none; }
.ad-slot--featured {
  grid-template-columns: minmax(220px, 28%) minmax(0, 1fr);
  height: clamp(220px, 24vw, 250px);
  min-height: 0;
  border-radius: 18px;
}
.ad-slot--featured .ad-content { padding: 30px 58px 28px 30px; }
.ad-slot--featured .ad-content h3 { font-size: clamp(20px, 2vw, 24px); }
.ad-slot--featured .ad-content p { font-size: 14px; }
.ad-slot--overlay {
  position: absolute;
  top: 50%;
  left: 50%;
  z-index: 20;
  grid-template-columns: minmax(220px, 48%) minmax(0, 1fr);
  width: clamp(480px, 54%, 620px);
  height: clamp(220px, 24vw, 260px);
  min-height: 0;
  aspect-ratio: auto;
  transform: translate(-50%, -50%);
  border-radius: 16px;
  box-shadow: 0 20px 60px rgba(0, 0, 0, .32);
}
.ad-slot--overlay:hover {
  border-color: rgba(137, 105, 236, .38);
  box-shadow: 0 24px 70px rgba(0, 0, 0, .38);
}
.ad-slot--overlay .ad-content { padding: 24px 50px 22px 22px; }
.ad-slot--overlay .ad-content h3 { font-size: 18px; }
.ad-slot--overlay .ad-content p { font-size: 12px; }
.ad-slot--overlay .ad-slogan { -webkit-line-clamp: 2; }

/* 全站顶部导航广告：紧凑横幅，避免遮挡主导航操作。 */
.ad-slot--navigation {
  grid-template-columns: minmax(150px, 230px) minmax(0, 1fr);
  width: 100%;
  height: 58px;
  min-height: 58px;
  border-radius: 12px;
  box-shadow: 0 5px 18px rgba(40, 31, 87, .10);
}
.ad-slot--navigation:not(.ad-slot--overlay):hover { transform: none; }
.ad-slot--navigation .ad-media { min-height: 58px; }
.ad-slot--navigation .ad-image { object-fit: cover; object-position: center; }
.ad-slot--navigation .ad-content {
  min-height: 58px;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  gap: 12px;
  padding: 8px 48px 8px 18px;
  white-space: nowrap;
}
.ad-slot--navigation .ad-label { margin: 0; flex-shrink: 0; }
.ad-slot--navigation .ad-content h3 {
  display: block;
  max-width: 240px;
  overflow: hidden;
  font-size: 15px;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.ad-slot--navigation .ad-content p {
  display: block;
  min-width: 0;
  overflow: hidden;
  margin: 0;
  font-size: 12px;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.ad-slot--navigation .ad-slogan { display: none; }
.ad-slot--navigation .ad-link { margin: 0 0 0 auto; flex-shrink: 0; }
.ad-slot--navigation .ad-close { top: 50%; right: 9px; width: 28px; height: 28px; transform: translateY(-50%); }
.ad-slot--navigation .ad-close:hover,
.ad-slot--navigation .ad-close:focus-visible { transform: translateY(-50%) scale(1.06); }

@media (max-width: 600px) {
  .ad-slot--featured {
    grid-template-columns: minmax(150px, 44%) minmax(0, 1fr);
    height: 180px;
  }
  .ad-slot--featured .ad-content { padding: 18px 42px 16px 16px; }
  .ad-slot--featured .ad-content h3 { font-size: 16px; }
  .ad-slot--featured .ad-content p { font-size: 12px; }
  .ad-slot--featured .ad-slogan { display: none; }
  .ad-slot--overlay {
    grid-template-columns: minmax(168px, 50%) minmax(0, 1fr);
    width: min(520px, calc(100% - 24px));
    height: clamp(184px, 52vw, 220px);
  }
  .ad-slot--overlay .ad-content { padding: 18px 40px 15px 14px; }
  .ad-slot--overlay .ad-content h3 { font-size: 15px; }
  .ad-slot--overlay .ad-content p { margin-top: 6px; font-size: 11px; }
  .ad-slot--overlay .ad-slogan { display: none; }
  .ad-slot--overlay .ad-link { margin-top: 9px; }
  .ad-close { top: 8px; right: 8px; width: 30px; height: 30px; }
  .ad-slot--navigation {
    grid-template-columns: 112px minmax(0, 1fr);
    height: 52px;
    min-height: 52px;
  }
  .ad-slot--navigation .ad-media { min-height: 52px; }
  .ad-slot--navigation .ad-content { min-height: 52px; gap: 8px; padding: 7px 40px 7px 12px; }
  .ad-slot--navigation .ad-label,
  .ad-slot--navigation .ad-content p,
  .ad-slot--navigation .ad-link { display: none; }
  .ad-slot--navigation .ad-content h3 { max-width: 100%; font-size: 13px; }
  .ad-slot--navigation .ad-close { top: 50%; right: 7px; width: 26px; height: 26px; }
}

@media (max-width: 390px) {
  .ad-slot--compact,
  .ad-slot--sidebar { grid-template-columns: minmax(128px, 46%) minmax(0, 1fr); }
  .ad-slot--compact .ad-content,
  .ad-slot--sidebar .ad-content { padding: 16px 38px 14px 13px; }
  .ad-slot--compact .ad-content p,
  .ad-slot--sidebar .ad-content p { -webkit-line-clamp: 2; }
  .ad-slot--overlay { grid-template-columns: minmax(150px, 51%) minmax(0, 1fr); }
  .ad-label { margin-bottom: 6px; padding: 2px 7px; }
}
</style>
