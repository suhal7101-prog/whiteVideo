<!--
  LoaderSpin — 自定义加载动画
  白熊动漫主题色: --path 描边 / --dot 圆点
-->
<template>
  <div class="loader-circle" :style="{ '--path': path, '--dot': dot, '--duration': duration }">
    <svg viewBox="0 0 80 80">
      <circle r="32" cy="40" cx="40"></circle>
    </svg>
  </div>
</template>

<script setup>
defineProps({
  path:  { type: String, default: 'rgba(124,92,231,0.18)' },   // 圈描边
  dot:   { type: String, default: '#7c5ce7' },                 // 圆点
  duration: { type: String, default: '2.5s' },                 // 速度
})
</script>

<style scoped>
.loader-circle {
  --path: #2f3545;
  --dot: #5628ee;
  --duration: 3s;
  width: 44px;
  height: 44px;
  position: relative;
}

.loader-circle:before {
  content: "";
  width: 6px;
  height: 6px;
  border-radius: 50%;
  position: absolute;
  display: block;
  background: var(--dot);
  top: 37px;
  left: 19px;
  transform: translate(-18px, -18px);
  animation: dotRect var(--duration) cubic-bezier(0.785, 0.135, 0.15, 0.86) infinite;
}

.loader-circle svg {
  display: block;
  width: 100%;
  height: 100%;
}

.loader-circle svg circle {
  fill: none;
  stroke: var(--path);
  stroke-width: 10px;
  stroke-linejoin: round;
  stroke-linecap: round;
  stroke-dasharray: 150 50 150 50;
  stroke-dashoffset: 75;
  animation: pathCircle var(--duration) cubic-bezier(0.785, 0.135, 0.15, 0.86) infinite;
}

@keyframes pathCircle {
  25%  { stroke-dashoffset: 125; }
  50%  { stroke-dashoffset: 175; }
  75%  { stroke-dashoffset: 225; }
  100% { stroke-dashoffset: 275; }
}

@keyframes dotRect {
  25%  { transform: translate(0, 0); }
  50%  { transform: translate(18px, -18px); }
  75%  { transform: translate(0, -36px); }
  100% { transform: translate(-18px, -18px); }
}
</style>
