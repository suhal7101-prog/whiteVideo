<template>
  <section
    class="managed-dynamic-banner"
    :style="{ height }"
    :data-theme="selectedTheme"
    aria-label="动态横幅"
  >
    <DynamicBanner :layers="layers" />
    <div v-if="$slots.default" class="managed-dynamic-banner__overlay">
      <slot />
    </div>
  </section>
</template>

<script setup>
import { onMounted, ref } from 'vue'
import request from '@/api/request'
import DynamicBanner from '@/components/community/DynamicBanner.vue'
import { normalizeBannerLayers } from '@/utils/bannerEffects'

const props = defineProps({
  height: { type: String, default: '160px' },
  storageKey: { type: String, required: true },
  targetPage: { type: String, default: 'ai' },
})

const layers = ref([])
const selectedTheme = ref('')

async function readEffect(effect) {
  const response = await fetch(effect.dataUrl, { cache: 'no-cache' })
  if (!response.ok) throw new Error(`HTTP ${response.status}`)
  const data = await response.json()
  const normalized = normalizeBannerLayers(data, { baseUrl: effect.assetBaseUrl })
  if (!normalized.length) throw new Error('动态横幅没有可用图层')
  return normalized
}

async function loadBanner() {
  try {
    const result = await request.get('/banner-effects/active', {
      params: { targetPage: props.targetPage },
      cancelDuplicate: false,
    })
    const effects = result?.list || []
    if (!effects.length) throw new Error('后台没有启用的动态横幅')

    const lastTheme = sessionStorage.getItem(props.storageKey)
    const candidates = effects.length > 1
      ? effects.filter(effect => effect.themeKey !== lastTheme)
      : effects
    const selected = candidates[Math.floor(Math.random() * candidates.length)] || effects[0]
    layers.value = await readEffect(selected)
    selectedTheme.value = selected.themeKey
    sessionStorage.setItem(props.storageKey, selected.themeKey)
  } catch (error) {
    console.warn('[ManagedDynamicBanner] 动态横幅加载失败:', error)
    const fallback = {
      themeKey: '2026-07-27',
      dataUrl: '/banner/2026-07-27/data.json',
      assetBaseUrl: '/banner/2026-07-27',
    }
    try {
      layers.value = await readEffect(fallback)
      selectedTheme.value = fallback.themeKey
    } catch (fallbackError) {
      console.warn('[ManagedDynamicBanner] 默认横幅加载失败:', fallbackError)
      layers.value = []
    }
  }
}

onMounted(loadBanner)
</script>

<style scoped>
.managed-dynamic-banner {
  position: relative;
  z-index: 0;
  isolation: isolate;
  width: 100%;
  overflow: hidden;
  background: #161625;
}

.managed-dynamic-banner :deep(.db) {
  height: 100%;
}

.managed-dynamic-banner__overlay {
  position: absolute;
  inset: 0;
  z-index: 1100;
  display: flex;
  align-items: center;
  pointer-events: none;
}

.managed-dynamic-banner__overlay :deep(button),
.managed-dynamic-banner__overlay :deep(a),
.managed-dynamic-banner__overlay :deep(input) {
  pointer-events: auto;
}
</style>
