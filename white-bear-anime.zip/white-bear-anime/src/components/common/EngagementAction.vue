<template>
  <span
    class="engagement-action"
    :class="[
      `engagement-action--${type}`,
      { 'is-active': active, 'is-filled': filled, 'is-clickable': clickable, 'is-disabled': disabled },
    ]"
    :role="clickable ? 'button' : undefined"
    :tabindex="clickable && !disabled ? 0 : undefined"
    :aria-label="ariaLabel"
    :aria-pressed="type === 'like' && clickable ? active : undefined"
    @click="handleClick"
    @keydown.enter.prevent="handleClick"
    @keydown.space.prevent="handleClick"
  >
    <svg v-if="type === 'like' && (active || filled)" class="engagement-action__icon" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
      <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z" />
    </svg>
    <svg v-else-if="type === 'like'" class="engagement-action__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
      <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z" />
    </svg>
    <svg v-else-if="type === 'comment'" class="engagement-action__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
      <path d="M21 15a4 4 0 0 1-4 4H8l-5 3V7a4 4 0 0 1 4-4h10a4 4 0 0 1 4 4z" />
      <circle cx="8" cy="11" r=".7" fill="currentColor" stroke="none" />
      <circle cx="12" cy="11" r=".7" fill="currentColor" stroke="none" />
      <circle cx="16" cy="11" r=".7" fill="currentColor" stroke="none" />
    </svg>
    <svg v-else class="engagement-action__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
      <path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71" />
      <path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71" />
    </svg>
    <span v-if="count !== null && count !== undefined" class="engagement-action__count">{{ count }}</span>
    <span v-if="label" class="engagement-action__label">{{ label }}</span>
  </span>
</template>

<script setup>
import { computed } from 'vue'

const props = defineProps({
  type: { type: String, default: 'like', validator: value => ['like', 'comment', 'share'].includes(value) },
  count: { type: [Number, String], default: null },
  label: { type: String, default: '' },
  active: { type: Boolean, default: false },
  filled: { type: Boolean, default: false },
  clickable: { type: Boolean, default: false },
  disabled: { type: Boolean, default: false },
})

const emit = defineEmits(['click'])

const ariaLabel = computed(() => {
  const name = props.type === 'like' ? '点赞' : props.type === 'comment' ? '评论' : '分享'
  return [name, props.count, props.label].filter(value => value !== null && value !== undefined && value !== '').join(' ')
})

function handleClick(event) {
  if (!props.clickable || props.disabled) return
  event.stopPropagation()
  emit('click', event)
}
</script>

<style scoped>
.engagement-action {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  color: #8f92a1;
  font-size: 14px;
  line-height: 1;
  white-space: nowrap;
  user-select: none;
}

.engagement-action__icon {
  width: 17px;
  height: 17px;
  flex: none;
}

.engagement-action--like.is-active,
.engagement-action--like.is-filled {
  color: #e74c3c;
}

.engagement-action--comment .engagement-action__icon,
.engagement-action--share .engagement-action__icon {
  color: #111827;
}

.engagement-action__count,
.engagement-action__label {
  color: #8f92a1;
  font-variant-numeric: tabular-nums;
}

.engagement-action.is-clickable {
  cursor: pointer;
}

.engagement-action.is-clickable:hover .engagement-action__count,
.engagement-action.is-clickable:hover .engagement-action__label,
.engagement-action--comment.is-clickable:hover,
.engagement-action--share.is-clickable:hover {
  color: #667eea;
}

.engagement-action.is-clickable:focus-visible {
  outline: 2px solid rgba(102, 126, 234, .45);
  outline-offset: 4px;
  border-radius: 4px;
}

.engagement-action.is-disabled {
  cursor: wait;
  opacity: .6;
}
</style>
