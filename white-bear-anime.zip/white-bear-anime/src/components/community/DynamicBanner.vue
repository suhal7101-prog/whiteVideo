<template>
  <div
    ref="containerRef"
    class="db"
    @mouseenter="onEnter"
    @mousemove="onMove"
    @mouseleave="onLeave"
  >
    <div
      v-for="(layer, index) in layers"
      :key="index"
      ref="layerRefs"
      class="db-layer"
      :class="{ 'db-layer--bottom': layer.bottom }"
      :style="{ zIndex: layer.zIndex ?? (index + 1) }"
    >
      <img
        v-if="layer.tagName === 'img' || layer.type === 'image'"
        :src="layer.src || layer.url"
        :alt="layer.alt || ''"
        class="db-img"
        :class="{ 'db-img--bottom': layer.bottom }"
        :style="layerMediaStyle(layer)"
        draggable="false"
      />
      <video
        v-else-if="layer.tagName === 'video' || layer.type === 'video'"
        :src="layer.src || layer.url"
        class="db-img db-video"
        :style="layerMediaStyle(layer)"
        autoplay
        muted
        loop
        playsinline
        preload="metadata"
      />
      <div v-else class="db-text">
        <h1 v-if="layer.title || layer.content?.title">
          {{ layer.title || layer.content?.title }}
        </h1>
        <p v-if="layer.desc || layer.content?.desc">
          {{ layer.desc || layer.content?.desc }}
        </p>
      </div>
    </div>

    <div class="db-gradient" />
  </div>
</template>

<script setup>
import { nextTick, onMounted, onUnmounted, ref, watch } from 'vue'

const props = defineProps({
  layers: { type: Array, default: () => [] },
})

const containerRef = ref(null)
const layerRefs = ref([])
const viewportScale = ref(1)

let initialMatrices = []
let animationFrameId = null
let entryClientX = 0
let targetMoveX = 0
let currentMoveX = 0
let pointerInside = false

function updateViewportScale() {
  const width = containerRef.value?.offsetWidth || window.innerWidth
  viewportScale.value = width > 1650 ? width / 1650 : 1
}

function layerMediaStyle(layer) {
  const style = {}
  const width = Number(layer.width)
  const height = Number(layer.height)
  const blur = Number(layer.blur)
  if (Number.isFinite(width) && width > 0) style.width = `${width * viewportScale.value}px`
  if (Number.isFinite(height) && height > 0) style.height = `${height * viewportScale.value}px`
  if (Number.isFinite(blur) && blur !== 0) style.filter = `blur(${blur}px)`
  return style
}

function buildInitialMatrices() {
  const scale = viewportScale.value
  initialMatrices = props.layers.map((layer) => {
    const source = Array.isArray(layer.transform) && layer.transform.length === 6
      ? layer.transform.map(Number)
      : [1, 0, 0, 1, 0, 0]
    const translateY = layer.bottom ? 0 : source[5] * scale
    return new DOMMatrix([
      source[0], source[1], source[2], source[3], source[4] * scale, translateY,
    ])
  })
}

function requestRender() {
  if (animationFrameId == null) animationFrameId = requestAnimationFrame(updateLayers)
}

function resetMotion() {
  targetMoveX = 0
  currentMoveX = 0
}

watch(
  () => props.layers,
  () => {
    if (animationFrameId != null) cancelAnimationFrame(animationFrameId)
    animationFrameId = null
    resetMotion()
    buildInitialMatrices()
    nextTick(requestRender)
  },
  { deep: true },
)

function onEnter(event) {
  pointerInside = true
  entryClientX = event.clientX
  targetMoveX = 0
  requestRender()
}

function onMove(event) {
  if (!containerRef.value) return
  if (!pointerInside) onEnter(event)
  const limit = containerRef.value.offsetWidth
  targetMoveX = Math.max(-limit, Math.min(limit, event.clientX - entryClientX))
  requestRender()
}

function onLeave() {
  pointerInside = false
  targetMoveX = 0
  requestRender()
}

function updateLayers() {
  animationFrameId = null
  currentMoveX += (targetMoveX - currentMoveX) * 0.18
  if (Math.abs(targetMoveX - currentMoveX) < 0.05) currentMoveX = targetMoveX

  const opacityDistance = Math.max(window.innerWidth / 2, 1)
  const opacityProgress = Math.max(0, Math.min(1, currentMoveX / opacityDistance))

  for (let index = 0; index < props.layers.length; index += 1) {
    const element = layerRefs.value[index]
    if (!element) continue

    const layer = props.layers[index]
    const speedX = Number.isFinite(Number(layer.a)) ? Number(layer.a) : 0.01
    const speedY = Number.isFinite(Number(layer.g)) ? Number(layer.g) : 0
    const rotation = Number.isFinite(Number(layer.deg)) ? Number(layer.deg) : 0
    const scaleSpeed = Number.isFinite(Number(layer.f)) ? Number(layer.f) : 0
    const motionScale = Math.max(0.2, Math.min(3, 1 + scaleSpeed * currentMoveX))

    let matrix = initialMatrices[index] || new DOMMatrix()
    matrix = matrix.multiply(new DOMMatrix([
      motionScale,
      0,
      0,
      motionScale,
      currentMoveX * speedX,
      currentMoveX * speedY,
    ]))

    if (rotation !== 0) {
      const angle = rotation * currentMoveX
      matrix = matrix.multiply(new DOMMatrix([
        Math.cos(angle), Math.sin(angle), -Math.sin(angle), Math.cos(angle), 0, 0,
      ]))
    }
    element.style.transform = matrix.toString()

    if (Array.isArray(layer.opacity) && layer.opacity.length === 2) {
      const start = Number(layer.opacity[0])
      const end = Number(layer.opacity[1])
      const opacity = start + (end - start) * opacityProgress
      element.style.opacity = String(Math.max(0, Math.min(1, opacity)))
    } else {
      element.style.opacity = '1'
    }
  }

  if (Math.abs(targetMoveX - currentMoveX) >= 0.05) requestRender()
}

function onResize() {
  updateViewportScale()
  buildInitialMatrices()
  requestRender()
}

onMounted(() => {
  updateViewportScale()
  buildInitialMatrices()
  window.addEventListener('resize', onResize)
  window.addEventListener('blur', onLeave)
  nextTick(requestRender)
})

onUnmounted(() => {
  window.removeEventListener('resize', onResize)
  window.removeEventListener('blur', onLeave)
  if (animationFrameId != null) cancelAnimationFrame(animationFrameId)
})
</script>

<style scoped>
.db {
  position: relative;
  height: 160px;
  overflow: hidden;
  cursor: default;
  background:
    radial-gradient(ellipse 80% 100% at 50% 0%, rgba(124, 92, 231, 0.35) 0%, transparent 55%),
    radial-gradient(ellipse 60% 80% at 20% 100%, rgba(240, 98, 146, 0.2) 0%, transparent 50%),
    linear-gradient(180deg, #1a1a2e 0%, #161625 100%);
  user-select: none;
}

.db-layer {
  position: absolute;
  inset: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  width: 100%;
  height: 100%;
  pointer-events: none;
  will-change: transform, opacity;
}

.db-layer--bottom {
  align-items: flex-end;
}

.db-img {
  display: block;
  max-width: none;
  flex: none;
  user-select: none;
  pointer-events: none;
}

.db-video {
  object-fit: fill;
}

.db-img--bottom {
  width: 100% !important;
  height: auto !important;
}

.db-text {
  display: flex;
  flex-direction: column;
  justify-content: center;
  width: 100%;
  height: 100%;
  box-sizing: border-box;
  padding-left: 60px;
  color: #fff;
  text-shadow: 0 2px 20px rgba(0, 0, 0, 0.6);
}

.db-text h1 {
  margin: 0 0 10px;
  font-size: 36px;
  font-weight: 700;
}

.db-text p {
  margin: 0;
  font-size: 16px;
  opacity: 0.85;
}

.db-gradient {
  position: absolute;
  right: 0;
  bottom: 0;
  left: 0;
  z-index: 900;
  height: 36%;
  background: linear-gradient(0deg, rgba(15, 23, 42, 0.24) 0%, transparent 100%);
  pointer-events: none;
}

@media (max-width: 768px) {
  .db { height: 110px; }
  .db-text { padding-left: 20px; }
  .db-text h1 { font-size: 22px; }
  .db-text p { font-size: 13px; }
}
</style>
