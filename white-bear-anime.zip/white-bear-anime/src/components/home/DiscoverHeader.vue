<!--
  DiscoverHeader — 动态视差头部

  效果：多层元素随鼠标移动产生视差
  - 最深景：光点粒子
  - 中景：浮动几何形状
  - 近景：角色剪影 / 装饰元素
-->
<template>
  <div class="dh" ref="containerRef" @mousemove="onMove" @mouseleave="resetPos">
    <!-- 背景层 -->
    <div class="dh-bg">
      <!-- 粒子光点 -->
      <span
        v-for="p in particles"
        :key="p.id"
        class="dh-particle"
        :style="particleStyle(p)"
      />
      <!-- 浮动几何 -->
      <span
        v-for="g in shapes"
        :key="g.id"
        class="dh-shape"
        :style="shapeStyle(g)"
      />
    </div>

    <!-- 前景文字（纯CSS，无emoji） -->
    <div class="dh-front" :style="frontStyle">
      <div class="dh-line" />
      <h1>发现你的下一部热爱</h1>
      <p>探索海量动漫资源，开启二次元之旅</p>
    </div>

    <!-- 装饰角色剪影 -->
    <div class="dh-chars" :style="charsStyle">
      <div class="dh-char dh-char-left" />
      <div class="dh-char dh-char-right" />
    </div>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue'

const containerRef = ref(null)

// 鼠标位置 (0~1 归一化, 中心为0)
const mx = ref(0)
const my = ref(0)

function onMove(e) {
  if (!containerRef.value) return
  const rect = containerRef.value.getBoundingClientRect()
  mx.value = (e.clientX - rect.left) / rect.width  - 0.5   // -0.5 ~ 0.5
  my.value = (e.clientY - rect.top)  / rect.height - 0.5
}

function resetPos() {
  mx.value = 0
  my.value = 0
}

// ===== 粒子 =====
const particles = Array.from({ length: 20 }, (_, i) => ({
  id: i,
  x: Math.random() * 100,      // % 位置
  y: Math.random() * 100,
  size: 2 + Math.random() * 4,  // px
  speed: 0.3 + Math.random() * 0.7,  // 视差倍率
  delay: Math.random() * 3,     // 动画延迟
}))

function particleStyle(p) {
  const dx = mx.value * 80 * p.speed
  const dy = my.value * 60 * p.speed
  return {
    left: `calc(${p.x}% + ${dx}px)`,
    top:  `calc(${p.y}% + ${dy}px)`,
    width:  `${p.size}px`,
    height: `${p.size}px`,
    animationDelay: `${p.delay}s`,
    opacity: 0.35 + p.speed * 0.5,
  }
}

// ===== 浮动几何 =====
const shapes = Array.from({ length: 6 }, (_, i) => ({
  id: i,
  x: 15 + i * 14,
  y: 30 + (i % 3) * 25,
  size: 24 + (i % 3) * 16,
  speed: 0.6 + (i * 0.08),
  round: i % 2 === 0,
}))

function shapeStyle(s) {
  const dx = mx.value * 50 * s.speed
  const dy = my.value * 40 * s.speed
  return {
    left:     `calc(${s.x}% + ${dx}px)`,
    top:      `calc(${s.y}% + ${dy}px)`,
    width:    `${s.size}px`,
    height:   `${s.size}px`,
    borderRadius: s.round ? '50%' : '8px',
    opacity:  0.08 + s.speed * 0.06,
    transform: `rotate(${mx.value * 30 * s.speed}deg)`,
  }
}

// ===== 前景视差 =====
const frontStyle = computed(() => ({
  transform: `translate(${mx.value * -15}px, ${my.value * -10}px)`,
}))

const charsStyle = computed(() => ({
  transform: `translate(${mx.value * 25}px, ${my.value * 15}px)`,
}))
</script>

<style scoped>
/* ================================================================
   DiscoverHeader — 动态视差 Banner
   ================================================================ */
.dh {
  position: relative;
  height: 160px;
  overflow: hidden;
  background:
    radial-gradient(ellipse 80% 100% at 50% 0%, rgba(124,92,231,0.4) 0%, transparent 60%),
    radial-gradient(ellipse 60% 80%  at 20% 100%, rgba(240,98,146,0.25) 0%, transparent 50%),
    radial-gradient(ellipse 50% 70%  at 80% 100%, rgba(129,140,248,0.2) 0%, transparent 50%),
    linear-gradient(180deg, #1a1a2e 0%, #161625 100%);
  cursor: default;
  user-select: none;
}

/* ---- 粒子 ---- */
.dh-bg {
  position: absolute;
  inset: 0;
  pointer-events: none;
}

.dh-particle {
  position: absolute;
  border-radius: 50%;
  background: #fff;
  animation: twinkle 3s ease-in-out infinite alternate;
}
@keyframes twinkle {
  0%   { opacity: 0.2; transform: scale(1); }
  100% { opacity: 0.7; transform: scale(1.6); }
}

/* ---- 浮动几何 ---- */
.dh-shape {
  position: absolute;
  border: 2px solid rgba(255,255,255,0.15);
  transition: transform 0.15s ease-out;
}

/* ---- 前景文字 ---- */
.dh-front {
  position: relative;
  z-index: 2;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 100%;
  text-align: center;
  color: #fff;
  transition: transform 0.2s ease-out;
}

.dh-line {
  width: 48px;
  height: 3px;
  border-radius: 2px;
  background: linear-gradient(90deg, var(--ds-pink, #f06292), var(--ds-accent, #7c5ce7));
  margin-bottom: 20px;
}

.dh-front h1 {
  font-size: 2rem;
  font-weight: 800;
  margin: 0 0 10px;
  letter-spacing: -0.03em;
  text-shadow: 0 2px 16px rgba(0,0,0,0.4);
}

.dh-front p {
  font-size: 0.9375rem;
  color: rgba(255,255,255,0.65);
  margin: 0;
  letter-spacing: 0.02em;
}

/* ---- 角色剪影 ---- */
.dh-chars {
  position: absolute;
  inset: 0;
  z-index: 1;
  pointer-events: none;
  transition: transform 0.25s ease-out;
}

.dh-char {
  position: absolute;
  bottom: 0;
  width: 160px;
  height: 200px;
  opacity: 0.12;
}

.dh-char-left {
  left: 8%;
  background:
    radial-gradient(ellipse 50% 40% at 50% 30%, rgba(255,255,255,0.9) 0%, transparent 70%),
    linear-gradient(180deg, transparent 20%, rgba(255,255,255,0.6) 60%, transparent 100%);
  mask-image: linear-gradient(180deg, #000 60%, transparent 100%);
  clip-path: polygon(30% 0%, 70% 0%, 80% 30%, 85% 50%, 75% 70%, 60% 85%, 50% 100%, 40% 100%, 30% 85%, 20% 70%, 15% 50%, 20% 30%);
}

.dh-char-right {
  right: 8%;
  width: 140px;
  height: 180px;
  background:
    radial-gradient(ellipse 50% 35% at 45% 28%, rgba(255,255,255,0.8) 0%, transparent 70%),
    linear-gradient(180deg, transparent 25%, rgba(255,255,255,0.5) 55%, transparent 100%);
  mask-image: linear-gradient(180deg, #000 55%, transparent 100%);
  clip-path: polygon(25% 0%, 75% 0%, 85% 35%, 80% 55%, 70% 75%, 55% 90%, 45% 100%, 35% 100%, 25% 90%, 15% 75%, 10% 55%, 15% 35%);
}

/* ================================================================
   响应式
   ================================================================ */
@media (max-width: 768px) {
  .dh { height: 140px; }
  .dh-front h1 { font-size: 1.35rem; }
  .dh-front p  { font-size: 0.8rem; }
  .dh-char { display: none; }
}
</style>
