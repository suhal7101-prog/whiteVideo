<!--
  VideoCard — 视频卡片组件 v3.1
  浅色主题 · 圆润卡片 · 动漫风格 · 悬浮内缩热区

  状态矩阵:
  ┌──────────┬─────────────────────────────────────────┐
  │ Default  │ 白色卡片 + 封面图 + 标题 + 元信息          │
  │ Hover    │ translateY(-6px) + glow 阴影 + 封面 zoom   │
  │ Focus    │ ring-2 靛紫环 (键盘导航)                   │
  │ Active   │ scale(0.97) (按下反馈)                    │
  │ Skeleton │ shimmer 脉冲动画                           │
  └──────────┴─────────────────────────────────────────┘
-->
<template>
  <article
    class="vc-card"
    tabindex="0"
    role="link"
    :aria-label="`观看视频: ${data.title}`"
    @click="$emit('click', data)"
    @keydown.enter="$emit('click', data)"
    @keydown.space.prevent="$emit('click', data)"
  >
    <!-- 内层容器 — 悬浮热区在此，边缘 5px 不触发 hover -->
    <div class="vc-inner">
      <div class="vc-cover">
        <img :src="data.cover" :alt="data.title" loading="lazy" />
        <div class="vc-overlay" aria-hidden="true">
          <div class="vc-play-btn">
            <svg viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg>
          </div>
        </div>
        <div class="vc-bar">
          <span class="vc-stat vc-stat-views" title="浏览量" :aria-label="`浏览量 ${data.views || 0}`">
            <svg class="vc-stat-icon" viewBox="0 0 24 24" fill="currentColor"><path d="M12 4.5C7 4.5 2.73 7.61 1 12c1.73 4.39 6 7.5 11 7.5s9.27-3.11 11-7.5c-1.73-4.39-6-7.5-11-7.5zM12 17c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5zm0-8c-1.66 0-3 1.34-3 3s1.34 3 3 3 3-1.34 3-3-1.34-3-3-3z"/></svg>
            {{ fmtNum(data.views) }}
          </span>
          <span class="vc-stat vc-stat-likes" title="点赞量" :aria-label="`点赞量 ${data.likes || 0}`">
            <svg class="vc-stat-icon" viewBox="0 0 24 24" fill="currentColor"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/></svg>
            {{ fmtNum(data.likes) }}
          </span>
        </div>
      </div>
      <div class="vc-body">
        <h4 class="vc-title" :title="data.title">{{ data.title }}</h4>
        <p class="vc-meta">
          <span class="vc-author">{{ data.author }}</span>
          <span class="vc-sep" aria-hidden="true">·</span>
          <span class="vc-time">{{ data.time }}</span>
        </p>
      </div>
    </div>

    <!-- 悬停简介层 (在内层之上) -->
    <div class="vc-hover-desc">
      <p>{{ data.desc || '暂无简介' }}</p>
    </div>
  </article>
</template>

<script setup>
defineProps({ data: { type: Object, required: true } })
defineEmits(['click'])

const fmtNum = (n) => {
  if (!n) return '0'
  if (n >= 10000) return (n / 10000).toFixed(1) + '万'
  if (n >= 1000)  return (n / 1000).toFixed(1) + 'k'
  return String(n)
}
</script>

<style scoped>
/* ---- 卡片容器 — 不参与 hover ---- */
.vc-card {
  --_radius: var(--ds-radius-md, 10px);

  position: relative;
  width: 100%;
  height: 100%;
  min-width: 0;
  box-sizing: border-box;
  outline: none;
  cursor: pointer;
  /* 5px 边距 = 悬停死角 */
  padding: 5px;
}

/* ---- 内层容器 — 所有视觉效果 & hover 在此 ---- */
.vc-inner {
  position: relative;
  z-index: 1;
  height: 100%;
  min-width: 0;
  display: flex;
  flex-direction: column;
  background: var(--ds-surface-1, #ffffff);
  border-radius: var(--_radius);
  overflow: hidden;
  box-shadow: var(--ds-shadow-sm, 0 1px 3px rgba(0,0,0,.08));
  transition:
    transform var(--ds-duration-base, 200ms) var(--ds-ease-decelerate),
    box-shadow var(--ds-duration-base, 200ms) var(--ds-ease-decelerate);
}

.vc-card:hover .vc-inner {
  transform: translateY(-6px);
  box-shadow:
    var(--ds-shadow-lg, 0 8px 24px rgba(0,0,0,.14)),
    var(--ds-shadow-glow, 0 0 24px rgba(124,92,231,.12));
}
.vc-card:hover .vc-cover img { transform: scale(1.07); }
.vc-card:hover .vc-overlay     { opacity: 1; }
.vc-card:hover .vc-title       { color: var(--ds-accent, #7c5ce7); }

/* ===== 双角展开动画 (在内层之上) ===== */
.vc-inner::before,
.vc-inner::after {
  position: absolute;
  content: "";
  width: 22%;
  height: 22%;
  background: transparent;
  transition: all 0.5s cubic-bezier(0.4, 0, 0.2, 1);
  z-index: 2;
  pointer-events: none;
}
.vc-inner::before {
  top: 0; right: 0;
  border-radius: 0 10px 0 100%;
}
.vc-inner::after {
  bottom: 0; left: 0;
  border-radius: 0 100% 0 10px;
}
.vc-card:hover .vc-inner::before,
.vc-card:hover .vc-inner::after {
  width: 100%;
  height: 100%;
  border-radius: 10px;
  background: linear-gradient(135deg, rgba(102, 126, 234, 0.85), rgba(118, 75, 162, 0.85));
  backdrop-filter: blur(12px);
  -webkit-backdrop-filter: blur(12px);
}

/* 悬停简介文字 */
.vc-hover-desc {
  position: absolute;
  inset: 5px;
  z-index: 3;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 20px;
  color: #fff;
  font-size: 13px;
  line-height: 1.7;
  text-align: center;
  opacity: 0;
  transition: opacity 0.3s ease 0.15s;
  pointer-events: none;
}
.vc-hover-desc p {
  margin: 0;
  display: -webkit-box;
  -webkit-line-clamp: 6;
  -webkit-box-orient: vertical;
  overflow: hidden;
}
.vc-card:hover .vc-hover-desc {
  opacity: 1;
  transition-delay: 0.25s;
}

/* ---- Focus-visible ---- */
.vc-card:focus-visible {
  outline: 2.5px solid var(--ds-accent, #7c5ce7);
  outline-offset: 2px;
}

/* ---- Active ---- */
.vc-card:active .vc-inner {
  transform: scale(0.97);
  box-shadow: var(--ds-shadow-xs);
  transition-duration: 80ms;
}

/* ---- 封面 (16:9) ---- */
.vc-cover {
  position: relative;
  width: 100%;
  flex: 0 0 auto;
  aspect-ratio: 16 / 9;
  overflow: hidden;
  background: var(--ds-surface-3, #f0f1fa);
}
.vc-cover img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  display: block;
  transition: transform var(--ds-duration-slow, 350ms) var(--ds-ease-decelerate);
}

/* ---- 悬浮播放遮罩 ---- */
.vc-overlay {
  position: absolute;
  inset: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  background: rgba(26,26,46,0.28);
  opacity: 0;
  transition: opacity var(--ds-duration-base, 200ms) ease;
}
.vc-play-btn {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 56px;
  height: 56px;
  border-radius: 50%;
  background: transparent;
  color: #fff;
  filter: drop-shadow(0 2px 8px rgba(0,0,0,0.5));
  transition: transform 0.2s var(--ds-ease-decelerate);
}
.vc-play-btn svg {
  width: 30px;
  height: 30px;
  margin-left: 2px;
}
.vc-card:hover .vc-play-btn { transform: scale(1.12); }

/* ---- 底部信息条 ---- */
.vc-bar {
  position: absolute;
  inset: auto 0 0 0;
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 7px;
  padding: 30px 9px 8px;
  background: linear-gradient(180deg, transparent 0%, rgba(0,0,0,0.58) 100%);
  pointer-events: none;
}
.vc-stat {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  min-width: 48px;
  padding: 4px 7px;
  border: 1px solid transparent;
  border-radius: 999px;
  background: transparent;
  font-size: var(--ds-text-xs, 0.75rem);
  font-weight: var(--ds-font-medium, 500);
  color: #fff;
  text-shadow: 0 1px 3px rgba(0,0,0,0.7);
  line-height: 1;
}
.vc-stat-likes { margin-left: auto; background: transparent; }
.vc-stat-icon {
  width: 13px;
  height: 13px;
  opacity: 0.85;
  flex-shrink: 0;
}

/* ---- 信息区 ---- */
.vc-body {
  padding: 12px 12px 14px;
  min-height: 72px;
  flex: 1;
  box-sizing: border-box;
  display: flex;
  flex-direction: column;
}

/* ---- 标题 ---- */
.vc-title {
  font-size: var(--ds-text-sm, 0.8125rem);
  font-weight: var(--ds-font-medium, 500);
  line-height: var(--ds-leading-normal, 1.5);
  color: var(--ds-text-primary, #1a1a2e);
  margin: 0 0 6px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  transition: color var(--ds-duration-fast, 120ms) ease;
}

/* ---- 元信息 ---- */
.vc-meta {
  display: flex;
  align-items: center;
  gap: 6px;
  margin: 0;
  font-size: var(--ds-text-xs, 0.75rem);
  line-height: 1;
  color: var(--ds-text-tertiary, #8f92a1);
  overflow: hidden;
}
.vc-author {
  color: var(--ds-text-tertiary, #8f92a1);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  flex-shrink: 1;
  min-width: 0;
}
.vc-sep    {
  color: var(--ds-text-disabled, #c4c6d0);
  flex-shrink: 0;
}
.vc-time   {
  color: var(--ds-text-tertiary, #8f92a1);
  white-space: nowrap;
  flex-shrink: 0;
}

/* ---- Skeleton 占位 ---- */
.vc-card.is-skeleton { pointer-events: none; padding: 0; }
.vc-card.is-skeleton .vc-inner {
  background: transparent;
  box-shadow: none;
}
.vc-card.is-skeleton .vc-cover {
  aspect-ratio: 16/9;
  background: linear-gradient(90deg,
    var(--ds-surface-3, #f0f1fa) 0%,
    var(--ds-surface-4, #e8e9f4) 50%,
    var(--ds-surface-3, #f0f1fa) 100%
  );
  background-size: 200% 100%;
  animation: shimmer 1.6s ease-in-out infinite;
}
@keyframes shimmer {
  0%   { background-position: 200% 0; }
  100% { background-position: -200% 0; }
}
</style>
