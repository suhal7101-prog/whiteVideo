<!--
  AI 个性化推荐组件（扩展预留）

  规划功能：
  - 基于用户观看历史和偏好标签推荐动漫
  - 生成推荐理由（LLM 生成）
  - 偏好标签管理
  - 推荐反馈（喜欢/不喜欢）

  技术栈：协同过滤 + DeepSeek 生成推荐理由
  当前状态：已接入数据库分类与推荐接口
-->
<template>
  <div class="ai-recommend" v-loading="loading">
    <div class="recommend-header">
      <h3>🤖 AI 个性化推荐</h3>
      <p>基于你的观看历史，AI 为你精选以下动漫</p>
    </div>

    <!-- ===== 偏好标签选择 ===== -->
    <div class="preference-tags">
      <span class="pref-label">我的偏好：</span>
      <el-tag
        v-for="tag in availableTags"
        :key="tag"
        :effect="selectedTags.includes(tag) ? 'dark' : 'plain'"
        :type="selectedTags.includes(tag) ? 'primary' : 'info'"
        round
        size="small"
        class="pref-tag"
        @click="toggleTag(tag)"
      >
        {{ tag }}
      </el-tag>
    </div>

    <!-- ===== 推荐结果 ===== -->
    <div class="recommend-grid" v-if="recommendList.length > 0">
      <div
        v-for="item in recommendList"
        :key="item.sourceVodId || item.id"
        class="recommend-item"
        role="link"
        tabindex="0"
        :aria-label="`播放《${item.title}》`"
        @click="playRecommendation(item)"
        @keydown.enter="playRecommendation(item)"
        @keydown.space.prevent="playRecommendation(item)"
      >
        <div class="rec-cover">
          <img :src="item.cover" :alt="item.title" />
          <span class="rec-match">匹配度 {{ item.match }}%</span>
        </div>
        <div class="rec-info">
          <h4>{{ item.title }}</h4>
          <p class="rec-reason">💡 {{ item.reason }}</p>
        </div>
      </div>
    </div>

    <!-- ===== 空状态 ===== -->
    <div class="empty-state" v-else>
      <span class="empty-icon">🎯</span>
      <p>选择你的偏好标签，AI 将为你精准推荐</p>
      <p class="empty-hint">数据库中暂无符合当前偏好的动漫</p>
    </div>
  </div>
</template>

<script setup>
import { onMounted, ref } from 'vue'
import { useRouter } from 'vue-router'
import axios from 'axios'
import { aiApi } from '@/api/modules/ai'

const router = useRouter()
const availableTags = ref([])
const selectedTags = ref([])
const recommendList = ref([])
const loading = ref(false)

function toggleTag(tag) {
  const idx = selectedTags.value.indexOf(tag)
  if (idx > -1) {
    selectedTags.value.splice(idx, 1)
  } else {
    selectedTags.value = [tag]
  }
  fetchRecommendations()
}

function playRecommendation(item) {
  const sourceVodId = Number(item.sourceVodId || item.vod_id || 0)
  if (sourceVodId > 0) router.push(`/play/${sourceVodId}`)
}

async function fetchRecommendations() {
  loading.value = true
  try {
    const category = selectedTags.value[0] || availableTags.value[0] || ''
    const result = await aiApi.getRecommendations({ category })
    recommendList.value = (result?.recommendations || []).map(item => ({
      ...item,
      sourceVodId: Number(item.sourceVodId || item.vod_id || 0),
      match: item.score != null
        ? Math.max(1, Math.min(99, Math.round(Number(item.score) * 100)))
        : Math.min(99, Math.round(Number(item.rating || 0) * 10)),
      reason: item.description || `根据你对“${item.category || category}”分类的偏好推荐`
    })).filter(item => item.sourceVodId > 0)
  } catch (error) {
    console.error('[AiRecommend] 推荐加载失败:', error)
    recommendList.value = []
  } finally {
    loading.value = false
  }
}

onMounted(async () => {
  try {
    const { data } = await axios.get('/api/catalog/categories')
    availableTags.value = (data.data?.list || []).map(item => item.name)
    if (availableTags.value.length) selectedTags.value = [availableTags.value[0]]
  } catch (error) {
    console.warn('[AiRecommend] 分类加载失败:', error.message)
  }
  await fetchRecommendations()
})
</script>

<style scoped>
.ai-recommend {
  background: #fff;
  border-radius: 16px;
  padding: 24px;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.06);
}
.recommend-header {
  margin-bottom: 20px;
}
.recommend-header h3 { margin: 0 0 6px; font-size: 18px; color: #1a1a2e; }
.recommend-header p { margin: 0; font-size: 14px; color: #999; }

/* 偏好标签 */
.preference-tags {
  display: flex;
  align-items: center;
  gap: 8px;
  flex-wrap: wrap;
  margin-bottom: 20px;
  padding: 12px 16px;
  background: #fafbfc;
  border-radius: 12px;
}
.pref-label { font-size: 14px; color: #666; font-weight: 500; }
.pref-tag { cursor: pointer; }

/* 推荐网格 */
.recommend-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
  gap: 16px;
}
.recommend-item {
  display: flex;
  gap: 14px;
  padding: 16px;
  background: #fafbfc;
  border-radius: 12px;
  transition: all 0.3s ease;
  cursor: pointer;
  outline: none;
}
.recommend-item:focus-visible {
  box-shadow: 0 0 0 3px rgba(102,126,234,.2);
}
.recommend-item:hover {
  background: #f0f3ff;
  transform: translateX(4px);
}
.rec-cover {
  position: relative;
  width: 80px;
  height: 110px;
  border-radius: 8px;
  overflow: hidden;
  flex-shrink: 0;
}
.rec-cover img { width: 100%; height: 100%; object-fit: cover; }
.rec-match {
  position: absolute;
  bottom: 0;
  left: 0;
  right: 0;
  background: linear-gradient(135deg, #667eea, #764ba2);
  color: #fff;
  font-size: 10px;
  text-align: center;
  padding: 2px 0;
}
.rec-info h4 { margin: 0 0 6px; font-size: 15px; color: #333; }
.rec-reason { font-size: 13px; color: #888; line-height: 1.5; margin: 0; }

/* 空状态 */
.empty-state {
  text-align: center;
  padding: 40px;
}
.empty-icon { font-size: 48px; display: block; margin-bottom: 12px; }
.empty-state p { color: #999; margin: 4px 0; }
.empty-hint { font-size: 13px; color: #667eea !important; }
</style>
