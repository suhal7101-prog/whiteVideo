<!--
  AI 智能问答组件（扩展预留）

  规划功能：
  - 动漫知识问答（基于 RAG 检索增强生成）
  - 角色信息查询
  - 多轮对话
  技术栈：DeepSeek API + Chroma 向量检索
  当前状态：已接入后端 DeepSeek 对话接口
-->
<template>
  <div class="ai-chat">
    <!-- ===== 对话区域 ===== -->
    <div class="chat-messages" ref="chatMessages">
      <!-- 欢迎消息 -->
      <div class="chat-welcome" v-if="messages.length === 0">
        <div class="welcome-icon">🤖</div>
        <h3>白熊 AI 助手</h3>
        <p>我是你的动漫知识小助手！可以问我关于动漫的任何问题～</p>
        <div class="quick-questions">
          <span
            v-for="q in quickQuestions"
            :key="q"
            class="quick-q-tag"
            @click="sendMessage(q)"
          >
            {{ q }}
          </span>
        </div>
      </div>

      <!-- 消息列表 -->
      <div
        v-for="(msg, idx) in messages"
        :key="idx"
        class="chat-message"
        :class="msg.role"
      >
        <div class="msg-avatar">
          {{ msg.role === 'user' ? '👤' : '🤖' }}
        </div>
        <div class="msg-content">
          <div class="msg-text">{{ msg.content }}</div>
          <div class="msg-time">{{ msg.time }}</div>
        </div>
      </div>

      <!-- 加载状态 -->
      <div class="chat-message assistant" v-if="isThinking">
        <div class="msg-avatar">🤖</div>
        <div class="msg-content">
          <div class="thinking-dots">
            <span></span><span></span><span></span>
          </div>
        </div>
      </div>
    </div>

    <!-- ===== 输入区 ===== -->
    <div class="chat-input-area">
      <el-input
        v-model="inputText"
        type="textarea"
        :rows="2"
        placeholder="问我关于动漫的任何问题... 🎬"
        @keydown.enter.exact="handleEnter"
        resize="none"
      />
      <div class="input-actions">
        <span class="input-hint">
          已接入 DeepSeek + Chroma RAG
        </span>
        <el-button
          type="primary"
          round
          :disabled="!inputText.trim() || isThinking"
          @click="sendMessage()"
        >
          <el-icon><Promotion /></el-icon>
          发送
        </el-button>
      </div>
    </div>
  </div>
</template>

<script setup>
/**
 * AI 对话组件
 *
 * 通过后端 AI 接口获取真实回答。
 */
import { ref, nextTick } from 'vue'
import { aiApi } from '@/api/modules/ai'

// ===== 快捷问题 =====
const quickQuestions = [
  '完美世界讲了什么故事？',
  '推荐几部玄幻冒险动漫',
  '有哪些热血国漫值得看？',
  '介绍一下斗罗大陆系列'
]

// ===== 状态 =====
const chatMessages = ref(null)
const messages = ref([])
const inputText = ref('')
const isThinking = ref(false)

/** 发送消息 */
async function sendMessage(text) {
  const content = text || inputText.value.trim()
  if (!content) return

  // 添加用户消息
  messages.value.push({
    role: 'user',
    content,
    time: new Date().toLocaleTimeString()
  })
  inputText.value = ''

  // 滚动到底部
  await nextTick()
  scrollToBottom()

  isThinking.value = true
  try {
    const history = messages.value.slice(0, -1).map(({ role, content: messageContent }) => ({
      role,
      content: messageContent
    }))
    const result = await aiApi.chat(content, history)
    messages.value.push({
      role: 'assistant',
      content: result?.answer || '暂时没有获取到回答，请稍后重试。',
      time: new Date().toLocaleTimeString()
    })
  } catch (error) {
    console.error('[AiChat] 对话请求失败:', error)
    messages.value.push({
      role: 'assistant',
      content: 'AI 服务暂时不可用，请稍后重试。',
      time: new Date().toLocaleTimeString()
    })
  } finally {
    isThinking.value = false
  }

  await nextTick()
  scrollToBottom()
}

/** Enter 发送 */
function handleEnter(e) {
  if (!e.shiftKey) {
    e.preventDefault()
    sendMessage()
  }
}

/** 滚动到底部 */
function scrollToBottom() {
  if (chatMessages.value) {
    chatMessages.value.scrollTop = chatMessages.value.scrollHeight
  }
}

</script>

<style scoped>
.ai-chat {
  display: flex;
  flex-direction: column;
  height: 500px;
  background: #fff;
  border-radius: 16px;
  overflow: hidden;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.06);
}

/* ===== 消息区 ===== */
.chat-messages {
  flex: 1;
  overflow-y: auto;
  padding: 20px;
  background: #fafbfc;
}

/* 欢迎 */
.chat-welcome {
  text-align: center;
  padding: 40px 20px;
}
.welcome-icon { font-size: 56px; margin-bottom: 12px; }
.chat-welcome h3 {
  font-size: 20px;
  margin: 0 0 8px;
  background: linear-gradient(135deg, #667eea, #764ba2);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
}
.chat-welcome p { color: #888; font-size: 14px; margin: 0 0 16px; }

/* 快捷问题标签 */
.quick-questions {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  justify-content: center;
}
.quick-q-tag {
  padding: 6px 16px;
  background: linear-gradient(135deg, rgba(102,126,234,0.08), rgba(118,75,162,0.05));
  border: 1px solid rgba(102,126,234,0.2);
  border-radius: 20px;
  font-size: 13px;
  color: #667eea;
  cursor: pointer;
  transition: all 0.2s;
}
.quick-q-tag:hover {
  background: linear-gradient(135deg, #667eea, #764ba2);
  color: #fff;
  border-color: transparent;
}

/* 消息项 */
.chat-message {
  display: flex;
  gap: 12px;
  margin-bottom: 16px;
}
.chat-message.user { flex-direction: row-reverse; }
.msg-avatar {
  width: 36px;
  height: 36px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 20px;
  flex-shrink: 0;
  background: #f0f0f0;
}
.msg-content {
  max-width: 75%;
}
.chat-message.user .msg-content { text-align: right; }
.msg-text {
  padding: 10px 16px;
  border-radius: 16px;
  font-size: 14px;
  line-height: 1.6;
  white-space: pre-wrap;
}
.chat-message.user .msg-text {
  background: linear-gradient(135deg, #667eea, #764ba2);
  color: #fff;
  border-radius: 16px 4px 16px 16px;
}
.chat-message.assistant .msg-text {
  background: #fff;
  color: #333;
  border: 1px solid #eee;
  border-radius: 4px 16px 16px 16px;
}
.msg-time { font-size: 11px; color: #bbb; margin-top: 4px; }

/* 思考动画 */
.thinking-dots {
  display: flex;
  gap: 6px;
  padding: 12px 16px;
}
.thinking-dots span {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: #667eea;
  animation: dot-bounce 1.4s infinite ease-in-out both;
}
.thinking-dots span:nth-child(1) { animation-delay: -0.32s; }
.thinking-dots span:nth-child(2) { animation-delay: -0.16s; }
@keyframes dot-bounce {
  0%, 80%, 100% { transform: scale(0); }
  40% { transform: scale(1); }
}

/* ===== 输入区 ===== */
.chat-input-area {
  padding: 16px 20px;
  background: #fff;
  border-top: 1px solid #f0f0f0;
}
.chat-input-area :deep(.el-textarea__inner) {
  border-radius: 12px;
  background: #f8f9fb;
  border: 1px solid #eee;
  font-size: 14px;
}
.chat-input-area :deep(.el-textarea__inner:focus) {
  border-color: #667eea;
}
.input-actions {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-top: 10px;
}
.input-hint {
  font-size: 12px;
  color: #bbb;
}
</style>
