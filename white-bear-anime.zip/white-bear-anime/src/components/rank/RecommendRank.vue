<template>
  <div class="recommend-rank">
    <div class="recommend-header">
      <h3 class="recommend-title">⭐ 推荐榜</h3>
      <span class="recommend-more" @click="$emit('more')">更多 ›</span>
    </div>
    <div class="recommend-grid">
      <div
        v-for="item in items"
        :key="item.id"
        class="recommend-item"
        @click="$emit('itemClick', item)"
      >
        <div class="recommend-cover">
          <img :src="item.cover" :alt="item.title" />
          <span class="recommend-badge" v-if="item.badge">{{ item.badge }}</span>
        </div>
        <div class="recommend-info">
          <div class="recommend-title-text">{{ item.title }}</div>
          <div class="recommend-author">{{ item.author }}</div>
          <div class="recommend-views">{{ item.views }}</div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
defineProps({
  items: {
    type: Array,
    default: () => []
  }
})
defineEmits(['more', 'itemClick'])
</script>

<style scoped>
.recommend-rank {
  background: #fff;
  border-radius: 12px;
  padding: 16px 18px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.04);
}
.recommend-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 12px;
}
.recommend-title {
  font-size: 17px;
  font-weight: 700;
  margin: 0;
}
.recommend-more {
  font-size: 13px;
  color: #999;
  cursor: pointer;
}
.recommend-more:hover {
  color: #667eea;
}
.recommend-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(140px, 1fr));
  gap: 12px;
}
.recommend-item {
  cursor: pointer;
  transition: transform 0.2s;
}
.recommend-item:hover {
  transform: translateY(-2px);
}
.recommend-cover {
  position: relative;
  aspect-ratio: 16 / 9;
  border-radius: 8px;
  overflow: hidden;
  background: #1a1a2e;
}
.recommend-cover img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}
.recommend-badge {
  position: absolute;
  top: 6px;
  right: 6px;
  background: linear-gradient(135deg, #f093fb, #f5576c);
  color: #fff;
  padding: 2px 8px;
  border-radius: 10px;
  font-size: 10px;
  font-weight: 600;
}
.recommend-info {
  padding: 6px 4px 0;
}
.recommend-title-text {
  font-size: 13px;
  font-weight: 500;
  color: #333;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
  line-height: 1.3;
  min-height: 32px;
}
.recommend-author {
  font-size: 12px;
  color: #667eea;
  margin-top: 2px;
}
.recommend-views {
  font-size: 11px;
  color: #999;
}
</style>