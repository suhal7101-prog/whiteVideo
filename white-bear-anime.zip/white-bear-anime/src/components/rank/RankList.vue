<template>
  <div class="rank-list">
    <div class="rank-header">
      <h3 class="rank-title">
        <span class="rank-icon">{{ icon }}</span>
        {{ title }}
      </h3>
      <span class="rank-more" @click="$emit('more')">更多 ›</span>
    </div>
    <div class="rank-body">
      <slot>
        <!-- 默认显示列表 -->
        <div
          v-for="(item, index) in items"
          :key="item.id"
          class="rank-item"
          @click="$emit('itemClick', item)"
        >
          <span class="rank-number" :class="getRankClass(index)">
            {{ index + 1 }}
          </span>
          <div class="rank-item-info">
            <span class="rank-item-title">{{ item.title }}</span>
            <span class="rank-item-meta">{{ item.views || item.score }}</span>
          </div>
        </div>
      </slot>
    </div>
  </div>
</template>

<script setup>
import { computed } from 'vue'

const props = defineProps({
  title: {
    type: String,
    required: true
  },
  icon: {
    type: String,
    default: '🏆'
  },
  items: {
    type: Array,
    default: () => []
  }
})

defineEmits(['more', 'itemClick'])

const getRankClass = (index) => {
  if (index === 0) return 'rank-1'
  if (index === 1) return 'rank-2'
  if (index === 2) return 'rank-3'
  return ''
}
</script>

<style scoped>
.rank-list {
  background: #fff;
  border-radius: 12px;
  padding: 16px 18px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.04);
}
.rank-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 12px;
}
.rank-title {
  font-size: 17px;
  font-weight: 700;
  margin: 0;
  display: flex;
  align-items: center;
  gap: 6px;
}
.rank-icon {
  font-size: 20px;
}
.rank-more {
  font-size: 13px;
  color: #999;
  cursor: pointer;
  transition: color 0.2s;
}
.rank-more:hover {
  color: #667eea;
}
.rank-item {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 6px 0;
  cursor: pointer;
  transition: background 0.2s;
  border-radius: 6px;
}
.rank-item:hover {
  background: rgba(102, 126, 234, 0.05);
}
.rank-number {
  width: 28px;
  height: 28px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 50%;
  font-size: 14px;
  font-weight: 600;
  color: #999;
  flex-shrink: 0;
  background: #f5f7fa;
}
.rank-number.rank-1 {
  background: linear-gradient(135deg, #ffd700, #ffb800);
  color: #fff;
}
.rank-number.rank-2 {
  background: linear-gradient(135deg, #c0c0c0, #a8a8a8);
  color: #fff;
}
.rank-number.rank-3 {
  background: linear-gradient(135deg, #cd7f32, #b8722a);
  color: #fff;
}
.rank-item-info {
  flex: 1;
  display: flex;
  justify-content: space-between;
  align-items: center;
  min-width: 0;
}
.rank-item-title {
  font-size: 14px;
  color: #333;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  flex: 1;
}
.rank-item-meta {
  font-size: 12px;
  color: #999;
  flex-shrink: 0;
  margin-left: 8px;
}
</style>