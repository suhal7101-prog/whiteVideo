<template>
  <div class="top-rank">
    <div class="top-header">
      <div class="top-title-area">
        <span class="top-icon">🍌</span>
        <h3 class="top-title">香蕉榜</h3>
      </div>
      <div class="top-tabs">
        <span
          v-for="tab in tabs"
          :key="tab.key"
          class="top-tab"
          :class="{ active: activeTab === tab.key }"
          @click="activeTab = tab.key"
        >
          {{ tab.label }}
        </span>
      </div>
    </div>
    <div class="top-list">
      <div
        v-for="(item, index) in filteredItems"
        :key="item.id"
        class="top-item"
        @click="$emit('itemClick', item)"
      >
        <span class="top-number">{{ index + 1 }}</span>
        <div class="top-info">
          <span class="top-title-text">{{ item.title }}</span>
          <div class="top-meta">
            <span class="top-author">{{ item.author }}</span>
            <span class="top-score">🍌 {{ item.score || item.views }}</span>
          </div>
        </div>
        <span class="top-views">{{ item.views }}</span>
      </div>
    </div>
    <div class="top-footer" @click="$emit('more')">
      更多榜单 ›
    </div>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue'

const props = defineProps({
  items: {
    type: Array,
    default: () => []
  },
  tabs: {
    type: Array,
    default: () => [
      { key: 'day', label: '日榜' },
      { key: 'three', label: '三日' },
      { key: 'week', label: '周榜' }
    ]
  }
})

defineEmits(['more', 'itemClick'])

const activeTab = ref('day')

const filteredItems = computed(() => {
  // 实际可按 tab 过滤数据
  return props.items.slice(0, 8)
})
</script>

<style scoped>
.top-rank {
  background: #fff;
  border-radius: 12px;
  padding: 16px 18px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.04);
}
.top-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 12px;
}
.top-title-area {
  display: flex;
  align-items: center;
  gap: 6px;
}
.top-icon {
  font-size: 22px;
}
.top-title {
  font-size: 17px;
  font-weight: 700;
  margin: 0;
}
.top-tabs {
  display: flex;
  gap: 4px;
}
.top-tab {
  font-size: 13px;
  color: #999;
  padding: 2px 10px;
  border-radius: 12px;
  cursor: pointer;
  transition: all 0.2s;
}
.top-tab:hover {
  color: #667eea;
}
.top-tab.active {
  background: linear-gradient(135deg, #667eea, #764ba2);
  color: #fff;
}
.top-list {
  display: flex;
  flex-direction: column;
  gap: 2px;
}
.top-item {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 5px 0;
  cursor: pointer;
  border-bottom: 1px solid #f5f7fa;
  transition: background 0.2s;
}
.top-item:hover {
  background: rgba(102, 126, 234, 0.03);
}
.top-number {
  width: 24px;
  text-align: center;
  font-size: 13px;
  font-weight: 600;
  color: #ccc;
  flex-shrink: 0;
}
.top-item:nth-child(1) .top-number {
  color: #ffd700;
  font-size: 16px;
}
.top-item:nth-child(2) .top-number {
  color: #c0c0c0;
  font-size: 15px;
}
.top-item:nth-child(3) .top-number {
  color: #cd7f32;
  font-size: 14px;
}
.top-info {
  flex: 1;
  min-width: 0;
}
.top-title-text {
  font-size: 14px;
  color: #333;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.top-meta {
  display: flex;
  gap: 12px;
  font-size: 12px;
  color: #999;
}
.top-author {
  color: #667eea;
}
.top-score {
  color: #f5a623;
}
.top-views {
  font-size: 12px;
  color: #999;
  flex-shrink: 0;
}
.top-footer {
  text-align: center;
  padding-top: 10px;
  font-size: 13px;
  color: #999;
  cursor: pointer;
  transition: color 0.2s;
}
.top-footer:hover {
  color: #667eea;
}
</style>