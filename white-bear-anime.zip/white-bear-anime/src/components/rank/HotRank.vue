<template>
  <div class="hot-rank">
    <div class="hot-header">
      <h3 class="hot-title">🔥 热播榜</h3>
      <span class="hot-more" @click="$emit('more')">更多 ›</span>
    </div>
    <div class="hot-list">
      <div
        v-for="(item, index) in items"
        :key="item.id"
        class="hot-item"
        @click="$emit('itemClick', item)"
      >
        <span class="hot-number">{{ index + 1 }}</span>
        <div class="hot-info">
          <span class="hot-title-text">{{ item.title }}</span>
          <span class="hot-author">{{ item.author }}</span>
        </div>
        <span class="hot-views">{{ item.views }}</span>
      </div>
    </div>
  </div>
</template>

<script setup>
defineProps({
  items: {
    type: Array,
    default: () => []
  }
})
defineEmits(['more', 'itemClick'])
</script>

<style scoped>
.hot-rank {
  background: #fff;
  border-radius: 12px;
  padding: 16px 18px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.04);
}
.hot-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 12px;
}
.hot-title {
  font-size: 17px;
  font-weight: 700;
  margin: 0;
}
.hot-more {
  font-size: 13px;
  color: #999;
  cursor: pointer;
}
.hot-more:hover {
  color: #667eea;
}
.hot-list {
  display: flex;
  flex-direction: column;
  gap: 4px;
}
.hot-item {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 6px 8px;
  border-radius: 8px;
  cursor: pointer;
  transition: background 0.2s;
}
.hot-item:hover {
  background: rgba(102, 126, 234, 0.05);
}
.hot-number {
  width: 24px;
  text-align: center;
  font-size: 14px;
  font-weight: 600;
  color: #bbb;
  flex-shrink: 0;
}
.hot-item:nth-child(1) .hot-number {
  color: #ffd700;
}
.hot-item:nth-child(2) .hot-number {
  color: #c0c0c0;
}
.hot-item:nth-child(3) .hot-number {
  color: #cd7f32;
}
.hot-info {
  flex: 1;
  display: flex;
  flex-direction: column;
  min-width: 0;
}
.hot-title-text {
  font-size: 14px;
  color: #333;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.hot-author {
  font-size: 12px;
  color: #999;
}
.hot-views {
  font-size: 12px;
  color: #999;
  flex-shrink: 0;
}
</style>