<!--
  播放页 v5.0 — 沉浸式 · Outcome-Oriented
  数据来源: 红牛资源 → 后端 API

  布局:
  ┌──────────────────────────────────────┐
  │ 标题 · 分类 · 年份 · 共N集              │
  ├──────────────────────┬───────────────┤
  │                      │ 作者          │
  │  BiliPlayer (16:9)   │ 选集 (折叠)   │
  │                      │ 相关推荐      │
  │ 评论 ▸ (折叠)         │ (sticky/scroll)│
  └──────────────────────┴───────────────┘
-->
<template>
  <div class="pp">

    <!-- ===== 1. 播放器 + 侧栏 ===== -->
    <div class="pp-body">
      <div class="pp-left">
        <!-- 加载状态 -->
        <div v-if="loading" class="pp-loading-wrap">
          <div class="pp-loading">
            <LoaderSpin />
            <span>加载中...</span>
          </div>
        </div>

        <!-- 错误状态 -->
        <div v-else-if="fetchError" class="pp-error-wrap">
          <div class="pp-error">
            <span>⚠️ 视频加载失败</span>
            <p>{{ fetchError }}</p>
            <button @click="fetchDetail">重试</button>
          </div>
        </div>

        <!-- Video.js 播放器 -->
        <BiliPlayer
          v-else
          ref="playerRef"
          :sources="videoSources"
          :poster="proxyCover"
          :anime-id="vodId"
          :episode-id="curEp?.id"
          :title="playerTitle"
          @ended="onEpisodeEnd"
          @danmakuSent="onDanmaku"
          @next="nextEp"
        />

        <!-- 评论区 (折叠) -->
        <div class="pp-cmt">
          <h3 class="pp-cmt-title">💬 评论 ({{ totalCommentCount }})</h3>
          <div class="pp-cmt-inner">
            <div class="pp-cmt-post">
              <UserAvatar :size="36" :src="myAvatar" :name="userStore.username" :user-id="userStore.userInfo?.id" />
              <div class="pp-cmt-post-right">
                <div v-if="replyTarget" class="pp-cmt-replying">
                  <span>正在回复 <strong>@{{ replyTarget.user }}</strong></span>
                  <button type="button" @click="cancelReply">取消</button>
                </div>
                <el-input ref="commentInputRef" v-model="newCmt" type="textarea" :rows="2"
                  :placeholder="replyTarget ? `回复 @${replyTarget.user}` : '发一条友善的评论吧~'" resize="none" />
                <div class="pp-cmt-post-ft">
                  <span class="pp-cmt-hint">友善交流</span>
                  <button class="pp-cmt-send" @click="postCmt" :disabled="!newCmt.trim() || commentSubmitting">
                    {{ commentSubmitting ? '提交中...' : (replyTarget ? '回复' : '发表') }}
                  </button>
                </div>
              </div>
            </div>
            <div v-if="commentLoading" class="pp-cmt-empty">评论加载中...</div>
            <div v-else-if="comments.length" class="pp-cmt-list">
              <div v-for="c in showComments" :key="c.id" class="pp-cmt-item">
                <UserAvatar :size="40" :src="c.avatar" :name="c.user" :user-id="c.userId" style="cursor:pointer" @click="openUser(c.user)" />
                <div class="pp-cmt-body">
                  <div class="pp-cmt-top">
                    <span class="pp-cmt-name" style="cursor:pointer" @click="openUser(c.user)">{{ c.user }}</span>
                    <span v-if="c.isAuthor" class="pp-cmt-owner-badge">楼主</span>
                    <span class="pp-cmt-time">{{ c.time }}</span>
                  </div>
                  <p class="pp-cmt-text">
                    <span v-if="c.replyTo" class="pp-cmt-reply-to">回复 @{{ c.replyTo }}：</span>{{ c.content }}
                  </p>
                  <div class="pp-cmt-ft">
                    <EngagementAction type="like" :count="c.likes || 0" :active="c.liked" :disabled="c.likeLoading" clickable @click="handleLikeComment(c)" />
                    <EngagementAction type="comment" label="回复" clickable @click="handleReplyComment(c)" />
                  </div>
                  <div v-if="c.replies?.length" class="pp-cmt-replies">
                    <div v-for="reply in c.replies" :key="reply.id" class="pp-cmt-reply-item">
                      <span class="pp-cmt-reply-user" @click="openUser(reply.user)">{{ reply.user }}</span>
                      <span v-if="reply.isAuthor" class="pp-cmt-owner-badge">楼主</span>
                      <span v-if="reply.replyTo" class="pp-cmt-reply-target">回复 @{{ reply.replyTo }}：</span>
                      <span class="pp-cmt-reply-content">{{ reply.content }}</span>
                    </div>
                  </div>
                </div>
              </div>
              <!-- 登录查看更多 -->
              <div v-if="showCommentLoginPrompt" class="pp-cmt-login">
                <span>登录后查看更多评论</span>
                <router-link :to="{ name: 'Login', query: { redirect: route.fullPath } }">立即登录</router-link>
              </div>
            </div>
            <div class="pp-cmt-empty" v-else>还没有评论，来抢沙发吧~</div>
          </div>
        </div>
      </div>

      <!-- 右侧栏 -->
      <aside class="pp-right">
        <!-- 作者/简介 -->
        <div class="pp-card">
          <div class="pp-author">
            <el-avatar :size="44" :src="proxyCover" />
            <div class="pp-author-info">
              <span class="pp-author-name">{{ anime.title }}</span>
              <span class="pp-author-sub" v-if="anime.director">导演: {{ anime.director }}</span>
              <span class="pp-author-sub" v-else>{{ anime.category || '未知' }}</span>
            </div>
          </div>
          <p class="pp-desc" v-if="anime.desc">{{ anime.desc }}</p>
          <div class="pp-author-acts">
            <button class="pp-author-btn" :class="{ on: favorited }" @click="toggleFavorite">
              {{ favorited ? '已追番' : '追番' }}
            </button>
            <button class="pp-author-btn pp-video-like-btn" :class="{ on: videoLiked }" @click="toggleVideoLike">
              <EngagementAction type="like" :active="videoLiked" />
              {{ videoLiked ? '已点赞' : '点赞' }} {{ fmtNum(videoLikes) }}
            </button>
            <button class="pp-author-btn" @click="handleShare"><EngagementAction type="share" />分享</button>
          </div>
        </div>

        <!-- 选集 (全部) -->
        <div class="pp-card">
          <h3 class="pp-ep-title">
            选集
            <span class="pp-ep-count">(共 {{ anime.episodes.length }} 集)</span>
          </h3>
          <!-- 超过50集 → 固定高度滚动 -->
          <div
            v-if="anime.episodes.length > 0"
            class="pp-ep-scroll"
            :class="{ 'pp-ep-scroll--active': anime.episodes.length > 50 }"
          >
            <div class="pp-ep-grid">
              <button
                v-for="ep in displayEps" :key="ep.id"
                class="pp-ep"
                :class="{ on: curEp && curEp.id === ep.id }"
                @click="switchEp(ep)"
              >
                {{ ep.episodeNum }}
              </button>
            </div>
          </div>
          <div class="pp-ep-empty" v-else>
            暂无剧集信息
          </div>
        </div>

        <!-- 相关推荐 (sticky, 独立滚动, 懒加载) -->
        <div class="pp-rel" ref="relRef">
          <h3>相关推荐</h3>
          <div class="pp-rel-inner" ref="relScroll">
            <div
              v-for="item in displayRel"
              :key="item.id"
              class="pp-rel-item"
              tabindex="0" role="link"
              :aria-label="item.title"
              @click="openRelated(item.id)"
              @keydown.enter="openRelated(item.id)"
            >
              <div class="pp-rel-cover">
                <img :src="item.cover" :alt="item.title" loading="lazy" />
                <span class="pp-rel-dur">{{ item.duration }}</span>
              </div>
              <div class="pp-rel-info">
                <div class="pp-rel-title">{{ item.title }}</div>
                <div class="pp-rel-meta">{{ item.author }} · {{ item.views }}</div>
              </div>
            </div>
            <div class="pp-rel-sentinel" ref="sentRef">
              <span v-if="relLoading" class="pp-rel-loading"><LoaderSpin :duration="'2s'" /> 加载中...</span>
              <span v-else-if="relEnd">— 没有更多了 —</span>
            </div>
          </div>
        </div>
      </aside>
    </div>
  </div>
</template>

<script setup>
/**
 * Player.vue — 播放页
 *
 * 数据流:
 *   1. 从路由获取 vod_id
 *   2. 调用 /api/anime/detail/{vod_id} 获取详情 + 剧集
 *   3. 播放时使用剧集中已有的 m3u8 地址
 *   4. 通过 HLS 代理处理 CORS / referrer 限制
 */
import { ref, reactive, computed, onMounted, onUnmounted, watch, nextTick } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import { useAuth } from '@/composables/useAuth'
import { useUserStore } from '@/stores/user'
import { userApi } from '@/api/modules/user'
import { communityApi } from '@/api/modules/community'
import axios from 'axios'
import BiliPlayer from '@/components/player/BiliPlayer.vue'
import LoaderSpin from '@/components/common/LoaderSpin.vue'
import UserAvatar from '@/components/common/UserAvatar.vue'
import EngagementAction from '@/components/common/EngagementAction.vue'

const route = useRoute()
const router = useRouter()
const { requireAuth } = useAuth()
const userStore = useUserStore()

const vodId = computed(() => Number(route.params.id) || 0)
const isDatabaseVideo = computed(() => route.query.source === 'db')

// ===== 状态 =====
const loading = ref(true)
const fetchError = ref('')
const playerRef = ref(null)
const newCmt = ref('')
const commentInputRef = ref(null)
const myAvatar = computed(() => userStore.avatar || '')

const anime = reactive({
  id: 0,
  title: '加载中...',
  cover: '',
  desc: '',
  director: '',
  actor: '',
  year: '',
  category: '',
  status: '',
  uploaderId: null,
  episodes: [],
})

const curEp = ref(null)
const videoSources = ref([])
const favorited = ref(false)
const videoLiked = ref(false)
const videoLikes = ref(0)

// ===== 计算属性 =====
const proxyCover = computed(() => {
  if (!anime.cover) return ''
  if (anime.cover.startsWith('/') || isDatabaseVideo.value) return anime.cover
  return `/api/proxy/image?url=${encodeURIComponent(anime.cover)}`
})

const playerTitle = computed(() => {
  if (!curEp.value) return anime.title
  return `${anime.title} - 第${curEp.value.episodeNum}集`
})

const displayEps = computed(() => anime.episodes)

const commentSourceType = computed(() => isDatabaseVideo.value ? 'db' : 'source')
const totalCommentCount = computed(() => comments.value.reduce(
  (total, comment) => total + 1 + (comment.replies?.length || 0),
  0,
))
const showComments = computed(() => userStore.isLoggedIn ? comments.value : comments.value.slice(0, 1))
const showCommentLoginPrompt = computed(() => !userStore.isLoggedIn && comments.value.length > 1)

// ===== 数据获取 =====
async function fetchDetail() {
  loading.value = true
  fetchError.value = ''

  try {
    const endpoint = isDatabaseVideo.value
      ? `/api/catalog/${vodId.value}`
      : `/api/anime/detail/${vodId.value}`
    const { data } = await axios.get(endpoint)

    if (data.code !== 200) {
      throw new Error('API 返回错误')
    }

    const raw = data.data
    const d = isDatabaseVideo.value
      ? { ...raw.video, desc: raw.video?.description, vod_id: raw.video?.id, episodes: raw.episodes || [] }
      : raw
    Object.assign(anime, {
      id: d.vod_id,
      title: d.title,
      cover: d.cover,
      desc: d.desc,
      director: d.director,
      actor: d.actor,
      year: d.year,
      category: d.category,
      status: d.status,
      uploaderId: d.uploaderId || null,
      episodes: (d.episodes || []).map((ep, i) => ({
        id: ep.id ?? i,
        episodeNum: ep.episodeNum ?? i + 1,
        title: ep.title,
        url: ep.videoUrl || ep.url,
        quality: ep.quality || '1080P',
      })),
    })

    // 自动选择 URL 指定剧集，默认第一集。
    if (anime.episodes.length > 0) {
      const requestedEpisode = Number(route.query.ep) || 1
      const selected = anime.episodes.find(ep => ep.episodeNum === requestedEpisode) || anime.episodes[0]
      curEp.value = selected
      updateSources(selected)
      recordPlay(selected)
    } else {
      videoSources.value = []
    }

    await fetchVideoActionState()
    await fetchComments()

    loading.value = false
  } catch (e) {
    console.error('[Player] 数据加载失败:', e.message)
    fetchError.value = e.response?.data?.detail || e.message || '加载失败'
    loading.value = false
  }
}

/**
 * 更新播放源
 * - 优先使用原始 m3u8 地址 (已验证可用且带 CORS 头)
 * - 同时提供 HLS 代理地址作为备用
 */
function updateSources(ep) {
  if (!ep?.url) {
    videoSources.value = []
    return
  }

  if (ep.url.startsWith('/')) {
    videoSources.value = [{ quality: ep.quality, url: ep.url, type: 'application/x-mpegURL' }]
    return
  }

  // 主播放源: HLS 代理 (安全、绕过 referrer 限制)
  const hlsProxy = `/api/proxy/hls/playlist?url=${encodeURIComponent(ep.url)}`

  // 备用: 直接 m3u8 地址 (已确认有 CORS 头)
  videoSources.value = [
    { quality: ep.quality, url: hlsProxy, type: 'application/x-mpegURL' },
    { quality: `${ep.quality}-直连`, url: ep.url, type: 'application/x-mpegURL' },
  ]
}

// ===== 剧集切换 =====
function switchEp(ep) {
  curEp.value = ep
  updateSources(ep)
  recordPlay(ep)

  // 超过50集时自动滚动选集区到当前集
  if (anime.episodes.length > 50) {
    nextTick(() => {
      const active = document.querySelector('.pp-ep.on')
      active?.scrollIntoView({ behavior: 'smooth', block: 'nearest' })
    })
  }

  window.scrollTo({ top: 0, behavior: 'smooth' })
}

function nextEp() {
  if (!curEp.value) return
  const idx = anime.episodes.findIndex((e) => e.id === curEp.value.id)
  if (idx < anime.episodes.length - 1) {
    switchEp(anime.episodes[idx + 1])
  } else {
    ElMessage.info('已经是最后一集了~')
  }
}

function onEpisodeEnd() {
  nextEp()
}

function onDanmaku(dm) {
  console.log('[弹幕]', dm.text)
}

// ===== 评论 =====
const comments = ref([])
const commentLoading = ref(false)
const commentSubmitting = ref(false)
const replyTarget = ref(null)

function fmtNum(n) {
  if (!n) return '0'
  if (n >= 10000) return (n / 10000).toFixed(1) + '万'
  return String(n)
}

function formatCommentTime(value) {
  if (!value) return '刚刚'
  const date = new Date(value)
  if (Number.isNaN(date.getTime())) return value
  const diff = Date.now() - date.getTime()
  if (diff < 60_000) return '刚刚'
  if (diff < 3_600_000) return `${Math.floor(diff / 60_000)}分钟前`
  if (diff < 86_400_000) return `${Math.floor(diff / 3_600_000)}小时前`
  return date.toLocaleDateString('zh-CN')
}

function mapVideoComment(comment) {
  return {
    id: comment.id,
    userId: comment.userId,
    user: comment.username || '匿名用户',
    avatar: comment.avatar || '',
    content: comment.content || '',
    time: formatCommentTime(comment.createTime),
    likes: Number(comment.likes || 0),
    liked: Boolean(comment.liked),
    parentId: comment.parentId || null,
    replyTo: comment.replyTo || '',
    isAuthor: Number(comment.userId || 0) > 0
      && Number(comment.userId) === Number(anime.uploaderId || 0),
    replies: [],
    likeLoading: false,
  }
}

function groupVideoComments(list) {
  const mapped = (list || []).map(mapVideoComment)
  const commentById = new Map(mapped.map(comment => [Number(comment.id), comment]))
  const roots = []
  mapped.forEach(comment => {
    let parent = commentById.get(Number(comment.parentId))
    if (!parent) {
      roots.push(comment)
      return
    }
    const visited = new Set([Number(comment.id)])
    while (parent?.parentId && !visited.has(Number(parent.id))) {
      visited.add(Number(parent.id))
      const nextParent = commentById.get(Number(parent.parentId))
      if (!nextParent) break
      parent = nextParent
    }
    parent.replies.push(comment)
  })
  return roots
}

function insertVideoComment(comment) {
  if (!comment.parentId) {
    comments.value.unshift(comment)
    return
  }
  const parentId = Number(comment.parentId)
  const root = comments.value.find(item =>
    Number(item.id) === parentId
      || item.replies?.some(reply => Number(reply.id) === parentId),
  )
  if (root) root.replies.unshift(comment)
  else comments.value.unshift(comment)
}

async function fetchComments() {
  if (!vodId.value) return
  commentLoading.value = true
  try {
    const data = await communityApi.getVideoComments(vodId.value, commentSourceType.value)
    comments.value = groupVideoComments(data?.list || [])
  } catch (error) {
    console.warn('[Player] 评论加载失败:', error.message)
    comments.value = []
  } finally {
    commentLoading.value = false
  }
}

async function postCmt() {
  if (!requireAuth()) return
  const content = newCmt.value.trim()
  if (!content || commentSubmitting.value) return
  commentSubmitting.value = true
  try {
    const created = await communityApi.addVideoComment({
      videoId: vodId.value,
      sourceType: commentSourceType.value,
      parentId: replyTarget.value?.id || null,
      content,
    })
    insertVideoComment(mapVideoComment(created))
    newCmt.value = ''
    replyTarget.value = null
    ElMessage.success('评论成功')
  } catch (error) {
    ElMessage.error(error.message || '评论失败')
  } finally {
    commentSubmitting.value = false
  }
}

async function handleLikeComment(c) {
  if (!requireAuth()) return
  if (c.likeLoading) return
  c.likeLoading = true
  try {
    const state = await communityApi.toggleVideoCommentLike(c.id)
    c.liked = Boolean(state?.liked)
    c.likes = Number(state?.likes || 0)
  } catch (error) {
    ElMessage.error(error.message || '点赞操作失败')
  } finally {
    c.likeLoading = false
  }
}

function handleReplyComment(c) {
  if (!requireAuth()) return
  replyTarget.value = c
  newCmt.value = ''
  nextTick(() => commentInputRef.value?.focus())
}

function cancelReply() {
  replyTarget.value = null
  newCmt.value = ''
}

async function handleShare() {
  if (!requireAuth()) return
  try {
    await navigator.clipboard.writeText(window.location.href)
    ElMessage.success('链接已复制到剪贴板 📋')
  } catch {
    ElMessage.info('分享链接: ' + window.location.href)
  }
}

function openUser(name) {
  router.push(`/home/${encodeURIComponent(name)}`)
}

function videoActionPayload() {
  return {
    videoId: isDatabaseVideo.value ? vodId.value : null,
    sourceVodId: isDatabaseVideo.value ? null : vodId.value,
    title: anime.title,
    cover: anime.cover,
    category: anime.category,
    description: anime.desc,
    status: anime.status,
    episodes: anime.episodes.length,
    year: Number(anime.year) || null,
  }
}

function applyVideoActionState(state) {
  favorited.value = Boolean(state?.favorited)
  videoLiked.value = Boolean(state?.liked)
  videoLikes.value = Number(state?.likes || 0)
}

async function fetchVideoActionState() {
  if (!userStore.isLoggedIn || !vodId.value || !anime.title) {
    applyVideoActionState(null)
    return
  }
  try {
    applyVideoActionState(await userApi.getVideoActionState(videoActionPayload()))
  } catch (error) {
    console.warn('[Player] 用户视频状态加载失败:', error.message)
  }
}

async function toggleFavorite() {
  if (!requireAuth()) return
  try {
    const state = await userApi.toggleVideoFavorite(videoActionPayload())
    applyVideoActionState(state)
    ElMessage.success(state.favorited ? '追番成功' : '已取消追番')
  } catch (error) {
    ElMessage.error(error.message || '追番操作失败')
  }
}

async function toggleVideoLike() {
  if (!requireAuth()) return
  try {
    const state = await userApi.toggleVideoLike(videoActionPayload())
    applyVideoActionState(state)
    ElMessage.success(state.liked ? '点赞成功' : '已取消点赞')
  } catch (error) {
    ElMessage.error(error.message || '点赞操作失败')
  }
}

// ===== 相关推荐 (真实数据 + 懒加载分页) =====
const allRel = ref([])
const relPage = ref(1)
const relLoading = ref(false)
const relEnd = ref(false)
const sentRef = ref(null)
const relScroll = ref(null)
let obs = null

const displayRel = computed(() => allRel.value)

async function fetchRelated(page = 1) {
  if (relLoading.value || relEnd.value) return
  relLoading.value = true
  try {
    const endpoint = isDatabaseVideo.value
      ? `/api/catalog/${vodId.value}/related`
      : `/api/anime/related/${vodId.value}`
    const { data } = await axios.get(endpoint, { params: { page, count: 10 } })
    if (data.code === 200) {
      const items = data.data.list.map(v => ({
        id: v.vod_id,
        title: v.title,
        cover: v.cover_proxy || v.cover,
        author: v.category || '',
        views: v.status || '',
        duration: v.year || '',
      }))
      if (page === 1) {
        allRel.value = items
      } else {
        allRel.value = [...allRel.value, ...items]
      }
      relPage.value = page
      if (items.length < 10) relEnd.value = true
    } else {
      relEnd.value = true
    }
  } catch (e) {
    console.warn('[Player] 相关推荐获取失败:', e.message)
    relEnd.value = true
  } finally {
    relLoading.value = false
  }
}

function openRelated(id) {
  const query = isDatabaseVideo.value ? '?source=db' : ''
  router.push(`/play/${id}${query}`)
}

async function recordPlay(ep) {
  try {
    let response
    const headers = userStore.token ? { Authorization: `Bearer ${userStore.token}` } : {}
    if (isDatabaseVideo.value) {
      response = await axios.post('/api/catalog/play', null, {
        params: { videoId: vodId.value, episodeId: ep?.id },
        headers
      })
    } else if (vodId.value) {
      response = await axios.post('/api/catalog/play-by-source', null, {
        params: { sourceVodId: vodId.value },
        headers
      })
    }
    if (response && response.data?.code !== 200) {
      console.warn('[Player] 播放统计未写入:', response.data?.message)
    }
  } catch (error) {
    console.warn('[Player] 播放统计记录失败:', error.message)
  }
}

function loadMore() {
  if (!relLoading.value && !relEnd.value) {
    fetchRelated(relPage.value + 1)
  }
}

// ===== 生命周期 =====
onMounted(() => {
  fetchDetail()
  fetchRelated(1)

  obs = new IntersectionObserver(
    ([e]) => {
      if (e.isIntersecting) loadMore()
    },
    {
      root: relScroll.value,
      rootMargin: '150px',
    }
  )
  if (sentRef.value) obs.observe(sentRef.value)
})

onUnmounted(() => {
  if (obs) obs.disconnect()
})

// 路由参数变化时重新获取
watch(
  () => [route.params.id, route.query.source],
  () => {
    if (route.params.id) {
      applyVideoActionState(null)
      comments.value = []
      replyTarget.value = null
      newCmt.value = ''
      allRel.value = []
      relPage.value = 1
      relEnd.value = false
      fetchDetail()
      fetchRelated(1)
      window.scrollTo({ top: 0, behavior: 'smooth' })
    }
  }
)

watch(
  () => userStore.isLoggedIn,
  () => fetchComments()
)
</script>

<style scoped>
/* ================================================================
   Design Tokens (scoped):
   --bg:      #f5f6fa
   --card:    #ffffff
   --t1:      #1a1a2e
   --t2:      #585a6e
   --t3:      #8f92a1
   --accent:  #7c5ce7
   --r-sm:    6px
   --r-md:    10px
   ================================================================ */
.pp {
  max-width: 1280px;
  margin: 0 auto;
  padding: 16px 16px 48px;
}

/* 加载 / 错误状态 */
.pp-loading-wrap,
.pp-error-wrap {
  position: relative;
  width: 100%;
  aspect-ratio: 16 / 9;
  background: #000;
  border-radius: 10px;
  display: flex;
  align-items: center;
  justify-content: center;
}

.pp-loading {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 12px;
  color: rgba(255, 255, 255, 0.7);
  font-size: 14px;
}

.pp-error {
  text-align: center;
  color: #999;
  max-width: 400px;
}

.pp-error span {
  font-size: 16px;
  color: #e74c3c;
}

.pp-error p {
  font-size: 13px;
  margin: 8px 0 12px;
  color: #999;
  word-break: break-all;
}

.pp-error button {
  padding: 8px 28px;
  border: 1px solid rgba(255, 255, 255, 0.25);
  border-radius: 6px;
  background: transparent;
  color: #fff;
  cursor: pointer;
  font-size: 13px;
}

.pp-error button:hover {
  background: rgba(255, 255, 255, 0.1);
}

/* 1. 标题 */
.pp-head {
  margin-bottom: 14px;
}

.pp-title {
  font-size: 1.375rem;
  font-weight: 800;
  margin: 0 0 6px;
  color: #1a1a2e;
  letter-spacing: -0.01em;
}

.pp-stats {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 0.8125rem;
  color: #8f92a1;
}

.pp-stat {
  display: inline-flex;
  align-items: center;
  gap: 3px;
}

.pp-dot {
  color: #c4c6d0;
}

/* 2. 双栏 */
.pp-body {
  display: flex;
  gap: 16px;
  align-items: flex-start;
}

.pp-left {
  flex: 1;
  min-width: 0;
}

.pp-right {
  width: 280px;
  flex-shrink: 0;
  display: flex;
  flex-direction: column;
  gap: 12px;
}

/* 卡片 */
.pp-card {
  background: #fff;
  border-radius: 10px;
  padding: 14px 16px;
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.04);
}

/* 作者 */
.pp-author {
  display: flex;
  align-items: center;
  gap: 10px;
  margin-bottom: 12px;
}

.pp-author-info {
  flex: 1;
  min-width: 0;
}

.pp-author-name {
  font-size: 0.8125rem;
  font-weight: 600;
  color: #1a1a2e;
  display: block;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.pp-author-sub {
  font-size: 0.75rem;
  color: #8f92a1;
}

.pp-author-acts {
  display: flex;
  gap: 8px;
  margin-bottom: 10px;
}

.pp-author-btn {
  flex: 1;
  padding: 8px 0;
  border-radius: 18px;
  border: 1px solid rgba(0, 0, 0, 0.1);
  background: #fff;
  color: #585a6e;
  font-size: 0.75rem;
  cursor: pointer;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 5px;
  transition: all 0.15s;
}

.pp-author-btn:hover,
.pp-author-btn.on {
  border-color: #7c5ce7;
  color: #7c5ce7;
  background: rgba(124, 92, 231, 0.05);
}

.pp-video-like-btn.on,
.pp-video-like-btn.on:hover {
  border-color: rgba(231, 76, 60, 0.35);
  color: #e74c3c;
  background: rgba(231, 76, 60, 0.05);
}

.pp-desc {
  margin: 8px 0 0;
  font-size: 0.75rem;
  color: #8f92a1;
  line-height: 1.6;
  display: -webkit-box;
  -webkit-line-clamp: 3;
  -webkit-box-orient: vertical;
  overflow: hidden;
}

/* 选集 */
.pp-ep-title {
  margin: 0 0 10px;
  font-size: 0.8125rem;
  font-weight: 600;
  color: #1a1a2e;
}

.pp-ep-count {
  font-weight: 400;
  color: #8f92a1;
  font-size: 0.75rem;
}

.pp-ep-scroll--active {
  max-height: 280px;
  overflow-y: auto;
  scrollbar-width: thin;
  scrollbar-color: rgba(0,0,0,.12) transparent;
  padding-right: 4px;
}
.pp-ep-scroll--active::-webkit-scrollbar { width: 4px; }
.pp-ep-scroll--active::-webkit-scrollbar-thumb {
  background: rgba(0,0,0,.12);
  border-radius: 2px;
}

.pp-ep-grid {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
}

.pp-ep {
  min-width: 40px;
  min-height: 40px;
  padding: 6px 4px;
  border-radius: 6px;
  border: 1px solid rgba(0, 0, 0, 0.1);
  background: #fff;
  color: #585a6e;
  font-size: 0.75rem;
  cursor: pointer;
  transition: all 0.15s;
}

.pp-ep:hover {
  border-color: #7c5ce7;
  color: #7c5ce7;
}

.pp-ep.on {
  background: linear-gradient(135deg, #7c5ce7, #a855f7);
  border-color: transparent;
  color: #fff;
}

.pp-ep-empty {
  text-align: center;
  padding: 16px;
  font-size: 0.8125rem;
  color: #8f92a1;
}

/* 相关推荐 */
.pp-rel {
  background: #fff;
  border-radius: 10px;
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.04);
  position: sticky;
  top: 80px;
  max-height: calc(100vh - 100px);
  display: flex;
  flex-direction: column;
}

.pp-rel h3 {
  margin: 0;
  padding: 14px 16px 8px;
  font-size: 1rem;
  font-weight: 700;
  color: #1a1a2e;
  flex-shrink: 0;
}

.pp-rel-inner {
  overflow-y: auto;
  flex: 1;
  padding: 0 16px 14px;
  scrollbar-width: thin;
}

.pp-rel-inner::-webkit-scrollbar {
  width: 5px;
}

.pp-rel-inner::-webkit-scrollbar-thumb {
  background: rgba(0, 0, 0, 0.08);
  border-radius: 3px;
}

.pp-rel-item {
  display: flex;
  gap: 10px;
  margin-bottom: 12px;
  cursor: pointer;
  border-radius: 6px;
  padding: 4px;
  transition: background 0.12s;
  outline: none;
}

.pp-rel-item:hover,
.pp-rel-item:focus-visible {
  background: #f8f9ff;
}

.pp-rel-cover {
  position: relative;
  width: 120px;
  aspect-ratio: 16 / 9;
  border-radius: 6px;
  overflow: hidden;
  flex-shrink: 0;
}

.pp-rel-cover img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  display: block;
}

.pp-rel-dur {
  position: absolute;
  bottom: 4px;
  right: 4px;
  background: rgba(0, 0, 0, 0.75);
  color: #fff;
  padding: 1px 6px;
  border-radius: 4px;
  font-size: 11px;
}

.pp-rel-info {
  flex: 1;
  min-width: 0;
}

.pp-rel-title {
  font-size: 0.75rem;
  font-weight: 500;
  color: #1a1a2e;
  line-height: 1.4;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
  margin-bottom: 4px;
}

.pp-rel-meta {
  font-size: 11px;
  color: #8f92a1;
}

.pp-rel-sentinel {
  text-align: center;
  padding: 14px 0 4px;
  font-size: 0.75rem;
  color: #8f92a1;
}
.pp-rel-loading {
  display: flex; align-items: center; justify-content: center; gap: 6px;
}

/* 评论 */
.pp-cmt {
  margin-top: 16px;
  background: #fff;
  border-radius: 16px;
  padding: 24px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.04);
}

.pp-cmt-title {
  margin: 0 0 18px;
  font-size: 18px;
  font-weight: 700;
  color: #1a1a2e;
}

.pp-cmt-inner {
}

.pp-cmt-post {
  display: flex;
  gap: 12px;
  align-items: flex-start;
  margin-bottom: 24px;
}

.pp-cmt-post-right {
  flex: 1;
  min-width: 0;
}

.pp-cmt-post :deep(.el-textarea__inner) {
  border-radius: 10px;
  min-height: 64px;
}

.pp-cmt-replying {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  margin-bottom: 7px;
  padding: 7px 10px;
  border-radius: 8px;
  background: rgba(124, 92, 231, 0.08);
  color: #585a6e;
  font-size: 0.75rem;
}

.pp-cmt-replying strong,
.pp-cmt-reply-to {
  color: #7c5ce7;
  font-weight: 600;
}

.pp-cmt-replying button {
  border: none;
  background: transparent;
  color: #8f92a1;
  cursor: pointer;
  font-size: 0.75rem;
}

.pp-cmt-replying button:hover {
  color: #7c5ce7;
}

.pp-cmt-post-ft {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-top: 8px;
}

.pp-cmt-hint {
  font-size: 0.75rem;
  color: #8f92a1;
}

.pp-cmt-send {
  padding: 5px 20px;
  border-radius: 16px;
  border: none;
  background: #7c5ce7;
  color: #fff;
  font-size: 0.75rem;
  cursor: pointer;
}

.pp-cmt-send:disabled {
  opacity: 0.4;
  cursor: default;
}

.pp-cmt-item {
  display: flex;
  gap: 14px;
  padding: 16px 0;
  border-top: 1px solid rgba(0, 0, 0, 0.06);
}

.pp-cmt-body {
  flex: 1;
  min-width: 0;
}

.pp-cmt-top {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-bottom: 4px;
}

.pp-cmt-name {
  font-size: 14px;
  font-weight: 600;
  color: #1a1a2e;
}

.pp-cmt-time {
  font-size: 12px;
  color: #c4c6d0;
}

.pp-cmt-owner-badge {
  display: inline-flex;
  align-items: center;
  height: 18px;
  padding: 0 6px;
  border-radius: 5px;
  color: #fff;
  background: #667eea;
  font-size: 10px;
  font-weight: 600;
  line-height: 1;
}

.pp-cmt-text {
  margin: 0 0 8px;
  font-size: 14px;
  color: #585a6e;
  line-height: 1.7;
}

.pp-cmt-ft {
  display: flex;
  gap: 16px;
}

.pp-cmt-replies {
  margin-top: 10px;
  padding: 10px 14px;
  border-radius: 10px;
  background: #fafbfc;
}

.pp-cmt-reply-item {
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 4px;
  color: #666;
  font-size: 13px;
  line-height: 1.7;
}

.pp-cmt-reply-item + .pp-cmt-reply-item {
  margin-top: 8px;
}

.pp-cmt-reply-user {
  color: #667eea;
  font-weight: 500;
  cursor: pointer;
}

.pp-cmt-reply-user:hover {
  color: #4f61d7;
}

.pp-cmt-reply-item .pp-cmt-owner-badge {
  height: 16px;
  padding: 0 5px;
}

.pp-cmt-reply-target {
  color: #9aa0af;
}

.pp-cmt-reply-content {
  color: #666;
}

.pp-cmt-empty {
  text-align: center;
  padding: 30px 0;
  font-size: 0.8125rem;
  color: #8f92a1;
}

.pp-cmt-login {
  text-align: center;
  padding: 20px 0 8px;
  font-size: 0.8125rem;
  color: #8f92a1;
}

.pp-cmt-login a {
  color: #7c5ce7;
  text-decoration: none;
  font-weight: 500;
  margin-left: 4px;
}

.pp-cmt-login a:hover {
  text-decoration: underline;
}

/* 响应式 */
@media (max-width: 1024px) {
  .pp-body {
    flex-direction: column;
  }

  .pp-right {
    width: 100%;
  }

  .pp-rel {
    position: static;
    max-height: 500px;
  }
}

@media (max-width: 768px) {
  .pp {
    padding: 12px 12px 32px;
  }

  .pp-title {
    font-size: 1.1rem;
  }
}
</style>
