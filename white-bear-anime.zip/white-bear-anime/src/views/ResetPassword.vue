<template>
  <main class="recovery-page">
    <section class="recovery-panel">
      <RouterLink to="/login" class="back-link">返回登录</RouterLink>
      <h1>重置密码</h1>
      <form v-if="!completed" @submit.prevent="submit">
        <label for="new-password">新密码</label>
        <input id="new-password" v-model="password" type="password" autocomplete="new-password" minlength="6" maxlength="32" required />
        <label for="confirm-password">确认新密码</label>
        <input id="confirm-password" v-model="confirmPassword" type="password" autocomplete="new-password" minlength="6" maxlength="32" required />
        <p v-if="error" class="error-message">{{ error }}</p>
        <button type="submit" :disabled="loading || !token">{{ loading ? '提交中...' : '重置密码' }}</button>
      </form>
      <p v-else class="success-message">密码已重置，可以返回登录。</p>
    </section>
  </main>
</template>

<script setup>
import { ref } from 'vue'
import { useRoute } from 'vue-router'
import { userApi } from '@/api/modules/user'

const route = useRoute()
const token = String(route.query.token || '')
const password = ref('')
const confirmPassword = ref('')
const loading = ref(false)
const completed = ref(false)
const error = ref(token ? '' : '重置链接缺少令牌')

async function submit() {
  error.value = ''
  if (password.value !== confirmPassword.value) {
    error.value = '两次输入的密码不一致'
    return
  }
  if (password.value.length < 6) {
    error.value = '密码至少需要 6 个字符'
    return
  }
  loading.value = true
  try {
    await userApi.resetPassword(token, password.value)
    completed.value = true
  } catch (requestError) {
    error.value = requestError?.response?.data?.message || requestError.message || '重置失败'
  } finally {
    loading.value = false
  }
}
</script>

<style scoped>
.recovery-page { min-height: calc(100vh - 64px); display: grid; place-items: center; padding: 24px; background: #f4f6f8; }
.recovery-panel { width: min(420px, 100%); padding: 32px; background: #fff; border: 1px solid #e1e5e9; border-radius: 8px; }
.recovery-panel h1 { margin: 20px 0 28px; font-size: 26px; color: #17191c; }
.back-link { color: #5d6570; text-decoration: none; font-size: 14px; }
form { display: grid; gap: 12px; }
label { font-size: 14px; color: #34383e; }
input { height: 44px; padding: 0 12px; border: 1px solid #cfd4da; border-radius: 6px; font-size: 15px; }
button { height: 44px; margin-top: 8px; border: 0; border-radius: 6px; background: #e85d4a; color: #fff; font-weight: 600; cursor: pointer; }
button:disabled { opacity: .6; cursor: default; }
.error-message { margin: 0; color: #c23b32; }
.success-message { margin: 20px 0 0; color: #227447; line-height: 1.6; }
</style>
