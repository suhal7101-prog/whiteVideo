<!--
  AI 智能助手页（扩展预留）

  整合三个 AI 功能板块：
  1. AI 动漫知识问答（基于 RAG）
  2. AI 个性化推荐
  3. AI 追番助手（Agent）

  当前状态：已接入 DeepSeek + Chroma RAG
-->
<template>
  <div class="ai-page">
    <DynamicBanner :layers="aiBannerLayers" />

    <div class="ai-body">
      <AdvertisementSlot position="ai_sidebar" variant="featured" class="ai-ad" />

      <!-- AI 功能导航卡片 -->
      <div class="ai-cards">
        <div
          v-for="card in aiCards"
          :key="card.key"
          class="ai-nav-card"
          :class="{ active: activeCard === card.key }"
          :style="{ '--card-color': card.color }"
          @click="activeCard = card.key"
        >
          <span class="ai-card-icon">{{ card.icon }}</span>
          <h3>{{ card.title }}</h3>
          <p>{{ card.desc }}</p>
          <el-tag size="small" effect="plain" round :type="card.status === '已上线' ? 'success' : 'info'">
            {{ card.status }}
          </el-tag>
        </div>
      </div>

      <!-- 功能内容区 -->
      <div class="ai-content">
        <!-- 1. AI 动漫知识问答 -->
        <div v-if="activeCard === 'chat'" class="ai-panel">
          <AiChat />
        </div>

        <!-- 2. AI 个性化推荐 -->
        <div v-if="activeCard === 'recommend'" class="ai-panel">
          <AiRecommend />
        </div>

        <!-- 3. AI 追番助手 -->
        <div v-if="activeCard === 'agent'" class="ai-panel">
          <div class="agent-placeholder">
            <div class="agent-hero">
              <h2>追番助手</h2>
              <p>输入文字指令，自动打开动漫或管理当前账号的追番列表</p>
            </div>

            <div class="agent-examples">
              <h4>常用指令</h4>
              <div class="example-list">
                <button
                  v-for="ex in exampleCommands"
                  :key="ex"
                  class="example-item"
                  type="button"
                  :disabled="agentExecuting"
                  @click="runExample(ex)"
                >
                  <span class="example-icon">›</span>
                  <span>{{ ex }}</span>
                </button>
              </div>
            </div>

            <div class="agent-input-area">
              <div class="command-row">
                <el-input
                  v-model="agentCommand"
                  size="large"
                  placeholder="例如：打开《完美世界》"
                  clearable
                  :disabled="agentExecuting"
                  @keydown.enter.prevent="executeCommand()"
                />
                <el-button
                  class="execute-button"
                  type="primary"
                  size="large"
                  :loading="agentExecuting"
                  :disabled="!agentCommand.trim()"
                  @click="executeCommand()"
                >
                  执行
                </el-button>
              </div>
            </div>

            <div v-if="agentResult" class="agent-result">
              <div class="result-summary" role="status">
                <span class="result-icon">✓</span>
                <div>
                  <strong>{{ actionLabel }}</strong>
                  <p>{{ agentResult.summary || agentResult.message }}</p>
                </div>
              </div>

              <div v-if="resultVideos.length" class="result-videos">
                <button
                  v-for="video in resultVideos"
                  :key="video.sourceVodId || video.id"
                  class="result-video"
                  type="button"
                  @click="openVideo(video)"
                >
                  <div class="video-cover-wrap">
                    <img v-if="video.cover" :src="video.cover" :alt="video.title" class="video-cover" />
                    <div v-else class="video-cover video-cover-empty">暂无封面</div>
                    <span v-if="video.rating" class="video-rating">{{ video.rating }}</span>
                  </div>
                  <span class="video-title">{{ video.title }}</span>
                  <span class="video-meta">{{ [video.category, video.status].filter(Boolean).join(' · ') || '点击播放' }}</span>
                </button>
              </div>
            </div>

            <div class="agent-footer">Agent 已连接 Chroma 动漫库与追番数据库</div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { computed, ref } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import { aiApi } from '@/api/modules/ai'
import AiChat from '@/components/ai/AiChat.vue'
import AiRecommend from '@/components/ai/AiRecommend.vue'
import DynamicBanner from '@/components/community/DynamicBanner.vue'
import AdvertisementSlot from '@/components/common/AdvertisementSlot.vue'
import request from '@/api/request'
import { normalizeBannerLayers } from '@/utils/bannerEffects'

const router = useRouter()
const activeCard = ref('agent')

const bannerTextLayer = {
  tagName: 'div',
  a: 0.008,
  transform: [1, 0, 0, 1, 0, 0],
  opacity: [1, 1],
  zIndex: 1000,
  content: {
    title: '🤖 AI 智能助手',
    desc: '基于 DeepSeek 大模型 + RAG 检索增强生成的动漫智能助手'
  }
}

const aiBannerLayers = ref([bannerTextLayer])
const aiBannerTheme = ref(null)

async function loadEffectLayers(effect) {
  const response = await fetch(effect.dataUrl, { cache: 'no-cache' })
  if (!response.ok) throw new Error(`效果图配置加载失败: HTTP ${response.status}`)
  const data = await response.json()
  if (!Array.isArray(data) || data.length === 0) throw new Error('效果图配置为空')
  return normalizeBannerLayers(data, { baseUrl: effect.assetBaseUrl })
}

async function loadAiBanner() {
  try {
    const result = await request.get('/banner-effects/active', { params: { targetPage: 'ai' } })
    const effects = result?.list || []
    if (!effects.length) throw new Error('后台没有启用的AI效果图')

    const lastTheme = sessionStorage.getItem('white_bear_last_ai_banner')
    const candidates = effects.length > 1
      ? effects.filter(effect => effect.themeKey !== lastTheme)
      : effects
    const selected = candidates[Math.floor(Math.random() * candidates.length)] || effects[0]
    const effectLayers = await loadEffectLayers(selected)

    aiBannerTheme.value = selected
    sessionStorage.setItem('white_bear_last_ai_banner', selected.themeKey)
    aiBannerLayers.value = [...effectLayers, bannerTextLayer]
  } catch (error) {
    console.warn('[AiAssistant] 横幅资源加载失败:', error)
    try {
      const fallback = {
        dataUrl: '/banner/2026-07-27/data.json',
        assetBaseUrl: '/banner/2026-07-27',
      }
      aiBannerLayers.value = [...await loadEffectLayers(fallback), bannerTextLayer]
    } catch (fallbackError) {
      console.warn('[AiAssistant] 默认横幅加载失败:', fallbackError)
      aiBannerLayers.value = [bannerTextLayer]
    }
  }
}

loadAiBanner()

const aiCards = ref([
  {
    key: 'chat', title: '动漫知识问答',
    desc: '基于RAG检索增强生成，精准回答动漫相关问题',
    icon: '💬', color: '#667eea', status: '已上线'
  },
  {
    key: 'recommend', title: '个性化推荐',
    desc: '根据你的偏好，AI生成个性化推荐和推荐理由',
    icon: '🎯', color: '#f093fb', status: '已上线'
  },
  {
    key: 'agent', title: '追番助手',
    desc: '文字指令自动打开动漫，AI Agent智能代理追番管理',
    icon: '🤖', color: '#f5576c', status: '已上线'
  }
])

const agentCommand = ref('')
const agentResult = ref(null)
const agentExecuting = ref(false)

const exampleCommands = [
  '打开《完美世界》',
  '帮我追《完美世界》',
  '查看我的追番列表',
  '取消追番《完美世界》',
  '推荐几部玄幻冒险动漫'
]

const resultVideos = computed(() => {
  const videos = agentResult.value?.videos || agentResult.value?.result?.videos
  return Array.isArray(videos) ? videos : []
})

const actionLabels = {
  open_anime: '正在打开',
  follow_anime: '追番完成',
  unfollow_anime: '已取消追番',
  list_following: '我的追番',
  similar_recommend: '相似推荐',
  new_anime: '最新动漫',
  ranking: '热门排行',
  general_query: '查询结果'
}

const actionLabel = computed(() => actionLabels[agentResult.value?.action || agentResult.value?.intent] || '执行完成')

function runExample(command) {
  agentCommand.value = command
  executeCommand(command)
}

async function executeCommand(command = agentCommand.value) {
  const cmd = String(command || '').trim()
  if (!cmd || agentExecuting.value) return
  agentExecuting.value = true
  agentResult.value = null
  try {
    const result = await aiApi.agentCommand(cmd)
    agentResult.value = result
    agentCommand.value = ''
    ElMessage.success(result?.message || '指令执行完成')
    const videos = Array.isArray(result?.videos) ? result.videos : []
    if (result?.action === 'open_anime' && videos.length) openVideo(videos[0])
  } catch (error) {
    console.error('[AiAssistant] Agent 执行失败:', error)
  } finally {
    agentExecuting.value = false
  }
}

function openVideo(video) {
  if (video.playUrl) {
    router.push(video.playUrl)
    return
  }
  const id = video.sourceVodId || video.vod_id || video.id
  if (id) router.push(`/play/${id}`)
}
</script>

<style scoped>
.ai-page { min-height: 100vh; padding-bottom: 88px; background: #f5f7fa; }

.ai-body { max-width: 1000px; margin: 0 auto; padding: 20px; }
.ai-ad { margin-bottom: 20px; }

/* AI 功能导航卡 */
.ai-cards { display: grid; grid-template-columns: repeat(3, 1fr); gap: 16px; margin-bottom: 24px; }

.ai-nav-card {
  background: #fff; border-radius: 16px; padding: 24px;
  text-align: center; cursor: pointer;
  box-shadow: 0 2px 12px rgba(0,0,0,0.04);
  transition: all 0.35s cubic-bezier(0.4,0,0.2,1);
  border: 2px solid transparent;
  position: relative; overflow: hidden;
}
.ai-nav-card::before {
  content: ''; position: absolute;
  top: 0; left: 0; right: 0; height: 4px;
  background: var(--card-color);
  transform: scaleY(0); transition: transform 0.3s;
}
.ai-nav-card:hover, .ai-nav-card.active {
  transform: translateY(-6px);
  box-shadow: 0 12px 32px rgba(102,126,234,0.15);
}
.ai-nav-card.active { border-color: var(--card-color); }
.ai-nav-card.active::before, .ai-nav-card:hover::before { transform: scaleY(1); }

.ai-card-icon { font-size: 44px; display: block; margin-bottom: 10px; }
.ai-nav-card h3 { font-size: 17px; margin: 0 0 6px; color: #1a1a2e; }
.ai-nav-card p { font-size: 13px; color: #888; margin: 0 0 10px; line-height: 1.5; }

/* 内容面板 */
.ai-content { min-height: 400px; }

/* Agent 面板样式 */
.agent-placeholder {
  background: #fff; border-radius: 16px; padding: 40px;
  box-shadow: 0 4px 20px rgba(0,0,0,0.06); text-align: center;
}
.agent-hero { margin-bottom: 30px; }
.agent-hero h2 { font-size: 22px; color: #1a1a2e; margin: 0 0 8px; }
.agent-hero p { font-size: 15px; color: #888; }

.agent-examples { text-align: left; max-width: 500px; margin: 0 auto 24px; }
.agent-examples h4 { margin: 0 0 12px; font-size: 15px; }
.example-list { display: flex; flex-direction: column; gap: 8px; }
.example-item {
  display: flex; align-items: center; gap: 10px;
  width: 100%; padding: 10px 16px; background: #fafbfc; border-radius: 8px;
  border: 1px solid #edf0f4; font-size: 14px; color: #555; text-align: left; cursor: pointer;
}
.example-item:hover { color: #5267d8; border-color: #cdd5ff; background: #f5f7ff; }
.example-item:disabled { cursor: wait; opacity: 0.65; }
.example-icon { color: #667eea; font-size: 18px; }

.agent-input-area { max-width: 680px; margin: 0 auto 20px; }
.command-row { display: grid; grid-template-columns: minmax(0, 1fr) auto; gap: 10px; align-items: center; }
.execute-button { min-width: 76px; margin: 0 !important; }

.agent-result { max-width: 760px; margin: 26px auto 20px; text-align: left; }
.result-summary { display: flex; gap: 12px; padding: 14px 0; border-top: 1px solid #e8ebf0; border-bottom: 1px solid #e8ebf0; }
.result-icon { font-size: 24px; }
.result-summary strong { color: #22283a; font-size: 15px; }
.result-summary p { font-size: 14px; color: #555; line-height: 1.6; white-space: pre-wrap; margin: 4px 0 0; }
.result-videos { display: grid; grid-template-columns: repeat(5, minmax(0, 1fr)); gap: 12px; margin-top: 18px; }
.result-video { min-width: 0; padding: 0; overflow: hidden; text-align: left; cursor: pointer; background: #fff; border: 1px solid #e5e8ef; border-radius: 8px; color: inherit; }
.result-video:hover { border-color: #667eea; box-shadow: 0 6px 18px rgba(28, 37, 65, 0.1); }
.video-cover-wrap { position: relative; width: 100%; aspect-ratio: 3 / 4; overflow: hidden; background: #eef1f6; }
.video-cover { width: 100%; height: 100%; display: block; object-fit: cover; }
.video-cover-empty { display: grid; place-items: center; color: #9aa2b1; font-size: 12px; }
.video-rating { position: absolute; right: 6px; bottom: 6px; padding: 2px 5px; color: #fff; background: #1e2433; border-radius: 4px; font-size: 12px; }
.video-title { display: block; padding: 9px 9px 3px; color: #252a38; font-size: 13px; font-weight: 600; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.video-meta { display: block; padding: 0 9px 10px; color: #89909f; font-size: 11px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }

.agent-footer { font-size: 13px; color: #bbb; margin-top: 20px; }

@media (max-width: 768px) {
  .ai-cards { grid-template-columns: 1fr; }
  .agent-placeholder { padding: 24px 16px; }
  .result-videos { grid-template-columns: repeat(2, minmax(0, 1fr)); }
  .command-row { grid-template-columns: minmax(0, 1fr); }
  .execute-button { grid-column: 1 / -1; width: 100%; }
}
</style>
