<template>
  <div class="submission-page">
    <section class="submission-hero">
      <span class="submission-hero-icon" aria-hidden="true">
        <svg viewBox="0 0 24 24">
          <path d="M5 18.5V20h14v-1.5M12 16V4m0 0L8 8m4-4 4 4" />
          <path d="M8.5 13.5h7" />
        </svg>
      </span>
      <div>
        <span class="submission-eyebrow">CREATOR STUDIO</span>
        <h1>动漫投稿</h1>
        <p>{{ userStore.isAdmin ? '管理员投稿审核后可直接发布。' : '认真填写内容信息，审核通过后将在平台公开展示。' }}</p>
      </div>
    </section>

    <div class="submission-layout">
      <main class="submission-card">
        <div class="submission-card-head">
          <div>
            <h2>填写投稿信息</h2>
            <p><span>*</span> 为必填内容</p>
          </div>
          <span class="submission-role">{{ userStore.isAdmin ? '管理员' : '认证创作者' }}</span>
        </div>

        <el-form ref="formRef" :model="form" :rules="rules" label-position="top" class="submission-form">
          <div class="form-grid">
            <el-form-item label="动漫标题" prop="title">
              <div class="title-search-control">
                <el-input
                  v-model="form.title"
                  maxlength="100"
                  show-word-limit
                  placeholder="输入动漫名称后按回车搜索"
                  @input="handleTitleChanged"
                  @keyup.enter.prevent="searchAnime"
                />
                <small>{{ searching ? '正在查询数据库...' : '按回车查询已有动漫资料' }}</small>
              </div>
            </el-form-item>
            <el-form-item label="内容分类" prop="category">
              <el-select v-model="form.category" placeholder="请选择分类" style="width:100%">
                <el-option v-for="item in categories" :key="item" :label="item" :value="item" />
              </el-select>
            </el-form-item>
            <el-form-item label="封面图片地址" prop="cover">
              <el-input v-model="form.cover" placeholder="https://example.com/cover.jpg" />
            </el-form-item>
            <el-form-item label="上传视频" required>
              <div class="video-upload-box">
                <input
                  ref="videoInput"
                  class="video-file-input"
                  type="file"
                  accept="video/mp4,video/webm,video/quicktime,.m4v"
                  @change="selectVideo"
                />
                <button type="button" class="video-select-button" :disabled="submitting" @click="videoInput?.click()">
                  <svg viewBox="0 0 24 24" aria-hidden="true">
                    <path d="M12 16V4m0 0L8 8m4-4 4 4M5 15v4h14v-4" />
                  </svg>
                  {{ videoFile ? '重新选择' : '选择视频' }}
                </button>
                <span class="video-upload-tip">支持 MP4、WebM、MOV、M4V，最大 500MB</span>
                <div v-if="videoFile" class="video-file-state">
                  <span class="video-file-icon" aria-hidden="true">▶</span>
                  <div class="video-file-info">
                    <strong :title="videoFile.name">{{ videoFile.name }}</strong>
                    <small>{{ formatFileSize(videoFile.size) }}</small>
                  </div>
                  <button type="button" class="video-remove-button" aria-label="移除视频" :disabled="submitting" @click="removeVideo">×</button>
                </div>
                <div v-if="uploading" class="video-upload-progress" aria-live="polite">
                  <span :style="{ width: `${uploadProgress}%` }"></span>
                  <small>正在上传 {{ uploadProgress }}%</small>
                </div>
              </div>
            </el-form-item>
            <el-form-item label="更新状态" prop="status">
              <el-select v-model="form.status" style="width:100%">
                <el-option label="连载中" value="连载中" />
                <el-option label="已完结" value="已完结" />
              </el-select>
            </el-form-item>
            <el-form-item label="当前上传集数" prop="episodeNumber">
              <el-input :model-value="form.episodeNumber" readonly class="episode-auto-input" />
            </el-form-item>
            <el-form-item label="播出年份" prop="year">
              <el-input-number v-model="form.year" :min="1900" :max="2100" :controls="false" style="width:100%" />
            </el-form-item>
            <el-form-item label="地区" prop="region">
              <el-select v-model="form.region" style="width:100%">
                <el-option label="中国" value="CN" />
                <el-option label="日本" value="JP" />
                <el-option label="其他" value="OTHER" />
              </el-select>
            </el-form-item>
          </div>

          <el-form-item label="内容标签" prop="tags">
            <el-input v-model="form.tags" maxlength="120" placeholder="多个标签使用逗号分隔，例如：热血,玄幻,冒险" />
          </el-form-item>
          <el-form-item label="内容简介" prop="description">
            <el-input v-model="form.description" type="textarea" :rows="6" maxlength="1000" show-word-limit resize="none" placeholder="请填写准确、完整的内容简介" />
          </el-form-item>

          <div v-if="form.cover" class="cover-preview">
            <span>封面预览</span>
            <img :src="form.cover" alt="投稿封面预览" @error="coverError = true" @load="coverError = false" />
            <small v-if="coverError">封面地址暂时无法加载，请检查链接。</small>
          </div>

          <div class="submission-actions">
            <button type="button" class="submission-cancel" @click="$router.back()">取消</button>
            <button type="button" class="submission-submit" :disabled="submitting" @click="submit">
              <span v-if="submitting">{{ uploading ? `正在上传 ${uploadProgress}%` : '正在提交...' }}</span>
              <span v-else>{{ userStore.isAdmin ? '确认发布' : '提交审核' }}</span>
            </button>
          </div>
        </el-form>
      </main>

      <aside class="submission-guide">
        <h3>投稿须知</h3>
        <ol>
          <li><span>1</span><p><strong>内容真实</strong>标题、分类和简介需要与投稿内容一致。</p></li>
          <li><span>2</span><p><strong>封面清晰</strong>建议使用 16:9 横向封面，避免变形或模糊。</p></li>
          <li><span>3</span><p><strong>版权合规</strong>请勿提交侵权、违规或来源不明的内容。</p></li>
          <li><span>4</span><p><strong>等待审核</strong>创作者投稿通过后才会进入前台视频库。</p></li>
        </ol>
      </aside>
    </div>

    <el-dialog v-model="searchDialogVisible" title="选择已有动漫" width="min(680px, 92vw)" class="anime-search-dialog">
      <p class="search-dialog-tip">请选择要沿用资料的动漫，确认后将自动填写投稿信息并计算下一集。</p>
      <div class="anime-search-list">
        <button
          v-for="item in searchResults"
          :key="item.id"
          type="button"
          class="anime-search-item"
          :class="{ selected: selectedAnimeId === item.id }"
          @click="selectedAnimeId = item.id"
        >
          <img v-if="item.cover" :src="item.cover" :alt="item.title" />
          <span v-else class="anime-search-cover-empty">暂无封面</span>
          <span class="anime-search-info">
            <strong>{{ item.title }}</strong>
            <small>{{ item.category || '未分类' }} · {{ item.year || '年份未知' }}</small>
            <em>已有 {{ item.existingCount }} 条记录，将上传第 {{ item.nextEpisode }} 集</em>
          </span>
          <span class="anime-search-check" aria-hidden="true">✓</span>
        </button>
      </div>
      <template #footer>
        <button type="button" class="dialog-cancel-button" @click="searchDialogVisible = false">取消</button>
        <button type="button" class="dialog-confirm-button" :disabled="!selectedAnimeId" @click="confirmExistingAnime">确认使用</button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { reactive, ref } from 'vue'
import { ElMessage } from 'element-plus'
import { useRouter } from 'vue-router'
import { useUserStore } from '@/stores/user'
import { userApi } from '@/api/modules/user'

const router = useRouter()
const userStore = useUserStore()
const formRef = ref(null)
const videoInput = ref(null)
const videoFile = ref(null)
const submitting = ref(false)
const uploading = ref(false)
const uploadProgress = ref(0)
const coverError = ref(false)
const searching = ref(false)
const searchDialogVisible = ref(false)
const searchResults = ref([])
const selectedAnimeId = ref(null)
const appliedAnimeTitle = ref('')
const categories = ['中国动漫', '日本动漫', '热血', '玄幻', '冒险', '科幻', '恋爱', '治愈', '悬疑', '搞笑']

const defaultForm = () => ({
  title: '', cover: '', videoUrl: '', videoFileSize: null, category: '', description: '',
  status: '连载中', episodeNumber: 1, tags: '', year: new Date().getFullYear(), region: 'CN',
})
const form = reactive(defaultForm())
const rules = {
  title: [{ required: true, message: '请输入动漫标题', trigger: 'blur' }],
  category: [{ required: true, message: '请选择内容分类', trigger: 'change' }],
  episodeNumber: [{ required: true, message: '请填写当前上传的是第几集', trigger: 'change' }],
  cover: [{ required: true, message: '请输入封面图片地址', trigger: 'blur' }],
  tags: [{ required: true, message: '请至少填写一个标签', trigger: 'blur' }],
  description: [{ required: true, message: '请填写内容简介', trigger: 'blur' }],
}

function selectVideo(event) {
  const file = event.target.files?.[0]
  if (!file) return
  const extension = file.name.slice(file.name.lastIndexOf('.')).toLowerCase()
  if (!['.mp4', '.webm', '.mov', '.m4v'].includes(extension) || !file.type.startsWith('video/')) {
    ElMessage.warning('仅支持 MP4、WebM、MOV 或 M4V 视频')
    event.target.value = ''
    return
  }
  if (file.size > 500 * 1024 * 1024) {
    ElMessage.warning('视频大小不能超过 500MB')
    event.target.value = ''
    return
  }
  videoFile.value = file
  form.videoUrl = ''
  form.videoFileSize = null
}

function removeVideo() {
  videoFile.value = null
  form.videoUrl = ''
  form.videoFileSize = null
  if (videoInput.value) videoInput.value.value = ''
}

function formatFileSize(bytes) {
  if (!Number.isFinite(bytes)) return ''
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`
  return `${(bytes / 1024 / 1024).toFixed(1)} MB`
}

function handleTitleChanged(value) {
  form.episodeNumber = 1
  searchDialogVisible.value = false
  selectedAnimeId.value = null
  if (appliedAnimeTitle.value && String(value).trim() !== appliedAnimeTitle.value) {
    Object.assign(form, {
      cover: '',
      category: '',
      description: '',
      status: '连载中',
      tags: '',
      year: new Date().getFullYear(),
      region: 'CN',
    })
    appliedAnimeTitle.value = ''
  }
}

async function searchAnime() {
  const title = form.title.trim()
  if (!title) {
    ElMessage.warning('请先输入动漫名称')
    return
  }
  if (searching.value) return
  searching.value = true
  try {
    const result = await userApi.searchSubmissionAnime(title)
    searchResults.value = Array.isArray(result?.list) ? result.list : []
    if (!searchResults.value.length) {
      form.episodeNumber = 1
      searchDialogVisible.value = false
      selectedAnimeId.value = null
      ElMessage.info('数据库中暂未找到该动漫，当前上传集数已设为第 1 集')
      return
    }
    selectedAnimeId.value = searchResults.value[0].id
    searchDialogVisible.value = true
  } catch (error) {
    console.error('搜索已有动漫失败:', error)
  } finally {
    searching.value = false
  }
}

function confirmExistingAnime() {
  const selected = searchResults.value.find(item => item.id === selectedAnimeId.value)
  if (!selected) return
  const category = selected.category || ''
  if (category && !categories.includes(category)) categories.push(category)
  const statusValue = String(selected.status || '').toLowerCase()
  const status = ['已完结', '完结', 'completed', 'finished'].includes(statusValue) ? '已完结' : '连载中'
  const regionValue = String(selected.region || '').toUpperCase()
  const region = regionValue === 'CN' || regionValue.includes('中国') || regionValue.includes('大陆')
    ? 'CN'
    : regionValue === 'JP' || regionValue.includes('日本')
      ? 'JP'
      : 'OTHER'
  Object.assign(form, {
    title: selected.title || form.title,
    cover: selected.cover || '',
    category,
    description: selected.description || '',
    status,
    episodeNumber: Math.max(1, Number(selected.nextEpisode) || 1),
    tags: selected.tags || '',
    year: Number(selected.year) || new Date().getFullYear(),
    region,
  })
  appliedAnimeTitle.value = form.title
  searchDialogVisible.value = false
  formRef.value?.clearValidate()
  ElMessage.success(`已填入《${form.title}》资料，当前集数为第 ${form.episodeNumber} 集`)
}

async function submit() {
  const valid = await formRef.value?.validate().catch(() => false)
  if (!valid || submitting.value) return
  if (!videoFile.value && !form.videoUrl) {
    ElMessage.warning('请先选择要上传的视频')
    return
  }
  submitting.value = true
  try {
    if (videoFile.value && !form.videoUrl) {
      uploading.value = true
      uploadProgress.value = 0
      const uploaded = await userApi.uploadSubmissionVideo(videoFile.value, progress => {
        uploadProgress.value = progress
      })
      form.videoUrl = uploaded.url
      form.videoFileSize = uploaded.size
      uploadProgress.value = 100
      uploading.value = false
    }
    const result = await userApi.submitVideo({
      ...form,
      title: form.title.trim(),
      cover: form.cover.trim(),
      tags: form.tags.trim(),
      description: form.description.trim(),
    })
    ElMessage.success(result?.approved ? '投稿已成功发布' : '投稿成功，已进入管理员审核队列')
    Object.assign(form, defaultForm())
    appliedAnimeTitle.value = ''
    removeVideo()
    formRef.value?.clearValidate()
    if (!result?.approved) router.push('/profile?tab=creator')
  } catch (error) {
    console.error('提交投稿失败:', error)
  } finally {
    uploading.value = false
    submitting.value = false
  }
}
</script>

<style scoped>
.submission-page { min-height: 100%; padding: 32px max(20px, calc((100vw - 1180px) / 2)) 72px; background: #f5f7fb; color: #202637; }
.submission-hero { display: flex; align-items: center; gap: 18px; margin-bottom: 24px; }
.submission-hero-icon { width: 62px; height: 62px; display: inline-flex; align-items: center; justify-content: center; border-radius: 18px; color: #fff; background: linear-gradient(135deg,#667eea,#7b61d7); box-shadow: 0 12px 28px rgba(102,126,234,.25); }
.submission-hero-icon svg { width: 31px; height: 31px; fill: none; stroke: currentColor; stroke-width: 1.8; stroke-linecap: round; stroke-linejoin: round; }
.submission-eyebrow { color: #667eea; font-size: 11px; font-weight: 800; letter-spacing: .12em; }
.submission-hero h1 { margin: 3px 0 4px; font-size: 28px; }
.submission-hero p { margin: 0; color: #7f8798; font-size: 13px; }
.submission-layout { display: grid; grid-template-columns: minmax(0,1fr) 280px; gap: 22px; align-items: start; }
.submission-card, .submission-guide { border: 1px solid #e8ebf2; border-radius: 18px; background: #fff; box-shadow: 0 8px 30px rgba(35,43,71,.05); }
.submission-card { padding: 28px; }
.submission-card-head { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 24px; padding-bottom: 18px; border-bottom: 1px solid #edf0f5; }
.submission-card-head h2 { margin: 0 0 6px; font-size: 20px; }
.submission-card-head p { margin: 0; color: #969dad; font-size: 12px; }
.submission-card-head p span { color: #e14f5d; }
.submission-role { padding: 6px 11px; border-radius: 999px; color: #5f6fd2; background: #eef1ff; font-size: 12px; font-weight: 600; }
.form-grid { display: grid; grid-template-columns: repeat(2,minmax(0,1fr)); gap: 0 18px; }
.submission-form :deep(.el-form-item__label) { color: #4b5365; font-weight: 600; }
.title-search-control { width: 100%; }
.title-search-control > small { display: block; margin-top: 5px; color: #969dad; font-size: 11px; line-height: 1.3; }
.episode-auto-input :deep(.el-input__wrapper) { background: #f7f8fb; }
.episode-auto-input :deep(.el-input__inner) { color: #4b5365; text-align: center; cursor: default; }
.search-dialog-tip { margin: -4px 0 15px; color: #7f8798; font-size: 13px; }
.anime-search-list { max-height: 430px; display: grid; gap: 10px; overflow-y: auto; padding-right: 3px; }
.anime-search-item { width: 100%; min-width: 0; padding: 10px; display: flex; align-items: center; gap: 13px; border: 1px solid #e2e6ef; border-radius: 12px; color: #41495b; background: #fff; text-align: left; cursor: pointer; transition: none; }
.anime-search-item.selected { border-color: #7684e9; background: #f7f8ff; box-shadow: 0 0 0 2px rgba(102,126,234,.1); }
.anime-search-item img, .anime-search-cover-empty { width: 90px; height: 56px; flex: 0 0 auto; display: flex; align-items: center; justify-content: center; border-radius: 8px; object-fit: cover; background: #eef0f5; color: #9aa1b1; font-size: 11px; }
.anime-search-info { min-width: 0; flex: 1; }
.anime-search-info strong, .anime-search-info small, .anime-search-info em { display: block; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.anime-search-info strong { margin-bottom: 4px; font-size: 14px; }
.anime-search-info small { color: #8a92a3; font-size: 12px; }
.anime-search-info em { margin-top: 5px; color: #6676d7; font-size: 11px; font-style: normal; }
.anime-search-check { width: 24px; height: 24px; flex: 0 0 auto; display: inline-flex; align-items: center; justify-content: center; border: 1px solid #d9deea; border-radius: 50%; color: transparent; background: #fff; }
.anime-search-item.selected .anime-search-check { border-color: #667eea; color: #fff; background: #667eea; }
.dialog-cancel-button, .dialog-confirm-button { min-width: 92px; height: 38px; border-radius: 9px; font: inherit; font-size: 13px; cursor: pointer; transition: none; }
.dialog-cancel-button { border: 1px solid #dfe3eb; color: #687083; background: #fff; }
.dialog-confirm-button { border: 1px solid #667eea; color: #fff; background: #667eea; }
.dialog-confirm-button:disabled { cursor: not-allowed; opacity: .55; }
.video-upload-box { width: 100%; min-height: 40px; display: flex; align-items: center; flex-wrap: wrap; gap: 9px 12px; }
.video-file-input { display: none; }
.video-select-button { height: 40px; padding: 0 16px; display: inline-flex; align-items: center; gap: 7px; border: 1px solid #cfd6ff; border-radius: 9px; color: #5f6fd2; background: #f8f9ff; font: inherit; cursor: pointer; transition: none; }
.video-select-button svg { width: 17px; height: 17px; fill: none; stroke: currentColor; stroke-width: 1.8; stroke-linecap: round; stroke-linejoin: round; }
.video-select-button:disabled, .video-remove-button:disabled { cursor: wait; opacity: .6; }
.video-upload-tip { color: #969dad; font-size: 12px; }
.video-file-state { width: 100%; min-width: 0; padding: 10px 11px; display: flex; align-items: center; gap: 10px; border: 1px solid #e4e7f0; border-radius: 10px; background: #fafbfe; }
.video-file-icon { width: 32px; height: 32px; flex: 0 0 auto; display: inline-flex; align-items: center; justify-content: center; border-radius: 8px; color: #667eea; background: #edf0ff; font-size: 11px; }
.video-file-info { min-width: 0; flex: 1; }
.video-file-info strong { display: block; overflow: hidden; color: #41495b; font-size: 13px; font-weight: 600; text-overflow: ellipsis; white-space: nowrap; }
.video-file-info small { display: block; margin-top: 2px; color: #969dad; font-size: 11px; }
.video-remove-button { width: 25px; height: 25px; flex: 0 0 auto; border: 0; border-radius: 50%; color: #7f8798; background: #e9ecf3; font-size: 18px; line-height: 1; cursor: pointer; transition: none; }
.video-upload-progress { position: relative; width: 100%; height: 7px; overflow: visible; border-radius: 999px; background: #e9ecf5; }
.video-upload-progress > span { position: absolute; inset: 0 auto 0 0; border-radius: inherit; background: #667eea; transition: width .2s linear; }
.video-upload-progress small { position: absolute; top: 10px; right: 0; color: #7e8698; font-size: 11px; }
.cover-preview { width: min(360px,100%); margin: 2px 0 24px; }
.cover-preview > span { display: block; margin-bottom: 8px; color: #4b5365; font-size: 13px; font-weight: 600; }
.cover-preview img { width: 100%; aspect-ratio: 16/9; display: block; object-fit: cover; border: 1px solid #e8ebf2; border-radius: 12px; background: #f3f5fa; }
.cover-preview small { display: block; margin-top: 6px; color: #e25b66; }
.submission-actions { display: flex; justify-content: flex-end; gap: 12px; padding-top: 22px; border-top: 1px solid #edf0f5; }
.submission-actions button { min-width: 108px; height: 40px; border-radius: 10px; font: inherit; font-size: 14px; cursor: pointer; transition: none; }
.submission-cancel { border: 1px solid #dfe3eb; color: #687083; background: #fff; }
.submission-submit { border: 1px solid #667eea; color: #fff; background: #667eea; }
.submission-submit:disabled { cursor: wait; opacity: .65; }
.submission-guide { padding: 24px; }
.submission-guide h3 { margin: 0 0 19px; font-size: 17px; }
.submission-guide ol { margin: 0; padding: 0; list-style: none; }
.submission-guide li { display: flex; gap: 11px; margin-bottom: 18px; }
.submission-guide li > span { width: 25px; height: 25px; flex: 0 0 auto; display: inline-flex; align-items: center; justify-content: center; border-radius: 8px; color: #667eea; background: #eef1ff; font-size: 12px; font-weight: 700; }
.submission-guide p { margin: 0; color: #868e9f; font-size: 12px; line-height: 1.65; }
.submission-guide strong { display: block; margin-bottom: 2px; color: #3d4556; font-size: 13px; }
@media (max-width: 860px) { .submission-layout { grid-template-columns: 1fr; } .submission-guide { order: -1; } }
@media (max-width: 620px) { .submission-page { padding: 20px 12px 50px; } .submission-card { padding: 19px 15px; } .form-grid { grid-template-columns: 1fr; } .submission-hero-icon { width: 52px; height: 52px; } .submission-hero h1 { font-size: 23px; } }
</style>
