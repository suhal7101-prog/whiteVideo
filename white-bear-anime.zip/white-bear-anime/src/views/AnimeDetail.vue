<!--
  动漫详情页
  展示动漫完整信息、剧集列表、评分、评论
-->
<template>
  <div class="detail-page">
    <!-- ===== 顶部 Banner 信息 ===== -->
    <div class="detail-hero" :style="{ backgroundImage: `url(${anime.cover})` }">
      <div class="hero-overlay">
        <div class="hero-content">
          <div class="hero-cover">
            <img :src="anime.cover" :alt="anime.title" />
          </div>
          <div class="hero-info">
            <h1>{{ anime.title }}</h1>
            <div class="hero-meta">
              <el-tag type="danger" effect="dark" round size="small">⭐ {{ anime.score }}</el-tag>
              <span>{{ anime.category }}</span>
              <span>{{ anime.year }}</span>
              <span>{{ anime.status }}</span>
              <span>{{ anime.episodeCount }}话</span>
            </div>
            <p class="hero-desc">{{ anime.description }}</p>
            <div class="hero-actions">
              <el-button
                type="primary"
                size="large"
                round
                :disabled="!anime.episodes.length"
                @click="playFirstEpisode"
              >
                {{ anime.episodes.length ? '▶ 开始观看' : '暂无可播放剧集' }}
              </el-button>
              <el-button size="large" round @click="handleShare"><EngagementAction type="share" label="分享" /></el-button>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- ===== 主内容 ===== -->
    <div class="detail-body">
      <!-- 剧集列表 -->
      <div class="detail-section">
        <h3>📺 剧集列表</h3>
        <el-tabs v-model="episodeTab">
          <el-tab-pane label="正片" name="main">
            <div class="episode-grid">
              <span
                v-for="ep in anime.episodes"
                :key="ep.id"
                class="episode-item"
                @click="goToPlay(ep)"
              >
                {{ ep.episodeNum }}
              </span>
            </div>
          </el-tab-pane>
          <el-tab-pane label="PV/预告" name="pv">
            <p class="text-muted">暂无PV内容</p>
          </el-tab-pane>
        </el-tabs>
      </div>

      <!-- 评论 -->
      <div class="detail-section">
        <h3>💬 热门评论</h3>
        <div v-if="comments.length" class="comment-list">
          <div v-for="c in comments" :key="c.id" class="comment-card">
            <div class="comment-user-row">
              <el-avatar :size="40" :src="c.avatar" />
              <div>
                <div class="comment-name">{{ c.user }}</div>
                <div class="comment-time">{{ c.time }}</div>
              </div>
              <span class="comment-score">⭐ {{ c.rating }}</span>
            </div>
            <p class="comment-text">{{ c.content }}</p>
            <div class="comment-footer">
              <EngagementAction type="like" :count="c.likes" filled />
              <EngagementAction type="comment" :count="c.replies" />
            </div>
          </div>
        </div>
        <el-empty v-else description="暂无评论" :image-size="80" />
      </div>

      <!-- 相关推荐 -->
      <div class="detail-section">
        <h3>🎬 看了该动漫的人还看了</h3>
        <div class="anime-card-row">
          <AnimeCard
            v-for="item in relatedList"
            :key="item.id"
            :data="item"
            @click="$router.push(`/anime/${item.id}`)"
          />
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, watch } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import axios from 'axios'
import { ElMessage } from 'element-plus'
import { useAuth } from '@/composables/useAuth'
import AnimeCard from '@/components/common/AnimeCard.vue'
import EngagementAction from '@/components/common/EngagementAction.vue'

const route = useRoute()
const router = useRouter()
const { requireAuth } = useAuth()

const episodeTab = ref('main')
const anime = ref({
  id: 0,
  title: '',
  cover: '',
  description: '',
  score: 0,
  category: '',
  year: '',
  status: '',
  episodeCount: 0,
  episodes: []
})
const comments = ref([])
const relatedList = ref([])

async function fetchDetail() {
  const id = Number(route.params.id)
  if (!id) return

  try {
    const [{ data: detailResponse }, { data: relatedResponse }] = await Promise.all([
      axios.get(`/api/catalog/${id}`),
      axios.get(`/api/catalog/${id}/related`, { params: { count: 6 } })
    ])
    const detail = detailResponse.data || {}
    const video = detail.video || {}
    anime.value = {
      id: video.id,
      title: video.title || '',
      cover: video.cover || '',
      description: video.description || '',
      score: Number(video.rating || 0),
      category: video.category || '',
      year: video.year || '',
      status: video.status || '',
      episodeCount: detail.episodeCount || video.episodes || 0,
      episodes: detail.episodes || []
    }
    relatedList.value = (relatedResponse.data?.list || []).map(item => ({
      id: item.vod_id,
      title: item.title,
      cover: item.cover_proxy || item.cover,
      score: Number(item.score || 0),
      tags: typeof item.tags === 'string' ? item.tags.split(',').filter(Boolean) : [],
      views: item.views || 0
    }))
  } catch (error) {
    console.error('[AnimeDetail] 加载失败:', error)
    ElMessage.error('动漫详情加载失败')
  }
}

function playFirstEpisode() {
  router.push(`/play/${anime.value.id}?source=db`)
}

function goToPlay(ep) {
  router.push(`/play/${anime.value.id}?source=db&ep=${ep.episodeNum || 1}`)
}

async function handleShare() {
  if (!requireAuth()) return
  try {
    await navigator.clipboard.writeText(window.location.href)
    ElMessage.success('链接已复制到剪贴板 📋')
  } catch {
    ElMessage.info('分享链接: ' + window.location.href)
  }
}

onMounted(fetchDetail)
watch(() => route.params.id, fetchDetail)
</script>

<style scoped>
.detail-page { background: #f5f7fa; min-height: 100vh; }

/* Hero */
.detail-hero {
  background-size: cover;
  background-position: center;
  position: relative;
}
.hero-overlay {
  background: linear-gradient(180deg, rgba(0,0,0,0.75) 0%, rgba(0,0,0,0.3) 100%);
  padding: 50px 0;
  backdrop-filter: blur(8px);
}
.hero-content {
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 20px;
  display: flex;
  gap: 30px;
  align-items: flex-start;
}
.hero-cover {
  width: 240px;
  aspect-ratio: 3/4;
  border-radius: 12px;
  overflow: hidden;
  flex-shrink: 0;
  box-shadow: 0 8px 32px rgba(0,0,0,0.5);
}
.hero-cover img { width: 100%; height: 100%; object-fit: cover; }

.hero-info { color: #fff; }
.hero-info h1 { font-size: 30px; font-weight: 800; margin: 0 0 12px; text-shadow: 0 2px 8px rgba(0,0,0,0.5); }
.hero-meta { display: flex; align-items: center; gap: 16px; font-size: 14px; opacity: 0.9; margin-bottom: 16px; }
.hero-desc { font-size: 15px; line-height: 1.8; opacity: 0.85; max-width: 600px; margin-bottom: 24px; }
.hero-actions { display: flex; gap: 12px; }

/* Body */
.detail-body {
  max-width: 1200px;
  margin: 0 auto;
  padding: 24px 20px 40px;
}
.detail-section {
  background: #fff;
  border-radius: 16px;
  padding: 24px;
  margin-bottom: 20px;
  box-shadow: 0 2px 12px rgba(0,0,0,0.04);
}
.detail-section h3 { margin: 0 0 16px; font-size: 18px; color: #1a1a2e; }

.episode-grid { display: flex; flex-wrap: wrap; gap: 8px; }
.episode-item {
  display: inline-flex; align-items: center; justify-content: center;
  width: 48px; height: 36px;
  border-radius: 8px; background: #f5f7fa; color: #666;
  font-size: 13px; font-weight: 500; cursor: pointer;
  transition: all 0.2s;
}
.episode-item:hover { background: rgba(102,126,234,0.1); color: #667eea; }

.comment-card {
  padding: 16px 0;
  border-bottom: 1px solid #f5f5f5;
}
.comment-card:last-child { border-bottom: none; }
.comment-user-row { display: flex; align-items: center; gap: 12px; margin-bottom: 10px; }
.comment-name { font-size: 14px; font-weight: 600; color: #333; }
.comment-time { font-size: 12px; color: #bbb; }
.comment-score { margin-left: auto; color: #ffb800; font-weight: 600; }
.comment-text { font-size: 14px; line-height: 1.7; color: #555; margin: 0 0 10px; }
.comment-footer { display: flex; gap: 16px; font-size: 13px; color: #999; }

.anime-card-row {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(160px, 1fr));
  gap: 16px;
}

.text-muted { color: #bbb; text-align: center; padding: 20px; }

@media (max-width: 768px) {
  .hero-content { flex-direction: column; align-items: center; text-align: center; }
  .hero-cover { width: 180px; }
  .hero-info h1 { font-size: 22px; }
  .hero-desc { max-width: 100%; }
  .hero-actions { justify-content: center; flex-wrap: wrap; }
}
</style>
