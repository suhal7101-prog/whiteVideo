<template>
  <div class="register-container">
    <!-- ===== 左侧：动画区域 ===== -->
    <div class="left-panel">
      <div class="logo-wrapper">
        
      </div>

      <div class="animation-wrapper">
        <AnimatedCharacters
          :isTyping="isTyping"
          :showPassword="showPassword"
          :passwordLength="form.password.length"
        />
      </div>

      <div class="footer-links">
       
      </div>
    </div>

    <!-- ===== 右侧：注册表单 ===== -->
    <div class="right-panel">
      <div class="form-container">
        <div class="mobile-logo">
          
        </div>

        <div class="form-header">
          <h1 class="form-title">创建账号</h1>
          <p class="form-subtitle">加入白熊动漫，开启二次元之旅</p>
        </div>

        <form @submit.prevent="onSubmit" class="register-form">
          <!-- 用户名 -->
          <div class="form-group">
            <label for="username" class="form-label">用户名</label>
            <input
              id="username"
              type="text"
              placeholder="你的昵称"
              autocomplete="off"
              v-model="form.username"
              @focus="isTyping = true"
              @blur="isTyping = false"
              class="form-input"
            />
            <p v-if="errors.username" class="form-error">{{ errors.username }}</p>
          </div>

          <!-- 邮箱 -->
          <div class="form-group">
            <label for="email" class="form-label">邮箱</label>
            <input
              id="email"
              type="email"
              placeholder="you@example.com"
              autocomplete="off"
              v-model="form.email"
              @focus="isTyping = true"
              @blur="isTyping = false"
              class="form-input"
            />
            <p v-if="errors.email" class="form-error">{{ errors.email }}</p>
          </div>

          <!-- 密码 -->
          <div class="form-group">
            <label for="password" class="form-label">密码</label>
            <div class="password-wrapper">
              <input
                id="password"
                :type="showPassword ? 'text' : 'password'"
                placeholder="至少6个字符"
                v-model="form.password"
                @focus="isTyping = true"
                @blur="isTyping = false"
                class="form-input password-input"
              />
              <button
                type="button"
                @click="showPassword = !showPassword"
                class="password-toggle"
              >
                <svg v-if="showPassword" xmlns="http://www.w3.org/2000/svg" class="size-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <path d="M9.87 9.87a3 3 0 1 0 4.26 4.26" />
                  <path d="M10.73 5.08A10.43 10.43 0 0 1 12 5c7 0 10 7 10 7a13.16 13.16 0 0 1-1.67 2.68" />
                  <path d="M6.61 6.61A13.526 13.526 0 0 0 2 12s3 7 10 7c.44 0 .87-.03 1.3-.08" />
                </svg>
                <svg v-else xmlns="http://www.w3.org/2000/svg" class="size-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z" />
                  <path d="M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6Z" />
                </svg>
              </button>
            </div>
            <p v-if="errors.password" class="form-error">{{ errors.password }}</p>
          </div>

          <!-- 确认密码 -->
          <div class="form-group">
            <label for="confirmPassword" class="form-label">确认密码</label>
            <input
              id="confirmPassword"
              type="password"
              placeholder="再次输入密码"
              v-model="form.confirmPassword"
              class="form-input"
            />
            <p v-if="errors.confirmPassword" class="form-error">{{ errors.confirmPassword }}</p>
          </div>

          <!-- 同意条款 -->
          <div class="form-checkbox-group">
            <input
              id="agree"
              type="checkbox"
              v-model="form.agree"
              class="checkbox"
            />
            <label for="agree" class="checkbox-label">
              我已阅读并同意
              <a href="/terms" class="link-primary">服务条款</a>
              和
              <a href="/privacy" class="link-primary">隐私政策</a>
            </label>
          </div>
          <p v-if="errors.agree" class="form-error">{{ errors.agree }}</p>

          <!-- 错误信息 -->
          <div v-if="error" class="form-error-box">{{ error }}</div>

          <!-- 注册按钮 -->
          <button type="submit" :disabled="isLoading" class="submit-btn">
            {{ isLoading ? '注册中...' : '立即注册' }}
          </button>
        </form>

        <div class="login-link">
          已有账号？
          <a href="/login" class="login-link-highlight">去登录</a>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive, computed } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import { userApi } from '@/api/modules/user'
import AnimatedCharacters from '@/components/AnimatedCharacters.vue'

const router = useRouter()

const showPassword = ref(false)
const isTyping = ref(false)
const isLoading = ref(false)
const error = ref('')

const form = reactive({
  username: '',
  email: '',
  password: '',
  confirmPassword: '',
  agree: false
})

const errors = computed(() => {
  const result = {}

  if (!form.username) {
    result.username = '请输入用户名'
  }

  if (!form.email) {
    result.email = '请输入邮箱地址'
  } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) {
    result.email = '请输入有效的邮箱地址'
  }

  if (!form.password) {
    result.password = '请设置密码'
  } else if (form.password.length < 6) {
    result.password = '密码至少6个字符'
  }

  if (!form.confirmPassword) {
    result.confirmPassword = '请确认密码'
  } else if (form.confirmPassword !== form.password) {
    result.confirmPassword = '两次密码输入不一致'
  }

  if (!form.agree) {
    result.agree = '请先同意服务条款和隐私政策'
  }

  return result
})

/**
 * 注册 —— 调用后端 /api/user/register 接口
 */
const onSubmit = async () => {
  if (Object.keys(errors.value).length > 0) return
  isLoading.value = true
  error.value = ''

  try {
    // 调用后端注册接口
    await userApi.register({
      username: form.username,
      email: form.email,
      password: form.password
    })

    ElMessage.success('注册成功！请登录 🎉')
    router.push(`/login?email=${encodeURIComponent(form.email)}`)
  } catch (err) {
    error.value = err?.response?.data?.message || err?.message || '注册失败，请稍后再试'
  } finally {
    isLoading.value = false
  }
}
</script>

<style scoped>
/* ===== 整体容器：铺满 app-body ===== */
.register-container {
  display: grid;
  grid-template-columns: 1fr 1fr;
  width: 100%;
  height: 100%;
  overflow: hidden;
  background: #ffffff;
}

/* ===== 左侧面板 ===== */
.left-panel {
  position: relative;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  padding: 24px 32px 20px;
  background: linear-gradient(135deg, #8a8f9a, #6b7280, #4b5563);
  color: #ffffff;
}

.left-panel::before {
  content: '';
  position: absolute;
  inset: 0;
  background: radial-gradient(circle at 30% 40%, rgba(255, 255, 255, 0.08) 0%, transparent 60%),
              radial-gradient(circle at 70% 80%, rgba(255, 255, 255, 0.05) 0%, transparent 50%);
  pointer-events: none;
}

.logo-wrapper {
  position: relative;
  z-index: 2;
}

.logo {
  font-size: 22px;
  font-weight: 700;
  cursor: pointer;
  background: linear-gradient(135deg, #c4b5fd, #a78bfa);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
  display: inline-block;
}

.animation-wrapper {
  position: relative;
  z-index: 2;
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: center;
  min-height: 0;
}

.footer-links {
  position: relative;
  z-index: 2;
  display: flex;
  gap: 24px;
  font-size: 12px;
  color: rgba(255, 255, 255, 0.6);
}

.footer-link {
  color: rgba(255, 255, 255, 0.6);
  text-decoration: none;
  transition: color 0.2s;
}
.footer-link:hover {
  color: #ffffff;
}

/* ===== 右侧面板 ===== */
.right-panel {
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 20px 32px 16px;
  background: #ffffff;
}

.form-container {
  width: 100%;
  max-width: 380px;
}

.mobile-logo {
  display: none;
  justify-content: center;
  margin-bottom: 16px;
}

.form-header {
  text-align: center;
  margin-bottom: 12px;
}

.form-title {
  font-size: 22px;
  font-weight: 700;
  color: #1a1a2e;
  margin-bottom: 0;
}

.form-subtitle {
  font-size: 13px;
  color: #6b7280;
}

.register-form {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.form-group {
  display: flex;
  flex-direction: column;
  gap: 2px;
}

.form-label {
  font-size: 13px;
  font-weight: 500;
  color: #374151;
}

.form-input {
  width: 100%;
  height: 34px;
  padding: 0 14px;
  background: #f9fafb;
  border: 1.5px solid #e5e7eb;
  border-radius: 8px;
  font-size: 14px;
  color: #1a1a2e;
  outline: none;
  transition: border-color 0.25s ease, box-shadow 0.25s ease;
}

.form-input:focus {
  border-color: #667eea;
  box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.10);
}

.form-input::placeholder {
  color: #9ca3af;
}

.password-wrapper {
  position: relative;
}
.password-input {
  padding-right: 40px;
}

.password-toggle {
  position: absolute;
  right: 10px;
  top: 50%;
  transform: translateY(-50%);
  background: none;
  border: none;
  color: #9ca3af;
  cursor: pointer;
  padding: 4px;
}
.password-toggle:hover {
  color: #374151;
}
.password-toggle svg {
  width: 18px;
  height: 18px;
}

.form-error {
  font-size: 12px;
  color: #ef4444;
  margin-top: 1px;
}

/* 同意条款 */
.form-checkbox-group {
  display: flex;
  align-items: flex-start;
  gap: 6px;
  margin: 2px 0;
}

.checkbox {
  width: 14px;
  height: 14px;
  accent-color: #667eea;
  cursor: pointer;
  margin-top: 2px;
  flex-shrink: 0;
}

.checkbox-label {
  font-size: 12px;
  color: #6b7280;
  cursor: pointer;
  line-height: 1.4;
}

.link-primary {
  color: #667eea;
  text-decoration: none;
}
.link-primary:hover {
  text-decoration: underline;
}

.form-error-box {
  padding: 6px 12px;
  font-size: 13px;
  color: #ef4444;
  background: rgba(239, 68, 68, 0.06);
  border: 1px solid rgba(239, 68, 68, 0.20);
  border-radius: 8px;
}

.submit-btn {
  width: 100%;
  height: 38px;
  background: linear-gradient(135deg, #667eea, #764ba2);
  color: #ffffff;
  font-size: 15px;
  font-weight: 600;
  border: none;
  border-radius: 8px;
  cursor: pointer;
  transition: none;
  margin-top: 2px;
}

.submit-btn:hover:not(:disabled) {
  opacity: 0.88;
}
.submit-btn:disabled {
  opacity: 0.6;
  cursor: not-allowed;
}

.login-link {
  text-align: center;
  font-size: 13px;
  color: #6b7280;
  margin-top: 10px;
}

.login-link-highlight {
  font-weight: 500;
  color: #1a1a2e;
  text-decoration: none;
}
.login-link-highlight:hover {
  color: #667eea;
  text-decoration: underline;
}

/* ===== 响应式 ===== */
@media (max-width: 1024px) {
  .register-container {
    grid-template-columns: 1fr;
    height: auto;
    min-height: 100%;
    overflow-y: auto;
  }
  .left-panel {
    display: none;
  }
  .mobile-logo {
    display: flex;
  }
  .right-panel {
    padding: 24px 16px;
    min-height: 100%;
  }
  .form-container {
    max-width: 360px;
  }
}

@media (max-width: 480px) {
  .form-title {
    font-size: 20px;
  }
  .form-input {
    height: 36px;
    font-size: 13px;
  }
  .submit-btn {
    height: 38px;
    font-size: 14px;
  }
}
</style>
