<!--
  首页 —— 白熊动漫平台 v3.0
  数据来源: MySQL /api/catalog/hot，异常时回退到 Python /api/anime/hot

  布局: 轮播(前5条) + 视频网格(最多20条)
-->
<template>
  <div class="home">
    <div class="home-inner">

      <!-- ===== 1. 轮播图 ===== -->
      <section v-if="banners.length" class="banner" aria-label="推荐轮播">
        <el-carousel height="100%" arrow="always"
          :autoplay="true" :interval="5000" trigger="click">
          <el-carousel-item v-for="b in banners" :key="b.vod_id">
            <div class="banner-slide"
              @click="open(b)" role="link" :aria-label="b.title" tabindex="0">
              <!-- 模糊背景层 -->
              <div class="banner-bg" :style="{ backgroundImage: `url(${b.cover_proxy})` }"></div>
              <!-- 渐变遮罩 -->
              <div class="banner-mask">
                <div class="banner-text">
                  <el-tag type="danger" effect="dark" round size="small" class="banner-chip">
                    🔥 热门推荐
                  </el-tag>
                  <h1>{{ b.title }}</h1>
                  <p v-if="b.shortDesc">{{ b.shortDesc }}</p>
                </div>
              </div>
            </div>
          </el-carousel-item>
        </el-carousel>
      </section>

      <!-- 轮播骨架 (加载中) -->
      <section v-else-if="loading" class="banner banner-skeleton" aria-label="加载中">
        <div class="banner-shimmer"></div>
      </section>

      <!-- ===== 2. 热门推荐 (视频 + 话题) ===== -->
      <section class="feed" aria-label="热门推荐">
        <header class="feed-head">
          <div class="feed-head-left">
            <span class="feed-icon">🔥</span>
            <div>
              <h2>热门推荐</h2>
              <p class="feed-sub">最新更新的精彩国漫</p>
            </div>
          </div>
        </header>

        <div class="feed-layout" :class="{ 'without-ad': !homeAdVisible }">
          <AdvertisementSlot
            v-if="homeAdVisible"
            position="home_top"
            variant="sidebar"
            class="home-ad"
            @close="homeAdVisible = false"
            @unavailable="homeAdVisible = false"
          />

          <!-- 左侧：视频网格 (3/4) -->
          <div class="feed-main">
            <!-- 骨架屏 -->
            <div v-if="loading" class="feed-grid">
              <div v-for="n in 20" :key="'s'+n" class="vc-card is-skeleton">
                <div class="vc-cover"></div>
                <div class="vc-body">
                  <div class="sk-line sk-title"></div>
                  <div class="sk-line sk-meta"></div>
                </div>
              </div>
            </div>

            <!-- 错误/空状态 -->
            <div v-else-if="!allVideos.length" class="feed-empty">
              <span v-if="error">⚠️ {{ error }}</span>
              <span v-else>暂无数据，请稍后再试</span>
              <button @click="fetchHot()">重试</button>
            </div>

            <!-- 视频网格 -->
            <template v-else>
              <div class="feed-grid">
                <VideoCard v-for="v in displayList" :key="v.id" :data="v" @click="open" />
              </div>
            </template>
          </div>

          <!-- 右侧：热门话题 (1/4) -->
          <aside class="feed-sidebar">
            <div class="hot-topics">
              <h3 class="topics-title">🔥 热门话题</h3>
              <ul class="topics-list">
                <li v-for="(topic, idx) in displayTopics" :key="topic.id" class="topic-item">
                  <span class="topic-rank" :class="'rank-' + (idx + 1)">{{ idx + 1 }}</span>
                  <div class="topic-info">
                    <a href="javascript:void(0)" class="topic-name" :title="topic.title" @click.prevent="openTopic(topic.id)">{{ topic.title }}</a>
                    <p class="topic-desc">{{ topic.desc }}</p>
                  </div>
                </li>
              </ul>
              <button class="topics-more" @click="$router.push('/community')">
                查看更多
                <svg viewBox="0 0 24 24" fill="currentColor" style="width:14px;height:14px"><path d="M10 6L8.59 7.41 13.17 12l-4.58 4.59L10 18l6-6z"/></svg>
              </button>
            </div>
          </aside>
        </div>

        <!-- 更多内容入口独立于左右对齐网格，避免影响热门话题底线 -->
        <div v-if="!loading && allVideos.length" class="feed-sentinel">
          <div class="feed-more-main">
            <button class="feed-more-videos" type="button" @click="$router.push('/discover')">
              查看更多视频内容
              <el-icon><ArrowRight /></el-icon>
            </button>
          </div>
        </div>
      </section>

      <div style="height:48px"></div>
    </div>
  </div>
</template>

<script setup>
/**
 * Home.vue — 首页热门推荐
 *
 * 数据流:
 *   1. 调用 /api/catalog/hot 从数据库获取热门视频及浏览量
 *   2. 前 5 条 → 轮播 Banner
 *   3. 登录用户按历史、追番、点赞偏好推荐，游客随机抽取
 *   4. 首页视频固定最多 20 条
 */
import { ref, computed, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import axios from 'axios'
import { ArrowRight } from '@element-plus/icons-vue'
import { communityApi } from '@/api/modules/community'
import { useUserStore } from '@/stores/user'
import VideoCard from '@/components/home/VideoCard.vue'
import AdvertisementSlot from '@/components/common/AdvertisementSlot.vue'

const router = useRouter()
const userStore = useUserStore()
const contentSource = ref('database')
const homeAdVisible = ref(true)
const open = (video) => {
  const sourceVodId = video?.sourceVodId || video?.source_vod_id
  const databaseId = video?.databaseId || video?.vod_id || video?.id || video
  router.push(sourceVodId || contentSource.value === 'python' ? `/play/${sourceVodId || databaseId}` : `/anime/${databaseId}`)
}

// ===== 状态 =====
const loading = ref(true)
const error = ref('')
const banners = ref([])
const allVideos = ref([])

const BATCH = 20

// ===== 社区真实热门话题 =====
const hotTopics = ref([])
const displayTopics = computed(() => hotTopics.value.slice(0, 10))

const displayList = computed(() => allVideos.value)

function formatTopicCount(value) {
  return Number(value || 0).toLocaleString('zh-CN')
}

async function fetchHotTopics() {
  try {
    const result = await communityApi.getPosts({ sort: 'hot', page: 1, size: 10 })
    const list = result?.list || (Array.isArray(result) ? result : [])
    hotTopics.value = list.slice(0, 10).map(post => ({
      id: post.id,
      title: post.title,
      desc: `${formatTopicCount(post.comments)} 讨论 · ${formatTopicCount(post.likes)} 赞`,
    }))
  } catch (topicError) {
    console.error('[Home] 社区热门话题加载失败:', topicError)
    hotTopics.value = []
  }
}

function openTopic(id) {
  router.push(`/community/${id}`)
}

function formatBannerDescription(description) {
  const plainText = String(description || '')
    .replace(/<[^>]*>/g, '')
    .replace(/\s+/g, ' ')
    .trim()
  if (!plainText || plainText.includes('暂无简介')) return ''
  return plainText.length > 30 ? `${plainText.slice(0, 24)}......` : plainText
}

function mapVideo(v) {
  const rawTitle = v.title || ''
  const views = Number(v.views ?? v.hits ?? 0)
  return {
    id: v.vod_id,
    databaseId: v.vod_id,
    sourceVodId: v.sourceVodId || v.source_vod_id || null,
    title: rawTitle.length > 15 ? rawTitle.slice(0, 15) + '...' : rawTitle,
    cover: v.cover_proxy || v.cover,
    views: views > 0 ? String(views) : '--',
    likes: v.likes || v.stars ? Number(v.likes || v.stars) : 0,
    author: v.category || '',
    time: v.status || '',
    desc: v.desc || '',
    category: v.category || '',
    tags: v.tags || '',
    year: v.year || null,
  }
}

function shuffle(list) {
  const result = [...list]
  for (let index = result.length - 1; index > 0; index -= 1) {
    const target = Math.floor(Math.random() * (index + 1))
    ;[result[index], result[target]] = [result[target], result[index]]
  }
  return result
}

function responseList(response) {
  const payload = response?.data?.data ?? response?.data ?? response
  return payload?.list || (Array.isArray(payload) ? payload : [])
}

function splitTags(value) {
  return String(value || '')
    .split(/[,，/|\s]+/)
    .map(tag => tag.trim())
    .filter(Boolean)
}

async function selectHomeVideos(candidates) {
  const uniqueCandidates = Array.from(new Map(candidates.map(video => [String(video.vod_id), video])).values())
  if (!userStore.isLoggedIn) return shuffle(uniqueCandidates).slice(0, BATCH)

  const headers = userStore.token ? { Authorization: `Bearer ${userStore.token}` } : {}
  const requests = await Promise.allSettled([
    axios.get('/api/user/history', { headers, timeout: 10000 }),
    axios.get('/api/user/favorites', { headers, timeout: 10000 }),
    axios.get('/api/user/video-likes', { headers, timeout: 10000 }),
  ])
  const history = requests[0].status === 'fulfilled' ? responseList(requests[0].value) : []
  const favorites = requests[1].status === 'fulfilled' ? responseList(requests[1].value) : []
  const likedVideos = requests[2].status === 'fulfilled' ? responseList(requests[2].value) : []
  const signals = [...history, ...favorites, ...likedVideos]
  if (!signals.length) return shuffle(uniqueCandidates).slice(0, BATCH)

  const candidateById = new Map(uniqueCandidates.map(video => [Number(video.vod_id), video]))
  const interactedIds = new Set()
  const categoryWeights = new Map()
  const tagWeights = new Map()
  const yearWeights = new Map()
  const addWeight = (weights, key, amount) => {
    if (key === null || key === undefined || key === '') return
    weights.set(String(key), (weights.get(String(key)) || 0) + amount)
  }

  signals.forEach(signal => {
    const databaseId = Number(signal.animeId || signal.videoId || signal.id || 0)
    const matched = candidateById.get(databaseId)
    const source = matched || signal
    if (databaseId > 0) interactedIds.add(databaseId)
    addWeight(categoryWeights, source.category, 4)
    splitTags(source.tags).forEach(tag => addWeight(tagWeights, tag, 2))
    addWeight(yearWeights, source.year, 1)
  })

  return uniqueCandidates
    .map(video => {
      let score = Math.random()
      score += categoryWeights.get(String(video.category || '')) || 0
      score += yearWeights.get(String(video.year || '')) || 0
      splitTags(video.tags).forEach(tag => { score += tagWeights.get(tag) || 0 })
      if (interactedIds.has(Number(video.vod_id))) score -= 1000
      return { video, score }
    })
    .sort((left, right) => right.score - left.score)
    .slice(0, BATCH)
    .map(item => item.video)
}

// ===== 数据获取 =====
async function fetchHot() {
  loading.value = true
  error.value = ''

  try {
    const firstResponse = await axios.get('/api/catalog/hot', {
      params: { count: 100, page: 1 },
      timeout: 15000,
    })
    const firstData = firstResponse.data
    if (firstData.code !== 200 || !firstData.data?.list?.length) throw new Error('数据库暂无视频数据')

    const total = Number(firstData.data.total || firstData.data.list.length)
    const candidates = [...firstData.data.list]
    if (total > 100) {
      const secondResponse = await axios.get('/api/catalog/hot', {
        params: { count: 100, page: 2 },
        timeout: 15000,
      })
      candidates.push(...(secondResponse.data?.data?.list || []))
    }
    const list = await selectHomeVideos(candidates)

    if (list.length > 0) {
      const videoMap = new Map(list.map(v => [String(v.vod_id), v]))
      contentSource.value = 'database'
      const configuredBanners = (firstData.data?.banners || []).filter(b => videoMap.has(String(b.vod_id)))
      const mapBanner = b => {
        const related = videoMap.get(String(b.vod_id)) || b
        return { ...related, ...b, shortDesc: formatBannerDescription(related.desc) }
      }
      const validConfiguredBanners = configuredBanners.map(mapBanner).filter(b => Boolean(b.shortDesc))
      const validFallbackBanners = list.map(mapBanner).filter(b => Boolean(b.shortDesc))
      banners.value = (validConfiguredBanners.length ? validConfiguredBanners : validFallbackBanners).slice(0, 5)
      allVideos.value = list.slice(0, BATCH).map(mapVideo)
    } else {
      error.value = '暂无数据'
    }
  } catch (e) {
    console.warn('[Home] 数据库视频加载失败，回退到 Python:', e.message)
    await fetchPythonFallback()
  } finally {
    loading.value = false
  }
}

async function fetchPythonFallback() {
  try {
    const { data } = await axios.get('/api/anime/hot', {
      params: { count: 20, page: 1 },
      timeout: 35000,
    })
    const list = data.data?.list || []
    contentSource.value = 'python'
    banners.value = list
      .map(v => ({ ...v, shortDesc: formatBannerDescription(v.desc) }))
      .filter(v => Boolean(v.shortDesc))
      .slice(0, 5)
    allVideos.value = shuffle(list).slice(0, BATCH).map(mapVideo)
    error.value = list.length ? '' : '暂无视频数据'
  } catch (fallbackError) {
    console.error('[Home] Python 兜底加载失败:', fallbackError)
    error.value = '视频加载失败，请稍后重试'
  }
}

// ===== 生命周期 =====
onMounted(() => {
  fetchHot()
  fetchHotTopics()
})
</script>

<style scoped>
/* ================================================================
   Home — Light Theme · 12-col Grid
   ================================================================ */

/* ---- Page ---- */
.home {
  width: 100%;
  height: 100%;
  overflow-y: auto;
  background: var(--ds-surface-0, #f5f6fa);
}
.home-inner {
  max-width: 1280px;
  margin: 0 auto;
  padding: 0 var(--ds-space-4, 16px);
}

/* ================================================================
   Banner
   ================================================================ */
.banner {
  height: 340px;
  border-radius: var(--ds-radius-lg, 14px);
  overflow: hidden;
  margin-top: var(--ds-space-4, 16px);
  background: var(--ds-surface-3, #f0f1fa);
}
.banner :deep(.el-carousel),
.banner :deep(.el-carousel__container),
.banner :deep(.el-carousel-item) { height: 100% !important; }

.banner-slide {
  height: 100%; cursor: pointer; position: relative; overflow: hidden;
  background: linear-gradient(135deg, #1a1a2e 0%, #2d2d44 100%);
}

/* 模糊背景层 — 填充整个区域 */
.banner-bg {
  position: absolute; inset: 0;
  background: center / cover no-repeat;
  filter: blur(20px) brightness(0.5) saturate(1.2);
  transform: scale(1.1);
}
.banner-bg::after {
  content: '';
  position: absolute; inset: 0;
  background: linear-gradient(90deg, rgba(10,10,26,.85) 0%, rgba(10,10,26,.35) 60%, rgba(10,10,26,.15) 100%);
}

.banner-mask {
  height: 100%;
  display: flex; align-items: center; position: relative; z-index: 1;
  padding: 0 var(--ds-space-12, 48px) 0 120px;
}
.banner-text {
  max-width: 460px;
  color: #fff;
}
.banner-chip {
  margin-bottom: var(--ds-space-3, 12px);
  font-weight: var(--ds-font-semibold, 600) !important;
}
.banner-text h1 {
  font-size: var(--ds-text-2xl, 1.9375rem);
  font-weight: var(--ds-font-extrabold, 800);
  margin: 0 0 var(--ds-space-3, 12px);
  line-height: var(--ds-leading-tight, 1.25);
  text-shadow: 0 2px 16px rgba(0,0,0,.55);
  letter-spacing: -0.02em;
}
.banner-text p {
  font-size: var(--ds-text-base, 1rem);
  opacity: .86;
  margin: 0;
  line-height: var(--ds-leading-relaxed, 1.65);
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}

/* Banner 骨架 */
.banner-skeleton {
  display: flex;
  align-items: center;
  justify-content: center;
}
.banner-shimmer {
  width: 100%;
  height: 100%;
  background: linear-gradient(90deg, #e8e9f4 0%, #f0f1fa 50%, #e8e9f4 100%);
  background-size: 200% 100%;
  animation: shimmer 1.6s ease-in-out infinite;
}

/* 指示器 */
.banner :deep(.el-carousel__indicators) { bottom: var(--ds-space-4, 16px); }
.banner :deep(.el-carousel__indicator .el-carousel__button) {
  width: 28px; height: 4px; border-radius: 3px;
  background: rgba(255,255,255,.3); opacity: 1;
}
.banner :deep(.el-carousel__indicator.is-active .el-carousel__button) {
  width: 44px;
  background: var(--ds-gradient-hero, linear-gradient(135deg, #667eea, #764ba2));
}

/* 轮播箭头 */
.banner :deep(.el-carousel__arrow) {
  width: 48px; height: 48px; font-size: 22px;
  background: transparent; border-radius: 50%; color: #fff;
  text-shadow: 0 1px 4px rgba(0,0,0,0.4);
}
.banner :deep(.el-carousel__arrow:hover) {
  background: rgba(255, 255, 255, 0.15);
}

/* ================================================================
   Feed
   ================================================================ */
.feed {
  margin-top: var(--ds-space-10, 40px);
  padding-top: var(--ds-space-6, 24px);
  border-top: 1px solid var(--ds-border-subtle, rgba(0,0,0,.06));
}

/* 标题行 */
.feed-head {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  margin-bottom: var(--ds-space-5, 20px);
}
.feed-head-left {
  display: flex;
  align-items: center;
  gap: var(--ds-space-3, 12px);
}
.feed-icon { font-size: var(--ds-text-lg, 1.25rem); margin-top: 2px; }
.feed-head h2 {
  margin: 0 0 2px;
  font-size: var(--ds-text-lg, 1.25rem);
  font-weight: var(--ds-font-bold, 700);
  color: var(--ds-text-primary, #1a1a2e);
  letter-spacing: -0.01em;
}
.feed-sub {
  margin: 0;
  font-size: var(--ds-text-xs, 0.75rem);
  color: var(--ds-text-tertiary, #8f92a1);
}
.feed-more {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  border: none; background: none;
  font-size: var(--ds-text-sm, 0.8125rem);
  color: var(--ds-text-tertiary, #8f92a1);
  cursor: pointer; padding: 4px 8px;
  border-radius: var(--ds-radius-sm, 6px);
  transition: color var(--ds-duration-fast, 120ms);
  font-family: inherit;
}
.feed-more:hover { color: var(--ds-accent, #7c5ce7); }

/* 左右布局 */
.feed-layout {
  display: grid;
  grid-template-columns: minmax(0, 1fr) minmax(240px, 300px);
  grid-template-rows: auto minmax(0, 1fr);
  grid-template-areas:
    "main ad"
    "main sidebar";
  gap: var(--ds-space-5, 20px);
  align-items: stretch;
}
.feed-main {
  grid-area: main;
  min-width: 0;
}
.feed-sidebar {
  grid-area: sidebar;
  align-self: stretch;
  width: 100%;
  min-width: 0;
}
.home-ad { grid-area: ad; width: 100%; max-width: 300px; justify-self: end; }
.feed-layout.without-ad {
  grid-template-areas: "main sidebar";
  grid-template-rows: minmax(0, 1fr);
}

/* 网格 */
.feed-grid {
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  grid-auto-rows: 1fr;
  align-items: stretch;
  gap: var(--ds-space-4, 16px);
}

/* 空状态 */
.feed-empty {
  text-align: center; padding: 60px 0;
  font-size: 0.875rem; color: #8f92a1;
  display: flex; flex-direction: column; align-items: center; gap: 12px;
}
.feed-empty button {
  padding: 6px 24px; border: 1px solid #7c5ce7; border-radius: 16px;
  background: transparent; color: #7c5ce7; cursor: pointer;
}

/* ================================================================
   Skeleton
   ================================================================ */
.vc-card.is-skeleton { pointer-events: none; }
.vc-card.is-skeleton .vc-cover {
  aspect-ratio: 16/9;
  background: linear-gradient(90deg, #e8e9f4 0%, #f0f1fa 50%, #e8e9f4 100%);
  background-size: 200% 100%;
  animation: shimmer 1.6s ease-in-out infinite;
  border-radius: 10px 10px 0 0;
}
.sk-line {
  height: 12px; border-radius: 6px; margin-bottom: 8px;
  background: linear-gradient(90deg, #e8e9f4 0%, #f0f1fa 50%, #e8e9f4 100%);
  background-size: 200% 100%;
  animation: shimmer 1.6s ease-in-out infinite;
}
.sk-title { width: 80%; }
.sk-meta  { width: 50%; }

@keyframes shimmer {
  0%   { background-position: 200% 0; }
  100% { background-position: -200% 0; }
}

/* 懒加载 */
.feed-sentinel {
  display: grid;
  grid-template-columns: minmax(0, 1fr) minmax(240px, 300px);
  column-gap: var(--ds-space-5, 20px);
  padding: 32px 0 16px;
}
.feed-more-main {
  grid-column: 1;
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: var(--ds-space-4, 16px);
}
.feed-more-videos {
  grid-column: 4;
  justify-self: end;
  display: inline-flex;
  align-items: center;
  gap: 5px;
  padding: 7px 4px;
  border: 0;
  background: transparent;
  color: var(--ds-accent, #7c5ce7);
  font: inherit;
  font-size: 13px;
  font-weight: 500;
  white-space: nowrap;
  cursor: pointer;
}
.feed-more-videos .el-icon { width: 14px; height: 14px; font-size: 14px; }
.feed-more-videos:hover { color: #5b45df; }

/* ================================================================
   Hot Topics Sidebar
   ================================================================ */
.hot-topics {
  display: flex;
  height: 100%;
  flex-direction: column;
  box-sizing: border-box;
  background: var(--ds-surface-raised, #fff);
  border-radius: var(--ds-radius-lg, 12px);
  padding: var(--ds-space-5, 20px);
  border: 1px solid var(--ds-border-subtle, rgba(0,0,0,.06));
  position: sticky;
  top: 16px;
}
.topics-title {
  font-size: var(--ds-text-base, 1rem);
  font-weight: var(--ds-font-bold, 700);
  color: var(--ds-text-primary, #1a1a2e);
  margin: 0 0 var(--ds-space-4, 16px);
}
.topics-list {
  flex: 1;
  list-style: none;
  margin: 0;
  padding: 0;
}
.topic-item {
  display: flex;
  align-items: flex-start;
  gap: var(--ds-space-3, 10px);
  padding: 10px 0;
  border-bottom: 1px solid var(--ds-border-subtle, rgba(0,0,0,.04));
  transition: background .15s;
}
.topic-item:last-child {
  border-bottom: none;
}
.topic-item:hover {
  background: var(--ds-surface-1, #f8f9fc);
  margin: 0 -8px;
  padding-left: 8px;
  padding-right: 8px;
  border-radius: var(--ds-radius-sm, 6px);
}
.topic-rank {
  flex-shrink: 0;
  width: 22px;
  height: 22px;
  border-radius: var(--ds-radius-sm, 6px);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 0.75rem;
  font-weight: var(--ds-font-bold, 700);
  color: var(--ds-text-tertiary, #8f92a1);
  background: var(--ds-surface-3, #f0f1fa);
  margin-top: 1px;
}
.topic-rank.rank-1 { background: #ff6b6b; color: #fff; }
.topic-rank.rank-2 { background: #ffa502; color: #fff; }
.topic-rank.rank-3 { background: #ffd43b; color: #333; }
.topic-info {
  flex: 1;
  min-width: 0;
}
.topic-name {
  display: block;
  font-size: var(--ds-text-xs, 0.8125rem);
  font-weight: var(--ds-font-medium, 500);
  color: var(--ds-text-primary, #1a1a2e);
  text-decoration: none;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  transition: color .15s;
}
.topic-name:hover {
  color: var(--ds-accent, #7c5ce7);
}
.topic-desc {
  margin: 3px 0 0;
  font-size: 0.7rem;
  color: var(--ds-text-tertiary, #8f92a1);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.topics-more {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 4px;
  width: 100%;
  margin-top: var(--ds-space-4, 14px);
  padding: 8px 0;
  border: 1px solid var(--ds-border-subtle, rgba(0,0,0,.08));
  border-radius: var(--ds-radius-md, 8px);
  background: var(--ds-surface-1, #f8f9fc);
  font-size: var(--ds-text-xs, 0.8125rem);
  color: var(--ds-accent, #7c5ce7);
  cursor: pointer;
  transition: all .2s;
  font-family: inherit;
}
.topics-more:hover {
  background: var(--ds-accent, #7c5ce7);
  color: #fff;
  border-color: var(--ds-accent, #7c5ce7);
}

/* ================================================================
   Responsive
   ================================================================ */
@media (max-width: 1199px) and (min-width: 900px) {
  .feed-grid { grid-template-columns: repeat(3,minmax(0,1fr)); }
  .feed-layout { grid-template-columns: minmax(0,1fr) minmax(200px,240px); }
  .feed-sentinel { grid-template-columns: minmax(0,1fr) minmax(200px,240px); }
  .feed-more-main { grid-template-columns: repeat(3,minmax(0,1fr)); }
  .feed-more-videos { grid-column: 3; }
}
@media (max-width:  899px) and (min-width: 600px) {
  .feed-layout {
    grid-template-columns: 1fr;
    grid-template-rows: auto;
    grid-template-areas: "ad" "main" "sidebar";
  }
  .feed-layout.without-ad { grid-template-areas: "main" "sidebar"; grid-template-rows: auto; }
  .home-ad { width: min(340px,100%); max-width: none; justify-self: center; }
  .feed-sidebar { width: 100%; max-width: none; min-width: 0; }
  .feed-grid { grid-template-columns: repeat(3,minmax(0,1fr)); }
  .feed-sentinel { grid-template-columns: 1fr; }
  .feed-more-main { grid-template-columns: repeat(3,minmax(0,1fr)); }
  .feed-more-videos { grid-column: 3; }
  .banner { height: 260px; }
  .banner-text h1 { font-size: var(--ds-text-xl, 1.5625rem); }
  .banner-text p  { font-size: var(--ds-text-sm, 0.8125rem); }
  .banner-mask { padding: 0 var(--ds-space-8, 32px); }
  .hot-topics { height: auto; position: static; }
}
@media (max-width: 599px) {
  .feed-layout {
    grid-template-columns: 1fr;
    grid-template-rows: auto;
    grid-template-areas: "ad" "main" "sidebar";
  }
  .feed-layout.without-ad { grid-template-areas: "main" "sidebar"; grid-template-rows: auto; }
  .home-ad { width: min(320px,100%); max-width: none; justify-self: center; }
  .feed-sidebar { width: 100%; max-width: none; min-width: 0; }
  .feed-grid { grid-template-columns: repeat(2,minmax(0,1fr)); gap: var(--ds-space-3, 12px); }
  .feed-sentinel { grid-template-columns: 1fr; }
  .feed-more-main { grid-template-columns: repeat(2,minmax(0,1fr)); gap:var(--ds-space-3,12px); }
  .feed-more-videos { grid-column: 2; }
  .home-inner { padding: 0 var(--ds-space-3, 12px); }
  .banner { height: 180px; border-radius: var(--ds-radius-md, 10px); margin-top: var(--ds-space-3, 12px); }
  .banner-text h1 { font-size: 1.125rem; }
  .banner-text p  { font-size: var(--ds-text-xs, 0.75rem); margin-bottom: var(--ds-space-3); display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden; }
  .banner-mask { padding: 0 var(--ds-space-4, 16px); }
  .feed-head h2 { font-size: var(--ds-text-base, 1rem); }
  .hot-topics { height: auto; position: static; }
}
</style>
