<template>
  <div class="login-container">
    <!-- ===== 左侧：动画区域 ===== -->
    <div class="left-panel">
  
      <div class="animation-wrapper">
        <AnimatedCharacters
          :isTyping="isTyping"
          :showPassword="showPassword"
          :passwordLength="form.password.length"
        />
      </div>
    </div>

    <!-- ===== 右侧：登录表单 ===== -->
    <div class="right-panel">
      <div class="form-container">

        <div class="form-header">
          <h1 class="form-title">欢迎回来！</h1>
          <p class="form-subtitle">登录你的账号</p>
        </div>

        <form @submit.prevent="onSubmit" class="login-form">
          <div class="form-group">
            <label for="email" class="form-label">邮箱</label>
            <input
              id="email"
              type="email"
              placeholder="you@example.com"
              autocomplete="off"
              v-model="form.email"
              @focus="isTyping = true"
              @blur="isTyping = false"
              class="form-input"
            />
            <p v-if="errors.email" class="form-error">{{ errors.email }}</p>
          </div>

          <div class="form-group">
            <label for="password" class="form-label">密码</label>
            <div class="password-wrapper">
              <input
                id="password"
                :type="showPassword ? 'text' : 'password'"
                placeholder="••••••••"
                v-model="form.password"
                @focus="isTyping = true"
                @blur="isTyping = false"
                class="form-input password-input"
              />
              <button
                type="button"
                @click="showPassword = !showPassword"
                class="password-toggle"
              >
                <svg v-if="showPassword" xmlns="http://www.w3.org/2000/svg" class="size-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <path d="M9.87 9.87a3 3 0 1 0 4.26 4.26" />
                  <path d="M10.73 5.08A10.43 10.43 0 0 1 12 5c7 0 10 7 10 7a13.16 13.16 0 0 1-1.67 2.68" />
                  <path d="M6.61 6.61A13.526 13.526 0 0 0 2 12s3 7 10 7c.44 0 .87-.03 1.3-.08" />
                </svg>
                <svg v-else xmlns="http://www.w3.org/2000/svg" class="size-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z" />
                  <path d="M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6Z" />
                </svg>
              </button>
            </div>
            <p v-if="errors.password" class="form-error">{{ errors.password }}</p>
          </div>

          <div class="form-options">
            <div class="remember-me">
              <input id="remember" type="checkbox" v-model="form.remember" class="checkbox" />
              <label for="remember" class="checkbox-label">记住我</label>
            </div>
            <RouterLink to="/forgot-password" class="forgot-link">忘记密码？</RouterLink>
          </div>

          <div v-if="error" class="form-error-box">{{ error }}</div>

          <button type="submit" :disabled="isLoading" class="submit-btn">
            {{ isLoading ? '登录中...' : '登录' }}
          </button>
        </form>

        <div class="register-link">
          还没有账号？
          <RouterLink to="/register" class="register-link-highlight">立即注册</RouterLink>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive, computed } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import { ElMessage } from 'element-plus'
import { useUserStore } from '@/stores/user'
import { userApi } from '@/api/modules/user'
import AnimatedCharacters from '@/components/AnimatedCharacters.vue'

import { onMounted } from 'vue'

const router = useRouter()
const route = useRoute()
const userStore = useUserStore()

// 注册成功后自动填入邮箱
onMounted(() => {
  if (route.query.email) {
    form.email = route.query.email
  }
})

const showPassword = ref(false)
const isTyping = ref(false)
const isLoading = ref(false)
const error = ref('')

const form = reactive({
  email: '',
  password: '',
  remember: false
})

const errors = computed(() => {
  const result = {}
  if (!form.email) {
    result.email = '请输入邮箱地址'
  } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) {
    result.email = '请输入有效的邮箱地址'
  }
  if (!form.password) {
    result.password = '请输入密码'
  } else if (form.password.length < 6) {
    result.password = '密码至少6个字符'
  }
  return result
})

/**
 * 登录 —— 调用后端 /api/user/login 接口
 * 后端返回格式: { code: 200, data: { token, userInfo }, message: 'success' }
 * axios 拦截器已自动解包 data 层，所以这里直接拿 token 和 userInfo
 */
const onSubmit = async () => {
  if (Object.keys(errors.value).length > 0) return
  isLoading.value = true
  error.value = ''

  try {
    // 调用后端登录接口
    const result = await userApi.login({
      email: form.email,
      password: form.password
    })

    // result = { token: 'xxx', userInfo: { username, email, avatar, role, ... } }
    const { token, userInfo } = result

    // 写入 Pinia Store + localStorage
    userStore.setLogin(token, userInfo)
    ElMessage.success(`欢迎回来，${userInfo.username || userInfo.nickname}！🐻`)

    if (userInfo.role === 'admin') {
      router.push('/admin/dashboard')
    } else {
      const redirect = route.query.redirect || '/'
      router.push(redirect)
    }
  } catch (err) {
    // 优先显示后端返回的业务错误，其次显示网络错误
    if (err?.response?.data?.message) {
      error.value = err.response.data.message
    } else if (err?.message) {
      error.value = err.message
    } else {
      error.value = '登录失败，请检查后端是否已启动（双击 启动后端.bat）'
    }
    console.error('[登录失败]', err)
  } finally {
    isLoading.value = false
  }
}
</script>

<style scoped>
/* ===== 整体容器：铺满 app-body ===== */
.login-container {
  display: grid;
  grid-template-columns: 1fr 1fr;
  width: 100%;
  height: 100%;
  overflow: hidden;
  background: #ffffff;
}

/* ===== 左侧面板 ===== */
.left-panel {
  position: relative;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  padding: 24px 32px 20px;
  background: linear-gradient(135deg, #8a8f9a, #6b7280, #4b5563);
  color: #ffffff;
}

.left-panel::before {
  content: '';
  position: absolute;
  inset: 0;
  background: radial-gradient(circle at 30% 40%, rgba(255, 255, 255, 0.08) 0%, transparent 60%),
              radial-gradient(circle at 70% 80%, rgba(255, 255, 255, 0.05) 0%, transparent 50%);
  pointer-events: none;
}

.logo-wrapper {
  position: relative;
  z-index: 2;
}

.logo {
  font-size: 22px;
  font-weight: 700;
  cursor: pointer;
  background: linear-gradient(135deg, #c4b5fd, #a78bfa);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
  display: inline-block;
}

.animation-wrapper {
  position: relative;
  z-index: 2;
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: center;
  min-height: 0;
}

.footer-links {
  position: relative;
  z-index: 2;
  display: flex;
  gap: 24px;
  font-size: 12px;
  color: rgba(255, 255, 255, 0.6);
}

.footer-link {
  color: rgba(255, 255, 255, 0.6);
  text-decoration: none;
  transition: color 0.2s;
}
.footer-link:hover {
  color: #ffffff;
}

/* ===== 右侧面板 ===== */
.right-panel {
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 24px 32px;
  background: #ffffff;
}

.form-container {
  width: 100%;
  max-width: 380px;
}

.mobile-logo {
  display: none;
  justify-content: center;
  margin-bottom: 20px;
}

.form-header {
  text-align: center;
  margin-bottom: 16px;
}

.form-title {
  font-size: 22px;
  font-weight: 700;
  color: #1a1a2e;
  margin-bottom: 2px;
}

.form-subtitle {
  font-size: 13px;
  color: #6b7280;
}

.login-form {
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.form-group {
  display: flex;
  flex-direction: column;
  gap: 2px;
}

.form-label {
  font-size: 13px;
  font-weight: 500;
  color: #374151;
}

.form-input {
  width: 100%;
  height: 38px;
  padding: 0 14px;
  background: #f9fafb;
  border: 1.5px solid #e5e7eb;
  border-radius: 8px;
  font-size: 14px;
  color: #1a1a2e;
  outline: none;
  transition: border-color 0.25s ease, box-shadow 0.25s ease;
}

.form-input:focus {
  border-color: #667eea;
  box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.10);
}

.form-input::placeholder {
  color: #9ca3af;
}

.password-wrapper {
  position: relative;
}
.password-input {
  padding-right: 40px;
}

.password-toggle {
  position: absolute;
  right: 10px;
  top: 50%;
  transform: translateY(-50%);
  background: none;
  border: none;
  color: #9ca3af;
  cursor: pointer;
  padding: 4px;
}
.password-toggle:hover {
  color: #374151;
}
.password-toggle svg {
  width: 18px;
  height: 18px;
}

.form-error {
  font-size: 12px;
  color: #ef4444;
  margin-top: 1px;
}

.form-options {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin: 2px 0;
}

.remember-me {
  display: flex;
  align-items: center;
  gap: 6px;
}

.checkbox {
  width: 14px;
  height: 14px;
  accent-color: #667eea;
  cursor: pointer;
}

.checkbox-label {
  font-size: 13px;
  color: #6b7280;
  cursor: pointer;
}

.forgot-link {
  font-size: 13px;
  font-weight: 500;
  color: #667eea;
  text-decoration: none;
}
.forgot-link:hover {
  color: #4a63c7;
  text-decoration: underline;
}

.form-error-box {
  padding: 8px 12px;
  font-size: 13px;
  color: #ef4444;
  background: rgba(239, 68, 68, 0.06);
  border: 1px solid rgba(239, 68, 68, 0.20);
  border-radius: 8px;
}

.submit-btn {
  width: 100%;
  height: 40px;
  background: linear-gradient(135deg, #667eea, #764ba2);
  color: #ffffff;
  font-size: 15px;
  font-weight: 600;
  border: none;
  border-radius: 8px;
  cursor: pointer;
  transition: none;
  margin-top: 2px;
}

.submit-btn:hover:not(:disabled) {
  opacity: 0.88;
}
.submit-btn:disabled {
  opacity: 0.6;
  cursor: not-allowed;
}

.register-link {
  text-align: center;
  font-size: 13px;
  color: #6b7280;
  margin-top: 12px;
}

.register-link-highlight {
  font-weight: 500;
  color: #1a1a2e;
  text-decoration: none;
}
.register-link-highlight:hover {
  color: #667eea;
  text-decoration: underline;
}

/* ===== 响应式 ===== */
@media (max-width: 1024px) {
  .login-container {
    grid-template-columns: 1fr;
    height: auto;
    min-height: 100%;
    overflow-y: auto;
  }
  .left-panel {
    display: none;
  }
  .mobile-logo {
    display: flex;
  }
  .right-panel {
    padding: 24px 16px;
    min-height: 100%;
  }
  .form-container {
    max-width: 360px;
  }
}

@media (max-width: 480px) {
  .form-title {
    font-size: 20px;
  }
  .form-input {
    height: 36px;
    font-size: 13px;
  }
  .submit-btn {
    height: 38px;
    font-size: 14px;
  }
}
</style>
