<!--
  社区互动页
  功能：帖子列表、发布帖子、点赞、评论预览
  参考设计：Bilibili 动态页
-->
<template>
  <div class="community-page">
    <DynamicBanner :layers="bannerLayers" />

    <div class="community-body">
      <!-- 左侧帖子列表 -->
      <div class="post-list-section">
        <!-- 发帖入口 (文字 + 图片) -->
        <div class="post-editor-card">
          <UserAvatar :size="40" :src="userStore.avatar" :name="userStore.username" :user-id="userStore.userInfo?.id" />
          <div class="editor-body">
            <el-input
              ref="postEditorRef"
              v-model="newPostContent"
              type="textarea"
              :rows="2"
              placeholder="分享你的动漫感想... 🎬"
              resize="none"
            />
            <div class="editor-tag-row">
              <span class="editor-tag-label">内容标签</span>
              <el-select v-model="newPostTag" size="small" class="editor-tag-select">
                <el-option
                  v-for="tag in postTagOptions"
                  :key="tag"
                  :label="tag"
                  :value="tag"
                />
              </el-select>
            </div>
            <!-- 图片预览 -->
            <div v-if="previewImages.length" class="preview-grid">
              <div
                v-for="(img, i) in previewImages"
                :key="i"
                class="preview-item"
              >
                <img :src="img" class="preview-thumb" />
                <button
                  type="button"
                  class="preview-remove"
                  :aria-label="`删除第 ${i + 1} 张图片`"
                  @click.stop="removeSelectedImage(i)"
                >
                  <svg viewBox="0 0 24 24" aria-hidden="true">
                    <path d="M7 7l10 10M17 7L7 17" />
                  </svg>
                </button>
              </div>
            </div>
            <input
              ref="fileInput"
              type="file"
              accept="image/*"
              multiple
              style="display:none"
              @change="onFileSelected"
            />
          </div>
          <div class="editor-actions">
            <div class="editor-image-actions">
              <button
                type="button"
                class="editor-upload-btn"
                :disabled="previewImages.length >= 9"
                @click="triggerUpload"
              >
                <svg viewBox="0 0 24 24" aria-hidden="true">
                  <rect x="3" y="5" width="18" height="14" rx="2" />
                  <circle cx="8.5" cy="10" r="1.5" />
                  <path d="M5 17l4.5-4 3.2 2.8 2.5-2.2L19 17" />
                </svg>
                <span>{{ previewImages.length >= 9 ? '图片已满' : '添加图片' }}</span>
              </button>
              <span class="editor-image-count">{{ previewImages.length }} / 9</span>
            </div>
            <el-button
              type="primary" size="small"
              @click="publishPost"
              :loading="publishing"
              :disabled="publishing || (!newPostContent.trim() && !previewImages.length)"
            >
              发布
            </el-button>
          </div>
        </div>

        <!-- 分类 Tab -->
        <el-tabs v-model="postTab">
          <el-tab-pane label="📋 综合" name="all" />
          <el-tab-pane label="🔥 热门" name="hot" />
          <el-tab-pane label="🆕 最新" name="new" />
          <el-tab-pane label="📺 追番" name="following" />
        </el-tabs>

        <!-- 话题筛选提示 -->
        <div v-if="selectedTopic" class="topic-filter-bar">
          🔍 筛选话题：<strong>#{{ selectedTopic }}</strong>
          <span class="topic-filter-clear" @click="selectedTopic = ''">✕ 清除</span>
        </div>

        <!-- 帖子列表 -->
        <div class="post-list" v-loading="loading">
          <div
            v-for="post in visiblePosts"
            :key="post.id"
            class="post-card"
            @click="goToPost(post.id)"
          >
            <!-- 作者信息 -->
            <div class="post-header">
              <UserAvatar :size="44" :src="post.authorAvatar" :name="post.author" :user-id="post.authorId" />
              <div class="post-author-info">
                <span class="post-author">{{ post.author }}</span>
                <span class="post-time">{{ post.time }}</span>
              </div>
              <el-tag v-if="post.tag" size="small" effect="plain" round>{{ post.tag }}</el-tag>
              <el-tag v-if="isHotPost(post)" size="small" type="danger" effect="dark" round>🔥 热门</el-tag>
            </div>

            <!-- 内容 -->
            <div class="post-content">
              <h3 class="post-title">{{ post.title }}</h3>
              <p class="post-text">{{ post.content }}</p>
              <!-- 图片预览 -->
              <div class="post-images" v-if="post.images && post.images.length">
                <img
                  v-for="(img, i) in post.images.slice(0, 4)"
                  :key="i"
                  :src="img"
                  class="post-img"
                  :class="'img-count-' + Math.min(post.images.length, 4)"
                />
              </div>
            </div>

            <!-- 互动数据 -->
            <div class="post-footer">
              <EngagementAction type="like" :count="post.likes" :active="likedPosts.has(post.id)" clickable @click="likePost(post)" />
              <EngagementAction type="comment" :count="post.comments" clickable @click="goToPost(post.id)" />
              <EngagementAction type="share" label="分享" clickable @click="sharePost(post)" />
              <span class="post-views">👁️ {{ post.views }}</span>
            </div>
          </div>

          <div v-if="!loading && filteredPosts.length === 0" class="post-empty-state">
            <div class="post-empty-icon">{{ emptyState.icon }}</div>
            <h3>{{ emptyState.title }}</h3>
            <p>{{ emptyState.description }}</p>
            <el-button type="primary" round @click="focusPostEditor">
              {{ emptyState.action }}
            </el-button>
          </div>

          <div ref="postLoadSentinel" v-show="!loading && filteredPosts.length && (hasMorePosts || loadingMore || totalPosts > 5)" class="lazy-load-status">
            <span v-if="loadingMore" class="loading-more-indicator">
              <i class="loading-more-spinner" aria-hidden="true"></i>
              正在加载更多内容...
            </span>
            <span v-else-if="hasMorePosts">向下滑动，加载更多内容</span>
            <span v-else>已经看完全部内容了</span>
          </div>
        </div>
      </div>

      <!-- 右侧面板 -->
      <div class="community-sidebar">
        <AdvertisementSlot position="community_sidebar" variant="compact" class="community-ad" />

        <div class="community-fixed-panels">
          <!-- 热门话题 -->
          <div class="side-card">
            <h4>🔥 热门话题</h4>
            <div class="topic-list">
              <span
                v-for="t in hotTopics"
                :key="t"
                class="topic-tag"
                :class="{ active: selectedTopic === t }"
                @click="selectTopic(t)"
              >#{{ t }}</span>
            </div>
          </div>

          <!-- 活跃用户 -->
          <div class="side-card">
            <h4>🌟 活跃用户</h4>
            <div class="user-list">
              <div
                v-for="u in activeUsers"
                :key="u.name"
                class="side-user"
                @click="openUserProfile(u)"
              >
                <UserAvatar :size="32" :src="u.avatar" :name="u.name" :user-id="u.id" />
                <span class="side-user-name">{{ u.name }}</span>
                <span class="side-user-badge">{{ u.badge }}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

  </div>
</template>

<script setup>
import { ref, computed, watch, onMounted, onBeforeUnmount } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import { useAuth } from '@/composables/useAuth'
import { useUserStore } from '@/stores/user'
import UserAvatar from '@/components/common/UserAvatar.vue'
import EngagementAction from '@/components/common/EngagementAction.vue'
import request from '@/api/request'
import { communityApi } from '@/api/modules/community'
import DynamicBanner from '@/components/community/DynamicBanner.vue'
import AdvertisementSlot from '@/components/common/AdvertisementSlot.vue'
import { normalizeBannerLayers } from '@/utils/bannerEffects'

const router = useRouter()
const { requireAuth } = useAuth()
const userStore = useUserStore()

// ===== 动态 Banner 图层 (DOMMatrix 格式, 兼容 data.json) =====
const bannerLayers = ref([])

async function loadBannerData() {
  try {
    const resp = await fetch('/banner/2023-10-26/data.json')
    const data = normalizeBannerLayers(await resp.json(), { baseUrl: '/banner/2023-10-26' })
    bannerLayers.value = data
    // 文字层
    bannerLayers.value.push({
      tagName: 'div',
      a: 0.02, deg: 0, g: 0.01, f: 0,
      opacity: [1, 1], transform: [1, 0, 0, 1, 0, 0],
      content: { title: '💬 社区广场', desc: '与动漫同好交流讨论，分享你的热爱 ✨' },
    })
  } catch (e) {
    console.warn('Banner 数据加载失败:', e)
  }
}
loadBannerData()

// 页面加载时获取数据
onMounted(() => {
  loadBannerData()
  fetchPosts('all')
  fetchActiveUsers()
})

const newPostContent = ref('')
const newPostTag = ref('分享')
const postTagOptions = ['分享', '追番', '推荐', '漫评', '资讯']
const postEditorRef = ref(null)
const fileInput = ref(null)
const previewImages = ref([])
const selectedFiles = ref([])
const publishing = ref(false)
const postTab = ref('all')
const selectedTopic = ref('')

const emptyState = computed(() => {
  if (selectedTopic.value) {
    return {
      icon: '🔎',
      title: `#${selectedTopic.value} 暂无内容`,
      description: '这个话题还没有人发布分享，欢迎你来开启第一场交流。',
      action: '发布第一条分享',
    }
  }
  const states = {
    all: {
      icon: '🌱',
      title: '社区还在等待第一位分享者',
      description: '这里暂时没有内容，分享一部最近在看的动漫，开启第一场交流吧。',
      action: '发布第一条分享',
    },
    hot: {
      icon: '🔥',
      title: '热门席位正在等待',
      description: '目前还没有达到热门标准的内容，发布优质分享并邀请大家一起互动吧。',
      action: '发布优质内容',
    },
    new: {
      icon: '✨',
      title: '这里还没有最新分享',
      description: '记录此刻的动漫心情，让你的分享成为社区今天的新鲜内容。',
      action: '发布最新分享',
    },
    following: {
      icon: '📺',
      title: '追番区还没有人发布',
      description: '来记录追番进度、更新提醒或最新一集感想，让同好一起追起来吧。',
      action: '发布追番动态',
    },
  }
  return states[postTab.value] || states.all
})

function openUserProfile(u) {
  if (!requireAuth()) return
  router.push(`/home/${encodeURIComponent(u.name)}`)
}

function selectTopic(t) {
  selectedTopic.value = selectedTopic.value === t ? '' : t
}

function focusPostEditor() {
  if (postTab.value === 'following') newPostTag.value = '追番'
  const textarea = postEditorRef.value?.$el?.querySelector('textarea')
  textarea?.focus()
  textarea?.scrollIntoView({ behavior: 'smooth', block: 'center' })
}

// 热门条件: 点赞≥500 或 评论≥500
const isHotPost = (p) => p.likes >= 500 || p.comments >= 500

const filteredPosts = computed(() => {
  return posts.value
})

const postLoadSentinel = ref(null)
const visiblePosts = computed(() => posts.value)
const currentPostPage = ref(1)
const totalPosts = ref(0)
const hasMorePosts = ref(false)
const loadingMore = ref(false)
let postLoadObserver = null

function loadMorePosts() {
  if (!loading.value && !loadingMore.value && hasMorePosts.value) {
    fetchPosts(postTab.value, false)
  }
}

watch([postTab, selectedTopic], () => {
  fetchPosts(postTab.value, true)
})

onMounted(() => {
  postLoadObserver = new IntersectionObserver(entries => {
    if (entries.some(entry => entry.isIntersecting)) loadMorePosts()
  }, { rootMargin: '160px 0px' })
  if (postLoadSentinel.value) postLoadObserver.observe(postLoadSentinel.value)
})

onBeforeUnmount(() => postLoadObserver?.disconnect())

function triggerUpload() {
  fileInput.value?.click()
}

function onFileSelected(e) {
  const files = Array.from(e.target.files)
  if (previewImages.value.length + files.length > 9) {
    ElMessage.warning('最多上传 9 张图片')
    return
  }
  files.forEach(file => {
    if (!file.type.startsWith('image/')) {
      ElMessage.warning('仅支持图片文件')
      return
    }
    if (file.size > 10 * 1024 * 1024) {
      ElMessage.warning('单张图片不能超过 10MB')
      return
    }
    selectedFiles.value.push(file)
    previewImages.value.push(URL.createObjectURL(file))
  })
  e.target.value = ''
}

function removeSelectedImage(index) {
  const preview = previewImages.value[index]
  if (preview) URL.revokeObjectURL(preview)
  previewImages.value.splice(index, 1)
  selectedFiles.value.splice(index, 1)
}

function clearSelectedImages() {
  previewImages.value.forEach(preview => URL.revokeObjectURL(preview))
  previewImages.value = []
  selectedFiles.value = []
}

onBeforeUnmount(clearSelectedImages)

// ===== 从后端拉取数据 =====
const posts = ref([])
const activeUsers = ref([])
const hotTopics = ref([])
const loading = ref(false)

// 格式化时间
function fmtTime(ts) {
  if (!ts) return ''
  const d = new Date(ts)
  const now = new Date()
  const diff = now - d
  if (diff < 60000) return '刚刚'
  if (diff < 3600000) return Math.floor(diff / 60000) + '分钟前'
  if (diff < 86400000) return Math.floor(diff / 3600000) + '小时前'
  return Math.floor(diff / 86400000) + '天前'
}

// 获取帖子列表
async function fetchPosts(sort = 'all', reset = true) {
  const page = reset ? 1 : currentPostPage.value + 1
  const loadStartedAt = Date.now()
  if (reset) {
    loading.value = true
    posts.value = []
  } else {
    loadingMore.value = true
  }
  try {
    const res = await request.get('/community/posts', {
      params: { sort, page, size: 5, topic: selectedTopic.value || undefined }
    })
    if (!reset) {
      const remaining = Math.max(0, 1000 - (Date.now() - loadStartedAt))
      if (remaining) await new Promise(resolve => setTimeout(resolve, remaining))
    }
    const list = res?.list || (Array.isArray(res) ? res : [])
    const mapped = list.map(p => ({
      ...p,
      author: p.author || p.username || '匿名',
      authorAvatar: p.authorAvatar || '',
      time: p.createTime ? fmtTime(p.createTime) : (p.time || ''),
      images: typeof p.images === 'string' ? JSON.parse(p.images || '[]') : (p.images || []),
    }))
    posts.value = reset
      ? mapped
      : Array.from(new Map([...posts.value, ...mapped].map(post => [Number(post.id), post])).values())
    currentPostPage.value = Number(res?.page || page)
    totalPosts.value = Number(res?.total || posts.value.length)
    hasMorePosts.value = res?.hasMore === true
    const nextLiked = reset ? new Set() : new Set(likedPosts.value)
    mapped.forEach(post => {
      if (post.liked === true) nextLiked.add(Number(post.id))
    })
    likedPosts.value = nextLiked
    // 热门话题从帖子中提取
    const tags = [...new Set(posts.value.map(p => p.tag).filter(Boolean))]
    hotTopics.value = tags.slice(0, 8)
  } catch (e) {
    console.error('加载帖子失败:', e)
  } finally {
    loading.value = false
    loadingMore.value = false
  }
}

// 获取活跃用户
async function fetchActiveUsers() {
  try {
    const res = await request.get('/user/top?limit=5')
    const list = res?.list || (Array.isArray(res) ? res : [])
    activeUsers.value = list.map(u => ({
      id: u.id,
      name: u.username || u.nickname,
      avatar: u.avatar || '',
      badge: u.role === 'admin' ? '官方' : (u.postCount > 5 ? '达人' : '活跃'),
      favorites: [],
    }))
  } catch {
    activeUsers.value = []
  }
}

// 发帖
async function publishPost() {
  if (!requireAuth()) return
  if (!newPostContent.value.trim() && !previewImages.value.length) return
  const content = newPostContent.value.trim()
  const publishTag = newPostTag.value
  const originTab = postTab.value
  publishing.value = true
  try {
    const images = []
    for (const file of selectedFiles.value) {
      const uploaded = await communityApi.uploadImage(file)
      images.push(uploaded.url)
    }
    const persistedContent = content || '分享了图片'
    const body = {
      title: content ? content.slice(0, 30) + (content.length > 30 ? '...' : '') : '图片分享',
      content: persistedContent,
      tag: publishTag,
      images,
    }
    await request.post('/community/post', body)
    const targetTab = publishTag === '追番' ? 'following' : 'new'
    if (originTab === 'following' && publishTag !== '追番') {
      ElMessage.success('发布成功，非追番内容已归入“最新”')
    } else {
      ElMessage.success(publishTag === '追番' ? '发布成功，已进入“追番”区' : '发布成功，已进入“最新”')
    }
    newPostContent.value = ''
    newPostTag.value = '分享'
    clearSelectedImages()
    const tabChanged = postTab.value !== targetTab
    const topicChanged = Boolean(selectedTopic.value)
    selectedTopic.value = ''
    postTab.value = targetTab
    if (!tabChanged && !topicChanged) fetchPosts(targetTab, true)
  } catch (e) {
    ElMessage.error('发布失败')
  } finally {
    publishing.value = false
  }
}

function goToPost(id) { router.push(`/community/${id}`) }

// 点赞
const likedPosts = ref(new Set())
async function likePost(post) {
  if (!requireAuth()) return
  try {
    const wasLiked = likedPosts.value.has(Number(post.id))
    const state = await request.post('/community/like', { targetId: post.id, type: 'post' })
    const isLiked = state?.liked === true
    const next = new Set(likedPosts.value)
    if (isLiked) next.add(Number(post.id))
    else next.delete(Number(post.id))
    likedPosts.value = next
    if (isLiked !== wasLiked) post.likes = Math.max(0, Number(post.likes || 0) + (isLiked ? 1 : -1))
  } catch {
    // 静默处理
  }
}

async function sharePost(post) {
  if (!requireAuth()) return
  try {
    await communityApi.share(post.id)
    const url = window.location.origin + '/community/' + post.id
    await navigator.clipboard.writeText(url)
    ElMessage.success('链接已复制到剪贴板 📋')
  } catch {
    ElMessage.info('分享链接: ' + window.location.origin + '/community/' + post.id)
  }
}
</script>

<style scoped>
.community-page { min-height: 100vh; background: #f5f7fa; }
.community-body {
  max-width: 1100px; margin: 0 auto; padding: 20px;
  display: flex; gap: 20px;
}
.post-list-section { flex: 1; min-width: 0; }
.community-sidebar { width: 280px; min-width: 0; flex-shrink: 0; }
.community-fixed-panels {
  position: sticky;
  top: 16px;
  width: 100%;
  max-height: calc(100vh - 96px);
  padding-right: 3px;
  overflow-y: auto;
  overscroll-behavior: contain;
  scrollbar-width: thin;
  scrollbar-color: #d8dce8 transparent;
}
.community-fixed-panels::-webkit-scrollbar { width: 5px; }
.community-fixed-panels::-webkit-scrollbar-track { background: transparent; }
.community-fixed-panels::-webkit-scrollbar-thumb { border-radius: 999px; background: #d8dce8; }
.community-ad { margin-bottom: 14px; }

/* 发帖区 */
.post-editor-card {
  background: #fff; border-radius: 16px; padding: 20px;
  margin-bottom: 16px; box-shadow: 0 2px 8px rgba(0,0,0,0.04);
  display: flex; flex-wrap: wrap; gap: 12px; align-items: flex-start;
}
.editor-body { flex: 1; min-width: 200px; display: flex; flex-direction: column; gap: 8px; }
.post-editor-card :deep(.el-textarea__inner) { border-radius: 10px; }
.editor-tag-row {
  display: flex;
  align-items: center;
  gap: 10px;
  min-height: 32px;
}
.editor-tag-label { color: #666; font-size: 13px; font-weight: 600; white-space: nowrap; }
.editor-tag-select { width: 112px; }
.preview-grid {
  display: flex; flex-wrap: wrap; gap: 10px; margin-top: 2px;
}
.preview-item {
  position: relative; width: 88px; height: 88px;
  overflow: hidden; background: #f6f7f9;
  border: 1px solid #e4e7ed; border-radius: 10px;
}
.preview-thumb {
  display: block; width: 100%; height: 100%; object-fit: cover;
}
.preview-remove {
  position: absolute; top: 6px; right: 6px;
  width: 22px; height: 22px; padding: 0;
  display: grid; place-items: center;
  color: #fff; background: rgba(20,26,38,.76);
  border: 0; border-radius: 6px;
  cursor: pointer; box-shadow: 0 2px 8px rgba(15,23,42,.22);
  transition: none; transform: none; animation: none;
}
.preview-remove svg { width: 13px; height: 13px; fill: none; stroke: currentColor; stroke-width: 2.4; stroke-linecap: round; }
.preview-remove:hover { color: #fff; background: #e5484d; }
.preview-remove:active { background: #cf3f44; }
.preview-remove:focus-visible { outline: 2px solid #667eea; outline-offset: 2px; }
.editor-actions {
  width: 100%; display: flex; justify-content: space-between; align-items: center; padding-left: 52px;
}
.editor-image-actions { display: flex; align-items: center; gap: 10px; }
.editor-upload-btn {
  height: 32px; padding: 0 12px;
  display: inline-flex; align-items: center; gap: 7px;
  color: #5968d9; background: #f7f8ff;
  border: 1px solid #d8ddfb; border-radius: 8px;
  font-size: 13px; cursor: pointer;
  transition: none; transform: none; animation: none;
}
.editor-upload-btn svg {
  width: 16px; height: 16px; fill: none; stroke: currentColor; stroke-width: 1.8;
  stroke-linecap: round; stroke-linejoin: round;
}
.editor-upload-btn:hover { color: #4f5fc9; background: #f0f2ff; border-color: #bcc5f5; }
.editor-upload-btn:disabled { color: #a8adbc; background: #f5f6f8; border-color: #e2e5eb; cursor: not-allowed; }
.editor-image-count { color: #9aa0af; font-size: 12px; font-variant-numeric: tabular-nums; }

/* 帖子卡片 */
.post-card {
  background: #fff; border-radius: 16px; padding: 20px;
  margin-bottom: 14px; box-shadow: 0 2px 8px rgba(0,0,0,0.04);
  cursor: pointer;
}

.post-header { display: flex; align-items: center; gap: 12px; margin-bottom: 14px; }
.post-author-info { flex: 1; }
.post-author { font-size: 15px; font-weight: 600; color: #333; display: block; }
.post-time { font-size: 12px; color: #bbb; }

.post-content { margin-bottom: 14px; }
.post-title { font-size: 17px; font-weight: 700; color: #1a1a2e; margin: 0 0 8px; }
.post-text { font-size: 14px; line-height: 1.7; color: #555; margin: 0; display: -webkit-box; -webkit-line-clamp: 3; -webkit-box-orient: vertical; overflow: hidden; }

.post-images { display: flex; max-width: 520px; gap: 6px; margin-top: 10px; border-radius: 8px; overflow: hidden; }
.post-img { object-fit: cover; border-radius: 6px; }
.post-img.img-count-1 { width: min(100%, 420px); max-height: 240px; }
.post-img.img-count-2 { width: calc(50% - 3px); height: 160px; }
.post-img.img-count-3 { width: calc(33.3% - 4px); height: 130px; }
.post-img.img-count-4 { width: calc(25% - 5px); height: 110px; }

.lazy-load-status {
  min-height: 42px; display: flex; align-items: center; justify-content: center;
  color: #9aa0af; font-size: 13px;
}
.loading-more-indicator { display: inline-flex; align-items: center; gap: 8px; color: #727b91; }
.loading-more-spinner {
  width: 17px; height: 17px; border: 2px solid #dfe3f2; border-top-color: #667eea;
  border-radius: 50%; animation: community-loading-spin .7s linear infinite;
}
@keyframes community-loading-spin { to { transform: rotate(360deg); } }

.post-footer { display: flex; align-items: center; gap: 24px; font-size: 14px; color: #999; padding-top: 12px; border-top: 1px solid #f5f5f5; }
.post-views { margin-left: auto; }

.post-empty-state {
  min-height: 300px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 46px 24px;
  text-align: center;
  background: #fff;
  border: 1px dashed #dfe4f3;
  border-radius: 16px;
  box-shadow: 0 2px 8px rgba(0,0,0,.03);
}
.post-empty-icon { margin-bottom: 14px; font-size: 46px; line-height: 1; }
.post-empty-state h3 { margin: 0 0 10px; color: #30364d; font-size: 18px; }
.post-empty-state p { max-width: 440px; margin: 0 0 20px; color: #8a91a3; font-size: 14px; line-height: 1.7; }

/* 侧边栏 */
.side-card {
  background: #fff; border-radius: 16px; padding: 18px;
  margin-bottom: 14px; box-shadow: 0 2px 8px rgba(0,0,0,0.04);
}
.side-card h4 { margin: 0 0 14px; font-size: 16px; color: #1a1a2e; }

.topic-list { display: flex; flex-wrap: wrap; gap: 8px; }
.topic-tag {
  padding: 4px 14px; background: #f5f7fa; border-radius: 16px;
  font-size: 13px; color: #667eea; cursor: pointer; transition: all 0.2s;
}
.topic-tag:hover { background: rgba(102,126,234,0.1); }
.topic-tag.active {
  background: rgba(102,126,234,0.15);
  color: #667eea;
  font-weight: 600;
}
.topic-filter-bar {
  font-size: 14px; color: #666; margin-bottom: 12px;
  padding: 8px 14px; background: #f0efff; border-radius: 8px;
  display: flex; align-items: center; gap: 8px;
}
.topic-filter-clear {
  margin-left: auto; color: #999; cursor: pointer; font-size: 12px;
}
.topic-filter-clear:hover { color: #e74c3c; }

.side-user {
  display: flex; align-items: center; gap: 10px; padding: 8px 10px; border-radius: 8px;
  cursor: pointer; transition: background .15s;
}
.side-user:hover { background: rgba(102,126,234,0.05); }
.side-user.active { background: rgba(102,126,234,0.1); }
.side-user-name { flex: 1; font-size: 14px; color: #333; font-weight: 500; }
.side-user-badge { font-size: 11px; color: #667eea; background: rgba(102,126,234,0.08); padding: 2px 8px; border-radius: 10px; }

@media (max-width: 900px) {
  .community-body { flex-direction: column; }
  .community-sidebar {
    width: 100%;
  }
  .community-fixed-panels {
    position: static; max-height: none; padding-right: 0;
    overflow-y: visible; overscroll-behavior: auto;
  }
  .editor-tag-row { flex-wrap: wrap; }
}
</style>
