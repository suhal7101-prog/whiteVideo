
<template>
  <div class="up">
    <!-- 顶部动态横幅 -->
    <ManagedDynamicBanner
      class="up-banner"
      height="160px"
      storage-key="white_bear_last_public_profile_banner"
    />

    <!-- 用户信息卡片 -->
    <div class="up-header">
      <el-avatar :size="88" :src="user.avatar" class="up-avatar" />
      <div class="up-info">
        <div class="up-info-row">
          <h1 class="up-name">{{ user.name }}</h1>
          <span class="up-badge">{{ user.badge }}</span>
        </div>
        <p class="up-bio">{{ user.bio || '这个人很懒，什么都没写~' }}</p>
        <div class="up-stats" aria-live="polite">
          <span><strong>{{ userStats.posts }}</strong> 帖子</span>
          <span><strong>{{ userStats.likes }}</strong> 获赞</span>
          <span><strong>{{ userStats.following }}</strong> 关注</span>
          <span><strong>{{ userStats.followers }}</strong> 粉丝</span>
        </div>
        <button
          v-if="user.id && !isOwnProfile"
          class="up-follow-btn"
          :class="{ followed }"
          :disabled="followLoading"
          :aria-pressed="followed"
          @click="toggleFollow"
        >
          {{ followLoading ? '处理中...' : (followed ? '✓ 已关注' : '+ 关注') }}
        </button>
      </div>
    </div>

    <div class="up-body">
      <!-- 左侧 -->
      <div class="up-main">
        <!-- Tab -->
        <div class="up-tabs">
          <button :class="{ active: tab === 'posts' }" @click="tab = 'posts'">📝 动态</button>
          <button :class="{ active: tab === 'favorites' }" @click="tab = 'favorites'">📺 追番</button>
          <button :class="{ active: tab === 'likes' }" @click="tab = 'likes'">♥ 点赞</button>
        </div>

        <!-- 动态列表 -->
        <div v-if="tab === 'posts'" class="up-posts">
          <template v-if="userPosts.length">
            <div v-for="p in userPosts" :key="p.id" class="up-post-card" @click="$router.push('/community/' + p.id)">
              <p class="up-post-content">{{ p.content }}</p>
              <div class="up-post-images" v-if="p.images?.length">
                <img v-for="(img, i) in p.images.slice(0, 3)" :key="i" :src="img" />
              </div>
              <div class="up-post-meta">
                <EngagementAction type="like" :count="p.likes" filled />
                <EngagementAction type="comment" :count="p.comments" clickable @click="$router.push('/community/' + p.id)" />
                <EngagementAction type="share" label="分享" clickable @click="shareUserPost(p)" />
                <span class="up-post-time">{{ p.time }}</span>
              </div>
            </div>
          </template>
          <div v-else class="up-empty">
            <span class="up-empty-icon">💬</span>
            <p>还没有发布动态</p>
            <p class="up-empty-hint">去<a href="/community">社区</a>分享你的想法吧~</p>
          </div>
        </div>

        <!-- 自己的追番列表 -->
        <div v-if="tab === 'favorites'" class="up-likes">
          <div v-if="favoriteAnime.length" class="up-like-row">
            <div v-for="a in favoriteAnime" :key="a.id" class="up-like-card" @click="$router.push(a.playUrl)">
              <img :src="a.cover" :alt="a.title" />
              <div class="up-like-foot">
                <span class="up-like-title">{{ a.title }}</span>
                <span class="up-like-count">已追番</span>
              </div>
            </div>
          </div>
          <div v-else class="up-empty">
            <span class="up-empty-icon">📺</span>
            <p>{{ isOwnProfile ? '还没有追番记录' : '该用户未公开追番记录' }}</p>
          </div>
        </div>

        <!-- 点赞过的动漫 -->
        <div v-if="tab === 'likes'" class="up-likes">
          <div v-if="likedAnime.length" class="up-like-row">
            <div v-for="a in likedAnime" :key="a.id" class="up-like-card" @click="$router.push(a.playUrl)">
              <img :src="a.cover" :alt="a.title" />
              <div class="up-like-foot">
                <span class="up-like-title">{{ a.title }}</span>
                <EngagementAction class="up-like-count" type="like" :count="a.likes || 0" filled />
              </div>
            </div>
          </div>
          <div v-else class="up-empty">
            <span class="up-empty-icon up-empty-icon--like">♥</span>
            <p>还没有点赞记录</p>
            <p class="up-empty-hint">去<a href="/discover">浏览页</a>为你喜欢的动漫点赞吧~</p>
          </div>
        </div>
      </div>

    </div>

  </div>
</template>

<script setup>
import { ref, reactive, computed, onMounted, onUnmounted, watch } from 'vue'
import { useRoute } from 'vue-router'
import { ElMessage } from 'element-plus'
import { useUserStore } from '@/stores/user'
import { userApi } from '@/api/modules/user'
import { useAuth } from '@/composables/useAuth'
import EngagementAction from '@/components/common/EngagementAction.vue'
import ManagedDynamicBanner from '@/components/common/ManagedDynamicBanner.vue'

const route = useRoute()
const userStore = useUserStore()
const { requireAuth } = useAuth()
const tab = ref('posts')
const followed = ref(false)
const followLoading = ref(false)

// ---- 从后端 API 获取用户数据 ----
import request from '@/api/request'

function fmtTime(ts) {
  if (!ts) return ''
  const d = new Date(ts), now = new Date(), diff = now - d
  if (diff < 60000) return '刚刚'
  if (diff < 3600000) return Math.floor(diff/60000)+'分钟前'
  if (diff < 86400000) return Math.floor(diff/3600000)+'小时前'
  return Math.floor(diff/86400000)+'天前'
}

const user = ref({ id: null, name: '', avatar: '', badge: '', bio: '', joinDate: '', isSelf: false })
const userPosts = ref([])
const likedAnime = ref([])
const favoriteAnime = ref([])
const isOwnProfile = computed(() => user.value.isSelf
  || (userStore.isLoggedIn && user.value.name === userStore.username))
const userStats = reactive({ posts: 0, likes: 0, following: 0, followers: 0 })
let statsTimer = null
let statsRefreshing = false
let profileLoadVersion = 0

function applyProfile(found) {
  user.value = {
    id: found.id,
    name: found.username,
    avatar: found.avatar || 'https://picsum.photos/seed/au/200',
    badge: found.role === 'admin' ? '官方' : (found.role === 'creator' ? '创作者' : '活跃'),
    bio: found.bio || '这个人很懒，什么都没写~',
    joinDate: found.registerDate || found.createTime || '',
    isSelf: Boolean(found.isSelf),
  }
  followed.value = Boolean(found.isFollowing)
  applyStats(found)
}

async function shareUserPost(post) {
  const url = `${window.location.origin}/community/${post.id}`
  try {
    await navigator.clipboard.writeText(url)
    ElMessage.success('分享链接已复制')
  } catch {
    ElMessage.info(`分享链接: ${url}`)
  }
}

function applyStats(data) {
  userStats.posts = Number(data.postCount || 0)
  userStats.likes = Number(data.receivedLikes || 0)
  userStats.following = Number(data.followingCount || 0)
  userStats.followers = Number(data.followerCount || 0)
  if (typeof data.isFollowing === 'boolean') followed.value = data.isFollowing
}

async function refreshLiveStats() {
  if (statsRefreshing) return null
  const name = decodeURIComponent(route.params.name || '')
  if (!name) return null
  statsRefreshing = true
  try {
    const found = await request.get(`/user/public/${encodeURIComponent(name)}`, {
      cancelDuplicate: false
    })
    if (found) applyProfile(found)
    return found
  } catch (error) {
    console.warn('同步用户统计失败:', error.message)
    return null
  } finally {
    statsRefreshing = false
  }
}

async function fetchUserProfile() {
  const loadVersion = ++profileLoadVersion
  const name = decodeURIComponent(route.params.name || '')
  try {
    const found = await refreshLiveStats()
    if (!found || loadVersion !== profileLoadVersion) return

    const allPosts = []
    let page = 1
    let hasMore = true
    while (hasMore && loadVersion === profileLoadVersion) {
      const result = await request.get('/community/posts', {
        params: { sort: 'new', page, size: 20, authorId: found.id },
        cancelDuplicate: false
      })
      allPosts.push(...(result?.list || []))
      hasMore = result?.hasMore === true
      page += 1
    }
    if (loadVersion !== profileLoadVersion) return
    userPosts.value = allPosts.map(p => ({
      ...p,
      time: fmtTime(p.createTime || p.time),
      images: typeof p.images === 'string' ? JSON.parse(p.images || '[]') : (p.images || [])
    }))

    if (found.isSelf) {
      const [likedResult, favoriteResult] = await Promise.all([
        userApi.getLikedVideos(),
        userApi.getFavorites()
      ])
      likedAnime.value = likedResult?.list || []
      favoriteAnime.value = (favoriteResult?.list || []).filter(Boolean).map(video => ({
        ...video,
        playUrl: video.sourceVodId
          ? `/play/${video.sourceVodId}`
          : `/play/${video.id}?source=db`
      }))
    } else {
      likedAnime.value = []
      favoriteAnime.value = []
    }
  } catch (e) { console.error('加载用户数据失败:', e) }
}

async function toggleFollow() {
  if (!requireAuth() || !user.value.id || followLoading.value) return
  followLoading.value = true
  try {
    const result = followed.value
      ? await userApi.unfollowUser(user.value.id)
      : await userApi.followUser(user.value.id)
    applyStats(result || {})
    ElMessage.success(followed.value ? '关注成功' : '已取消关注')
  } catch (error) {
    console.error('关注操作失败:', error)
  } finally {
    followLoading.value = false
  }
}

function startStatsSync() {
  if (statsTimer) clearInterval(statsTimer)
  statsTimer = setInterval(() => {
    if (document.visibilityState === 'visible') refreshLiveStats()
  }, 5000)
}

onMounted(() => {
  fetchUserProfile()
  startStatsSync()
})

watch(() => route.params.name, () => {
  tab.value = 'posts'
  userPosts.value = []
  likedAnime.value = []
  favoriteAnime.value = []
  fetchUserProfile()
})

onUnmounted(() => {
  if (statsTimer) clearInterval(statsTimer)
})
</script>

<style scoped>
.up { min-height: 100vh; background: #f5f7fa; }
.up-banner {
  height: 220px; position: relative; overflow: hidden;
  background: linear-gradient(180deg, #2a1a4e 0%, #3d2b6e 40%, #251a45 100%);
}
.up-banner::before {
  display: none;
  content: '';
  position: absolute; inset: -50%;
  background:
    radial-gradient(1.5px 1.5px at 10% 20%, rgba(255,255,255,.9), transparent),
    radial-gradient(1px 1px at 25% 45%, rgba(255,255,255,.7), transparent),
    radial-gradient(2px 2px at 40% 15%, rgba(255,255,255,.95), transparent),
    radial-gradient(1px 1px at 55% 60%, rgba(255,255,255,.6), transparent),
    radial-gradient(2.5px 2.5px at 70% 30%, rgba(255,240,255,.85), transparent),
    radial-gradient(1.5px 1.5px at 85% 55%, rgba(255,255,255,.7), transparent),
    radial-gradient(2px 2px at 15% 70%, rgba(220,200,255,.85), transparent),
    radial-gradient(1px 1px at 60% 80%, rgba(255,220,240,.8), transparent),
    radial-gradient(1.5px 1.5px at 35% 35%, rgba(255,255,255,.65), transparent),
    radial-gradient(2px 2px at 75% 10%, rgba(255,255,255,.85), transparent),
    radial-gradient(1px 1px at 90% 40%, rgba(255,255,255,.7), transparent),
    radial-gradient(2.5px 2.5px at 50% 50%, rgba(255,235,250,.9), transparent),
    radial-gradient(1.5px 1.5px at 20% 85%, rgba(255,255,255,.6), transparent),
    radial-gradient(2px 2px at 80% 70%, rgba(220,210,255,.8), transparent),
    radial-gradient(1px 1px at 45% 5%, rgba(255,255,255,.85), transparent),
    radial-gradient(1.5px 1.5px at 5% 50%, rgba(255,255,255,.6), transparent),
    radial-gradient(2px 2px at 95% 90%, rgba(255,255,255,.7), transparent),
    radial-gradient(1.5px 1.5px at 30% 95%, rgba(255,200,225,.8), transparent),
    radial-gradient(2px 2px at 65% 45%, rgba(255,255,255,.75), transparent),
    radial-gradient(1.5px 1.5px at 12% 8%, rgba(255,230,250,.8), transparent),
    radial-gradient(2px 2px at 82% 22%, rgba(255,255,255,.7), transparent),
    radial-gradient(1px 1px at 48% 72%, rgba(255,255,255,.65), transparent),
    radial-gradient(2.5px 2.5px at 22% 58%, rgba(240,220,255,.85), transparent),
    radial-gradient(1.5px 1.5px at 68% 88%, rgba(255,255,255,.7), transparent);
  animation: starsDrift 25s linear infinite;
  pointer-events: none;
}
@keyframes starsDrift {
  0%   { transform: translate(0, 0) rotate(0deg); }
  100% { transform: translate(-5%, -5%) rotate(1deg); }
}

/* 粒子 */
.up-particle {
  position: absolute; border-radius: 50%;
  animation: upFloat 6s ease-in-out infinite;
  pointer-events: none;
}
.up-particle:nth-child(3n)   { background: rgba(255,255,255,0.95); box-shadow: 0 0 8px 3px rgba(180,160,255,.7); }
.up-particle:nth-child(3n+1) { background: rgba(255,220,240,0.85); box-shadow: 0 0 6px 2px rgba(255,150,200,.6); }
.up-particle:nth-child(3n+2) { background: rgba(220,210,255,0.9); box-shadow: 0 0 10px 4px rgba(150,130,240,.65); }
@keyframes upFloat {
  0%, 100% { transform: translateY(0) scale(1); opacity: 0.2; }
  25%      { transform: translateY(-20px) scale(1.4); opacity: 0.9; }
  50%      { transform: translateY(-5px) scale(0.9); opacity: 0.4; }
  75%      { transform: translateY(-25px) scale(1.2); opacity: 0.7; }
}

/* 浮动几何 */
.up-shape {
  position: absolute; border-radius: 3px;
  pointer-events: none; transition: transform 0.15s ease-out;
  animation: upOrb 8s ease-in-out infinite;
}
.up-shape:nth-child(odd)  { border: 1px solid rgba(124,92,231,.2); background: rgba(124,92,231,.05); }
.up-shape:nth-child(even) { border: 1px solid rgba(240,98,146,.15); background: rgba(240,98,146,.04); }
@keyframes upOrb {
  0%, 100% { transform: rotate(0deg) scale(1); opacity: 0.4; }
  50%      { transform: rotate(180deg) scale(1.3); opacity: 0.8; }
}



.up-header {
  max-width: 900px; margin: -44px auto 0; padding: 0 20px;
  display: flex; gap: 20px; align-items: flex-start;
  position: relative; z-index: 20;
}
.up-avatar {
  border: 5px solid #fff; box-shadow: 0 8px 32px rgba(0,0,0,.2);
  flex-shrink: 0; position: relative; z-index: 21; margin-top: 0;
}
.up-info {
  flex: 1; margin-top: 44px;
  background: rgba(255,255,255,0.35);
  backdrop-filter: blur(8px);
  -webkit-backdrop-filter: blur(8px);
  border: 1px solid rgba(255,255,255,0.25);
  border-radius: 16px;
  padding: 16px 20px;
  position: relative; z-index: 20;
}
.up-info-row {
  display: flex; align-items: center; gap: 10px;
}
.up-name { font-size: 24px; font-weight: 700; margin: 0; color: #1a1a2e; }
.up-badge {
  display: inline-block; font-size: 12px;
  color: #667eea; background: rgba(102,126,234,.12); padding: 2px 10px; border-radius: 10px;
}
.up-bio { font-size: 14px; color: #444; margin: 8px 0; }
.up-stats { display: flex; gap: 24px; margin: 12px 0; font-size: 14px; color: #666; }
.up-stats strong { color: #333; }
.up-stats strong { font-variant-numeric: tabular-nums; }
.up-follow-btn {
  padding: 8px 28px; border-radius: 20px; border: none;
  background: linear-gradient(135deg, #667eea, #764ba2); color: #fff;
  font-size: 14px; font-weight: 600; cursor: pointer; transition: none;
}
.up-follow-btn.followed { background: #e8e8e8; color: #666; }
.up-follow-btn:hover { opacity: .9; }
.up-follow-btn:disabled { cursor: wait; opacity: .7; }

.up-body { max-width: 900px; margin: 24px auto 60px; padding: 0 20px; display: flex; gap: 24px; }
.up-main { flex: 1; min-width: 0; }

.up-tabs { display: flex; gap: 4px; margin-bottom: 16px; background: #fff; border-radius: 12px; padding: 4px; }
.up-tabs button {
  flex: 1; padding: 10px 0; border: none; border-radius: 10px;
  background: transparent; font-size: 14px; color: #666; cursor: pointer; transition: all .2s;
}
.up-tabs button.active { background: #f0efff; color: #667eea; font-weight: 600; }

.up-post-card {
  background: #fff; border-radius: 12px; padding: 18px; margin-bottom: 12px;
  box-shadow: 0 1px 3px rgba(0,0,0,.04); cursor: pointer; transition: box-shadow .2s;
}
.up-post-card:hover { box-shadow: 0 4px 16px rgba(0,0,0,.08); }
.up-post-content { font-size: 14px; color: #333; line-height: 1.7; margin: 0 0 10px; }
.up-post-images { display: flex; gap: 8px; margin-bottom: 10px; }
.up-post-images img { width: 120px; height: 80px; object-fit: cover; border-radius: 8px; }
.up-post-meta { display: flex; align-items: center; gap: 24px; font-size: 14px; color: #bbb; }
.up-post-time { margin-left: auto; color: #bbb; font-size: 12px; }

/* 点赞卡片 (横向排列) */
.up-like-row { display: flex; gap: 12px; flex-wrap: wrap; }
.up-like-card {
  background: #fff; border-radius: 10px; overflow: hidden; cursor: pointer;
  width: 200px; flex-shrink: 0;
  box-shadow: 0 1px 3px rgba(0,0,0,.04); transition: transform .2s;
}
.up-like-card:hover { transform: translateY(-4px); }
.up-like-card img { width: 100%; aspect-ratio: 16/10; object-fit: cover; display: block; }
.up-like-foot {
  display: flex; justify-content: space-between; align-items: center;
  padding: 10px 12px; gap: 8px;
}
.up-like-title {
  font-size: 13px; color: #333; font-weight: 500;
  overflow: hidden; text-overflow: ellipsis; white-space: nowrap; flex: 1; min-width: 0;
}
.up-like-count {
  font-size: 12px; white-space: nowrap; flex-shrink: 0;
}

.up-empty {
  text-align: center; padding: 60px 0; color: #bbb; font-size: 14px;
}
.up-empty-icon { font-size: 48px; display: block; margin-bottom: 12px; }
.up-empty-icon--like { color: #e74c3c; }
.up-empty p { margin: 4px 0; }
.up-empty-hint { font-size: 13px; color: #bbb; }
.up-empty-hint a { color: #667eea; text-decoration: none; }
.up-empty-hint a:hover { text-decoration: underline; }

@media (max-width: 768px) {
  .up-body { flex-direction: column; }
  .up-header { flex-direction: column; align-items: center; text-align: center; }
  .up-info { padding-top: 10px; }
  .up-stats { justify-content: center; }
  .up-post-meta { gap: 16px; flex-wrap: wrap; }
  .up-post-time { width: 100%; margin-left: 0; }
}
</style>
