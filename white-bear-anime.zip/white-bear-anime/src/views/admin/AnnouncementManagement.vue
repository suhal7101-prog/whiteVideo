<template>
  <div class="am-page">
    <div class="am-toolbar">
      <div>
        <h2>公告管理</h2>
        <p>发布后所有登录用户均可收到，阅读状态按用户独立记录</p>
      </div>
      <el-button class="admin-action-btn" type="primary" @click="openCreate">
        <el-icon><Plus /></el-icon>
        发布公告
      </el-button>
    </div>

    <div class="am-table-wrap">
      <el-table
        :data="announcements"
        stripe
        v-loading="loading"
        empty-text="暂无公告，请点击右上角发布第一条公告"
        style="width:100%"
      >
        <el-table-column prop="id" label="ID" width="70" />
        <el-table-column prop="title" label="标题" min-width="230" show-overflow-tooltip>
          <template #default="{ row }">
            <div class="am-title-cell">
              <el-tag v-if="Number(row.pinned) === 1" size="small" type="danger">置顶</el-tag>
              <span>{{ row.title }}</span>
            </div>
          </template>
        </el-table-column>
        <el-table-column prop="status" label="状态" width="100" align="center">
          <template #default="{ row }">
            <el-tag :type="row.status === 'published' ? 'success' : 'info'">
              {{ row.status === 'published' ? '已发布' : '草稿' }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="readCount" label="已读人数" width="100" align="center" />
        <el-table-column prop="publishTime" label="发布时间" width="175">
          <template #default="{ row }">{{ formatDate(row.publishTime || row.createTime) }}</template>
        </el-table-column>
        <el-table-column label="操作" width="250" fixed="right" align="center">
          <template #default="{ row }">
            <el-button class="admin-action-btn" size="small" @click="openEdit(row)">编辑</el-button>
            <el-button
              class="admin-action-btn"
              :class="{ 'admin-action-danger': row.status === 'published' }"
              size="small"
              :type="row.status === 'published' ? 'warning' : 'success'"
              @click="toggleStatus(row)"
            >
              {{ row.status === 'published' ? '下线' : '发布' }}
            </el-button>
            <el-button class="admin-action-btn admin-action-danger" size="small" type="danger" @click="removeAnnouncement(row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>

    <el-dialog v-model="dialogVisible" :title="editingId ? '编辑公告' : '发布公告'" width="620px">
      <el-form ref="formRef" :model="form" :rules="rules" label-position="top">
        <el-form-item label="公告标题" prop="title">
          <el-input v-model="form.title" maxlength="256" show-word-limit placeholder="请输入公告标题" />
        </el-form-item>
        <el-form-item label="公告内容" prop="content">
          <el-input
            v-model="form.content"
            type="textarea"
            :rows="7"
            maxlength="5000"
            show-word-limit
            resize="vertical"
            placeholder="请输入公告正文"
          />
        </el-form-item>
        <div class="am-form-row">
          <el-form-item label="发布状态">
            <el-radio-group v-model="form.status">
              <el-radio-button value="published">立即发布</el-radio-button>
              <el-radio-button value="draft">保存草稿</el-radio-button>
            </el-radio-group>
          </el-form-item>
          <el-form-item label="置顶公告">
            <el-switch v-model="form.pinned" :active-value="1" :inactive-value="0" />
          </el-form-item>
        </div>
      </el-form>
      <template #footer>
        <el-button class="admin-action-btn" @click="dialogVisible = false">取消</el-button>
        <el-button class="admin-action-btn" type="primary" :loading="saving" @click="saveAnnouncement">
          {{ form.status === 'published' ? '确认发布' : '保存草稿' }}
        </el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { onMounted, reactive, ref } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import dayjs from 'dayjs'
import { adminApi } from '@/api/modules/admin'

const announcements = ref([])
const loading = ref(false)
const saving = ref(false)
const dialogVisible = ref(false)
const editingId = ref(null)
const formRef = ref(null)

const form = reactive({ title: '', content: '', status: 'published', pinned: 0 })
const rules = {
  title: [{ required: true, message: '请输入公告标题', trigger: 'blur' }],
  content: [{ required: true, message: '请输入公告内容', trigger: 'blur' }]
}

async function fetchAnnouncements() {
  loading.value = true
  try {
    const result = await adminApi.getAnnouncements()
    announcements.value = result?.list || []
  } finally {
    loading.value = false
  }
}

function resetForm() {
  editingId.value = null
  Object.assign(form, { title: '', content: '', status: 'published', pinned: 0 })
  formRef.value?.clearValidate()
}

function openCreate() {
  resetForm()
  dialogVisible.value = true
}

function openEdit(row) {
  editingId.value = row.id
  Object.assign(form, {
    title: row.title,
    content: row.content,
    status: row.status || 'published',
    pinned: Number(row.pinned) === 1 ? 1 : 0
  })
  dialogVisible.value = true
}

async function saveAnnouncement() {
  await formRef.value?.validate()
  saving.value = true
  try {
    const payload = { ...form }
    if (editingId.value) await adminApi.updateAnnouncement(editingId.value, payload)
    else await adminApi.createAnnouncement(payload)
    ElMessage.success(form.status === 'published' ? '公告发布成功' : '草稿保存成功')
    dialogVisible.value = false
    await fetchAnnouncements()
  } finally {
    saving.value = false
  }
}

async function toggleStatus(row) {
  const status = row.status === 'published' ? 'draft' : 'published'
  await adminApi.updateAnnouncement(row.id, {
    title: row.title,
    content: row.content,
    pinned: Number(row.pinned) === 1 ? 1 : 0,
    status
  })
  ElMessage.success(status === 'published' ? '公告已发布' : '公告已下线')
  await fetchAnnouncements()
}

async function removeAnnouncement(row) {
  await ElMessageBox.confirm(`确认删除公告“${row.title}”吗？`, '删除公告', {
    type: 'warning',
    confirmButtonClass: 'admin-action-btn admin-action-danger',
    cancelButtonClass: 'admin-action-btn'
  })
  await adminApi.deleteAnnouncement(row.id)
  ElMessage.success('公告已删除')
  await fetchAnnouncements()
}

function formatDate(value) {
  return value ? dayjs(value).format('YYYY-MM-DD HH:mm') : '-'
}

onMounted(fetchAnnouncements)
</script>

<style scoped>
.am-page { min-width: 0; }
.am-toolbar { display: flex; align-items: center; justify-content: space-between; gap: 20px; margin-bottom: 18px; }
.am-toolbar h2 { margin: 0 0 5px; color: #252b3b; font-size: 20px; }
.am-toolbar p { margin: 0; color: #8b93a3; font-size: 13px; }
.am-table-wrap { overflow: hidden; border-radius: 8px; background: #fff; box-shadow: 0 1px 6px rgba(0,0,0,.05); }
.am-title-cell { display: flex; align-items: center; gap: 8px; min-width: 0; }
.am-title-cell span { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.am-form-row { display: grid; grid-template-columns: minmax(0, 1fr) 120px; gap: 24px; }
@media (max-width: 760px) {
  .am-toolbar { align-items: flex-start; flex-direction: column; }
  .am-form-row { grid-template-columns: 1fr; gap: 0; }
}
</style>
