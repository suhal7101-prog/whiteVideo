<template>
  <div class="effect-page">
    <div class="effect-toolbar">
      <div>
        <h2>效果图管理</h2>
        <p>管理AI页面鼠标视差横幅，已导入 {{ summary.total }} 套，启用 {{ summary.active }} 套</p>
      </div>
      <el-button class="admin-action-btn" type="primary" :loading="loading" @click="fetchEffects">刷新数据</el-button>
    </div>

    <div class="effect-table-wrap">
      <el-table :data="effects" stripe v-loading="loading" empty-text="暂无效果图" style="width:100%">
        <el-table-column prop="sortOrder" label="排序" width="72" align="center" />
        <el-table-column label="效果图" min-width="310">
          <template #default="{ row }">
            <div class="effect-info">
              <div class="effect-thumb-wrap">
                <img :src="row.previewUrl" :alt="row.name" class="effect-thumb" loading="lazy" />
                <span v-if="row.hasVideo" class="effect-video-badge">视频</span>
              </div>
              <div class="effect-title">
                <strong>{{ row.name }}</strong>
                <small>{{ row.themeKey }}</small>
              </div>
            </div>
          </template>
        </el-table-column>
        <el-table-column prop="dateKey" label="日期" width="112" align="center" />
        <el-table-column label="图层" width="95" align="center">
          <template #default="{ row }">{{ row.layerCount }} 层</template>
        </el-table-column>
        <el-table-column label="投放页面" width="110" align="center">
          <template #default="{ row }">
            <el-tag size="small" type="info">{{ row.targetPage === 'community' ? '社区广场' : 'AI助手' }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column label="启用状态" width="115" align="center">
          <template #default="{ row }">
            <el-switch
              v-model="row.status"
              active-value="active"
              inactive-value="inactive"
              inline-prompt
              active-text="启用"
              inactive-text="停用"
              @change="toggleStatus(row)"
            />
          </template>
        </el-table-column>
        <el-table-column label="操作" width="170" fixed="right" align="center">
          <template #default="{ row }">
            <el-button class="admin-action-btn" @click="previewEffect(row)">预览</el-button>
            <el-button class="admin-action-btn" @click="openEdit(row)">编辑</el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>

    <el-dialog v-model="previewVisible" :title="previewing?.name || '效果图预览'" width="min(1100px, 92vw)" destroy-on-close>
      <div class="effect-preview" v-loading="previewLoading">
        <DynamicBanner v-if="previewLayers.length" :layers="previewLayers" />
        <el-empty v-else-if="!previewLoading" description="效果图配置加载失败" />
      </div>
      <div v-if="previewing" class="effect-preview-meta">
        <span>主题：{{ previewing.themeKey }}</span>
        <span>配置：{{ previewing.dataUrl }}</span>
        <span>{{ previewing.layerCount }} 个图层</span>
      </div>
    </el-dialog>

    <el-dialog v-model="editVisible" title="编辑效果图" width="520px" destroy-on-close>
      <el-form ref="formRef" :model="form" :rules="rules" label-width="90px">
        <el-form-item label="效果名称" prop="name"><el-input v-model="form.name" maxlength="128" /></el-form-item>
        <el-form-item label="主题标识"><el-input :model-value="form.themeKey" disabled /></el-form-item>
        <el-form-item label="投放页面">
          <el-select v-model="form.targetPage" style="width:100%">
            <el-option label="AI助手" value="ai" />
            <el-option label="社区广场" value="community" />
          </el-select>
        </el-form-item>
        <el-form-item label="排序"><el-input-number v-model="form.sortOrder" :min="0" :max="999" /></el-form-item>
        <el-form-item label="状态">
          <el-radio-group v-model="form.status">
            <el-radio value="active">启用</el-radio>
            <el-radio value="inactive">停用</el-radio>
          </el-radio-group>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button class="admin-action-btn" @click="editVisible = false">取消</el-button>
        <el-button class="admin-action-btn" type="primary" :loading="saving" @click="saveEffect">保存</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { onMounted, reactive, ref } from 'vue'
import { ElMessage } from 'element-plus'
import { adminApi } from '@/api/modules/admin'
import DynamicBanner from '@/components/community/DynamicBanner.vue'
import { normalizeBannerLayers } from '@/utils/bannerEffects'

const effects = ref([])
const loading = ref(false)
const saving = ref(false)
const editVisible = ref(false)
const previewVisible = ref(false)
const previewLoading = ref(false)
const previewing = ref(null)
const previewLayers = ref([])
const editingId = ref(null)
const formRef = ref(null)
const summary = reactive({ total: 0, active: 0 })
const form = reactive({ name: '', themeKey: '', targetPage: 'ai', status: 'active', sortOrder: 0 })
const rules = { name: [{ required: true, message: '请输入效果图名称', trigger: 'blur' }] }

async function fetchEffects() {
  loading.value = true
  try {
    const result = await adminApi.getBannerEffects()
    effects.value = result?.list || []
    summary.total = Number(result?.total || effects.value.length)
    summary.active = Number(result?.active || 0)
  } finally {
    loading.value = false
  }
}

function payloadOf(row) {
  return {
    name: row.name,
    targetPage: row.targetPage || 'ai',
    status: row.status || 'inactive',
    sortOrder: Number(row.sortOrder || 0),
  }
}

async function toggleStatus(row) {
  const nextStatus = row.status
  try {
    await adminApi.updateBannerEffect(row.id, payloadOf(row))
    ElMessage.success(nextStatus === 'active' ? '效果图已启用' : '效果图已停用')
    await fetchEffects()
  } catch (error) {
    row.status = nextStatus === 'active' ? 'inactive' : 'active'
    throw error
  }
}

function openEdit(row) {
  editingId.value = row.id
  Object.assign(form, {
    name: row.name,
    themeKey: row.themeKey,
    targetPage: row.targetPage || 'ai',
    status: row.status || 'inactive',
    sortOrder: Number(row.sortOrder || 0),
  })
  editVisible.value = true
}

async function saveEffect() {
  await formRef.value?.validate()
  saving.value = true
  try {
    await adminApi.updateBannerEffect(editingId.value, payloadOf(form))
    ElMessage.success('效果图已保存')
    editVisible.value = false
    await fetchEffects()
  } finally {
    saving.value = false
  }
}

async function previewEffect(row) {
  previewing.value = row
  previewLayers.value = []
  previewVisible.value = true
  previewLoading.value = true
  try {
    const response = await fetch(row.dataUrl, { cache: 'no-cache' })
    if (!response.ok) throw new Error(`HTTP ${response.status}`)
    const data = await response.json()
    previewLayers.value = normalizeBannerLayers(data, { baseUrl: row.assetBaseUrl })
  } catch (error) {
    ElMessage.error(`预览加载失败：${error.message}`)
  } finally {
    previewLoading.value = false
  }
}

onMounted(fetchEffects)
</script>

<style scoped>
.effect-toolbar { display:flex; align-items:center; justify-content:space-between; gap:20px; margin-bottom:18px; }
.effect-toolbar h2 { margin:0 0 5px; font-size:20px; color:#252b3b; }
.effect-toolbar p { margin:0; color:#8b93a3; font-size:13px; }
.effect-table-wrap { overflow:hidden; border-radius:10px; background:#fff; box-shadow:0 1px 6px rgba(0,0,0,.05); }
.effect-info { display:flex; align-items:center; gap:12px; min-width:0; }
.effect-thumb-wrap { position:relative; width:132px; height:62px; flex:none; overflow:hidden; border-radius:8px; background:linear-gradient(135deg,#eef1f7,#dfe5f0); }
.effect-thumb { display:block; width:100%; height:100%; object-fit:cover; }
.effect-video-badge { position:absolute; right:5px; bottom:5px; padding:2px 6px; border-radius:8px; color:#fff; background:rgba(24,30,45,.72); font-size:10px; }
.effect-title { display:flex; flex-direction:column; gap:5px; min-width:0; }
.effect-title strong,.effect-title small { overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
.effect-title small { color:#8b93a3; }
.effect-preview { min-height:130px; overflow:hidden; border-radius:10px; background:#161625; }
.effect-preview :deep(.db) { border-radius:10px; }
.effect-preview-meta { display:flex; flex-wrap:wrap; gap:16px; margin-top:12px; color:#8b93a3; font-size:12px; }
@media(max-width:760px){.effect-toolbar{align-items:flex-start;flex-direction:column}.effect-thumb-wrap{width:100px}}
</style>
