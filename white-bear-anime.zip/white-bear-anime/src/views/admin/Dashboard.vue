<!--
  管理后台 · 仪表盘
  对接后端 /api/admin/stats/overview
-->
<template>
  <div class="db-page">
    <!-- 加载骨架 -->
    <div v-if="loading" class="db-skeleton">
      <div v-for="i in 4" :key="i" class="db-skel-card"></div>
    </div>

    <template v-else>
      <!-- ===== 统计卡片 ===== -->
      <div class="db-stats">
        <div class="db-stat-card" style="--accent: #667eea">
          <div class="db-stat-icon bg-purple">👥</div>
          <div class="db-stat-info">
            <span class="db-stat-num">{{ overview.totalUsers ?? '--' }}</span>
            <span class="db-stat-label">用户总数</span>
          </div>
          <div class="db-stat-extra">
            今日新增 {{ overview.todayNewUsers === null ? '--' : `+${overview.todayNewUsers}` }}
          </div>
        </div>
        <div class="db-stat-card" style="--accent: #f59e0b">
          <div class="db-stat-icon bg-orange">🎬</div>
          <div class="db-stat-info">
            <span class="db-stat-num">{{ overview.totalVideos ?? '--' }}</span>
            <span class="db-stat-label">视频总数</span>
          </div>
        </div>
        <div class="db-stat-card" style="--accent: #10b981">
          <div class="db-stat-icon bg-green">💬</div>
          <div class="db-stat-info">
            <span class="db-stat-num">{{ overview.totalPosts ?? '--' }}</span>
            <span class="db-stat-label">帖子总数</span>
          </div>
        </div>
        <div class="db-stat-card" style="--accent: #ef4444">
          <div class="db-stat-icon bg-red">▶️</div>
          <div class="db-stat-info">
            <span class="db-stat-num">{{ formatNum(overview.todayPlays ?? 0) }}</span>
            <span class="db-stat-label">今日播放</span>
          </div>
        </div>
      </div>

      <!-- ===== 视频排行 Top5 ===== -->
      <div class="db-ranking">
        <h3 class="db-section-title">🏆 视频热度排行 Top5</h3>
        <div v-if="topVideos.length" class="db-rank-list">
          <div
            v-for="(v, i) in topVideos"
            :key="v.id"
            class="db-rank-item"
          >
            <span class="db-rank-pos" :class="'rk-' + (i + 1)">{{ i + 1 }}</span>
            <img :src="v.cover" class="db-rank-cover" :alt="v.title" />
            <span class="db-rank-title">{{ v.title }}</span>
            <span class="db-rank-stat">👁 {{ formatNum(v.views) }}</span>
            <span class="db-rank-stat">❤ {{ formatNum(v.likes) }}</span>
          </div>
        </div>
        <div v-else class="db-empty-state">暂无热度排行数据，请先在排行榜管理中同步视频</div>
      </div>

      <!-- ===== 快捷入口 ===== -->
      <div class="db-quick-links">
        <h3 class="db-section-title">快捷操作</h3>
        <div class="db-link-grid">
          <div class="db-link-card" @click="$router.push('/admin/users')">
            <span class="db-link-icon">👥</span>
            <span class="db-link-text">用户管理</span>
            <span class="db-link-desc">管理平台用户，编辑角色与状态</span>
          </div>
          <div class="db-link-card" @click="$router.push('/admin/videos')">
            <span class="db-link-icon">🎬</span>
            <span class="db-link-text">视频管理</span>
            <span class="db-link-desc">增删改查动漫视频资源</span>
          </div>
          <div class="db-link-card" @click="$router.push('/admin/content')">
            <span class="db-link-icon">📝</span>
            <span class="db-link-text">社区管理</span>
            <span class="db-link-desc">管理轮播图与帖子审核</span>
          </div>
          <div class="db-link-card" @click="$router.push('/admin/advertisements')">
            <span class="db-link-icon">📣</span>
            <span class="db-link-text">广告管理</span>
            <span class="db-link-desc">发布、上下线与维护广告内容</span>
          </div>
        </div>
      </div>
    </template>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import { ElMessage } from 'element-plus'
import { adminApi } from '@/api/modules/admin'

const loading = ref(true)
const topVideos = ref([])

const overview = reactive({
  totalUsers: null, todayNewUsers: null,
  totalVideos: null, totalPosts: null, todayPlays: null
})

function toCount(value) {
  const count = Number(value)
  return Number.isFinite(count) && count >= 0 ? count : null
}

async function fetchOverview() {
  loading.value = true
  try {
    const res = await adminApi.getStatsOverview()
    if (res) {
      Object.assign(overview, {
        totalUsers: toCount(res.totalUsers),
        todayNewUsers: toCount(res.todayNewUsers),
        totalVideos: toCount(res.totalVideos),
        totalPosts: toCount(res.totalPosts),
        todayPlays: toCount(res.todayPlays)
      })
    }
  } catch (error) {
    console.error('[Dashboard] 概览加载失败:', error)
    Object.assign(overview, {
      totalUsers: null,
      todayNewUsers: null,
      totalVideos: null,
      totalPosts: null,
      todayPlays: null
    })
    ElMessage.error(error.message || '仪表盘数据加载失败')
  } finally {
    loading.value = false
  }
}

async function fetchRanking() {
  try {
    const data = await adminApi.getRankingStats({ period: 'all' })
    const list = data?.ranking
    topVideos.value = Array.isArray(list) ? list.slice(0, 5) : []
  } catch (error) {
    topVideos.value = []
    console.error('[Dashboard] 排行榜加载失败:', error)
    ElMessage.error(error.message || '排行榜加载失败')
  }
}

function formatNum(n) {
  if (n === null || n === undefined) return '--'
  if (n >= 10000) return (n / 10000).toFixed(1) + '万'
  if (n >= 1000) return (n / 1000).toFixed(1) + 'k'
  return String(n)
}

onMounted(() => {
  fetchOverview()
  fetchRanking()
})
</script>

<style scoped>
.db-page {
  padding: 0;
}

/* 骨架屏 */
.db-skeleton {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 16px;
}
.db-skel-card {
  height: 140px;
  background: linear-gradient(90deg, #f0f0f0 25%, #e0e0e0 50%, #f0f0f0 75%);
  background-size: 200% 100%;
  animation: shimmer 1.5s infinite;
  border-radius: 12px;
}
@keyframes shimmer {
  0% { background-position: 200% 0; }
  100% { background-position: -200% 0; }
}

/* 统计卡片 */
.db-stats {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 16px;
  margin-bottom: 28px;
}
.db-stat-card {
  background: #ffffff;
  border-radius: 12px;
  padding: 20px 24px;
  display: flex;
  align-items: center;
  gap: 16px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.04);
  transition: transform 0.2s, box-shadow 0.2s;
  border-left: 4px solid var(--accent);
}
.db-stat-card:hover {
  transform: translateY(-2px);
  box-shadow: 0 6px 20px rgba(0, 0, 0, 0.08);
}
.db-stat-icon {
  width: 50px;
  height: 50px;
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 24px;
  flex-shrink: 0;
}
.bg-purple { background: rgba(102, 126, 234, 0.12); }
.bg-orange { background: rgba(245, 158, 11, 0.12); }
.bg-green  { background: rgba(16, 185, 129, 0.12); }
.bg-red    { background: rgba(239, 68, 68, 0.12); }

.db-stat-info {
  display: flex;
  flex-direction: column;
}
.db-stat-num {
  font-size: 26px;
  font-weight: 800;
  color: var(--accent);
  line-height: 1.2;
}
.db-stat-label {
  font-size: 13px;
  color: #909399;
  margin-top: 2px;
}
.db-stat-extra {
  font-size: 11px;
  color: #67c23a;
  margin-left: auto;
  white-space: nowrap;
}

/* 排行榜 */
.db-ranking { margin-bottom: 28px; }
.db-rank-list { background: #fff; border-radius: 12px; padding: 12px 20px; box-shadow: 0 2px 8px rgba(0,0,0,.04); }
.db-empty-state { padding: 36px 20px; text-align: center; color: #909399; background: #fff; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,.04); }
.db-rank-item { display: flex; align-items: center; gap: 12px; padding: 10px 0; border-bottom: 1px solid #f5f5f5; }
.db-rank-item:last-child { border-bottom: none; }
.db-rank-pos { width: 28px; height: 28px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: 700; font-size: 13px; flex-shrink: 0; }
.rk-1 { background: #f44336; color: #fff; }
.rk-2 { background: #ff9800; color: #fff; }
.rk-3 { background: #ffc107; color: #333; }
.rk-4, .rk-5 { background: #e8e8e8; color: #666; }
.db-rank-cover { width: 60px; aspect-ratio: 16/9; object-fit: cover; border-radius: 6px; flex-shrink: 0; }
.db-rank-title { flex: 1; font-size: 14px; font-weight: 500; color: #333; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.db-rank-stat { font-size: 13px; color: #888; flex-shrink: 0; }

/* 快捷入口 */
.db-section-title {
  font-size: 16px;
  font-weight: 600;
  color: #333;
  margin-bottom: 14px;
}
.db-link-grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 14px;
}
.db-link-card {
  background: #ffffff;
  border-radius: 10px;
  padding: 18px 16px;
  cursor: pointer;
  box-shadow: 0 1px 4px rgba(0, 0, 0, 0.04);
  transition: transform 0.2s, box-shadow 0.2s;
  display: flex;
  flex-direction: column;
  align-items: center;
  text-align: center;
  gap: 6px;
  border: 1px solid #f0f0f0;
}
.db-link-card:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 16px rgba(102, 126, 234, 0.12);
  border-color: #c4b5fd;
}
.db-link-icon {
  font-size: 28px;
}
.db-link-text {
  font-weight: 600;
  font-size: 14px;
  color: #333;
}
.db-link-desc {
  font-size: 12px;
  color: #999;
}

/* 响应式 */
@media (max-width: 1024px) {
  .db-stats { grid-template-columns: repeat(2, 1fr); }
  .db-link-grid { grid-template-columns: repeat(2, 1fr); }
}
@media (max-width: 600px) {
  .db-stats { grid-template-columns: 1fr; }
  .db-link-grid { grid-template-columns: 1fr; }
}
</style>
