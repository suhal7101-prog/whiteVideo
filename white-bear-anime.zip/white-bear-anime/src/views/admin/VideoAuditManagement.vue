<template>
  <div class="va-page">
    <div class="va-toolbar">
      <div class="va-filters">
        <el-input
          v-model.trim="keyword"
          clearable
          placeholder="搜索动漫或投稿用户"
          class="va-search"
          @keyup.enter="handleSearch"
          @clear="handleSearch"
        />
        <el-select v-model="auditStatus" class="va-status" @change="handleSearch">
          <el-option label="待审核" value="pending" />
          <el-option label="已通过" value="approved" />
          <el-option label="已拒绝" value="rejected" />
          <el-option label="全部投稿" value="all" />
        </el-select>
        <el-button class="admin-action-btn" type="primary" :icon="Search" @click="handleSearch">搜索</el-button>
        <el-button class="admin-action-btn" :icon="Refresh" @click="fetchData">刷新</el-button>
      </div>
      <div class="va-count">共 {{ total }} 条投稿</div>
    </div>

    <div class="va-table-wrap">
      <el-table
        :data="submissions"
        stripe
        v-loading="loading"
        empty-text="当前没有需要处理的动漫投稿"
        style="width: 100%"
      >
        <el-table-column prop="id" label="ID" width="70" />
        <el-table-column label="封面" width="104">
          <template #default="{ row }">
            <el-image class="va-cover" :src="row.cover" fit="cover">
              <template #error><div class="va-cover-empty">暂无封面</div></template>
            </el-image>
          </template>
        </el-table-column>
        <el-table-column prop="title" label="动漫标题" min-width="190" show-overflow-tooltip />
        <el-table-column label="投稿用户" min-width="130">
          <template #default="{ row }">
            <div class="va-uploader-name">{{ uploaderName(row) }}</div>
            <div class="va-uploader-id">用户 ID：{{ row.uploaderId || '-' }}</div>
          </template>
        </el-table-column>
        <el-table-column prop="category" label="分类" width="110" show-overflow-tooltip />
        <el-table-column label="标签" min-width="160">
          <template #default="{ row }">
            <div class="va-tags">
              <el-tag v-for="tag in splitTags(row.tags)" :key="tag" size="small" effect="plain">{{ tag }}</el-tag>
              <span v-if="!splitTags(row.tags).length" class="va-muted">未填写</span>
            </div>
          </template>
        </el-table-column>
        <el-table-column label="投稿时间" width="170">
          <template #default="{ row }">{{ formatDate(row.submitTime || row.createTime) }}</template>
        </el-table-column>
        <el-table-column label="审核状态" width="100" align="center">
          <template #default="{ row }">
            <el-tag :type="auditTagType(row.auditStatus)" size="small">{{ auditLabel(row.auditStatus) }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column label="操作" width="270" fixed="right" align="center">
          <template #default="{ row }">
            <el-button class="admin-action-btn" text @click="showDetails(row)">查看</el-button>
            <el-button class="admin-action-btn" text :disabled="!row.videoUrl" @click="previewVideo(row)">预览</el-button>
            <el-button
              v-if="row.auditStatus !== 'approved'"
              class="admin-action-btn"
              text
              :loading="auditingId === row.id"
              @click="approve(row)"
            >通过</el-button>
            <el-button
              v-if="row.auditStatus !== 'rejected'"
              class="admin-action-btn admin-action-danger"
              text
              :loading="auditingId === row.id"
              @click="reject(row)"
            >拒绝</el-button>
          </template>
        </el-table-column>
      </el-table>

      <div class="va-pagination">
        <el-pagination
          v-model:current-page="pageNum"
          v-model:page-size="pageSize"
          :total="total"
          :page-sizes="[10, 20, 50]"
          layout="total, sizes, prev, pager, next"
          @current-change="fetchData"
          @size-change="handleSizeChange"
        />
      </div>
    </div>

    <el-dialog v-model="detailVisible" title="投稿详情" width="640px" destroy-on-close>
      <div v-if="selected" class="va-detail">
        <el-image class="va-detail-cover" :src="selected.cover" fit="cover">
          <template #error><div class="va-cover-empty">暂无封面</div></template>
        </el-image>
        <div class="va-detail-content">
          <h3>{{ selected.title }}</h3>
          <dl>
            <dt>投稿用户</dt><dd>{{ uploaderName(selected) }}（ID：{{ selected.uploaderId || '-' }}）</dd>
            <dt>分类</dt><dd>{{ selected.category || '未填写' }}</dd>
            <dt>连载状态</dt><dd>{{ videoStatusLabel(selected.status) }}</dd>
            <dt>年份/地区</dt><dd>{{ [selected.year, selected.region].filter(Boolean).join(' / ') || '未填写' }}</dd>
            <dt>标签</dt><dd>{{ splitTags(selected.tags).join('、') || '未填写' }}</dd>
            <dt>投稿时间</dt><dd>{{ formatDate(selected.submitTime || selected.createTime) }}</dd>
            <dt>审核状态</dt><dd>{{ auditLabel(selected.auditStatus) }}</dd>
            <template v-if="selected.auditReason">
              <dt>审核说明</dt><dd class="va-reason">{{ selected.auditReason }}</dd>
            </template>
          </dl>
          <div class="va-description">
            <strong>内容简介</strong>
            <p>{{ selected.description || '投稿用户未填写内容简介。' }}</p>
          </div>
        </div>
      </div>
      <template #footer>
        <el-button class="admin-action-btn" @click="detailVisible = false">关闭</el-button>
        <el-button class="admin-action-btn" type="primary" plain :disabled="!selected?.videoUrl" @click="previewVideo(selected)">
          预览视频
        </el-button>
        <el-button v-if="selected?.auditStatus !== 'approved'" class="admin-action-btn" type="success" @click="approve(selected)">通过</el-button>
        <el-button v-if="selected?.auditStatus !== 'rejected'" class="admin-action-btn admin-action-danger" type="danger" @click="reject(selected)">拒绝</el-button>
      </template>
    </el-dialog>

    <el-dialog v-model="previewVisible" :title="previewTitle" width="900px" append-to-body destroy-on-close
      @closed="previewError = false">
      <div v-if="selected?.videoUrl" class="va-video-preview">
        <video :key="selected.videoUrl" :src="selected.videoUrl" :poster="selected.cover" controls preload="metadata"
          playsinline @loadeddata="previewError = false" @error="previewError = true">
          当前浏览器不支持该视频格式。
        </video>
        <div class="va-video-meta">
          <span>第 {{ selected.episodeNumber || 1 }} 集</span>
          <span v-if="selected.videoFileSize">{{ formatFileSize(selected.videoFileSize) }}</span>
          <a :href="selected.videoUrl" target="_blank" rel="noopener">新窗口打开</a>
        </div>
        <el-alert v-if="previewError" title="视频加载失败，请确认文件仍存在或尝试在新窗口打开" type="error" :closable="false" show-icon />
      </div>
      <el-empty v-else description="该投稿没有可用的视频文件" />
    </el-dialog>
  </div>
</template>

<script setup>
import { computed, onMounted, ref } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { Refresh, Search } from '@element-plus/icons-vue'
import dayjs from 'dayjs'
import { adminApi } from '@/api/modules/admin'

const submissions = ref([])
const loading = ref(false)
const auditingId = ref(null)
const pageNum = ref(1)
const pageSize = ref(10)
const total = ref(0)
const keyword = ref('')
const auditStatus = ref('pending')
const detailVisible = ref(false)
const previewVisible = ref(false)
const previewError = ref(false)
const selected = ref(null)

async function fetchData() {
  loading.value = true
  try {
    const res = await adminApi.getVideoSubmissions({
      page: pageNum.value,
      size: pageSize.value,
      keyword: keyword.value || undefined,
      auditStatus: auditStatus.value
    })
    submissions.value = res?.list || res?.records || []
    total.value = Number(res?.total || 0)
  } catch (error) {
    ElMessage.error('获取投稿审核列表失败：' + (error?.message || '未知错误'))
  } finally {
    loading.value = false
  }
}

function handleSearch() {
  pageNum.value = 1
  fetchData()
}

function handleSizeChange() {
  pageNum.value = 1
  fetchData()
}

function showDetails(row) {
  selected.value = row
  detailVisible.value = true
}

function previewVideo(row) {
  if (!row?.videoUrl) {
    ElMessage.warning('该投稿没有可用的视频文件')
    return
  }
  selected.value = row
  previewError.value = false
  previewVisible.value = true
}

async function approve(row) {
  if (!row) return
  try {
    await ElMessageBox.confirm(`确认通过动漫「${row.title}」的投稿审核吗？`, '通过投稿', {
      confirmButtonText: '确认通过',
      cancelButtonText: '取消',
      type: 'success'
    })
    await submitAudit(row, { status: 'approved', reason: '' })
  } catch (error) {
    if (error !== 'cancel' && error !== 'close') ElMessage.error('审核失败：' + (error?.message || '未知错误'))
  }
}

async function reject(row) {
  if (!row) return
  try {
    const { value } = await ElMessageBox.prompt(`请填写拒绝「${row.title}」的原因，投稿用户将据此修改。`, '拒绝投稿', {
      confirmButtonText: '确认拒绝',
      cancelButtonText: '取消',
      inputType: 'textarea',
      inputPlaceholder: '例如：封面不清晰，请重新上传高清封面',
      inputValidator: value => value?.trim() ? true : '拒绝投稿时必须填写原因',
      type: 'warning'
    })
    await submitAudit(row, { status: 'rejected', reason: value.trim() })
  } catch (error) {
    if (error !== 'cancel' && error !== 'close') ElMessage.error('审核失败：' + (error?.message || '未知错误'))
  }
}

async function submitAudit(row, data) {
  auditingId.value = row.id
  try {
    await adminApi.auditVideoSubmission(row.id, data)
    ElMessage.success(data.status === 'approved' ? '投稿已通过，将显示在动漫视频中' : '投稿已拒绝')
    detailVisible.value = false
    await fetchData()
  } finally {
    auditingId.value = null
  }
}

function uploaderName(row) {
  return row.uploaderNickname || row.uploadernickname || row.uploaderUsername || row.uploaderusername || '未知用户'
}

function splitTags(tags) {
  return String(tags || '').split(',').map(item => item.trim()).filter(Boolean)
}

function auditLabel(status) {
  return ({ pending: '待审核', approved: '已通过', rejected: '已拒绝' })[status] || '待审核'
}

function auditTagType(status) {
  return ({ pending: 'warning', approved: 'success', rejected: 'danger' })[status] || 'warning'
}

function videoStatusLabel(status) {
  if (status === 'serializing' || status === '连载中') return '连载中'
  if (status === 'finished' || status === '已完结') return '已完结'
  return status || '未填写'
}

function formatDate(value) {
  return value ? dayjs(value).format('YYYY-MM-DD HH:mm') : '-'
}

function formatFileSize(value) {
  const bytes = Number(value)
  if (!Number.isFinite(bytes) || bytes <= 0) return ''
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`
  return `${(bytes / 1024 / 1024).toFixed(1)} MB`
}

const previewTitle = computed(() => selected.value?.title ? `投稿视频预览：${selected.value.title}` : '投稿视频预览')

onMounted(fetchData)
</script>

<style scoped>
.va-page { display: flex; flex-direction: column; gap: 16px; }
.va-toolbar, .va-table-wrap { background: #fff; border-radius: 12px; box-shadow: 0 2px 12px rgba(24, 39, 75, 0.05); }
.va-toolbar { min-height: 68px; padding: 14px 18px; display: flex; align-items: center; justify-content: space-between; gap: 16px; }
.va-filters { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; }
.va-search { width: 240px; }
.va-status { width: 130px; }
.va-count { color: #8b93a3; font-size: 13px; white-space: nowrap; }
.va-table-wrap { overflow: hidden; padding-bottom: 14px; }
.va-cover { width: 64px; height: 82px; border-radius: 7px; background: #f1f3f7; }
.va-cover-empty { width: 100%; height: 100%; display: flex; align-items: center; justify-content: center; color: #a6adba; font-size: 12px; }
.va-uploader-name { color: #303442; }
.va-uploader-id, .va-muted { margin-top: 3px; color: #9aa1af; font-size: 12px; }
.va-tags { display: flex; flex-wrap: wrap; gap: 5px; }
.va-pagination { display: flex; justify-content: flex-end; padding: 16px 18px 0; }
.va-detail { display: grid; grid-template-columns: 160px 1fr; gap: 22px; }
.va-detail-cover { width: 160px; height: 220px; border-radius: 10px; background: #f1f3f7; }
.va-detail-content h3 { margin: 0 0 15px; color: #202432; font-size: 19px; }
.va-detail-content dl { display: grid; grid-template-columns: 76px 1fr; gap: 8px 12px; margin: 0; font-size: 13px; }
.va-detail-content dt { color: #9299a8; }
.va-detail-content dd { margin: 0; color: #454b59; word-break: break-word; }
.va-reason { color: #e0525d !important; }
.va-description { margin-top: 18px; padding-top: 14px; border-top: 1px solid #eef0f4; color: #4d5361; font-size: 13px; }
.va-description p { margin: 7px 0 0; line-height: 1.7; color: #707785; white-space: pre-wrap; }
.va-video-preview { display: flex; flex-direction: column; gap: 12px; }
.va-video-preview video { display: block; width: 100%; max-height: 65vh; border-radius: 10px; background: #090b10; }
.va-video-meta { display: flex; align-items: center; gap: 16px; color: #7d8595; font-size: 13px; }
.va-video-meta a { margin-left: auto; color: #667eea; text-decoration: none; }
.va-video-meta a:hover { text-decoration: underline; }
@media (max-width: 900px) {
  .va-toolbar { align-items: flex-start; flex-direction: column; }
  .va-detail { grid-template-columns: 1fr; }
  .va-detail-cover { width: 130px; height: 180px; }
}
</style>
