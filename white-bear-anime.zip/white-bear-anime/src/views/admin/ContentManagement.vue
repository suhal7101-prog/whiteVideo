<!--
  管理后台 · 社区管理
  帖子审核
-->
<template>
  <div class="cm-page">
    <div class="cm-toolbar">
      <h3 class="cm-section-h">📋 帖子审核</h3>
    </div>

    <div class="cm-table-wrap">
      <el-table
        :data="pendingPosts"
        stripe
        v-loading="postLoading"
        empty-text="暂无待审核帖子"
        style="width:100%"
      >
        <el-table-column prop="id" label="ID" width="70" />
        <el-table-column prop="title" label="标题" min-width="220" />
        <el-table-column prop="authorId" label="作者ID" width="90" align="center" />
        <el-table-column prop="tag" label="标签" width="90" align="center">
          <template #default="{ row }">
            <el-tag size="small" type="info">{{ row.tag || '-' }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="createTime" label="发布时间" width="170">
          <template #default="{ row }">
            {{ formatDate(row.createTime) }}
          </template>
        </el-table-column>
        <el-table-column label="操作" width="180" fixed="right" align="center">
          <template #default="{ row }">
            <el-button link class="admin-action-btn" @click="auditPost(row, 'approved')">通过</el-button>
            <el-button link class="admin-action-btn admin-action-danger" @click="auditPost(row, 'rejected')">拒绝</el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { ElMessage } from 'element-plus'
import { adminApi } from '@/api/modules/admin'
import dayjs from 'dayjs'

const pendingPosts = ref([])
const postLoading = ref(false)

async function fetchPendingPosts() {
  postLoading.value = true
  try {
    const res = await adminApi.getPendingPosts({ page: 1, size: 20 })
    pendingPosts.value = Array.isArray(res) ? res : (res?.records || res?.list || [])
  } catch (e) {
    console.error('[ContentManagement] 获取待审核帖子失败:', e)
  } finally {
    postLoading.value = false
  }
}

async function auditPost(row, status) {
  try {
    await adminApi.auditPost(row.id, status)
    ElMessage.success(status === 'approved' ? '帖子已通过审核' : '帖子已拒绝')
    fetchPendingPosts()
  } catch (e) {
    ElMessage.error('审核失败: ' + (e?.message || '未知错误'))
  }
}

function formatDate(d) {
  if (!d) return ''
  const date = dayjs(d)
  return date.isValid() ? date.format('YYYY-MM-DD HH:mm') : d
}

onMounted(() => {
  fetchPendingPosts()
})
</script>

<style scoped>
.cm-page { padding: 0; }
.cm-toolbar {
  display: flex; justify-content: space-between; align-items: center;
  margin-bottom: 14px;
}
.cm-section-h { font-size: 16px; font-weight: 600; color: #333; margin: 0; }
.cm-table-wrap {
  background: #fff; border-radius: 10px;
  box-shadow: 0 1px 6px rgba(0,0,0,.05); overflow: hidden;
}
</style>
