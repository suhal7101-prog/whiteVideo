<!-- 管理后台 · 排行榜管理 -->
<template>
  <div class="rk-page">
    <div class="rk-header">
      <h2>🏆 视频排行榜 Top10</h2>
      <el-button class="admin-action-btn" type="primary" :loading="syncing" @click="refreshRanking">
        <el-icon><Refresh /></el-icon> 刷新数据
      </el-button>
    </div>

    <div class="rk-table-wrap" v-loading="loading">
      <el-table
        :data="rankingList"
        stripe
        empty-text="暂无排行榜数据，请点击右上角刷新数据"
        style="width:100%"
        row-key="id"
      >
        <el-table-column label="排名" width="70" align="center">
          <template #default="{ $index }">
            <span class="rk-rank" :class="'rk-rank-' + ($index + 1)">
              {{ $index + 1 }}
            </span>
          </template>
        </el-table-column>
        <el-table-column label="封面" width="110">
          <template #default="{ row }">
            <img :src="row.cover" class="rk-cover" :alt="row.title" />
          </template>
        </el-table-column>
        <el-table-column prop="title" label="视频名称" min-width="220" />
        <el-table-column prop="category" label="分类" width="100" />
        <el-table-column label="浏览量" width="120" sortable prop="views" align="center">
          <template #default="{ row }">
            <span class="rk-views">{{ formatNum(row.views) }}</span>
          </template>
        </el-table-column>
        <el-table-column label="点赞量" width="120" sortable prop="likes" align="center">
          <template #default="{ row }">
            <span class="rk-likes">{{ formatNum(row.likes) }}</span>
          </template>
        </el-table-column>
      </el-table>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { ElMessage } from 'element-plus'
import request from '@/api/request'

const rankingList = ref([])
const loading = ref(false)
const syncing = ref(false)

function formatNum(n) {
  if (!n && n !== 0) return '0'
  if (n >= 10000) return (n / 10000).toFixed(1) + '万'
  return n.toLocaleString()
}

async function fetchRanking() {
  loading.value = true
  try {
    const res = await request.get('/ranking/top10')
    // 兼容多种返回格式
    const data = res?.data || res
    const list = data?.list || data?.records || data
    rankingList.value = Array.isArray(list) ? list : []
  } catch (e) {
    console.error('获取排行榜失败:', e)
    ElMessage.error(e.message || '获取排行榜失败，请确认后台服务已启动')
  } finally {
    loading.value = false
  }
}

async function refreshRanking() {
  syncing.value = true
  try {
    const result = await request.post('/ranking/refresh', null, { timeout: 60000 })
    await fetchRanking()
    if (result?.synced === false) {
      ElMessage.warning(result.warning || `视频源暂时不可用，已保留现有 ${result?.retained || 0} 条数据`)
    } else {
      ElMessage.success('更新成功')
    }
  } catch (error) {
    console.error('刷新排行榜失败:', error)
    ElMessage.error(error.message || '刷新排行榜失败，请检查 Python 服务')
  } finally {
    syncing.value = false
  }
}

onMounted(fetchRanking)
</script>

<style scoped>
.rk-page { padding: 0; }
.rk-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px; }
.rk-header h2 { margin: 0; font-size: 18px; }
.rk-table-wrap {
  background: #fff; border-radius: 12px; overflow: hidden;
  box-shadow: 0 2px 8px rgba(0,0,0,.04);
}

.rk-cover { width: 90px; aspect-ratio: 16/9; object-fit: cover; border-radius: 6px; }

.rk-rank { font-size: 18px; font-weight: 800; }
.rk-rank-1 { color: #f44336; }
.rk-rank-2 { color: #ff9800; }
.rk-rank-3 { color: #ffc107; }
.rk-rank-4,
.rk-rank-5 { color: #667eea; }

.rk-views { color: #667eea; font-weight: 600; }
.rk-likes { color: #e74c3c; font-weight: 600; }
</style>
