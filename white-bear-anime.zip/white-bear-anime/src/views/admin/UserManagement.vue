<!--
  管理后台 · 用户管理
  对接后端 /api/admin/users 系列接口
-->
<template>
  <div class="um-page">
    <!-- ===== 顶部操作栏 ===== -->
    <div class="um-toolbar">
      <div class="um-filters">
        <el-input
          v-model="keyword"
          placeholder="搜索用户名/邮箱..."
          clearable
          :prefix-icon="Search"
          style="width: 260px"
          @keyup.enter="handleSearch"
          @clear="handleSearch"
        />
        <el-select v-model="filterRole" placeholder="角色筛选" clearable style="width: 140px" @change="handleSearch">
          <el-option label="全部角色" value="" />
          <el-option label="管理员" value="admin" />
          <el-option label="版主" value="moderator" />
          <el-option label="普通用户" value="user" />
          <el-option label="创作者" value="creator" />
        </el-select>
        <el-select v-model="filterStatus" placeholder="状态筛选" clearable style="width: 140px" @change="handleSearch">
          <el-option label="全部状态" value="" />
          <el-option label="正常" value="active" />
          <el-option label="禁用" value="banned" />
        </el-select>
        <el-button class="admin-action-btn" type="primary" :icon="Search" @click="handleSearch">搜索</el-button>
      </div>
    </div>

    <!-- ===== 提示信息 ===== -->
    <el-alert
      v-if="total > 0"
      :title="`共找到 ${total} 条用户记录`"
      type="info"
      :closable="false"
      show-icon
      style="margin-bottom: 16px"
    />

    <!-- ===== 用户表格 ===== -->
    <div class="um-table-wrap">
      <el-table
        :data="users"
        stripe
        v-loading="loading"
        empty-text="暂无符合当前筛选条件的用户"
        style="width: 100%"
        :default-sort="{ prop: 'id', order: 'ascending' }"
      >
        <el-table-column prop="id" label="ID" width="75" sortable />
        <el-table-column prop="username" label="用户名" min-width="120">
          <template #default="{ row }">
            <div class="um-user-cell">
              <el-avatar :size="32" :src="row.avatar">
                {{ row.username?.charAt(0)?.toUpperCase() }}
              </el-avatar>
              <span class="um-user-name">{{ row.username }}</span>
            </div>
          </template>
        </el-table-column>
        <el-table-column prop="email" label="邮箱" min-width="200" />
        <el-table-column prop="nickname" label="昵称" min-width="120" />
        <el-table-column label="密码" width="160" align="center">
          <template #default="{ row }">
            <div class="um-pwd-cell">
              <span class="um-pwd-text">
                {{ sessionPasswords.has(row.id)
                  ? (hiddenPwd.has(row.id) ? '******' : sessionPasswords.get(row.id))
                  : '******' }}
              </span>
              <el-tooltip
                :content="isPasswordHidden(row.id) ? '显示密码' : '隐藏密码'"
                placement="top"
              >
                <el-button
                  size="small"
                  text
                  class="admin-action-btn admin-icon-action um-pwd-btn"
                  :aria-label="isPasswordHidden(row.id) ? '显示密码' : '隐藏密码'"
                  @click="togglePwd(row.id)"
                >
                  <el-icon><View v-if="isPasswordHidden(row.id)" /><Hide v-else /></el-icon>
                </el-button>
              </el-tooltip>
            </div>
          </template>
        </el-table-column>
        <el-table-column prop="role" label="角色" width="100" align="center">
          <template #default="{ row }">
            <el-tag
              :type="roleTagType(row.role)"
              size="small"
              effect="plain"
            >
              {{ roleLabel(row.role) }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="status" label="状态" width="80" align="center">
          <template #default="{ row }">
            <el-tag
              :type="row.status === 'active' ? 'success' : 'danger'"
              size="small"
              effect="dark"
            >
              {{ row.status === 'active' ? '正常' : '禁用' }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="registerDate" label="注册时间" width="170">
          <template #default="{ row }">
            {{ formatDate(row.registerDate) }}
          </template>
        </el-table-column>
        <el-table-column prop="lastLogin" label="最后登录" width="170">
          <template #default="{ row }">
            {{ formatDate(row.lastLogin) || '从未登录' }}
          </template>
        </el-table-column>
        <el-table-column label="操作" width="200" fixed="right" align="center">
          <template #default="{ row }">
            <el-button size="small" text class="admin-action-btn" @click="openEdit(row)">编辑</el-button>
            <el-button size="small" text class="admin-action-btn" @click="openResetPwd(row)">重置密码</el-button>
            <el-button size="small" text class="admin-action-btn admin-action-danger" @click="handleDelete(row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>

    <!-- ===== 分页 ===== -->
    <div class="um-pagination" v-if="total > 0">
      <el-pagination
        v-model:current-page="pageNum"
        v-model:page-size="pageSize"
        :page-sizes="[10, 20, 50, 100]"
        :total="total"
        layout="total, sizes, prev, pager, next, jumper"
        background
        @size-change="fetchData"
        @current-change="fetchData"
      />
    </div>

    <!-- ===== 编辑用户弹窗 ===== -->
    <el-dialog v-model="editVisible" title="编辑用户信息" width="500px" destroy-on-close>
      <el-form :model="editForm" label-width="80px" label-position="right">
        <el-form-item label="头像">
          <div style="display:flex;align-items:center;gap:12px">
            <el-avatar :size="48" :src="editForm.avatar" />
            <el-input v-model="editForm.avatar" placeholder="头像URL" style="flex:1" />
          </div>
        </el-form-item>
        <el-form-item label="昵称">
          <el-input v-model="editForm.nickname" placeholder="用户昵称" maxlength="64" show-word-limit />
        </el-form-item>
        <el-form-item label="简介">
          <el-input
            v-model="editForm.bio"
            type="textarea"
            :rows="3"
            placeholder="个人简介"
            maxlength="512"
            show-word-limit
          />
        </el-form-item>
        <el-form-item label="状态">
          <el-switch
            v-model="editForm.status"
            active-value="active"
            inactive-value="banned"
            active-text="正常"
            inactive-text="禁用"
          />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button class="admin-action-btn" @click="editVisible = false">取消</el-button>
        <el-button class="admin-action-btn" type="primary" :loading="saving" @click="saveEdit">保存</el-button>
      </template>
    </el-dialog>

    <!-- 重置密码弹窗 -->
    <el-dialog v-model="pwdVisible" title="重置密码" width="380px" destroy-on-close>
      <el-form label-width="80px">
        <el-form-item label="用户">
          <span style="font-weight:600">{{ pwdForm?.username }}</span>
        </el-form-item>
        <el-form-item label="新密码">
          <el-input v-model="pwdForm.newPwd" type="password" show-password placeholder="请输入新密码" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button class="admin-action-btn" @click="pwdVisible = false">取消</el-button>
        <el-button class="admin-action-btn" type="primary" :loading="saving" @click="savePwd">确认重置</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { Hide, Search, View } from '@element-plus/icons-vue'
import { adminApi } from '@/api/modules/admin'
import dayjs from 'dayjs'

// ===== 列表数据 =====
const users = ref([])
const loading = ref(false)
const total = ref(0)
const pageNum = ref(1)
const pageSize = ref(10)

// 筛选
const keyword = ref('')
const filterRole = ref('')
const filterStatus = ref('')

// BCrypt 无法还原原密码，只临时保存本页面刚刚重置的新密码。
const sessionPasswords = ref(new Map())
const hiddenPwd = ref(new Set())

function isPasswordHidden(id) {
  return !sessionPasswords.value.has(id) || hiddenPwd.value.has(id)
}

function togglePwd(id) {
  if (!sessionPasswords.value.has(id)) {
    ElMessage.warning('原密码无法查看，请先重置密码')
    return
  }
  const s = hiddenPwd.value
  s.has(id) ? s.delete(id) : s.add(id)
  hiddenPwd.value = new Set(s)
}

// ===== 获取用户列表 =====
async function fetchData() {
  loading.value = true
  try {
    const params = {
      page: pageNum.value,
      size: pageSize.value
    }
    if (keyword.value) params.keyword = keyword.value
    if (filterRole.value) params.role = filterRole.value
    if (filterStatus.value) params.status = filterStatus.value

    const res = await adminApi.getUsers(params)
    // 后端返回 { records: [...], total: n, ... } 或 { list: [...], total: n }
    users.value = res.records || res.list || []
    total.value = res.total || 0
  } catch (e) {
    ElMessage.error('获取用户列表失败: ' + (e?.message || '未知错误'))
    console.error('[UserManagement] fetchData error:', e)
  } finally {
    loading.value = false
  }
}

function handleSearch() {
  pageNum.value = 1
  fetchData()
}

// ===== 编辑用户 =====
const editVisible = ref(false)
const saving = ref(false)
const editForm = reactive({
  id: null,
  avatar: '',
  nickname: '',
  bio: '',
  status: 'active'
})

function openEdit(row) {
  editForm.id = row.id
  editForm.avatar = row.avatar || ''
  editForm.nickname = row.nickname || ''
  editForm.bio = row.bio || ''
  editForm.status = row.status || 'active'
  editVisible.value = true
}

async function saveEdit() {
  saving.value = true
  try {
    await adminApi.updateUser(editForm.id, {
      avatar: editForm.avatar,
      nickname: editForm.nickname,
      bio: editForm.bio,
      status: editForm.status
    })
    ElMessage.success('用户信息已更新')
    editVisible.value = false
    fetchData()
  } catch (e) {
    ElMessage.error('更新失败: ' + (e?.message || '未知错误'))
  } finally {
    saving.value = false
  }
}

// ===== 重置密码 =====
const pwdVisible = ref(false)
const pwdForm = reactive({ id: null, username: '', newPwd: '' })

function openResetPwd(row) {
  pwdForm.id = row.id
  pwdForm.username = row.username
  pwdForm.newPwd = ''
  pwdVisible.value = true
}

async function savePwd() {
  if (!pwdForm.newPwd || pwdForm.newPwd.length < 6) {
    ElMessage.warning('密码至少6个字符')
    return
  }
  saving.value = true
  try {
    await adminApi.resetPassword(pwdForm.id, pwdForm.newPwd)
    const passwords = new Map(sessionPasswords.value)
    passwords.set(pwdForm.id, pwdForm.newPwd)
    sessionPasswords.value = passwords

    const hidden = new Set(hiddenPwd.value)
    hidden.add(pwdForm.id)
    hiddenPwd.value = hidden

    ElMessage.success('密码已重置')
    pwdVisible.value = false
    pwdForm.newPwd = ''
  } catch (e) {
    ElMessage.error('重置失败')
  } finally {
    saving.value = false
  }
}

// ===== 删除用户 =====
async function handleDelete(row) {
  try {
    await ElMessageBox.confirm(
      `确定要删除用户 「${row.username}」(${row.email}) 吗？此操作不可逆！`,
      '删除确认',
      {
        confirmButtonText: '确定删除',
        cancelButtonText: '取消',
        type: 'warning',
        confirmButtonClass: 'admin-action-btn admin-action-danger',
        cancelButtonClass: 'admin-action-btn'
      }
    )
    await adminApi.deleteUser(row.id)
    ElMessage.success(`用户 「${row.username}」 已删除`)
    fetchData()
  } catch (e) {
    if (e !== 'cancel' && e !== 'close') {
      ElMessage.error('删除失败: ' + (e?.message || '未知错误'))
    }
  }
}

// ===== 工具函数 =====
function roleLabel(role) {
  const map = { admin: '管理员', creator: '创作者', moderator: '版主', user: '普通用户' }
  return map[role] || role
}

function roleTagType(role) {
  const map = { admin: 'danger', creator: 'success', moderator: 'warning', user: 'info' }
  return map[role] || 'info'
}

function formatDate(dateStr) {
  if (!dateStr) return ''
  // 适配各种日期格式
  try {
    const d = dayjs(dateStr)
    if (d.isValid()) {
      return d.format('YYYY-MM-DD HH:mm')
    }
  } catch (e) { /* ignore */ }
  return dateStr
}

// ===== 初始化 =====
onMounted(() => {
  fetchData()
})
</script>

<style scoped>
.um-page {
  padding: 0;
}

/* 顶部操作栏 */
.um-toolbar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 16px;
  flex-wrap: wrap;
  gap: 12px;
}
.um-filters {
  display: flex;
  align-items: center;
  gap: 12px;
  flex-wrap: wrap;
}

/* 表格容器 */
.um-table-wrap {
  background: #ffffff;
  border-radius: 10px;
  box-shadow: 0 1px 6px rgba(0, 0, 0, 0.05);
  overflow: hidden;
}

/* 用户单元格 */
.um-user-cell {
  display: flex;
  align-items: center;
  gap: 10px;
}
.um-user-name {
  font-weight: 500;
  color: #333;
}

/* 分页 */
.um-pagination {
  display: flex;
  justify-content: flex-end;
  margin-top: 20px;
  padding-bottom: 8px;
}


/* 密码列 */
.um-pwd-cell {
  display: flex; align-items: center; justify-content: center; gap: 4px;
}
.um-pwd-text {
  font-family: monospace; font-size: 12px; color: #888;
  max-width: 100px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
}
.um-pwd-btn {
  color: #999; flex-shrink: 0;
}

/* 响应式 */
@media (max-width: 768px) {
  .um-filters {
    flex-direction: column;
    align-items: stretch;
  }
  .um-filters .el-input,
  .um-filters .el-select {
    width: 100% !important;
  }
}
</style>
