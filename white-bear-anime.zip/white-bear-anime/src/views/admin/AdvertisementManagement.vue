<template>
  <div class="ad-page">
    <div class="ad-toolbar">
      <div>
        <h2>广告管理</h2>
        <p>管理广告图片、跳转地址、展示位置与有效期</p>
      </div>
      <el-button class="admin-action-btn" type="primary" @click="openCreate">新增广告</el-button>
    </div>

    <div class="ad-table-wrap">
      <el-table
        :data="advertisements"
        stripe
        v-loading="loading"
        empty-text="暂无广告，请点击右上角新增广告"
        style="width:100%"
      >
        <el-table-column prop="id" label="ID" width="65" />
        <el-table-column label="广告图" width="150">
          <template #default="{ row }">
            <el-image
              class="ad-thumb"
              :src="row.imageUrl"
              fit="cover"
              :preview-src-list="[row.imageUrl]"
              preview-teleported
              :z-index="6000"
            />
          </template>
        </el-table-column>
        <el-table-column prop="title" label="标题" min-width="180">
          <template #default="{ row }">
            <div class="ad-title"><strong>{{ row.title }}</strong><small>{{ row.description || '-' }}</small></div>
          </template>
        </el-table-column>
        <el-table-column prop="position" label="展示位置" width="125" align="center">
          <template #default="{ row }"><el-tag size="small" type="info">{{ positionLabel(row.position) }}</el-tag></template>
        </el-table-column>
        <el-table-column prop="targetUrl" label="跳转地址" min-width="135" show-overflow-tooltip />
        <el-table-column label="有效期" width="180">
          <template #default="{ row }">
            <div class="ad-period"><span>{{ formatDate(row.startTime) }}</span><span>至 {{ formatDate(row.endTime) }}</span></div>
          </template>
        </el-table-column>
        <el-table-column prop="status" label="状态" width="90" align="center">
          <template #default="{ row }">
            <el-tag :type="row.status === 'active' ? 'success' : 'info'">{{ row.status === 'active' ? '已上线' : '已下线' }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column label="操作" width="220" fixed="right" align="center">
          <template #default="{ row }">
            <el-button class="admin-action-btn" @click="openEdit(row)">编辑</el-button>
            <el-button class="admin-action-btn" :class="{ 'admin-action-danger': row.status === 'active' }" @click="toggleStatus(row)">
              {{ row.status === 'active' ? '下线' : '上线' }}
            </el-button>
            <el-button class="admin-action-btn admin-action-danger" @click="removeAdvertisement(row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>

    <el-dialog v-model="dialogVisible" :title="editingId ? '编辑广告' : '新增广告'" width="680px" destroy-on-close>
      <el-form ref="formRef" :model="form" :rules="rules" label-width="90px">
        <el-form-item label="标题" prop="title"><el-input v-model="form.title" maxlength="128" /></el-form-item>
        <el-form-item label="广告说明"><el-input v-model="form.description" type="textarea" :rows="2" maxlength="500" /></el-form-item>
        <el-form-item label="广告图片" prop="imageUrl">
          <div class="ad-image-picker" v-loading="imageLoading">
            <div class="ad-image-picker-head">
              <span>从 ad 文件夹选择，或上传新图片</span>
              <el-upload
                accept="image/png,image/jpeg,image/webp,image/gif"
                :show-file-list="false"
                :http-request="uploadAdvertisementImage"
              >
                <el-button class="admin-action-btn" :loading="uploading">上传图片</el-button>
              </el-upload>
            </div>
            <div v-if="imageLibrary.length" class="ad-image-library">
              <button
                v-for="image in imageLibrary"
                :key="image.url"
                type="button"
                class="ad-image-option"
                :class="{ selected: form.imageUrl === image.url }"
                :title="image.name"
                @click="form.imageUrl = image.url"
              >
                <img :src="image.url" :alt="image.name" />
                <span v-if="form.imageUrl === image.url" class="ad-image-selected" aria-label="已选择">
                  <el-icon><Check /></el-icon>
                </span>
              </button>
            </div>
            <el-empty v-else-if="!imageLoading" description="图片库暂无可用图片，请点击上方按钮上传" :image-size="54" />
          </div>
        </el-form-item>
        <el-form-item label="跳转地址"><el-input v-model="form.targetUrl" placeholder="/discover" /></el-form-item>
        <div class="ad-form-grid">
          <el-form-item label="展示位置">
            <el-select v-model="form.position" style="width:100%">
              <el-option label="顶部导航栏" value="nav_top" />
              <el-option label="首页推荐区" value="home_top" />
              <el-option label="社区侧边" value="community_sidebar" />
              <el-option label="AI 侧边" value="ai_sidebar" />
              <el-option label="播放器暂停层" value="player_pause" />
            </el-select>
          </el-form-item>
          <el-form-item label="排序"><el-input-number v-model="form.sortOrder" :min="0" :max="999" /></el-form-item>
        </div>
        <el-form-item label="开始时间"><el-date-picker v-model="form.startTime" type="datetime" value-format="YYYY-MM-DDTHH:mm:ss" style="width:100%" /></el-form-item>
        <el-form-item label="结束时间"><el-date-picker v-model="form.endTime" type="datetime" value-format="YYYY-MM-DDTHH:mm:ss" style="width:100%" /></el-form-item>
        <el-form-item label="状态">
          <el-radio-group v-model="form.status"><el-radio value="active">立即上线</el-radio><el-radio value="inactive">保存下线</el-radio></el-radio-group>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button class="admin-action-btn" @click="dialogVisible = false">取消</el-button>
        <el-button class="admin-action-btn" type="primary" :loading="saving" @click="saveAdvertisement">保存</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { onMounted, reactive, ref } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { Check } from '@element-plus/icons-vue'
import dayjs from 'dayjs'
import { adminApi } from '@/api/modules/admin'

const advertisements = ref([])
const loading = ref(false)
const saving = ref(false)
const dialogVisible = ref(false)
const editingId = ref(null)
const formRef = ref(null)
const imageLibrary = ref([])
const imageLoading = ref(false)
const uploading = ref(false)
const emptyForm = () => ({ title: '', description: '', imageUrl: '', targetUrl: '', position: 'home_top', status: 'active', startTime: '', endTime: '', sortOrder: 0 })
const form = reactive(emptyForm())
const rules = { title: [{ required: true, message: '请输入广告标题', trigger: 'blur' }], imageUrl: [{ required: true, message: '请选择或上传广告图片', trigger: 'change' }] }

async function fetchAdvertisements() {
  loading.value = true
  try { advertisements.value = (await adminApi.getAdvertisements())?.list || [] }
  finally { loading.value = false }
}
async function loadImageLibrary() {
  imageLoading.value = true
  try { imageLibrary.value = await adminApi.getAdvertisementImages() || [] }
  finally { imageLoading.value = false }
}
function openCreate() { editingId.value = null; Object.assign(form, emptyForm()); dialogVisible.value = true; loadImageLibrary() }
function openEdit(row) { editingId.value = row.id; Object.assign(form, { ...emptyForm(), ...row }); dialogVisible.value = true; loadImageLibrary() }
async function uploadAdvertisementImage(options) {
  uploading.value = true
  try {
    const image = await adminApi.uploadAdvertisementImage(options.file)
    form.imageUrl = image.url
    await loadImageLibrary()
    options.onSuccess?.(image)
    ElMessage.success('广告图片上传成功')
  } catch (error) {
    options.onError?.(error)
  } finally { uploading.value = false }
}
async function saveAdvertisement() {
  await formRef.value?.validate(); saving.value = true
  try {
    const payload = { ...form, startTime: form.startTime || null, endTime: form.endTime || null }
    if (editingId.value) await adminApi.updateAdvertisement(editingId.value, payload)
    else await adminApi.createAdvertisement(payload)
    ElMessage.success('广告已保存'); dialogVisible.value = false; await fetchAdvertisements()
  } finally { saving.value = false }
}
async function toggleStatus(row) {
  await adminApi.updateAdvertisement(row.id, { ...row, status: row.status === 'active' ? 'inactive' : 'active' })
  ElMessage.success(row.status === 'active' ? '广告已下线' : '广告已上线'); await fetchAdvertisements()
}
async function removeAdvertisement(row) {
  await ElMessageBox.confirm(`确认删除广告“${row.title}”吗？`, '删除广告', { type: 'warning', confirmButtonClass: 'admin-action-btn admin-action-danger', cancelButtonClass: 'admin-action-btn' })
  await adminApi.deleteAdvertisement(row.id); ElMessage.success('广告已删除'); await fetchAdvertisements()
}
function positionLabel(value) { return ({ nav_top: '顶部导航栏', home_top: '首页推荐区', home_sidebar: '首页侧边', community_sidebar: '社区侧边', ai_sidebar: 'AI 侧边', player_pause: '播放器暂停层' })[value] || value }
function formatDate(value) { return value ? dayjs(value).format('YYYY-MM-DD HH:mm') : '-' }
onMounted(fetchAdvertisements)
</script>

<style scoped>
.ad-toolbar { display:flex; align-items:center; justify-content:space-between; gap:20px; margin-bottom:18px; }
.ad-toolbar h2 { margin:0 0 5px; font-size:20px; color:#252b3b; }
.ad-toolbar p { margin:0; color:#8b93a3; font-size:13px; }
.ad-table-wrap { overflow:hidden; border-radius:10px; background:#fff; box-shadow:0 1px 6px rgba(0,0,0,.05); }
.ad-thumb { width:120px; height:60px; border-radius:6px; background:#f3f4f7; }
.ad-title { display:flex; flex-direction:column; gap:5px; min-width:0; }
.ad-title strong,.ad-title small { overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
.ad-title small { color:#8b93a3; }
.ad-period { display:flex; flex-direction:column; gap:3px; font-size:12px; color:#606778; }
.ad-form-grid { display:grid; grid-template-columns:1fr 1fr; gap:16px; }
.ad-image-picker { width:100%; min-height:118px; padding:12px; border:1px solid #e2e5eb; border-radius:8px; box-sizing:border-box; }
.ad-image-picker-head { display:flex; align-items:center; justify-content:space-between; gap:12px; margin-bottom:10px; color:#8b93a3; font-size:12px; }
.ad-image-library { display:grid; grid-template-columns:repeat(4,minmax(0,1fr)); gap:9px; max-height:250px; overflow:auto; }
.ad-image-option { position:relative; aspect-ratio:1/1; overflow:hidden; padding:0; border:2px solid transparent; border-radius:7px; background:#f3f4f7; cursor:pointer; }
.ad-image-option.selected { border-color:#6c63ff; box-shadow:0 0 0 2px rgba(108,99,255,.18),0 5px 14px rgba(58,70,155,.18); }
.ad-image-option img { display:block; width:100%; height:100%; object-fit:cover; }
.ad-image-selected { position:absolute; right:6px; top:6px; display:grid; width:25px; height:25px; place-items:center; border:2px solid #fff; border-radius:9px; color:#fff; background:linear-gradient(135deg,#786dff 0%,#3b78ff 100%); box-shadow:0 3px 9px rgba(43,64,160,.42),inset 0 1px 0 rgba(255,255,255,.28); box-sizing:border-box; }
.ad-image-selected .el-icon { width:15px; height:15px; font-size:15px; font-weight:700; filter:drop-shadow(0 1px 1px rgba(0,0,0,.18)); }
@media(max-width:760px){.ad-toolbar{align-items:flex-start;flex-direction:column}.ad-form-grid{grid-template-columns:1fr}}
</style>
