<!--
  管理后台 · 独立布局
  结构: 左侧固定导航栏 + 右侧内容区域
-->
<template>
  <div class="admin-layout">
    <!-- ===== 左侧导航栏 ===== -->
    <aside class="admin-sidebar" :class="{ collapsed: sidebarCollapsed }">
      <!-- Logo 区域 -->
      <div class="sidebar-logo" @click="$router.push('/')">
        <span class="logo-icon">🐻</span>
        <span class="logo-text" v-show="!sidebarCollapsed">白熊管理后台</span>
      </div>

      <!-- 导航菜单 -->
      <nav class="sidebar-nav">
        <template v-for="item in menuItems" :key="item.path">
          <div v-if="item.children" class="nav-menu-group">
            <button
              type="button"
              class="nav-menu-item nav-menu-parent admin-plain-button"
              :class="{ active: isActive(item.path) }"
              @click="toggleMenu(item)"
            >
              <span class="menu-icon">{{ item.icon }}</span>
              <span class="menu-text" v-show="!sidebarCollapsed">{{ item.label }}</span>
              <span v-show="!sidebarCollapsed" class="menu-arrow" :class="{ expanded: isMenuOpen(item.path) }">›</span>
            </button>
            <div v-show="!sidebarCollapsed && isMenuOpen(item.path)" class="nav-submenu">
              <router-link
                v-for="child in item.children"
                :key="child.path"
                :to="child.path"
                class="nav-submenu-item"
                :class="{ active: route.path === child.path }"
              >
                {{ child.label }}
              </router-link>
            </div>
          </div>
          <router-link
            v-else
            :to="item.path"
            class="nav-menu-item"
            :class="{ active: isActive(item.path) }"
          >
            <span class="menu-icon">{{ item.icon }}</span>
            <span class="menu-text" v-show="!sidebarCollapsed">{{ item.label }}</span>
          </router-link>
        </template>
      </nav>

      <!-- 底部操作区 -->
      <div class="sidebar-footer">
        <button type="button" class="collapse-btn admin-plain-button" @click="sidebarCollapsed = !sidebarCollapsed" :title="sidebarCollapsed ? '展开菜单' : '收起菜单'">
          <span class="collapse-icon">{{ sidebarCollapsed ? '▶' : '◀' }}</span>
        </button>
        <div class="user-info" v-show="!sidebarCollapsed">
          <el-avatar :size="32" :src="userStore.avatar" />
          <span class="user-name">{{ userStore.username }}</span>
        </div>
        <el-button
          v-show="!sidebarCollapsed"
          class="admin-action-btn admin-sidebar-action back-home-btn"
          text
          size="small"
          @click="$router.push('/')"
        >
          返回前台
        </el-button>
      </div>
    </aside>

    <!-- ===== 右侧内容区域 ===== -->
    <main class="admin-main">
      <!-- 顶部面包屑 + 操作栏 -->
      <header class="admin-topbar">
        <div class="topbar-left">
          <h1 class="page-title">{{ currentTitle }}</h1>
        </div>
        <div class="topbar-right">
          <el-dropdown trigger="click" @command="handleCommand">
            <span class="admin-user-trigger">
              <el-avatar :size="28" :src="userStore.avatar" />
              <span>{{ userStore.username }}</span>
              <el-icon><ArrowDown /></el-icon>
            </span>
            <template #dropdown>
              <el-dropdown-menu>
                <el-dropdown-item command="profile">个人中心</el-dropdown-item>
                <el-dropdown-item command="home">返回前台</el-dropdown-item>
                <el-dropdown-item command="logout" divided>退出登录</el-dropdown-item>
              </el-dropdown-menu>
            </template>
          </el-dropdown>
        </div>
      </header>

      <!-- 内容区 -->
      <div class="admin-content">
        <router-view v-slot="{ Component }">
          <transition name="admin-fade" mode="out-in">
            <component :is="Component" />
          </transition>
        </router-view>
      </div>
    </main>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { useUserStore } from '@/stores/user'

const route = useRoute()
const router = useRouter()
const userStore = useUserStore()

// 侧边栏收起状态
const sidebarCollapsed = ref(false)

// 菜单项
const menuItems = [
  { path: '/admin/dashboard', icon: '📊', label: '仪表盘' },
  {
    path: '/admin/users', icon: '👥', label: '用户管理',
    children: [
      { path: '/admin/users/list', label: '用户数据' },
      { path: '/admin/users/creator-audit', label: '创作者审核' }
    ]
  },
  {
    path: '/admin/videos', icon: '🎬', label: '视频管理',
    children: [
      { path: '/admin/videos/audit', label: '动漫审核' },
      { path: '/admin/videos/list', label: '动漫视频' }
    ]
  },
  { path: '/admin/content',   icon: '📝', label: '社区管理' },
  { path: '/admin/announcements', icon: '📢', label: '公告管理' },
  { path: '/admin/ranking',   icon: '🏆', label: '排行榜管理' },
  { path: '/admin/advertisements', icon: '📣', label: '广告管理' },
  { path: '/admin/banner-effects', icon: '🖼️', label: '效果图管理' }
]

// 二级菜单默认收起，仅在管理员点击一级菜单时展开。
const openMenu = ref('')

function isMenuOpen(path) {
  return openMenu.value === path
}

function toggleMenu(item) {
  if (sidebarCollapsed.value) {
    router.push(item.children[0].path)
    return
  }
  openMenu.value = openMenu.value === item.path ? '' : item.path
}

// 当前激活菜单判断
function isActive(path) {
  return route.path === path || route.path.startsWith(path + '/')
}

// 当前页面标题
const currentTitle = computed(() => {
  if (route.meta.adminTitle) return route.meta.adminTitle
  const item = menuItems.find(m => isActive(m.path))
  return item ? item.label : '管理后台'
})

// 下拉菜单操作
function handleCommand(cmd) {
  switch (cmd) {
    case 'profile':
      router.push('/profile')
      break
    case 'home':
      router.push('/')
      break
    case 'logout':
      userStore.logout()
      router.push('/')
      break
  }
}
</script>

<style scoped>
/* ===== 整体布局 ===== */
.admin-layout {
  display: flex;
  height: 100vh;
  width: 100vw;
  overflow: hidden;
  background: #f0f2f5;
}

/* ===== 左侧导航栏 ===== */
.admin-sidebar {
  width: 240px;
  min-width: 240px;
  background: linear-gradient(180deg, #1a1a2e 0%, #16213e 100%);
  color: #ffffff;
  display: flex;
  flex-direction: column;
  transition: width 0.3s ease, min-width 0.3s ease;
  position: relative;
  z-index: 10;
  box-shadow: 2px 0 12px rgba(0, 0, 0, 0.15);
}
.admin-sidebar.collapsed {
  width: 64px;
  min-width: 64px;
}

/* Logo */
.sidebar-logo {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 20px 18px;
  border-bottom: 1px solid rgba(255, 255, 255, 0.08);
  cursor: pointer;
  transition: background 0.2s;
}
.sidebar-logo:hover {
  background: rgba(255, 255, 255, 0.05);
}
.logo-icon {
  font-size: 26px;
  flex-shrink: 0;
}
.logo-text {
  font-size: 15px;
  font-weight: 700;
  white-space: nowrap;
  overflow: hidden;
}

/* 导航菜单 */
.sidebar-nav {
  flex: 1;
  padding: 12px 0;
  overflow-y: auto;
  overflow-x: hidden;
}
.nav-menu-item {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 13px 20px;
  margin: 2px 12px;
  border-radius: 10px;
  color: rgba(255, 255, 255, 0.65);
  text-decoration: none;
  font-size: 14px;
  font-weight: 500;
  transition: all 0.25s ease;
  white-space: nowrap;
  overflow: hidden;
}
.nav-menu-item:hover {
  background: rgba(255, 255, 255, 0.08);
  color: #ffffff;
}
.nav-menu-item.active {
  background: linear-gradient(135deg, rgba(102, 126, 234, 0.35), rgba(118, 75, 162, 0.25));
  color: #ffffff;
  font-weight: 600;
  box-shadow: 0 2px 8px rgba(102, 126, 234, 0.2);
}
.menu-icon {
  font-size: 18px;
  flex-shrink: 0;
  width: 24px;
  text-align: center;
}
.menu-text {
  overflow: hidden;
  text-overflow: ellipsis;
}

/* 底部操作区 */
.sidebar-footer {
  padding: 12px;
  border-top: 1px solid rgba(255, 255, 255, 0.08);
  display: flex;
  flex-direction: column;
  gap: 8px;
  align-items: center;
}
.collapse-btn {
  padding: 4px 8px;
  cursor: pointer;
  align-self: stretch;
  text-align: center;
}
.nav-menu-parent {
  width: calc(100% - 24px);
  cursor: pointer;
  text-align: left;
}
.nav-menu-parent .menu-text {
  flex: 1;
}
.menu-arrow {
  margin-left: auto;
  font-size: 20px;
  line-height: 1;
  transition: transform 0.2s ease;
}
.menu-arrow.expanded {
  transform: rotate(90deg);
}
.nav-submenu {
  padding: 2px 12px 4px 48px;
}
.nav-submenu-item {
  display: block;
  position: relative;
  padding: 9px 12px;
  border-radius: 8px;
  color: rgba(255, 255, 255, 0.55);
  text-decoration: none;
  font-size: 13px;
  transition: color 0.2s ease, background 0.2s ease;
}
.nav-submenu-item::before {
  content: '';
  position: absolute;
  left: -13px;
  top: 50%;
  width: 5px;
  height: 5px;
  border-radius: 50%;
  background: rgba(255, 255, 255, 0.25);
  transform: translateY(-50%);
}
.nav-submenu-item:hover {
  color: #fff;
  background: rgba(255, 255, 255, 0.07);
}
.nav-submenu-item.active {
  color: #fff;
  background: rgba(102, 126, 234, 0.2);
  font-weight: 600;
}
.nav-submenu-item.active::before {
  background: #8fa3ff;
}
.collapse-icon {
  font-size: 12px;
  color: rgba(255, 255, 255, 0.5);
}
.user-info {
  display: flex;
  align-items: center;
  gap: 8px;
  width: 100%;
}
.user-name {
  font-size: 13px;
  color: rgba(255, 255, 255, 0.75);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.back-home-btn {
  color: rgba(255, 255, 255, 0.6) !important;
  width: 100%;
}

/* ===== 右侧主区域 ===== */
.admin-main {
  flex: 1;
  display: flex;
  flex-direction: column;
  overflow: hidden;
  min-width: 0;
}

/* 顶部操作栏 */
.admin-topbar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  height: 56px;
  padding: 0 24px;
  background: #ffffff;
  border-bottom: 1px solid #e8eaed;
  flex-shrink: 0;
}
.topbar-left {
  display: flex;
  align-items: center;
}
.page-title {
  font-size: 18px;
  font-weight: 700;
  color: #1a1a2e;
  margin: 0;
}
.topbar-right {
  display: flex;
  align-items: center;
}
.admin-user-trigger {
  display: flex;
  align-items: center;
  gap: 8px;
  cursor: pointer;
  padding: 4px 10px;
  border-radius: 20px;
  font-size: 13px;
  color: #555;
  transition: background 0.2s;
}
.admin-user-trigger:hover {
  background: #f5f7fa;
}

/* 内容区 */
.admin-content {
  flex: 1;
  overflow-y: auto;
  padding: 24px;
  background: #f0f2f5;
}

/* 页面过渡 */
.admin-fade-enter-active,
.admin-fade-leave-active {
  transition: opacity 0.15s ease;
}
.admin-fade-enter-from,
.admin-fade-leave-to {
  opacity: 0;
}

</style>

<style>
/* 后台全局操作按钮：与表格文字操作保持统一 */
.admin-action-btn.el-button {
  height: 32px !important;
  padding: 0 8px !important;
  border: 0 !important;
  border-radius: 0 !important;
  color: #3b78ff !important;
  background: transparent !important;
  background-image: none !important;
  box-shadow: none !important;
  font-size: 14px !important;
  font-weight: 400 !important;
  opacity: 1 !important;
  transition: none !important;
  transform: none !important;
}
.admin-action-btn.el-button:hover,
.admin-action-btn.el-button:focus,
.admin-action-btn.el-button:active {
  border: 0 !important;
  color: #3b78ff !important;
  background: transparent !important;
  box-shadow: none !important;
  opacity: 1 !important;
  transform: none !important;
}
.admin-action-btn.el-button + .admin-action-btn.el-button { margin-left: 16px !important; }
.admin-action-btn.admin-action-danger.el-button,
.admin-action-btn.admin-action-danger.el-button:hover,
.admin-action-btn.admin-action-danger.el-button:focus,
.admin-action-btn.admin-action-danger.el-button:active {
  color: #ff4d57 !important;
  background: transparent !important;
}
.admin-action-btn.admin-icon-action.el-button {
  width: 32px !important;
  padding: 0 !important;
  color: #8b93a3 !important;
}
.admin-action-btn.admin-sidebar-action.el-button,
.admin-action-btn.admin-sidebar-action.el-button:hover,
.admin-action-btn.admin-sidebar-action.el-button:focus,
.admin-action-btn.admin-sidebar-action.el-button:active {
  color: rgba(255, 255, 255, 0.72) !important;
  background: transparent !important;
}
.admin-action-btn.el-button.is-disabled,
.admin-action-btn.el-button.is-disabled:hover { opacity: 0.45 !important; }
.admin-plain-button {
  appearance: none;
  border: 0;
  border-radius: 0;
  background: transparent;
  box-shadow: none;
  transition: none;
  transform: none;
}
.admin-plain-button:hover,
.admin-plain-button:focus,
.admin-plain-button:active { border: 0; background: transparent; box-shadow: none; outline: none; }
</style>
