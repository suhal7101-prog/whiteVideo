<template>
  <div class="ca-page">
    <div class="ca-toolbar">
      <div class="ca-filters">
        <el-input
          v-model.trim="keyword"
          clearable
          placeholder="搜索用户名、昵称或邮箱"
          class="ca-search"
          @keyup.enter="handleSearch"
          @clear="handleSearch"
        />
        <el-select v-model="applyStatus" class="ca-status" @change="handleSearch">
          <el-option label="待审核" value="pending" />
          <el-option label="已通过" value="approved" />
          <el-option label="已拒绝" value="rejected" />
          <el-option label="全部申请" value="all" />
        </el-select>
        <el-button class="admin-action-btn" type="primary" :icon="Search" @click="handleSearch">搜索</el-button>
        <el-button class="admin-action-btn" :icon="Refresh" @click="fetchData">刷新</el-button>
      </div>
      <span class="ca-total">共 {{ total }} 条申请</span>
    </div>

    <div class="ca-table-wrap">
      <el-table
        :data="applications"
        stripe
        v-loading="loading"
        empty-text="当前没有需要处理的创作者申请"
        style="width: 100%"
      >
        <el-table-column prop="id" label="ID" width="70" />
        <el-table-column label="申请用户" min-width="170">
          <template #default="{ row }">
            <div class="ca-user">
              <el-avatar :size="38" :src="row.avatar">{{ row.username?.slice(0, 1)?.toUpperCase() }}</el-avatar>
              <div><strong>{{ row.nickname || row.username }}</strong><span>@{{ row.username }}</span></div>
            </div>
          </template>
        </el-table-column>
        <el-table-column prop="email" label="邮箱" min-width="200" show-overflow-tooltip />
        <el-table-column label="申请信息" min-width="240" show-overflow-tooltip>
          <template #default="{ row }">{{ row.creatorApplyMessage || '未填写申请信息' }}</template>
        </el-table-column>
        <el-table-column label="申请时间" width="170">
          <template #default="{ row }">{{ formatDate(row.creatorApplyTime) }}</template>
        </el-table-column>
        <el-table-column label="审核状态" width="100" align="center">
          <template #default="{ row }">
            <el-tag :type="statusType(row.creatorApplyStatus)" size="small">{{ statusLabel(row.creatorApplyStatus) }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column label="审核说明" min-width="150" show-overflow-tooltip>
          <template #default="{ row }">{{ row.creatorApplyReason || '-' }}</template>
        </el-table-column>
        <el-table-column label="操作" width="170" fixed="right" align="center">
          <template #default="{ row }">
            <el-button
              v-if="row.creatorApplyStatus !== 'approved'"
              class="admin-action-btn"
              text
              :loading="auditingId === row.id"
              @click="approve(row)"
            >通过</el-button>
            <el-button
              v-if="row.creatorApplyStatus !== 'rejected'"
              class="admin-action-btn admin-action-danger"
              text
              :loading="auditingId === row.id"
              @click="reject(row)"
            >拒绝</el-button>
          </template>
        </el-table-column>
      </el-table>

      <div class="ca-pagination">
        <el-pagination
          v-model:current-page="pageNum"
          v-model:page-size="pageSize"
          :page-sizes="[10, 20, 50]"
          :total="total"
          layout="total, sizes, prev, pager, next"
          @current-change="fetchData"
          @size-change="handleSizeChange"
        />
      </div>
    </div>
  </div>
</template>

<script setup>
import { onMounted, ref } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { Refresh, Search } from '@element-plus/icons-vue'
import dayjs from 'dayjs'
import { adminApi } from '@/api/modules/admin'

const applications = ref([])
const loading = ref(false)
const auditingId = ref(null)
const total = ref(0)
const pageNum = ref(1)
const pageSize = ref(10)
const keyword = ref('')
const applyStatus = ref('pending')

async function fetchData() {
  loading.value = true
  try {
    const res = await adminApi.getCreatorApplications({
      page: pageNum.value,
      size: pageSize.value,
      keyword: keyword.value || undefined,
      applyStatus: applyStatus.value
    })
    applications.value = res?.list || res?.records || []
    total.value = Number(res?.total || 0)
  } catch (error) {
    ElMessage.error('获取创作者申请失败：' + (error?.message || '未知错误'))
  } finally {
    loading.value = false
  }
}

function handleSearch() {
  pageNum.value = 1
  fetchData()
}

function handleSizeChange() {
  pageNum.value = 1
  fetchData()
}

async function approve(row) {
  try {
    await ElMessageBox.confirm(
      `确认通过「${row.nickname || row.username}」的创作者申请吗？通过后该用户角色将变更为创作者。`,
      '通过创作者申请',
      { confirmButtonText: '确认通过', cancelButtonText: '取消', type: 'success' }
    )
    await submitAudit(row, { status: 'approved', reason: '' })
  } catch (error) {
    if (error !== 'cancel' && error !== 'close') ElMessage.error('审核失败：' + (error?.message || '未知错误'))
  }
}

async function reject(row) {
  try {
    const { value } = await ElMessageBox.prompt(
      `请填写拒绝「${row.nickname || row.username}」申请的原因。`,
      '拒绝创作者申请',
      {
        confirmButtonText: '确认拒绝',
        cancelButtonText: '取消',
        inputType: 'textarea',
        inputPlaceholder: '例如：个人资料不完整，请补充创作方向后重新申请',
        inputValidator: value => value?.trim() ? true : '拒绝申请时必须填写原因',
        type: 'warning'
      }
    )
    await submitAudit(row, { status: 'rejected', reason: value.trim() })
  } catch (error) {
    if (error !== 'cancel' && error !== 'close') ElMessage.error('审核失败：' + (error?.message || '未知错误'))
  }
}

async function submitAudit(row, data) {
  auditingId.value = row.id
  try {
    await adminApi.auditCreatorApplication(row.id, data)
    ElMessage.success(data.status === 'approved' ? '审核通过，用户角色已变更为创作者' : '申请已拒绝')
    await fetchData()
  } finally {
    auditingId.value = null
  }
}

function statusLabel(status) {
  return ({ pending: '待审核', approved: '已通过', rejected: '已拒绝' })[status] || '待审核'
}

function statusType(status) {
  return ({ pending: 'warning', approved: 'success', rejected: 'danger' })[status] || 'warning'
}

function formatDate(value) {
  return value ? dayjs(value).format('YYYY-MM-DD HH:mm') : '-'
}

onMounted(fetchData)
</script>

<style scoped>
.ca-page { display: flex; flex-direction: column; gap: 16px; }
.ca-toolbar, .ca-table-wrap { background: #fff; border-radius: 12px; box-shadow: 0 2px 12px rgba(24, 39, 75, 0.05); }
.ca-toolbar { min-height: 68px; padding: 14px 18px; display: flex; align-items: center; justify-content: space-between; gap: 16px; }
.ca-filters { display: flex; align-items: center; flex-wrap: wrap; gap: 10px; }
.ca-search { width: 250px; }
.ca-status { width: 130px; }
.ca-total { color: #8b93a3; font-size: 13px; white-space: nowrap; }
.ca-table-wrap { overflow: hidden; padding-bottom: 14px; }
.ca-user { display: flex; align-items: center; gap: 10px; }
.ca-user strong, .ca-user span { display: block; }
.ca-user strong { color: #303442; font-size: 14px; }
.ca-user span { margin-top: 2px; color: #9299a8; font-size: 12px; }
.ca-pagination { display: flex; justify-content: flex-end; padding: 16px 18px 0; }
@media (max-width: 900px) {
  .ca-toolbar { align-items: flex-start; flex-direction: column; }
  .ca-search { width: 210px; }
}
</style>
