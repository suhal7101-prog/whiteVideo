<!--
  管理后台 · 视频管理
  对接后端 /api/admin/videos 系列接口
-->
<template>
  <div class="vm-page">
    <div class="vm-toolbar">
      <div class="vm-filters">
        <el-input
          v-model="keyword"
          placeholder="搜索视频名称..."
          clearable
          :prefix-icon="Search"
          style="width: 240px"
          @keyup.enter="fetchData"
          @clear="fetchData"
        />
        <el-select v-model="filterCategory" placeholder="分类/标签筛选" clearable style="width: 160px" @change="fetchData">
          <el-option label="全部分类/标签" value="" />
          <el-option label="热血" value="热血" />
          <el-option label="搞笑" value="搞笑" />
          <el-option label="奇幻" value="奇幻" />
          <el-option label="科幻" value="科幻" />
          <el-option label="恋爱" value="恋爱" />
        </el-select>
        <el-button class="admin-action-btn" type="primary" :icon="Search" @click="fetchData">搜索</el-button>
      </div>
      <el-button class="admin-action-btn" type="primary" :icon="Plus" @click="openCreate">新增视频</el-button>
    </div>

    <div class="vm-table-wrap">
      <el-table
        :data="videos"
        stripe
        v-loading="loading"
        empty-text="暂无符合当前筛选条件的视频"
        style="width:100%"
      >
        <el-table-column prop="id" label="ID" width="70" />
        <el-table-column label="封面" width="130">
          <template #default="{ row }">
            <el-image
              :src="row.cover"
              fit="cover"
              style="width:100px;height:56px;border-radius:6px"
              :preview-src-list="[row.cover]"
              :hide-on-click-modal="true"
            >
              <template #error>
                <div class="vm-img-placeholder">🎬</div>
              </template>
            </el-image>
          </template>
        </el-table-column>
        <el-table-column prop="title" label="标题" min-width="200" />
        <el-table-column prop="category" label="分类" width="90" align="center">
          <template #default="{ row }">
            <el-tag size="small">{{ row.category || '-' }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="tags" label="标签" min-width="170">
          <template #default="{ row }">
            <div class="vm-tags">
              <el-tag v-for="tag in tagList(row.tags)" :key="tag" size="small" type="warning">
                {{ tag }}
              </el-tag>
              <span v-if="!tagList(row.tags).length">-</span>
            </div>
          </template>
        </el-table-column>
        <el-table-column prop="status" label="状态" width="100" align="center">
          <template #default="{ row }">
            <el-tag
              :type="statusTagType(row.status)"
              size="small"
            >
              {{ statusLabel(row.status) }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="views" label="播放量" width="100" align="right">
          <template #default="{ row }">
            {{ formatNum(row.views || 0) }}
          </template>
        </el-table-column>
        <el-table-column prop="createTime" label="创建时间" width="170">
          <template #default="{ row }">
            {{ formatDate(row.createTime) }}
          </template>
        </el-table-column>
        <el-table-column label="操作" width="160" fixed="right" align="center">
          <template #default="{ row }">
            <el-button size="small" text class="admin-action-btn" @click="openEdit(row)">编辑</el-button>
            <el-button size="small" text class="admin-action-btn admin-action-danger" @click="handleDelete(row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>

    <!-- 分页 -->
    <div class="vm-pagination" v-if="total > 10">
      <el-pagination
        v-model:current-page="pageNum"
        v-model:page-size="pageSize"
        :page-sizes="[10, 20, 50]"
        :total="total"
        layout="total, sizes, prev, pager, next"
        background
        @size-change="fetchData"
        @current-change="fetchData"
      />
    </div>

    <!-- 新增/编辑弹窗 -->
    <el-dialog v-model="dialogVisible" :title="isEdit ? '编辑视频' : '新增视频'" width="600px" destroy-on-close>
      <el-form :model="form" label-width="80px" label-position="right">
        <el-form-item label="标题">
          <el-input v-model="form.title" placeholder="视频标题" maxlength="256" />
        </el-form-item>
        <el-form-item label="封面URL">
          <el-input v-model="form.cover" placeholder="https://..." />
        </el-form-item>
        <el-form-item label="分类">
          <el-input v-model="form.category" placeholder="如: 热血、搞笑" />
        </el-form-item>
        <el-form-item label="状态">
          <el-select v-model="form.status" style="width:100%">
            <el-option label="连载中" value="serializing" />
            <el-option label="已完结" value="finished" />
          </el-select>
        </el-form-item>
        <el-form-item label="简介">
          <el-input v-model="form.description" type="textarea" :rows="3" placeholder="视频简介" />
        </el-form-item>
        <el-form-item label="标签">
          <el-input v-model="form.tags" placeholder="用逗号分隔, 如: 热血,战斗,玄幻" />
        </el-form-item>
        <el-form-item label="年份">
          <el-input-number v-model="form.year" :min="2000" :max="2030" />
        </el-form-item>
        <el-form-item label="地区">
          <el-select v-model="form.region" style="width:100%">
            <el-option label="中国" value="中国" />
            <el-option label="日本" value="日本" />
            <el-option label="其它" value="其它" />
          </el-select>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button class="admin-action-btn" @click="dialogVisible = false">取消</el-button>
        <el-button class="admin-action-btn" type="primary" :loading="saving" @click="save">{{ isEdit ? '保存' : '新增' }}</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { Search, Plus } from '@element-plus/icons-vue'
import { adminApi } from '@/api/modules/admin'
import dayjs from 'dayjs'

const videos = ref([])
const loading = ref(false)
const total = ref(0)
const pageNum = ref(1)
const pageSize = ref(10)
const keyword = ref('')
const filterCategory = ref('')

async function fetchData() {
  loading.value = true
  try {
    const params = { page: pageNum.value, size: pageSize.value }
    if (keyword.value) params.keyword = keyword.value
    if (filterCategory.value) params.category = filterCategory.value
    const res = await adminApi.getVideos(params)
    videos.value = res.records || res.list || []
    total.value = res.total || 0
  } catch (e) {
    ElMessage.error('获取视频列表失败')
  } finally {
    loading.value = false
  }
}

// 新增/编辑
const dialogVisible = ref(false)
const isEdit = ref(false)
const saving = ref(false)
const form = reactive({
  id: null, title: '', cover: '', category: '',
  status: 'serializing', description: '', tags: '', year: 2026, region: '中国'
})

function openCreate() {
  isEdit.value = false
  Object.assign(form, {
    id: null, title: '', cover: '', category: '',
    status: 'serializing', description: '', tags: '', year: 2026, region: '中国'
  })
  dialogVisible.value = true
}

function openEdit(row) {
  isEdit.value = true
  Object.assign(form, {
    id: row.id, title: row.title || '', cover: row.cover || '',
    category: row.category || '', status: row.status || 'serializing',
    description: row.description || '', tags: row.tags || '',
    year: row.year || 2026, region: row.region || '中国'
  })
  dialogVisible.value = true
}

async function save() {
  saving.value = true
  try {
    const data = { ...form }
    delete data.id
    if (isEdit.value) {
      await adminApi.updateVideo(form.id, data)
      ElMessage.success('视频已更新')
    } else {
      await adminApi.createVideo(data)
      ElMessage.success('视频已新增')
    }
    dialogVisible.value = false
    fetchData()
  } catch (e) {
    ElMessage.error('操作失败: ' + (e?.message || '未知错误'))
  } finally {
    saving.value = false
  }
}

async function handleDelete(row) {
  try {
    await ElMessageBox.confirm(`确定删除视频「${row.title}」吗？`, '删除确认', {
      confirmButtonText: '确定删除',
      cancelButtonText: '取消',
      confirmButtonClass: 'admin-action-btn admin-action-danger',
      cancelButtonClass: 'admin-action-btn',
      type: 'warning'
    })
    await adminApi.deleteVideo(row.id)
    ElMessage.success(`视频「${row.title}」已删除`)
    fetchData()
  } catch (e) {
    if (e !== 'cancel' && e !== 'close') {
      ElMessage.error('删除失败: ' + (e?.message || '未知错误'))
    }
  }
}

function formatDate(d) {
  if (!d) return ''
  const date = dayjs(d)
  return date.isValid() ? date.format('YYYY-MM-DD HH:mm') : d
}

function tagList(tags) {
  if (!tags) return []
  return String(tags).split(',').map(tag => tag.trim()).filter(Boolean)
}

function statusLabel(status) {
  if (status === 'serializing' || status === '连载中') return '连载中'
  if (status === 'finished' || status === '已完结') return '已完结'
  return status || '-'
}

function statusTagType(status) {
  if (status === 'serializing' || status === '连载中') return 'success'
  if (status === 'finished' || status === '已完结') return 'info'
  return 'warning'
}

function formatNum(n) {
  if (n >= 10000) return (n / 10000).toFixed(1) + '万'
  if (n >= 1000) return (n / 1000).toFixed(1) + 'k'
  return String(n)
}

onMounted(() => fetchData())
</script>

<style scoped>
.vm-page { padding: 0; }
.vm-toolbar {
  display: flex; justify-content: space-between; align-items: center;
  margin-bottom: 16px; flex-wrap: wrap; gap: 12px;
}
.vm-filters { display: flex; align-items: center; gap: 12px; flex-wrap: wrap; }
.vm-table-wrap {
  background: #fff; border-radius: 10px;
  box-shadow: 0 1px 6px rgba(0,0,0,.05); overflow: hidden;
}
.vm-img-placeholder {
  width: 100px; height: 56px; display: flex; align-items: center;
  justify-content: center; background: #f0f2f5; border-radius: 6px;
  font-size: 24px;
}
.vm-pagination { display: flex; justify-content: flex-end; margin-top: 20px; }
.vm-tags { display: flex; flex-wrap: wrap; gap: 4px; }

</style>
