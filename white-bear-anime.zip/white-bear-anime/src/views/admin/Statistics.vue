<!--
  管理后台 · 数据统计
  对接 /api/admin/stats/* 系列接口
-->
<template>
  <div class="st-page">
    <!-- ===== 概览卡片 ===== -->
    <div class="st-cards">
      <div class="st-card" v-for="item in overviewCards" :key="item.label" :style="{ '--accent': item.color }">
        <div class="st-card-icon" :style="{ background: item.bg }">{{ item.icon }}</div>
        <div class="st-card-body">
          <span class="st-card-num">{{ item.value ?? '--' }}</span>
          <span class="st-card-label">{{ item.label }}</span>
        </div>
      </div>
    </div>

    <!-- ===== 图表区域 ===== -->
    <div class="st-charts">
      <div class="st-chart-box">
        <h3 class="st-chart-title">📈 播放趋势（近7天）</h3>
        <div class="st-chart-empty" v-if="!playData.length">
          <p>{{ playLoading ? '播放数据加载中...' : '近7天暂无播放记录' }}</p>
        </div>
        <div v-else class="st-bar-chart">
          <div class="st-bar-item" v-for="d in playData" :key="d.date">
            <span class="st-bar-num">{{ d.count }}</span>
            <div class="st-bar" :style="{ height: barHeight(d.count, playMax) + '%' }"></div>
            <span class="st-bar-date">{{ d.date }}</span>
          </div>
        </div>
      </div>

      <div class="st-chart-box">
        <h3 class="st-chart-title">👥 用户活跃度（近7天）</h3>
        <div class="st-chart-empty" v-if="!userData.length">
          <p>{{ userLoading ? '用户数据加载中...' : '近7天暂无活跃用户记录' }}</p>
        </div>
        <div v-else class="st-bar-chart">
          <div class="st-bar-item" v-for="d in userData" :key="d.date">
            <span class="st-bar-num">{{ d.count }}</span>
            <div class="st-bar active" :style="{ height: barHeight(d.count, userMax) + '%' }"></div>
            <span class="st-bar-date">{{ d.date }}</span>
          </div>
        </div>
      </div>
    </div>

    <!-- ===== 排行榜 ===== -->
    <div class="st-ranking">
      <h3 class="st-chart-title">🏆 热门视频排行 Top 20</h3>
      <el-table
        :data="rankingData"
        stripe
        v-loading="rankingLoading"
        empty-text="暂无热门视频排行数据"
        style="width: 100%; margin-top: 12px;"
        max-height="500"
      >
        <el-table-column label="排名" width="70" align="center">
          <template #default="{ $index }">
            <el-tag v-if="$index === 0" type="danger" size="small">🥇</el-tag>
            <el-tag v-else-if="$index === 1" type="warning" size="small">🥈</el-tag>
            <el-tag v-else-if="$index === 2" type="info" size="small">🥉</el-tag>
            <span v-else>{{ $index + 1 }}</span>
          </template>
        </el-table-column>
        <el-table-column prop="title" label="视频名称" min-width="240" />
        <el-table-column prop="playCount" label="播放量" width="120" align="center">
          <template #default="{ row }">
            {{ formatNum(row.playCount || row.views || 0) }}
          </template>
        </el-table-column>
        <el-table-column prop="category" label="分类" width="100" align="center">
          <template #default="{ row }">
            <el-tag size="small">{{ row.category || '-' }}</el-tag>
          </template>
        </el-table-column>
      </el-table>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import { adminApi } from '@/api/modules/admin'

// ===== 概览 =====
const overviewCards = reactive([
  { label: '总PV', value: 0, color: '#667eea', bg: 'rgba(102,126,234,0.12)', icon: '👁️' },
  { label: '总UV', value: 0, color: '#f59e0b', bg: 'rgba(245,158,11,0.12)', icon: '👤' },
  { label: '人均时长', value: '--', color: '#10b981', bg: 'rgba(16,185,129,0.12)', icon: '⏱️' },
  { label: '今日新增', value: 0, color: '#ef4444', bg: 'rgba(239,68,68,0.12)', icon: '🆕' }
])

// ===== 播放数据 =====
const playData = ref([])
const playMax = ref(0)
const playLoading = ref(true)

// ===== 用户活跃 =====
const userData = ref([])
const userMax = ref(0)
const userLoading = ref(true)

// ===== 排行榜 =====
const rankingData = ref([])
const rankingLoading = ref(true)

async function fetchStats() {
  try {
    // 概览
    const overview = await adminApi.getStatsOverview()
    if (overview) {
      overviewCards[0].value = formatNum(overview.totalPlays || overview.todayPlays || 0)
      overviewCards[1].value = formatNum(overview.totalUsers || 0)
      overviewCards[2].value = '--'
      overviewCards[3].value = overview.todayNewUsers || 0
    }
  } catch (e) {
    console.error('[Statistics] overview error:', e)
  }

  try {
    // 播放统计
    const playRes = await adminApi.getPlayStats({ period: 'week' })
    const playList = Array.isArray(playRes) ? playRes : (playRes?.data || playRes?.records || playRes?.list || [])
    playData.value = playList.map(d => ({ date: d.date, count: d.count || d.playCount || 0 }))
    playMax.value = Math.max(...playData.value.map(d => d.count), 1)
  } catch (e) {
    console.error('[Statistics] play stats error:', e)
  } finally {
    playLoading.value = false
  }

  try {
    // 用户活跃度
    const userRes = await adminApi.getUserStats({ period: 'week' })
    const activeList = Array.isArray(userRes) ? userRes : (userRes?.data || userRes?.records || userRes?.list || [])
    userData.value = activeList.map(d => ({
      date: d.date,
      count: d.count || d.activeUsers || d.active_users || 0
    }))
    userMax.value = Math.max(...userData.value.map(d => d.count), 1)
  } catch (e) {
    console.error('[Statistics] user stats error:', e)
  } finally {
    userLoading.value = false
  }

  try {
    // 排行榜
    const rankRes = await adminApi.getRankingStats({ period: 'week' })
    rankingData.value = Array.isArray(rankRes)
      ? rankRes
      : (rankRes?.ranking || rankRes?.records || rankRes?.list || [])
  } catch (e) {
    console.error('[Statistics] ranking error:', e)
  } finally {
    rankingLoading.value = false
  }
}

function barHeight(count, max) {
  if (!max || max === 0) return 0
  return Math.max((count / max) * 100, 4)
}

function formatNum(n) {
  if (n >= 10000) return (n / 10000).toFixed(1) + '万'
  if (n >= 1000) return (n / 1000).toFixed(1) + 'k'
  return String(n)
}

onMounted(() => {
  fetchStats()
})
</script>

<style scoped>
.st-page { padding: 0; }

/* 概览卡片 */
.st-cards {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 16px;
  margin-bottom: 24px;
}
.st-card {
  background: #fff;
  border-radius: 12px;
  padding: 18px 20px;
  display: flex;
  align-items: center;
  gap: 14px;
  box-shadow: 0 2px 8px rgba(0,0,0,.04);
  border-left: 4px solid var(--accent);
}
.st-card-icon {
  width: 46px;
  height: 46px;
  border-radius: 10px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 22px;
  flex-shrink: 0;
}
.st-card-body { display: flex; flex-direction: column; }
.st-card-num { font-size: 24px; font-weight: 800; color: var(--accent); }
.st-card-label { font-size: 13px; color: #999; margin-top: 2px; }

/* 图表区域 */
.st-charts {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 16px;
  margin-bottom: 24px;
}
.st-chart-box {
  background: #fff;
  border-radius: 12px;
  padding: 20px 24px;
  box-shadow: 0 2px 8px rgba(0,0,0,.04);
}
.st-chart-title {
  font-size: 15px;
  font-weight: 600;
  color: #333;
  margin-bottom: 16px;
}
.st-chart-empty {
  height: 200px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #ccc;
}

/* 柱状图 */
.st-bar-chart {
  display: flex;
  align-items: flex-end;
  justify-content: space-around;
  height: 220px;
  padding-bottom: 30px;
  position: relative;
}
.st-bar-item {
  display: flex;
  flex-direction: column;
  align-items: center;
  height: 100%;
  justify-content: flex-end;
}
.st-bar-num {
  font-size: 11px;
  color: #666;
  margin-bottom: 4px;
}
.st-bar {
  width: 36px;
  background: linear-gradient(180deg, #667eea, #764ba2);
  border-radius: 6px 6px 0 0;
  min-height: 4px;
  transition: height 0.4s ease;
}
.st-bar.active {
  background: linear-gradient(180deg, #f59e0b, #ef4444);
}
.st-bar-date {
  font-size: 11px;
  color: #999;
  margin-top: 8px;
  position: absolute;
  bottom: 0;
}

/* 排行榜 */
.st-ranking {
  background: #fff;
  border-radius: 12px;
  padding: 20px 24px;
  box-shadow: 0 2px 8px rgba(0,0,0,.04);
}

/* 响应式 */
@media (max-width: 1024px) {
  .st-cards { grid-template-columns: repeat(2, 1fr); }
  .st-charts { grid-template-columns: 1fr; }
}
@media (max-width: 600px) {
  .st-cards { grid-template-columns: 1fr; }
}
</style>
