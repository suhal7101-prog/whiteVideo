<!--
  个人中心页
  功能：查看/编辑个人资料、修改密码、观看历史、退出登录
  仅登录后可访问
-->
<template>
  <div class="pf-page">
    <!-- 顶部横幅 -->
    <ManagedDynamicBanner
      class="pf-banner"
      height="160px"
      storage-key="white_bear_last_profile_center_banner"
    >
      <div class="pf-banner-content">
        <el-avatar :size="80" :src="userStore.avatar" class="pf-avatar" />
        <div class="pf-banner-info">
          <h1>{{ userStore.userInfo?.nickname || userStore.username || '白熊粉丝' }}</h1>
          <p>{{ userStore.email || '未绑定邮箱' }}</p>
        </div>
      </div>
    </ManagedDynamicBanner>

    <div class="pf-body">
      <!-- 左侧菜单 -->
      <aside class="pf-sidebar">
        <el-menu :default-active="activeMenu" @select="handleMenu" class="pf-menu">
          <el-menu-item index="home">
            <el-icon><HomeFilled /></el-icon> 个人主页
          </el-menu-item>
          <el-menu-item index="profile">
            <el-icon><User /></el-icon> 个人资料
          </el-menu-item>
          <el-menu-item index="creator">
            <el-icon><Upload /></el-icon> 创作者申请
          </el-menu-item>
          <el-menu-item index="password">
            <el-icon><Lock /></el-icon> 修改密码
          </el-menu-item>
          <el-menu-item index="history">
            <el-icon><Clock /></el-icon> 观看历史
          </el-menu-item>
          <el-menu-item index="logout" class="pf-menu-logout">
            <el-icon><SwitchButton /></el-icon> 退出登录
          </el-menu-item>
        </el-menu>
      </aside>

      <!-- 右侧内容 -->
      <main class="pf-content">
        <!-- 个人资料编辑 -->
        <div class="pf-card" v-if="activeMenu === 'profile'">
          <h3>📝 个人资料</h3>
          <el-form :model="profileForm" label-width="90px">
            <el-form-item label="头像">
              <el-avatar :size="64" :src="profileForm.avatar" />
              <input ref="avatarInput" type="file" accept="image/*" style="display:none" @change="onAvatarChange" />
              <el-button size="small" round style="margin-left:12px" @click="triggerAvatar">选择图片</el-button>
              <span class="pf-avatar-hint" v-if="avatarFile">已选择：{{ avatarFile.name }}</span>
            </el-form-item>
            <el-form-item label="昵称">
              <el-input v-model="profileForm.name" placeholder="请输入昵称" maxlength="64" />
            </el-form-item>
            <el-form-item label="邮箱">
              <el-input v-model="profileForm.email" disabled />
            </el-form-item>
            <el-form-item label="个性签名">
              <el-input v-model="profileForm.bio" type="textarea" :rows="3" resize="none" placeholder="介绍一下自己吧~" />
            </el-form-item>
            <el-form-item>
              <el-button type="primary" round :loading="profileSaving" @click="saveProfile">保存修改</el-button>
              <el-button round @click="resetProfile">重置</el-button>
            </el-form-item>
          </el-form>
        </div>

        <!-- 创作者申请 -->
        <div class="pf-card" v-if="activeMenu === 'creator'">
          <div class="pf-creator-head">
            <span class="pf-creator-logo">
              <svg viewBox="0 0 24 24" aria-hidden="true">
                <path d="M5 18.5V20h14v-1.5M12 16V4m0 0L8 8m4-4 4 4" />
              </svg>
            </span>
            <div>
              <h3>创作者中心</h3>
              <p>成为创作者后，可通过顶部“投稿”入口提交动漫内容。</p>
            </div>
          </div>

          <div v-if="userStore.isAdmin" class="pf-creator-status success">
            <strong>管理员已拥有创作者权限</strong>
            <span>无需申请，您可以直接发布投稿内容。</span>
            <el-button type="primary" round @click="$router.push('/submit')">立即投稿</el-button>
          </div>

          <div v-else-if="userStore.isCreator" class="pf-creator-status success">
            <strong>创作者申请已成功</strong>
            <span>投稿入口已开启，提交内容后将由管理员审核。</span>
            <el-button type="primary" round @click="$router.push('/submit')">开始投稿</el-button>
          </div>

          <div v-else-if="userStore.userInfo?.creatorApplyStatus === 'pending'" class="pf-creator-status pending">
            <strong>创作者申请审核中</strong>
            <span>申请已经提交，请耐心等待管理员审核。审核通过后，您的角色将自动变更为创作者。</span>
            <div class="pf-creator-application"><b>申请信息</b>{{ userStore.userInfo?.creatorApplyMessage || '未填写' }}</div>
            <el-tag type="warning" effect="plain">待审核</el-tag>
          </div>

          <div v-else-if="userStore.userInfo?.creatorApplyStatus === 'rejected'" class="pf-creator-status rejected">
            <strong>创作者申请未通过</strong>
            <span>审核原因：{{ userStore.userInfo?.creatorApplyReason || '申请资料暂不符合要求' }}</span>
            <el-input
              v-model="creatorApplyMessage"
              type="textarea"
              :rows="4"
              maxlength="500"
              show-word-limit
              placeholder="请说明您的创作方向、相关经验及申请成为创作者的理由"
              class="pf-creator-message"
            />
            <el-button type="primary" round :loading="creatorApplying" @click="applyCreator">修改后重新申请</el-button>
          </div>

          <div v-else class="pf-creator-status">
            <strong>申请成为白熊创作者</strong>
            <span>请确保投稿内容信息真实、封面清晰，并遵守社区内容规范。</span>
            <ul>
              <li>可提交原创或获得授权的动漫内容</li>
              <li>投稿需要经过管理员审核后公开展示</li>
              <li>申请成功后，顶部导航栏会显示投稿入口</li>
            </ul>
            <el-input
              v-model="creatorApplyMessage"
              type="textarea"
              :rows="4"
              maxlength="500"
              show-word-limit
              placeholder="请说明您的创作方向、相关经验及申请成为创作者的理由"
              class="pf-creator-message"
            />
            <el-button type="primary" round :loading="creatorApplying" @click="applyCreator">
              申请成为创作者
            </el-button>
          </div>
        </div>

        <!-- 修改密码 -->
        <div class="pf-card" v-if="activeMenu === 'password'">
          <h3>🔒 修改密码</h3>
          <el-form :model="pwdForm" label-width="100px">
            <el-form-item label="当前密码">
              <el-input v-model="pwdForm.oldPwd" type="password" show-password placeholder="请输入当前密码" />
            </el-form-item>
            <el-form-item label="新密码">
              <el-input v-model="pwdForm.newPwd" type="password" show-password placeholder="请输入新密码" />
            </el-form-item>
            <el-form-item label="确认新密码">
              <el-input v-model="pwdForm.confirmPwd" type="password" show-password placeholder="请再次输入新密码" />
            </el-form-item>
            <el-form-item>
              <el-button type="primary" round :loading="passwordSaving" @click="savePassword">修改密码</el-button>
            </el-form-item>
          </el-form>
        </div>

        <!-- 观看历史 -->
        <div class="pf-card" v-if="activeMenu === 'history'">
          <div class="pf-card-header">
            <h3>⏱️ 观看历史</h3>
            <el-button v-if="watchHistory.length" size="small" round text type="danger" @click="clearHistory">清空历史</el-button>
          </div>
          <div class="pf-hist-list" v-if="watchHistory.length">
            <div v-for="h in watchHistory" :key="h.id" class="pf-hist-item" @click="$router.push(h.playUrl)">
              <div class="pf-hist-cover">
                <img :src="h.cover" :alt="h.title" />
                <span class="pf-hist-progress">{{ h.progress }}%</span>
              </div>
              <div class="pf-hist-info">
                <span class="pf-hist-title">{{ h.title }}</span>
                <span class="pf-hist-ep">{{ h.episode }}</span>
                <span class="pf-hist-time">{{ h.watchedAt }}</span>
              </div>
            </div>
          </div>
          <div v-else class="pf-empty">
            <span class="pf-empty-icon">📺</span>
            <p>还没有观看记录</p>
            <p class="pf-empty-hint">去<a href="/discover">发现好番</a>开始追剧吧~</p>
          </div>
        </div>
      </main>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted, onUnmounted } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import { ElMessage } from 'element-plus'
import { useUserStore } from '@/stores/user'
import { userApi } from '@/api/modules/user'
import request from '@/api/request'
import ManagedDynamicBanner from '@/components/common/ManagedDynamicBanner.vue'

const router = useRouter()
const route = useRoute()
const userStore = useUserStore()

const activeMenu = ref(route.query.tab === 'creator' ? 'creator' : 'profile')

function handleMenu(index) {
  if (index === 'home') {
    router.push(`/home/${encodeURIComponent(userStore.username)}`)
    return
  }
  if (index === 'logout') {
    userStore.logout()
    router.push('/')
    ElMessage.success('已退出登录')
    return
  }
  activeMenu.value = index
}

// ===== 头像上传 =====
const avatarInput = ref(null)
const avatarFile = ref(null)
let avatarPreviewUrl = ''

function triggerAvatar() {
  avatarInput.value?.click()
}

function onAvatarChange(e) {
  const file = e.target.files?.[0]
  if (!file) return
  if (!file.type.startsWith('image/')) {
    ElMessage.warning('请选择图片文件')
    return
  }
  if (file.size > 5 * 1024 * 1024) {
    ElMessage.warning('图片大小不能超过 5MB')
    return
  }
  avatarFile.value = file
  if (avatarPreviewUrl) URL.revokeObjectURL(avatarPreviewUrl)
  avatarPreviewUrl = URL.createObjectURL(file)
  profileForm.avatar = avatarPreviewUrl
}

// ===== 个人资料 =====
const profileForm = reactive({
  name: '',
  email: '',
  avatar: '',
  bio: '',
})

const profileSaving = ref(false)
const passwordSaving = ref(false)
const creatorApplying = ref(false)
const creatorApplyMessage = ref('')

async function applyCreator() {
  const message = creatorApplyMessage.value.trim()
  if (!message) {
    ElMessage.warning('请填写申请理由')
    return
  }
  creatorApplying.value = true
  try {
    const result = await userApi.applyCreator(message)
    userStore.updateInfo({
      role: result?.role || userStore.role,
      creatorApplyStatus: result?.status || 'pending',
      creatorApplyMessage: result?.applicationMessage || message,
      creatorApplyReason: result?.reason || null
    })
    ElMessage.success(result?.creator
      ? '您已经拥有创作者权限'
      : '创作者申请已提交，请等待管理员审核')
  } catch (error) {
    console.error('申请创作者失败:', error)
  } finally {
    creatorApplying.value = false
  }
}

onMounted(async () => {
  try {
    const profile = await userApi.getProfile()
    userStore.updateInfo(profile)
    applyProfile(profile)
  } catch {
    applyProfile(userStore.userInfo || {})
  }
})

function applyProfile(profile) {
  profileForm.name = profile.nickname || profile.username || '白熊粉丝'
  profileForm.email = profile.email || ''
  profileForm.avatar = profile.avatar || ''
  profileForm.bio = profile.bio || ''
  creatorApplyMessage.value = profile.creatorApplyMessage || ''
}

function resetProfile() {
  applyProfile(userStore.userInfo || {})
  avatarFile.value = null
  ElMessage.info('已重置')
}

async function saveProfile() {
  const nickname = profileForm.name.trim()
  if (!nickname) {
    ElMessage.warning('昵称不能为空')
    return
  }

  profileSaving.value = true
  try {
    let avatar = profileForm.avatar
    if (avatarFile.value) {
      const uploaded = await userApi.uploadAvatar(avatarFile.value)
      avatar = uploaded.url
    }
    await userApi.updateProfile({ nickname, avatar, bio: profileForm.bio.trim() })
    userStore.updateInfo({ nickname, avatar, bio: profileForm.bio.trim() })
    profileForm.avatar = avatar
    avatarFile.value = null
    ElMessage.success('个人资料已保存')
  } catch (error) {
    console.error('保存个人资料失败:', error)
  } finally {
    profileSaving.value = false
  }
}

// ===== 密码修改 =====
const pwdForm = reactive({ oldPwd: '', newPwd: '', confirmPwd: '' })

async function savePassword() {
  if (!pwdForm.oldPwd || !pwdForm.newPwd || !pwdForm.confirmPwd) {
    ElMessage.warning('请填写完整')
    return
  }
  if (pwdForm.newPwd !== pwdForm.confirmPwd) {
    ElMessage.error('两次输入的新密码不一致')
    return
  }
  if (pwdForm.newPwd.length < 6) {
    ElMessage.warning('密码长度不能少于6位')
    return
  }
  passwordSaving.value = true
  try {
    await userApi.changePassword({
      oldPassword: pwdForm.oldPwd,
      newPassword: pwdForm.newPwd
    })
    pwdForm.oldPwd = ''
    pwdForm.newPwd = ''
    pwdForm.confirmPwd = ''
    ElMessage.success('密码修改成功')
  } catch (error) {
    console.error('修改密码失败:', error)
  } finally {
    passwordSaving.value = false
  }
}

function fmtTime(ts) {
  if (!ts) return ''
  const d = new Date(ts), now = new Date(), diff = now - d
  if (diff < 60000) return '刚刚'
  if (diff < 3600000) return Math.floor(diff/60000)+'分钟前'
  if (diff < 86400000) return Math.floor(diff/3600000)+'小时前'
  return Math.floor(diff/86400000)+'天前'
}

// ===== 观看历史 (从后端API获取) =====
const watchHistory = ref([])

async function fetchHistory() {
  try {
    const res = await request.get('/user/history')
    const list = res?.list || (Array.isArray(res) ? res : [])
    watchHistory.value = list.map(h => ({
      id: h.animeId || h.id,
      title: h.title || '未知动漫',
      episode: h.episodeNum ? `第${h.episodeNum}话` : '',
      progress: h.duration > 0 ? Math.round(h.currentTime / h.duration * 100) : 0,
      cover: h.cover || 'https://picsum.photos/seed/wh/200/120',
      watchedAt: fmtTime(h.watchedAt || h.createTime),
      playUrl: h.playUrl || `/play/${h.animeId || h.id}?source=db`,
    }))
  } catch (e) {
    console.error('加载观看历史失败:', e)
  }
}

onMounted(() => { fetchHistory() })
onUnmounted(() => {
  if (avatarPreviewUrl) URL.revokeObjectURL(avatarPreviewUrl)
})

async function clearHistory() {
  await userApi.clearHistory()
  watchHistory.value = []
  ElMessage.success('观看历史已清空')
}
</script>

<style scoped>
.pf-page { min-height: 100vh; background: #f5f7fa; }

/* ===== 顶部横幅 ===== */
.pf-banner {
  background: #161625;
}
.pf-banner-content {
  width: 100%; max-width: 1000px; margin: 0 auto; padding: 0 20px;
  display: flex; align-items: center; gap: 20px;
}
.pf-avatar { border: 4px solid rgba(255,255,255,.72); box-shadow: 0 6px 22px rgba(0,0,0,.28); flex-shrink: 0; }
.pf-banner-info { padding: 10px 16px; border-radius: 12px; background: rgba(15,23,42,.32); backdrop-filter: blur(4px); text-shadow: 0 2px 8px rgba(0,0,0,.5); }
.pf-banner-info h1 { margin: 0; font-size: 22px; color: #fff; }
.pf-banner-info p { margin: 4px 0 0; font-size: 14px; color: rgba(255,255,255,.86); }

/* ===== 主体 ===== */
.pf-body {
  --pf-panel-height: 440px;
  max-width: 1000px; margin: 24px auto 60px; padding: 0 20px;
  display: flex; align-items: flex-start; gap: 20px;
}

/* 侧边栏 */
.pf-sidebar { width: 220px; height: var(--pf-panel-height); display: flex; flex-shrink: 0; }
.pf-menu {
  width: 100%; height: 100%; flex: 1;
  border-radius: 12px; overflow: hidden; border: none !important;
  box-shadow: 0 2px 8px rgba(0,0,0,.04);
}
.pf-menu :deep(.el-menu-item) { font-size: 14px; }
.pf-menu-logout { color: #f56c6c !important; }
.pf-menu-logout:hover { background: rgba(245,108,108,.08) !important; }

/* 内容区 */
.pf-content { height: var(--pf-panel-height); display: flex; flex: 1; min-width: 0; }
.pf-card {
  width: 100%; height: 100%; min-height: 0; overflow-y: auto; box-sizing: border-box;
  background: #fff; border-radius: 16px; padding: 24px;
  box-shadow: 0 2px 8px rgba(0,0,0,.04);
}
.pf-card h3 { margin: 0 0 20px; font-size: 18px; color: #1a1a2e; }
.pf-card-header {
  display: flex; justify-content: space-between; align-items: center;
  margin-bottom: 16px;
}
.pf-card-header h3 { margin: 0; }
.pf-avatar-hint { font-size: 12px; color: #999; margin-left: 8px; }

.pf-card :deep(.el-form-item) { margin-bottom: 18px; }

/* 创作者申请 */
.pf-creator-head { display: flex; align-items: center; gap: 16px; padding-bottom: 20px; border-bottom: 1px solid #eef0f5; }
.pf-creator-head h3 { margin: 0 0 5px; }
.pf-creator-head p { margin: 0; color: #8a91a2; font-size: 13px; }
.pf-creator-logo {
  width: 48px; height: 48px; display: inline-flex; align-items: center; justify-content: center;
  border-radius: 14px; color: #fff; background: linear-gradient(135deg, #667eea, #8065d9);
  box-shadow: 0 8px 20px rgba(102,126,234,.22);
}
.pf-creator-logo svg { width: 25px; height: 25px; fill: none; stroke: currentColor; stroke-width: 1.9; stroke-linecap: round; stroke-linejoin: round; }
.pf-creator-status { margin-top: 20px; padding: 22px; border: 1px solid #e1e5f2; border-radius: 14px; background: #f8f9fd; }
.pf-creator-status.success { border-color: #cfe8dc; background: #f3fbf7; }
.pf-creator-status.pending { border-color: #f3dca8; background: #fffbf1; }
.pf-creator-status.rejected { border-color: #f2c8cc; background: #fff7f7; }
.pf-creator-status strong { display: block; margin-bottom: 7px; color: #252b3a; font-size: 16px; }
.pf-creator-status > span { display: block; margin-bottom: 16px; color: #71798c; font-size: 13px; line-height: 1.7; }
.pf-creator-status ul { margin: 0 0 20px; padding-left: 19px; color: #697185; font-size: 13px; line-height: 2; }
.pf-creator-message { display: block; margin: 0 0 18px; }
.pf-creator-application { margin: 0 0 16px; padding: 12px 14px; border-radius: 10px; color: #676f81; background: rgba(255, 255, 255, 0.72); font-size: 13px; line-height: 1.65; white-space: pre-wrap; }
.pf-creator-application b { display: block; margin-bottom: 4px; color: #3e4554; }

/* 观看历史 */
.pf-hist-list { display: flex; flex-direction: column; gap: 8px; }
.pf-hist-item {
  display: flex; gap: 12px; align-items: center; padding: 10px;
  border-radius: 10px; cursor: pointer; transition: background .2s;
}
.pf-hist-item:hover { background: #f8f9fc; }
.pf-hist-cover {
  position: relative; width: 120px; aspect-ratio: 16/9;
  border-radius: 8px; overflow: hidden; flex-shrink: 0;
}
.pf-hist-cover img { width: 100%; height: 100%; object-fit: cover; }
.pf-hist-progress {
  position: absolute; bottom: 0; left: 0; right: 0;
  background: rgba(0,0,0,.6); color: #fff; font-size: 11px;
  text-align: center; padding: 2px 0;
}
.pf-hist-info { display: flex; flex-direction: column; gap: 2px; }
.pf-hist-title { font-size: 14px; font-weight: 600; color: #333; }
.pf-hist-ep { font-size: 12px; color: #667eea; }
.pf-hist-time { font-size: 12px; color: #bbb; }

.pf-empty { text-align: center; padding: 60px 0; color: #bbb; font-size: 14px; }
.pf-empty-icon { font-size: 48px; display: block; margin-bottom: 12px; }
.pf-empty p { margin: 4px 0; }
.pf-empty-hint { font-size: 13px; color: #bbb; }
.pf-empty-hint a { color: #667eea; text-decoration: none; }

@media (max-width: 768px) {
  .pf-body { flex-direction: column; }
  .pf-sidebar { width: 100%; height: auto; }
  .pf-content { height: auto; display: block; }
  .pf-card { height: auto; min-height: 0; overflow-y: visible; }
  .pf-banner-content { flex-direction: column; text-align: center; }
}
</style>
