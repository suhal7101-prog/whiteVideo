<!-- 404 未找到页面 -->
<template>
  <div class="not-found">
    <div class="nf-content">
      <span class="nf-icon">🐻</span>
      <h1>404</h1>
      <p>哎呀，这个页面走丢了...</p>
      <p class="nf-sub">也许它去二次元旅行了？</p>
      <el-button type="primary" round size="large" @click="$router.push('/')">
        🏠 返回首页
      </el-button>
    </div>
  </div>
</template>

<style scoped>
.not-found {
  display: flex; align-items: center; justify-content: center;
  min-height: 70vh; background: #f5f7fa;
}
.nf-content { text-align: center; }
.nf-icon { font-size: 80px; display: block; margin-bottom: 16px; }
.nf-content h1 {
  font-size: 72px; font-weight: 800;
  background: linear-gradient(135deg, #667eea, #764ba2);
  -webkit-background-clip: text; -webkit-text-fill-color: transparent;
  margin: 0 0 8px;
}
.nf-content p { font-size: 18px; color: #666; margin: 0 0 4px; }
.nf-sub { font-size: 14px !important; color: #aaa !important; margin-bottom: 24px !important; }
</style>
