<!--
  帖子详情页 —— 社区帖子内容 + 评论/回复
-->
<template>
  <div class="post-detail-page">
    <div class="post-detail-body">
      <!-- 返回按钮 -->
      <div class="back-row">
        <el-button text @click="$router.back()">← 返回社区</el-button>
      </div>

      <!-- 帖子主体 -->
      <div class="post-main-card">
        <div class="post-header">
          <UserAvatar :size="44" :src="post.authorAvatar" :name="post.author" :user-id="post.authorId" style="cursor:pointer" @click="openUser(post.author)" />
          <div class="post-author-info">
            <div class="post-author-line">
              <span class="post-author" style="cursor:pointer" @click="openUser(post.author)">{{ post.author }}</span>
              <span class="owner-badge">楼主</span>
            </div>
            <span class="post-time">{{ post.time }}</span>
          </div>
          <el-tag v-if="post.tag" size="small" effect="plain" round>{{ post.tag }}</el-tag>
        </div>

        <h1 class="post-title" v-if="post.title">{{ post.title }}</h1>
        <p class="post-content">{{ post.content }}</p>

        <!-- 图片 -->
        <div class="post-images" v-if="post.images && post.images.length">
          <img
            v-for="(img, i) in post.images.slice(0, 4)"
            :key="i"
            :src="img"
            class="post-img"
            :class="'img-count-' + Math.min(post.images.length, 4)"
          />
        </div>

        <!-- 互动 -->
        <div class="post-actions">
          <EngagementAction type="like" :count="post.likes" :active="hasLiked" clickable @click="onLikeClick" />
          <EngagementAction type="comment" :count="totalCommentCount" clickable @click="focusCommentComposer" />
          <EngagementAction type="share" label="分享" clickable @click="sharePost" />
          <span class="post-views">👁️ {{ post.views }}</span>
        </div>
      </div>

      <!-- 评论区 -->
      <div class="comments-section">
        <h3>💬 评论 ({{ totalCommentCount }})</h3>

        <!-- 发表评论 -->
        <div class="comment-input-row">
          <UserAvatar :size="36" :src="userStore.avatar" :name="userStore.username" :user-id="userStore.userInfo?.id" />
          <div class="comment-composer">
            <div class="comment-input-wrap">
              <div class="reply-indicator" v-if="replyTarget">
                正在回复 <strong>@{{ replyTarget.user }}</strong>
                <span class="cancel-reply" @click="cancelReply">✕ 取消</span>
              </div>
              <el-input
                ref="commentInputRef"
                v-model="newComment"
                type="textarea"
                :rows="2"
                placeholder="写下你的评论... ✨"
                resize="none"
                @keydown.enter.exact.prevent="submitComment"
              />
            </div>

            <div v-if="commentImageItems.length" class="comment-preview-grid">
              <div v-for="(item, i) in commentImageItems" :key="item.preview" class="comment-preview-item">
                <img :src="item.preview" :alt="`待发布图片 ${i + 1}`" />
                <button
                  type="button"
                  class="comment-image-remove"
                  :aria-label="`删除第 ${i + 1} 张图片`"
                  @click="removeCommentImage(i)"
                >
                  <svg viewBox="0 0 24 24" aria-hidden="true">
                    <path d="M7 7l10 10M17 7L7 17" />
                  </svg>
                </button>
              </div>
            </div>

            <input
              ref="commentFileInput"
              type="file"
              accept="image/*"
              multiple
              class="visually-hidden"
              @change="onCommentFileSelected"
            />
            <div class="comment-compose-actions">
              <button
                type="button"
                class="comment-image-btn"
                :disabled="commentImageItems.length >= 9"
                @click="triggerCommentUpload"
              >
                <svg viewBox="0 0 24 24" aria-hidden="true">
                  <rect x="3" y="5" width="18" height="14" rx="2" />
                  <circle cx="8.5" cy="10" r="1.5" />
                  <path d="M5 17l4.5-4 3.2 2.8 2.5-2.2L19 17" />
                </svg>
                <span>{{ commentImageItems.length >= 9 ? '图片已满' : '添加图片' }}</span>
              </button>
              <span class="comment-image-count">{{ commentImageItems.length }} / 9</span>
              <el-button
                type="primary"
                round
                size="small"
                :loading="submittingComment"
                :disabled="submittingComment || (!newComment.trim() && !commentImageItems.length)"
                @click="submitComment"
              >发表</el-button>
            </div>
          </div>
        </div>

        <!-- 评论列表 -->
        <div class="comment-list">
          <div v-for="cmt in visibleComments" :key="cmt.id" class="comment-item">
            <UserAvatar :size="40" :src="cmt.avatar" :name="cmt.user" :user-id="cmt.userId" style="cursor:pointer" @click="openUser(cmt.user)" />
            <div class="comment-main">
              <div class="comment-row1">
                <span class="comment-name" style="cursor:pointer" @click="openUser(cmt.user)">{{ cmt.user }}</span>
                <span v-if="cmt.isAuthor" class="owner-badge owner-badge--comment">楼主</span>
                <span class="comment-time">{{ cmt.time }}</span>
              </div>
              <p v-if="cmt.content" class="comment-text">{{ cmt.content }}</p>
              <div v-if="cmt.images.length" class="comment-image-section">
                <div class="comment-images">
                  <el-image
                    v-for="(img, i) in visibleCommentImages(cmt)"
                    :key="`${cmt.id}-${img}`"
                    :src="img"
                    :preview-src-list="cmt.images"
                    :initial-index="i"
                    fit="cover"
                    class="comment-image"
                    preview-teleported
                  />
                </div>
                <button
                  v-if="cmt.images.length > 3"
                  type="button"
                  class="comment-images-toggle"
                  @click="toggleCommentImages(cmt.id)"
                >
                  {{ isCommentImagesExpanded(cmt.id) ? '收起图片' : `展开其余 ${cmt.images.length - 3} 张图片` }}
                </button>
              </div>
              <div class="comment-actions">
                <EngagementAction type="like" :count="cmt.likes" :active="cmt.liked" clickable @click="likeComment(cmt)" />
                <EngagementAction type="comment" label="回复" clickable @click="replyTo(cmt)" />
              </div>

              <!-- 回复的子评论 -->
              <div class="replies" v-if="cmt.replies && cmt.replies.length">
                <div v-for="reply in cmt.replies" :key="reply.id" class="reply-item">
                  <div class="reply-line">
                    <span class="reply-user">{{ reply.user }}</span>
                    <span v-if="reply.isAuthor" class="owner-badge owner-badge--reply">楼主</span>
                    <span v-if="reply.replyTo" class="reply-to"> 回复 @{{ reply.replyTo }}</span>
                    <span v-if="reply.content">：{{ reply.content }}</span>
                  </div>
                  <div v-if="reply.images.length" class="comment-image-section comment-image-section--reply">
                    <div class="comment-images comment-images--reply">
                      <el-image
                        v-for="(img, i) in visibleCommentImages(reply)"
                        :key="`${reply.id}-${img}`"
                        :src="img"
                        :preview-src-list="reply.images"
                        :initial-index="i"
                        fit="cover"
                        class="comment-image comment-image--reply"
                        preview-teleported
                      />
                    </div>
                    <button
                      v-if="reply.images.length > 3"
                      type="button"
                      class="comment-images-toggle"
                      @click="toggleCommentImages(reply.id)"
                    >
                      {{ isCommentImagesExpanded(reply.id) ? '收起图片' : `展开其余 ${reply.images.length - 3} 张图片` }}
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div ref="commentLoadSentinel" class="comment-lazy-status">
            <span v-if="hasMoreComments">向下滑动，加载更多评论</span>
            <span v-else-if="comments.length > 5">全部评论已加载</span>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted, onBeforeUnmount, watch } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import { ElMessage } from 'element-plus'
import { useAuth } from '@/composables/useAuth'
import { useUserStore } from '@/stores/user'
import { communityApi } from '@/api/modules/community'
import UserAvatar from '@/components/common/UserAvatar.vue'
import EngagementAction from '@/components/common/EngagementAction.vue'

const router = useRouter()
const route = useRoute()
const { requireAuth } = useAuth()
const userStore = useUserStore()

const hasLiked = ref(false)
const newComment = ref('')
const replyTarget = ref(null)
const commentInputRef = ref(null)
const commentFileInput = ref(null)
const commentImageItems = ref([])
const submittingComment = ref(false)
const expandedCommentImages = ref(new Set())
const totalCommentCount = ref(0)

import request from '@/api/request'

function fmtTime(ts) {
  if (!ts) return ''
  const d = new Date(ts), now = new Date(), diff = now - d
  if (diff < 60000) return '刚刚'
  if (diff < 3600000) return Math.floor(diff/60000)+'分钟前'
  if (diff < 86400000) return Math.floor(diff/3600000)+'小时前'
  return Math.floor(diff/86400000)+'天前'
}

const post = ref({ id: 0, authorId: 0, title: '', content: '', author: '', authorAvatar: '', time: '', tag: '', likes: 0, images: [] })
const comments = ref([])
const commentLoadSentinel = ref(null)
const visibleCommentCount = ref(5)
const visibleComments = computed(() => comments.value.slice(0, visibleCommentCount.value))
const hasMoreComments = computed(() => visibleCommentCount.value < comments.value.length)
let commentLoadObserver = null

function normalizeImages(value) {
  if (Array.isArray(value)) return value.filter(Boolean)
  if (typeof value !== 'string' || !value.trim()) return []
  try {
    const parsed = JSON.parse(value)
    return Array.isArray(parsed) ? parsed.filter(Boolean) : []
  } catch {
    return []
  }
}

async function fetchPost() {
  const id = route.params.id
  try {
    const res = await request.get(`/community/post/${id}`)
    const p = res || {}
    post.value = {
      ...p,
      author: p.author || p.username || '匿名',
      authorAvatar: p.authorAvatar || '',
      time: fmtTime(p.createTime || p.time),
      images: normalizeImages(p.images),
    }
    hasLiked.value = p.liked === true
    const rawComments = Array.isArray(p.commentList) ? p.commentList : []
    totalCommentCount.value = rawComments.length
    const mappedComments = rawComments.map((comment, index) => ({
      id: comment.id,
      userId: Number(comment.userId || 0),
      user: comment.username || '匿名',
      avatar: comment.avatar || '',
      content: comment.content,
      time: fmtTime(comment.createTime),
      likes: comment.likes || 0,
      liked: comment.liked === true,
      parentId: comment.parentId,
      isAuthor: comment.isAuthor === true || Number(comment.userId || 0) === Number(p.authorId || 0),
      images: normalizeImages(comment.images),
      replies: []
    }))
    const commentById = new Map(mappedComments.map(comment => [Number(comment.id), comment]))
    comments.value = mappedComments.filter(comment => {
      const parent = commentById.get(Number(comment.parentId))
      if (!parent) return true
      parent.replies.push({ ...comment, replyTo: parent.user })
      return false
    })
    visibleCommentCount.value = 5
  } catch (e) { console.error('加载帖子失败:', e) }
}
onMounted(fetchPost)
watch(() => route.params.id, (nextId, previousId) => {
  if (nextId !== previousId) fetchPost()
})

onMounted(() => {
  commentLoadObserver = new IntersectionObserver(entries => {
    if (entries.some(entry => entry.isIntersecting) && hasMoreComments.value) {
      visibleCommentCount.value += 5
    }
  }, { rootMargin: '160px 0px' })
  if (commentLoadSentinel.value) commentLoadObserver.observe(commentLoadSentinel.value)
})

onBeforeUnmount(() => commentLoadObserver?.disconnect())

async function onLikeClick() {
  if (!requireAuth()) return
  try {
    const wasLiked = hasLiked.value
    const state = await request.post('/community/like', { targetId: post.value.id, type: 'post' })
    const isLiked = state?.liked === true
    hasLiked.value = isLiked
    if (isLiked !== wasLiked) {
      post.value.likes = Math.max(0, Number(post.value.likes || 0) + (isLiked ? 1 : -1))
    }
  } catch {}
}

function focusCommentComposer() {
  commentInputRef.value?.focus()
  commentInputRef.value?.$el?.scrollIntoView({ behavior: 'smooth', block: 'center' })
}

async function submitComment() {
  if (!requireAuth()) return
  if (!newComment.value.trim() && !commentImageItems.value.length) return
  const content = newComment.value.trim()

  submittingComment.value = true
  try {
    const images = []
    for (const item of commentImageItems.value) {
      const uploaded = await communityApi.uploadImage(item.file)
      images.push(uploaded.url)
    }
    await communityApi.addComment({
      postId: post.value.id,
      parentId: replyTarget.value?.id || null,
      content: replyTarget.value
        ? content.replace(`@${replyTarget.value.user}`, '').trim()
        : content,
      images
    })
    newComment.value = ''
    replyTarget.value = null
    clearCommentImages()
    await fetchPost()
    ElMessage.success('评论发表成功！')
  } catch (error) {
    console.error('评论发表失败:', error)
    ElMessage.error('评论发表失败，请稍后重试')
  } finally {
    submittingComment.value = false
  }
}

function triggerCommentUpload() {
  if (!requireAuth()) return
  commentFileInput.value?.click()
}

function onCommentFileSelected(event) {
  const files = Array.from(event.target.files || [])
  if (commentImageItems.value.length + files.length > 9) {
    ElMessage.warning('评论最多上传 9 张图片')
    event.target.value = ''
    return
  }
  files.forEach(file => {
    if (!file.type.startsWith('image/')) {
      ElMessage.warning('仅支持图片文件')
      return
    }
    if (file.size > 10 * 1024 * 1024) {
      ElMessage.warning('单张图片不能超过 10MB')
      return
    }
    commentImageItems.value.push({ file, preview: URL.createObjectURL(file) })
  })
  event.target.value = ''
}

function removeCommentImage(index) {
  const [removed] = commentImageItems.value.splice(index, 1)
  if (removed?.preview) URL.revokeObjectURL(removed.preview)
}

function clearCommentImages() {
  commentImageItems.value.forEach(item => URL.revokeObjectURL(item.preview))
  commentImageItems.value = []
}

function cancelReply() {
  replyTarget.value = null
  newComment.value = ''
}

function isCommentImagesExpanded(commentId) {
  return expandedCommentImages.value.has(Number(commentId))
}

function toggleCommentImages(commentId) {
  const next = new Set(expandedCommentImages.value)
  const id = Number(commentId)
  if (next.has(id)) next.delete(id)
  else next.add(id)
  expandedCommentImages.value = next
}

function visibleCommentImages(comment) {
  return isCommentImagesExpanded(comment.id) ? comment.images : comment.images.slice(0, 3)
}

onBeforeUnmount(clearCommentImages)

function replyTo(cmt) {
  replyTarget.value = cmt
  newComment.value = `@${cmt.user} `
  // 延迟聚焦，等 DOM 渲染完
  setTimeout(() => {
    const el = commentInputRef.value?.$el?.querySelector('textarea')
    if (el) { el.focus(); el.setSelectionRange(el.value.length, el.value.length) }
  }, 100)
}

async function likeComment(cmt) {
  if (!requireAuth()) return
  try {
    const wasLiked = cmt.liked === true
    const state = await communityApi.toggleLike(cmt.id, 'comment')
    const isLiked = state?.liked === true
    cmt.liked = isLiked
    if (isLiked !== wasLiked) {
      cmt.likes = Math.max(0, Number(cmt.likes || 0) + (isLiked ? 1 : -1))
    }
  } catch (error) {
    console.error('评论点赞失败:', error)
  }
}

async function sharePost() {
  if (!requireAuth()) return
  try {
    await communityApi.share(post.value.id)
    await navigator.clipboard.writeText(window.location.href)
    ElMessage.success('链接已复制到剪贴板 📋')
  } catch {
    ElMessage.info('分享链接: ' + window.location.href)
  }
}

function openUser(name) {
  router.push(`/home/${encodeURIComponent(name)}`)
}
</script>

<style scoped>
.post-detail-page { min-height: 100vh; background: #f5f7fa; }
.post-detail-body { max-width: 800px; margin: 0 auto; padding: 20px; }

.back-row { margin-bottom: 16px; }

.post-main-card {
  background: #fff; border-radius: 16px; padding: 20px;
  margin-bottom: 16px; box-shadow: 0 2px 8px rgba(0,0,0,0.04);
}

.post-header { display: flex; align-items: center; gap: 12px; margin-bottom: 14px; }
.post-author-info { flex: 1; }
.post-author-line { display: flex; align-items: center; gap: 7px; }
.post-author { font-size: 15px; font-weight: 600; color: #333; }
.post-time { font-size: 12px; color: #bbb; }
.owner-badge {
  display: inline-flex;
  align-items: center;
  height: 20px;
  padding: 0 7px;
  border-radius: 5px;
  color: #fff;
  background: #667eea;
  font-size: 11px;
  font-weight: 600;
  line-height: 1;
}
.owner-badge--comment { height: 18px; padding: 0 6px; }
.owner-badge--reply { height: 16px; margin: 0 3px; padding: 0 5px; font-size: 10px; }

.post-title { font-size: 17px; font-weight: 700; color: #1a1a2e; margin: 0 0 8px; }
.post-content { font-size: 14px; line-height: 1.7; color: #555; white-space: pre-wrap; margin: 0 0 14px; }

.post-images { display: flex; max-width: 520px; gap: 6px; margin: 10px 0 14px; border-radius: 8px; overflow: hidden; }
.post-img { object-fit: cover; border-radius: 6px; }
.post-img.img-count-1 { width: min(100%, 420px); max-height: 240px; }
.post-img.img-count-2 { width: calc(50% - 3px); height: 160px; }
.post-img.img-count-3 { width: calc(33.3% - 4px); height: 130px; }
.post-img.img-count-4 { width: calc(25% - 5px); height: 110px; }

.post-actions {
  display: flex; align-items: center; gap: 24px; font-size: 14px; color: #999;
  padding-top: 12px; border-top: 1px solid #f5f5f5;
}
.post-views { margin-left: auto; }

/* 评论区 */
.comments-section {
  background: #fff; border-radius: 16px; padding: 24px;
  box-shadow: 0 2px 8px rgba(0,0,0,0.04);
}
.comments-section h3 { margin: 0 0 18px; font-size: 18px; }

.comment-input-row {
  display: flex; gap: 12px; align-items: flex-start; margin-bottom: 24px;
}
.comment-composer { flex: 1; min-width: 0; }
.comment-input-wrap { flex: 1; }
.reply-indicator {
  font-size: 13px; color: #666; margin-bottom: 6px;
  padding: 4px 10px; background: #f0efff; border-radius: 6px;
  display: flex; align-items: center; justify-content: space-between;
}
.cancel-reply { color: #999; cursor: pointer; font-size: 12px; }
.cancel-reply:hover { color: #e74c3c; }
.comment-input-wrap :deep(.el-textarea__inner) { border-radius: 10px; }
.comment-compose-actions {
  display: flex; align-items: center; gap: 8px; margin-top: 10px;
}
.comment-compose-actions .el-button:last-child { margin-left: auto; }
.comment-image-btn {
  height: 32px; padding: 0 12px;
  display: inline-flex; align-items: center; gap: 7px;
  color: #5968d9; background: #f7f8ff;
  border: 1px solid #d8ddfb; border-radius: 8px;
  font-size: 13px; cursor: pointer;
  transition: none; transform: none; animation: none;
}
.comment-image-btn svg {
  width: 16px; height: 16px; fill: none; stroke: currentColor; stroke-width: 1.8;
  stroke-linecap: round; stroke-linejoin: round;
}
.comment-image-btn:hover { color: #4f5fc9; background: #f0f2ff; border-color: #bcc5f5; }
.comment-image-btn:disabled { color: #a8adbc; background: #f5f6f8; border-color: #e2e5eb; cursor: not-allowed; }
.comment-image-count { color: #9aa0af; font-size: 12px; font-variant-numeric: tabular-nums; }
.visually-hidden {
  position: absolute; width: 1px; height: 1px; padding: 0; margin: -1px;
  overflow: hidden; clip: rect(0, 0, 0, 0); white-space: nowrap; border: 0;
}
.comment-preview-grid { display: flex; flex-wrap: wrap; gap: 9px; margin-top: 10px; }
.comment-preview-item { position: relative; width: 76px; height: 76px; }
.comment-preview-item img {
  width: 100%; height: 100%; object-fit: cover; border-radius: 9px; border: 1px solid #edf0f7;
}
.comment-image-remove {
  position: absolute; top: 6px; right: 6px;
  width: 22px; height: 22px; padding: 0;
  display: grid; place-items: center;
  color: #fff; background: rgba(20,26,38,.76);
  border: 0; border-radius: 6px;
  cursor: pointer; box-shadow: 0 2px 8px rgba(15,23,42,.22);
  transition: none; transform: none; animation: none;
}
.comment-image-remove svg { width: 13px; height: 13px; fill: none; stroke: currentColor; stroke-width: 2.4; stroke-linecap: round; }
.comment-image-remove:hover { color: #fff; background: #e5484d; }
.comment-image-remove:active { background: #cf3f44; }
.comment-image-remove:focus-visible { outline: 2px solid #667eea; outline-offset: 2px; }
.comment-compose-actions .el-button--primary,
.comment-compose-actions .el-button--primary:hover,
.comment-compose-actions .el-button--primary:focus,
.comment-compose-actions .el-button--primary:active {
  transition: none !important; transform: none !important; animation: none !important;
  box-shadow: none !important;
}

.comment-item {
  display: flex; gap: 14px; padding: 16px 0; border-bottom: 1px solid #f5f5f5;
}
.comment-item:last-child { border-bottom: none; }
.comment-main { flex: 1; }
.comment-row1 { display: flex; align-items: center; gap: 8px; margin-bottom: 6px; }
.comment-name { font-size: 14px; font-weight: 600; color: #333; }
.comment-time { font-size: 12px; color: #bbb; }
.comment-text { font-size: 14px; line-height: 1.7; color: #555; margin: 0 0 8px; }
.comment-image-section { margin: 8px 0 10px; }
.comment-images {
  display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 7px; max-width: 360px;
}
.comment-image {
  width: 100%; aspect-ratio: 1; border-radius: 9px; overflow: hidden; cursor: zoom-in;
  background: #f3f5f8;
}
.comment-images-toggle {
  margin-top: 8px; padding: 0; border: 0; color: #667eea; background: transparent;
  font-size: 12px; cursor: pointer;
}
.comment-images-toggle:hover { color: #4f61d7; }
.comment-images-toggle:focus-visible { outline: 2px solid #667eea; outline-offset: 3px; border-radius: 2px; }
.comment-actions { display: flex; align-items: center; gap: 16px; font-size: 13px; color: #999; }

.replies {
  margin-top: 10px; padding: 10px 14px;
  background: #fafbfc; border-radius: 10px;
}
.reply-item { font-size: 13px; line-height: 1.6; color: #666; margin-bottom: 4px; }
.reply-item + .reply-item { margin-top: 10px; }
.reply-line { display: flex; align-items: center; flex-wrap: wrap; }
.reply-user { color: #667eea; font-weight: 500; }
.reply-to { color: #aaa; }
.comment-image-section--reply { margin-bottom: 4px; }
.comment-images--reply { max-width: 300px; gap: 6px; }
.comment-image--reply { border-radius: 7px; }
.comment-lazy-status {
  min-height: 42px; display: flex; align-items: center; justify-content: center;
  color: #9aa0af; font-size: 13px;
}

@media (max-width: 768px) {
  .post-detail-body { padding: 12px; }
  .post-title { font-size: 18px; }
  .comments-section { padding: 18px 14px; }
  .comment-input-row { gap: 8px; }
  .comment-images { gap: 6px; }
  .comment-item { gap: 9px; }
}
</style>
