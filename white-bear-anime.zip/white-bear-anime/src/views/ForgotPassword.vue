<template>
  <main class="recovery-page">
    <section class="recovery-panel">
      <RouterLink to="/login" class="back-link">返回登录</RouterLink>
      <h1>找回密码</h1>
      <form @submit.prevent="submit">
        <label for="recovery-email">邮箱</label>
        <input id="recovery-email" v-model.trim="email" type="email" autocomplete="email" required />
        <button type="submit" :disabled="loading">{{ loading ? '发送中...' : '发送重置链接' }}</button>
      </form>
      <p v-if="sent" class="success-message">{{ sent }}</p>
    </section>
  </main>
</template>

<script setup>
import { ref } from 'vue'
import { userApi } from '@/api/modules/user'

const email = ref('')
const loading = ref(false)
const sent = ref('')

async function submit() {
  if (!email.value || loading.value) return
  loading.value = true
  sent.value = ''
  try {
    await userApi.forgotPassword(email.value)
    sent.value = '如果该邮箱已注册，重置链接将在几分钟内送达。'
  } finally {
    loading.value = false
  }
}
</script>

<style scoped>
.recovery-page { min-height: calc(100vh - 64px); display: grid; place-items: center; padding: 24px; background: #f4f6f8; }
.recovery-panel { width: min(420px, 100%); padding: 32px; background: #fff; border: 1px solid #e1e5e9; border-radius: 8px; }
.recovery-panel h1 { margin: 20px 0 28px; font-size: 26px; color: #17191c; }
.back-link { color: #5d6570; text-decoration: none; font-size: 14px; }
form { display: grid; gap: 12px; }
label { font-size: 14px; color: #34383e; }
input { height: 44px; padding: 0 12px; border: 1px solid #cfd4da; border-radius: 6px; font-size: 15px; }
button { height: 44px; margin-top: 8px; border: 0; border-radius: 6px; background: #e85d4a; color: #fff; font-weight: 600; cursor: pointer; }
button:disabled { opacity: .6; cursor: default; }
.success-message { margin: 20px 0 0; color: #227447; line-height: 1.6; }
</style>
