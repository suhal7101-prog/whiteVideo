<!--
  动漫浏览页 v3.0 — 哔哩哔哩风格

  Design System: UI Visual Design System
  参考: Bilibili 分区浏览页

  布局:
  ┌──────────────────────────────────────┐
  │  PageHeader (渐变 Banner)            │
  ├──────────────────────────────────────┤
  │  🔍 搜索 | 综合▾ 最热 最新 评分      │  ← 搜索+排序一体栏
  ├──────────────────────────────────────┤
  │  [全部] 热血🔥 恋爱💕 科幻🚀 ... →  │  ← 横向可滚动分类
  ├──────────────────────────────────────┤
  │  🏆 排行榜 [热播] [新番] [高分]      │
  │   #1 ···  #2 ···  #3 ···  #4 ···    │  ← 紧凑排行条(可折叠)
  ├──────────────────────────────────────┤
  │  共 40 部作品                        │
  │  ┌─────┐┌─────┐┌─────┐┌─────┐      │
  │  │16:9 ││16:9 ││16:9 ││16:9 │      │  ← 4列网格
  │  └─────┘└─────┘└─────┘└─────┘      │
  ├──────────────────────────────────────┤
  │          分页                        │
  └──────────────────────────────────────┘
-->
<template>
  <div class="dp">
    <!-- ===== 1. 动态视差头部 ===== -->
    <DiscoverHeader />

    <div class="dp-body">
      <!-- ===== 2. 搜索 + 排序一体栏 ===== -->
      <div class="dp-toolbar">
        <div class="dp-search-row">
          <div class="searchBox" style="max-width:300px">
            <input
              class="searchInput"
              v-model="searchKeyword"
              type="text"
              placeholder="搜索动漫......"
            />
            <button class="searchButton" @click="doSearch">
              <svg xmlns="http://www.w3.org/2000/svg" width="29" height="29" viewBox="0 0 29 29" fill="none">
                <g clip-path="url(#clip0_2_17)">
                  <path d="M23.7953 23.9182L19.0585 19.1814M19.0585 19.1814C19.8188 18.4211 20.4219 17.5185 20.8333 16.5251C21.2448 15.5318 21.4566 14.4671 21.4566 13.3919C21.4566 12.3167 21.2448 11.252 20.8333 10.2587C20.4219 9.2653 19.8188 8.36271 19.0585 7.60242C18.2982 6.84214 17.3956 6.23905 16.4022 5.82759C15.4089 5.41612 14.3442 5.20435 13.269 5.20435C12.1938 5.20435 11.1291 5.41612 10.1358 5.82759C9.1424 6.23905 8.23981 6.84214 7.47953 7.60242C5.94407 9.13789 5.08145 11.2204 5.08145 13.3919C5.08145 15.5634 5.94407 17.6459 7.47953 19.1814C9.01499 20.7168 11.0975 21.5794 13.269 21.5794C15.4405 21.5794 17.523 20.7168 19.0585 19.1814Z" stroke="white" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>
                </g>
              </svg>
            </button>
          </div>
          <button class="dp-reset-btn" @click="resetFilters">重置</button>
        </div>
        <div class="dp-sorts">
          <button
            v-for="s in sortOptions"
            :key="s.key"
            class="dp-sort-btn"
            :class="{ active: sortBy === s.key }"
            @click="sortBy = s.key"
          >{{ s.label }}</button>
        </div>
      </div>

      <!-- ===== 动漫评分 Top10 ===== -->
      <section
        v-if="rankingLoading || rankingList.length"
        class="dp-top-section"
        aria-labelledby="discover-top-title"
      >
        <div class="dp-top-head">
          <h2 id="discover-top-title">动漫评分 Top10</h2>
        </div>
        <div class="dp-top-scroller" role="list">
          <article
            v-for="(item, index) in rankingList"
            :key="item.id"
            class="dp-top-item"
            role="listitem"
            tabindex="0"
            :aria-label="`播放《${item.title}》`"
            @click="playRanking(item)"
            @keydown.enter="playRanking(item)"
            @keydown.space.prevent="playRanking(item)"
          >
            <span class="dp-top-rank" :class="`top-${index + 1}`">{{ index + 1 }}</span>
            <img
              :src="item.cover"
              :alt="item.title"
              loading="lazy"
              @error="onCoverError"
            />
            <div class="dp-top-info">
              <h3 :title="item.title">{{ item.title }}</h3>
              <div class="dp-top-meta">
                <strong>★ {{ item.dynamicScore.toFixed(1) }}</strong>
                <span>{{ fmt(item.views) }} 浏览</span>
                <span>{{ fmt(item.likes) }} 赞</span>
              </div>
            </div>
          </article>
          <article
            v-for="n in (rankingLoading ? 5 : 0)"
            :key="`rank-skeleton-${n}`"
            class="dp-top-item dp-top-item--skeleton"
            aria-hidden="true"
          ></article>
        </div>
      </section>

      <!-- ===== 3. 横向可滚动分类标签 (搜索时隐藏) ===== -->
      <div class="dp-cats-wrap" v-if="!isSearchMode">
        <button
          class="dp-cat"
          :class="{ active: selectedTag === '' }"
          @click="selectedTag = ''; fetchData(true)"
        >全部</button>
        <button
          v-for="cat in categories"
          :key="cat.name"
          class="dp-cat"
          :class="{ active: selectedTag === cat.name }"
          @click="selectTag(cat.name)"
        >{{ cat.name }}</button>
      </div>

      <!-- ===== 搜索结果提示 ===== -->
      <div v-if="isSearchMode && allAnime.length > 0" class="dp-search-info">
        找到 <strong>{{ allAnime.length }}</strong> 部有关 "<em>{{ searchedKeyword }}</em>" 的动漫
      </div>

      <!-- ===== 6. 卡片网格 (懒加载) ===== -->
      <div class="dp-grid" v-if="displayList.length > 0 || loading">
        <div
          v-for="item in displayList"
          :key="item.id"
          class="dp-card"
          tabindex="0"
          role="link"
          :aria-label="`观看: ${item.title}`"
          @click="playVideo(item.id)"
          @keydown.enter="playVideo(item.id)"
          @keydown.space.prevent="playVideo(item.id)"
        >
          <!-- 封面 16:9 -->
          <div class="dp-cover">
            <img
              :src="item.cover"
              :alt="item.title"
              loading="lazy"
              @error="onCoverError"
            />

            <!-- 悬浮遮罩 -->
            <div class="dp-cover-mask">
              <svg viewBox="0 0 24 24" fill="white" width="44" height="44">
                <path d="M8 5v14l11-7z"/>
              </svg>
            </div>

            <!-- 底部信息条 -->
            <div class="dp-cover-bar">
              <span>{{ item.status }}</span>
            </div>
          </div>

          <!-- 信息 -->
          <div class="dp-info">
            <h4 class="dp-title" :title="item.title">{{ item.title }}</h4>
            <div class="dp-meta">
              <span class="dp-meta-tags" v-if="item.tags?.length">
                <el-tag
                  v-for="t in item.tags.slice(0, 2)"
                  :key="t" size="small" effect="plain" round
                >{{ t }}</el-tag>
              </span>
              <span class="dp-meta-year">{{ item.year }}</span>
            </div>
          </div>
        </div>

        <!-- 骨架卡片 (加载中) -->
        <template v-if="loading">
          <div v-for="n in 8" :key="'sk'+n" class="dp-card dp-card--skeleton">
            <div class="dp-cover dp-cover--shimmer"></div>
            <div class="dp-info">
              <div class="dp-skl dp-skl-title"></div>
              <div class="dp-skl dp-skl-meta"></div>
            </div>
          </div>
        </template>
      </div>

      <!-- ===== 7. 空状态 ===== -->
      <div class="dp-empty" v-if="!loading && allAnime.length === 0">
        <span class="dp-empty-icon">🔍</span>
        <p v-if="isSearchMode">没有找到有关 "<strong>{{ searchedKeyword }}</strong>" 的动漫</p>
        <p v-else>没有找到相关作品</p>
        <el-button round @click="resetFilters">重置</el-button>
      </div>

      <!-- ===== 8. 懒加载 Sentinel ===== -->
      <div
        v-if="displayList.length > 0"
        ref="sentinelRef"
        class="dp-sentinel"
      >
        <span v-if="loading" class="dp-loading"><LoaderSpin /> 加载中...</span>
        <span v-else-if="noMore && isSearchMode" class="dp-nomore">— 已加载全部搜索结果 —</span>
        <span v-else-if="noMore" class="dp-nomore">— 已经到底了 —</span>
        <span v-else class="dp-scroll-hint">👇 下滑加载更多</span>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, watch, onMounted, onUnmounted } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import axios from 'axios'
import DiscoverHeader from '@/components/home/DiscoverHeader.vue'
import LoaderSpin from '@/components/common/LoaderSpin.vue'

const router = useRouter()
const route = useRoute()

// ===== 状态 =====
const searchKeyword = ref(route.query.keyword || '')
const searchedKeyword = ref('')  // 实际已搜索的关键词
const selectedTag = ref('')
const sortBy = ref('hot')

const page = ref(1)
const loading = ref(false)
const noMore = ref(false)
const sentinelRef = ref(null)
let observer = null

const sortOptions = [
  { key: 'hot',   label: '🔥 热门' },
  { key: 'new',   label: '🆕 最新' }
]

// 分类标签由 Python 视频源动态生成。
const categories = ref([])

// ===== 数据 =====
const allAnime = ref([])
const rankingList = ref([])
const rankingLoading = ref(false)
let rankingTimer = null
let rankingRequest = null

const FALLBACK_COVER = '/cover-placeholder.svg'

const displayList = computed(() => allAnime.value)
const isSearchMode = computed(() => searchedKeyword.value !== '')

function normalizeCoverUrl(value) {
  const cover = String(value || '').trim()
  if (!cover) return FALLBACK_COVER
  if (cover.startsWith('//')) {
    return `/api/proxy/image?url=${encodeURIComponent(`https:${cover}`)}`
  }
  if (cover.startsWith('/')) return cover
  if (/^https?:\/\//i.test(cover)) {
    return `/api/proxy/image?url=${encodeURIComponent(cover)}`
  }
  return FALLBACK_COVER
}

function mapRankingItem(item) {
  const tags = typeof item.tags === 'string'
    ? item.tags.split(',').map(tag => tag.trim()).filter(Boolean)
    : []
  return {
    id: item.id,
    sourceVodId: Number(item.sourceVodId || 0),
    title: item.title || '',
    cover: normalizeCoverUrl(item.cover),
    category: item.category || '',
    description: item.description || '',
    status: item.status || '',
    tags: tags.length ? tags : (item.category ? [item.category] : []),
    year: item.year || '',
    rating: Number(item.rating || 0),
    views: Number(item.views || 0),
    likes: Number(item.likes || 0),
    rankingScore: Number(item.rankingScore || 0),
    dynamicScore: Number(item.dynamicScore || 0),
  }
}

async function fetchRanking() {
  if (rankingRequest) return rankingRequest

  rankingLoading.value = true
  rankingRequest = axios.get('/api/ranking/top10')
    .then(({ data }) => {
      rankingList.value = (data.data?.list || []).slice(0, 10).map(mapRankingItem)
      return rankingList.value
    })
    .catch((error) => {
      console.warn('[Discover] 排行榜加载失败:', error.message)
      return rankingList.value
    })
    .finally(() => {
      rankingLoading.value = false
      rankingRequest = null
    })

  return rankingRequest
}

// ===== 搜索 =====
function doSearch() {
  const kw = searchKeyword.value.trim()
  if (!kw) return
  searchedKeyword.value = kw
  fetchData(true)
}

function onClearSearch() {
  searchKeyword.value = ''
  searchedKeyword.value = ''
  fetchData(true)
}

// ===== 数据获取 =====
async function fetchData(reset = false) {
  if (loading.value) return
  if (reset) { page.value = 1; allAnime.value = []; noMore.value = false }
  loading.value = true

  try {
    const requestPage = reset ? 1 : page.value
    const useRankingTop10 = sortBy.value === 'hot'
      && requestPage === 1
      && !searchKeyword.value.trim()
      && !selectedTag.value
    const rankingPromise = useRankingTop10 ? fetchRanking() : Promise.resolve()

    const { data } = await axios.get('/api/catalog/discover', {
      params: {
        page: requestPage,
        count: 20,
        ...(searchKeyword.value.trim() ? { keyword: searchKeyword.value.trim() } : {}),
        ...(selectedTag.value ? { tag: selectedTag.value } : {}),
        sort: sortBy.value,
      },
    })

    if (data.code === 200) {
      await rankingPromise
      const items = data.data.list.map(v => ({
        id: v.vod_id,
        title: v.title,
        cover: normalizeCoverUrl(v.cover_proxy || v.cover),
        tags: [...new Set(
          (typeof v.tags === 'string' ? v.tags.split(',') : (v.tags || []))
            .map(tag => String(tag).trim())
            .filter(Boolean)
        )],
        year: v.year,
        status: v.status,
        score: parseFloat(v.score) || 0,
        desc: v.desc,
        views: Number(v.views || 0),
        likes: Number(v.likes || 0),
      }))

      if (useRankingTop10 && rankingList.value.length) {
        const topCards = rankingList.value
          .filter(item => item.sourceVodId > 0)
          .map(item => ({
            id: item.sourceVodId,
            title: item.title,
            cover: item.cover,
            tags: item.tags,
            year: item.year,
            status: item.status,
            score: item.rating,
            desc: item.description,
            views: item.views,
            likes: item.likes,
          }))
        const topIds = new Set(topCards.map(item => item.id))
        const remaining = items.filter(item => !topIds.has(item.id))
        items.splice(0, items.length, ...topCards, ...remaining.slice(0, Math.max(0, 20 - topCards.length)))
      }

      if (reset) {
        allAnime.value = items
      } else {
        const ids = new Set(allAnime.value.map(i => i.id))
        allAnime.value = [...allAnime.value, ...items.filter(i => !ids.has(i.id))]
      }

      if (items.length < 20) noMore.value = true
      page.value = reset ? 2 : page.value + 1
    }
  } catch (e) {
    console.warn('[Discover] 数据获取失败:', e.message)
    noMore.value = true
  } finally {
    loading.value = false
  }
}

// ===== 方法 =====
function selectTag(name) {
  selectedTag.value = selectedTag.value === name ? '' : name
}

function resetFilters() {
  searchKeyword.value = ''
  searchedKeyword.value = ''
  selectedTag.value = ''
  sortBy.value = 'hot'
  router.replace({ query: {} })
  fetchData(true)
}

function playVideo(id) { router.push(`/play/${id}`) }

function onCoverError(event) {
  const image = event.currentTarget
  if (!image || image.dataset.fallbackApplied === 'true') return
  image.dataset.fallbackApplied = 'true'
  image.src = FALLBACK_COVER
}

function playRanking(item) {
  if (item.sourceVodId) router.push(`/play/${item.sourceVodId}`)
}

function loadMore() { fetchData(false) }

// 搜索框清空时自动重置
watch(searchKeyword, (val) => {
  if (!val && searchedKeyword.value) onClearSearch()
})

// 过滤器变化时重新请求
watch([selectedTag, sortBy], () => { fetchData(true) })

// 从导航栏跳转过来时 (query 变化)
watch(() => route.query.keyword, (kw) => {
  searchKeyword.value = kw || ''
  if (kw) { searchedKeyword.value = kw; fetchData(true) }
})

onMounted(() => {
  fetchRanking()
  rankingTimer = window.setInterval(fetchRanking, 30000)

  axios.get('/api/catalog/categories')
    .then(({ data }) => { categories.value = data.data?.list || [] })
    .catch((error) => { console.warn('[Discover] 分类加载失败:', error.message) })
  fetchData(true)

  observer = new IntersectionObserver(
    ([e]) => {
      if (e.isIntersecting && !loading.value && !noMore.value) {
        loadMore()
        // 自动滚动失效时，追加 window 滚动兜底
      }
    },
    { rootMargin: '400px' }
  )

  // 等 DOM 渲染完后绑定 observer
  const bindObs = () => {
    if (sentinelRef.value) {
      observer.observe(sentinelRef.value)
      // 如果首屏数据不够触发滚动，主动加载更多
      if (sentinelRef.value.getBoundingClientRect().top < window.innerHeight + 400) {
        loadMore()
      }
    } else {
      setTimeout(bindObs, 200)
    }
  }
  setTimeout(bindObs, 300)
})

onUnmounted(() => {
  if (observer) observer.disconnect()
  if (rankingTimer) window.clearInterval(rankingTimer)
})

function fmt(n) {
  if (!n) return '0'
  if (n >= 10000) return (n / 10000).toFixed(1) + '万'
  return String(n)
}
</script>

<style scoped>
/* ================================================================
   Discover v3.0 — Bilibili-Style · Light Theme
   Token: src/assets/styles/design-tokens.css v2.0
   ================================================================ */

.dp {
  min-height: 100vh;
  background: var(--ds-surface-0, #f5f6fa);
}

.dp-body {
  max-width: 1240px;
  margin: 0 auto;
  padding: 20px 20px 48px;
}

/* ================================================================
   2. 搜索 + 排序一体栏
   ================================================================ */
.dp-toolbar {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-bottom: 16px;
  flex-wrap: wrap;
}

/* 搜索框 (与导航栏同款浅色版) */
.searchBox {
  display: flex;
  max-width: 300px;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  background: #f0f2f5;
  border-radius: 50px;
  position: relative;
  border: 2px solid #e4e7ed;
  transition: border-color 0.3s ease, box-shadow 0.3s ease;
}
.searchBox:focus-within {
  border-color: #667eea;
  box-shadow: 0 0 0 4px rgba(102, 126, 234, 0.12);
}
.searchInput {
  border: none;
  background: none;
  outline: none;
  color: #2d3436;
  font-size: 14px;
  padding: 12px 44px 12px 18px;
  width: 100%;
}
.searchInput::placeholder {
  color: #a0a4a8;
}
.searchButton {
  color: white;
  position: absolute;
  right: 5px;
  width: 40px;
  height: 40px;
  border-radius: 50%;
  background: linear-gradient(135deg, #667eea, #764ba2);
  border: 0;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  transition: none;
  cursor: pointer;
  flex-shrink: 0;
}
.searchButton:hover {
  background: linear-gradient(135deg, #5a6fd6, #6a3f9e);
  box-shadow: 0 6px 20px rgba(102, 126, 234, 0.35);
}
.searchButton:active {
  box-shadow: none;
}
.searchButton svg {
  width: 20px;
  height: 20px;
}
.searchButton svg path {
  stroke: #ffffff;
}

/* 排序按钮组 */
.dp-sorts {
  display: flex;
  gap: 2px;
  background: var(--ds-surface-1, #fff);
  border-radius: 10px;
  padding: 3px;
}
.dp-sort-btn {
  padding: 6px 16px;
  border: none;
  border-radius: 8px;
  background: transparent;
  font-size: var(--ds-text-xs, 0.75rem);
  color: var(--ds-text-secondary, #585a6e);
  cursor: pointer;
  transition: all 0.15s;
  white-space: nowrap;
}
.dp-sort-btn:hover { color: var(--ds-accent, #7c5ce7); }
.dp-sort-btn.active {
  background: var(--ds-accent-subtle, rgba(124,92,231,.08));
  color: var(--ds-accent, #7c5ce7);
  font-weight: var(--ds-font-semibold, 600);
}


/* ================================================================
   3. 横向分类标签 (可滚动)
   ================================================================ */
.dp-cats-wrap {
  display: flex;
  flex-wrap: nowrap;
  gap: 8px;
  width: 100%;
  min-width: 0;
  overflow-x: auto;
  overflow-y: hidden;
  padding: 2px 0 10px;
  margin-bottom: 8px;
  overscroll-behavior-x: contain;
  scrollbar-width: thin;
  scrollbar-color: #667eea #e5e7eb;
}
.dp-cats-wrap::-webkit-scrollbar { height: 8px; }
.dp-cats-wrap::-webkit-scrollbar-track {
  background: #e5e7eb;
  border-radius: 4px;
}
.dp-cats-wrap::-webkit-scrollbar-thumb {
  background: #667eea;
  border-radius: 4px;
}

.dp-cat {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  padding: 7px 18px;
  border: 1px solid var(--ds-border-default, rgba(0,0,0,.10));
  border-radius: 20px;
  background: var(--ds-surface-1, #fff);
  font-size: var(--ds-text-sm, 0.8125rem);
  color: var(--ds-text-secondary, #585a6e);
  cursor: pointer;
  white-space: nowrap;
  transition: all 0.18s ease;
  flex-shrink: 0;
  outline: none;
  scroll-snap-align: start;
}
.dp-cat:hover {
  border-color: var(--ds-accent, #7c5ce7);
  color: var(--ds-accent, #7c5ce7);
}
.dp-cat:focus-visible {
  outline: 2px solid var(--ds-accent, #7c5ce7);
  outline-offset: 1px;
}
.dp-cat.active {
  background: var(--ds-gradient-brand, linear-gradient(135deg, #7c5ce7, #a855f7));
  border-color: transparent;
  color: #fff;
}

/* ================================================================
   4. 动漫评分 Top10
   ================================================================ */
.dp-top-section {
  margin-bottom: 16px;
  padding-bottom: 4px;
  border-bottom: 1px solid var(--ds-border-subtle, rgba(0,0,0,.06));
}
.dp-top-head {
  display: flex;
  align-items: center;
  min-height: 28px;
  margin-bottom: 8px;
}
.dp-top-head h2 {
  margin: 0;
  font-size: 14px;
  line-height: 1.4;
  font-weight: 700;
  color: var(--ds-text-primary, #1a1a2e);
}
.dp-top-scroller {
  display: flex;
  gap: 10px;
  overflow-x: auto;
  padding: 2px 0 10px;
  scrollbar-width: thin;
  scrollbar-color: rgba(124,92,231,.35) transparent;
  scroll-snap-type: x proximity;
}
.dp-top-item {
  display: grid;
  grid-template-columns: 24px 78px minmax(0, 1fr);
  align-items: center;
  gap: 8px;
  flex: 0 0 286px;
  min-height: 70px;
  padding: 7px 10px;
  border: 1px solid var(--ds-border-subtle, rgba(0,0,0,.06));
  border-radius: 8px;
  background: var(--ds-surface-1, #fff);
  scroll-snap-align: start;
  cursor: pointer;
  outline: none;
}
.dp-top-item:focus-visible {
  border-color: var(--ds-accent, #7c5ce7);
  box-shadow: 0 0 0 2px rgba(124,92,231,.16);
}
.dp-top-item img {
  width: 78px;
  height: 52px;
  border-radius: 5px;
  object-fit: cover;
  background: var(--ds-surface-3, #f0f1fa);
}
.dp-top-rank {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 22px;
  height: 22px;
  border-radius: 50%;
  background: var(--ds-surface-3, #f0f1fa);
  color: var(--ds-text-tertiary, #8f92a1);
  font-size: 11px;
  font-weight: 700;
}
.dp-top-rank.top-1 { background: #f5b700; color: #fff; }
.dp-top-rank.top-2 { background: #9ca3af; color: #fff; }
.dp-top-rank.top-3 { background: #b87333; color: #fff; }
.dp-top-info { min-width: 0; }
.dp-top-info h3 {
  margin: 0 0 7px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  font-size: 12px;
  line-height: 1.35;
  font-weight: 600;
  color: var(--ds-text-primary, #1a1a2e);
}
.dp-top-meta {
  display: grid;
  grid-template-columns: auto minmax(0, 1fr) auto;
  align-items: center;
  gap: 8px;
  overflow: visible;
  white-space: nowrap;
  font-size: 10px;
  color: var(--ds-text-tertiary, #8f92a1);
}
.dp-top-meta span { min-width: 0; }
.dp-top-meta strong {
  color: #d97706;
  font-size: 12px;
}
.dp-top-item--skeleton {
  min-height: 64px;
  border-color: transparent;
  background: linear-gradient(90deg, #e8e9f4 0%, #f4f5fa 45%, #e8e9f4 90%);
  background-size: 200% 100%;
  animation: dp-shimmer 1.6s ease-in-out infinite;
}

/* ================================================================
   5. 结果统计
   ================================================================ */
.dp-result {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-bottom: 14px;
  font-size: var(--ds-text-sm, 0.8125rem);
  color: var(--ds-text-tertiary, #8f92a1);
}
.dp-result strong { color: var(--ds-accent, #7c5ce7); font-weight: 700; }
.dp-reset {
  padding: 2px 12px;
  border: 1px solid var(--ds-border-default, rgba(0,0,0,.10));
  border-radius: 12px;
  background: transparent;
  font-size: var(--ds-text-xs, 0.75rem);
  color: var(--ds-text-tertiary, #8f92a1);
  cursor: pointer;
  transition: all 0.15s;
}
.dp-reset:hover { border-color: var(--ds-accent, #7c5ce7); color: var(--ds-accent, #7c5ce7); }

/* ================================================================
   6. 卡片网格 (4列)
   ================================================================ */
.dp-grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 16px;
}

/* 单张卡片 */
.dp-card {
  display: flex;
  flex-direction: column;
  background: var(--ds-surface-1, #fff);
  border-radius: var(--ds-radius-md, 10px);
  overflow: hidden;
  cursor: pointer;
  outline: none;
  box-shadow: var(--ds-shadow-xs, 0 1px 2px rgba(0,0,0,.04));
  transition:
    transform var(--ds-duration-base, 200ms) var(--ds-ease-decelerate),
    box-shadow var(--ds-duration-base, 200ms) var(--ds-ease-decelerate);
}
.dp-card:hover {
  transform: translateY(-4px);
  box-shadow:
    var(--ds-shadow-md, 0 4px 12px rgba(0,0,0,.10)),
    var(--ds-shadow-glow, 0 0 24px rgba(124,92,231,.12));
}
.dp-card:hover .dp-cover img { transform: scale(1.06); }
.dp-card:hover .dp-cover-mask { opacity: 1; }
.dp-card:focus-visible {
  outline: 2.5px solid var(--ds-accent, #7c5ce7);
  outline-offset: 2px;
}
.dp-card:active {
  transform: scale(0.98);
  box-shadow: var(--ds-shadow-xs);
  transition-duration: 80ms;
}

/* 封面 16:9 */
.dp-cover {
  position: relative;
  aspect-ratio: 16 / 9;
  overflow: hidden;
  background: var(--ds-surface-3, #f0f1fa);
}
.dp-cover img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  display: block;
  transition: transform var(--ds-duration-slow, 350ms) var(--ds-ease-decelerate);
}

/* 悬浮播放图标 */
.dp-cover-mask {
  position: absolute;
  inset: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  background: rgba(26,26,46,.25);
  opacity: 0;
  transition: opacity var(--ds-duration-base, 200ms) ease;
}
.dp-cover-mask svg { filter: drop-shadow(0 2px 6px rgba(0,0,0,.4)); }

/* 底部数据条 */
.dp-cover-bar {
  position: absolute;
  inset: auto 0 0 0;
  display: flex;
  justify-content: flex-end;
  align-items: flex-end;
  padding: 22px 10px 7px;
  background: linear-gradient(180deg, transparent 0%, rgba(0,0,0,.55) 100%);
  font-size: var(--ds-text-xs, 0.75rem);
  color: #fff;
  text-shadow: 0 1px 3px rgba(0,0,0,.7);
  pointer-events: none;
}

/* 信息区 */
.dp-info {
  display: flex;
  flex: 1;
  flex-direction: column;
  padding: 10px 12px 12px;
}

.dp-title {
  font-size: var(--ds-text-sm, 0.8125rem);
  font-weight: var(--ds-font-medium, 500);
  color: var(--ds-text-primary, #1a1a2e);
  line-height: var(--ds-leading-normal, 1.5);
  margin: 0 0 8px;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
  min-height: 3em;
}
.dp-card:hover .dp-title { color: var(--ds-accent, #7c5ce7); }

.dp-meta {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  min-height: 24px;
  margin-top: auto;
}
.dp-meta-tags { display: flex; gap: 4px; }
.dp-meta-year {
  font-size: var(--ds-text-xs, 0.75rem);
  color: var(--ds-text-tertiary, #8f92a1);
  flex-shrink: 0;
}

/* ================================================================
   7-8. 空状态 + 分页
   ================================================================ */
.dp-empty { text-align: center; padding: 80px 20px; }
.dp-empty-icon { font-size: 56px; display: block; margin-bottom: 16px; }
.dp-empty p { color: var(--ds-text-tertiary, #8f92a1); margin-bottom: 16px; }

.dp-sentinel {
  display: flex;
  justify-content: center;
  padding: 32px 0 16px;
  font-size: var(--ds-text-xs, 0.75rem);
}
.dp-loading {
  display: flex; align-items: center; justify-content: center; gap: 8px;
  color: var(--ds-accent, #7c5ce7);
}
.dp-nomore { color: var(--ds-text-tertiary, #8f92a1); }
.dp-scroll-hint {
  color: var(--ds-accent, #7c5ce7);
  animation: dp-bounce 1.5s ease-in-out infinite;
}

/* 搜索结果提示 */
.dp-search-info {
  text-align: center; padding: 8px 0 16px;
  font-size: 0.875rem; color: #585a6e;
}
.dp-search-info em { font-style: normal; color: var(--ds-accent, #7c5ce7); font-weight: 600; }

.dp-search-row { display: flex; align-items: center; gap: 10px; }
.dp-reset-btn {
  border: 1px solid #d0d5dd; border-radius: 20px;
  background: #fff; color: #585a6e; cursor: pointer;
  padding: 8px 18px; font-size: 0.8125rem;
  transition: all .15s; flex-shrink: 0;
}
.dp-reset-btn:hover { border-color: var(--ds-accent, #7c5ce7); color: var(--ds-accent, #7c5ce7); }

@keyframes dp-bounce {
  0%, 100% { transform: translateY(0); opacity: 0.6; }
  50%      { transform: translateY(-4px); opacity: 1; }
}

/* ================================================================
   响应式
   ================================================================ */
@media (max-width: 1100px) {
  .dp-grid { grid-template-columns: repeat(3, 1fr); }
}
@media (max-width: 768px) {
  .dp-body { padding: 14px 14px 36px; }
  .dp-toolbar { gap: 8px; }
  .searchBox { max-width: 100%; width: 100%; order: -1; }
  .dp-grid { grid-template-columns: repeat(2, 1fr); gap: 12px; }
  .dp-top-item { flex-basis: 270px; }
}
@media (max-width: 480px) {
  .dp-grid { grid-template-columns: repeat(2, 1fr); gap: 10px; }
  .dp-sorts { gap: 0; }
  .dp-sort-btn { padding: 5px 10px; font-size: 11px; }
}

/* ===== 骨架卡片 ===== */
.dp-card--skeleton { pointer-events: none; }
.dp-cover--shimmer {
  aspect-ratio: 16 / 9;
  background: linear-gradient(90deg, #e8e9f4 0%, #f0f1fa 40%, #e8e9f4 80%);
  background-size: 200% 100%;
  animation: dp-shimmer 1.6s ease-in-out infinite;
}
.dp-skl {
  height: 12px; border-radius: 6px; margin-bottom: 8px;
  background: linear-gradient(90deg, #e8e9f4 0%, #f0f1fa 40%, #e8e9f4 80%);
  background-size: 200% 100%;
  animation: dp-shimmer 1.6s ease-in-out infinite;
}
.dp-skl-title { width: 80%; }
.dp-skl-meta  { width: 50%; }

@keyframes dp-shimmer {
  0%   { background-position: 200% 0; }
  100% { background-position: -200% 0; }
}
</style>
