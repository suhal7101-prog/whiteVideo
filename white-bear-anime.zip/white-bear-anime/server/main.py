"""
白熊动漫 API v2.0 — 多资源站数据代理 + 视频解析
数据来源: 红牛资源
"""
from fastapi.applications import FastAPI


from fastapi import FastAPI, Query, HTTPException, Request
from fastapi.responses import Response, StreamingResponse
from fastapi.middleware.cors import CORSMiddleware
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from urllib.parse import urljoin, urlparse
import ipaddress
import hashlib
import json
import math
import os
import random
from pathlib import Path
import socket
import re
import threading
import time

try:
    import chromadb
except ImportError:  # 服务仍可启动，向量接口会明确提示安装依赖。
    chromadb = None

app: FastAPI = FastAPI(title="白熊动漫 API")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0"
}

# ============================================================
#  带重试的 requests Session (抗上游抖动)
# ============================================================
def _make_session() -> requests.Session:
    s = requests.Session()
    retry = Retry(
        total=3,
        backoff_factor=0.5,
        status_forcelist=[500, 502, 503, 504],
        allowed_methods=["GET"],
    )
    adapter = HTTPAdapter(max_retries=retry, pool_connections=5, pool_maxsize=10)
    s.mount("https://", adapter)
    s.mount("http://", adapter)
    s.verify = True
    s.headers.update(HEADERS)
    return s

_session = _make_session()

JAVA_API_URL = os.getenv("JAVA_API_URL", "http://127.0.0.1:8088").rstrip("/")
RANKING_METRICS_TTL_SECONDS = 5
_ranking_metrics_lock = threading.RLock()
_ranking_metrics_cache = {"expires_at": 0.0, "data": {}}


def _get_ranking_metrics() -> dict:
    """读取 MySQL 中的视频热度；Java 不可用时返回最近缓存或空数据。"""
    now = time.monotonic()
    with _ranking_metrics_lock:
        if now < _ranking_metrics_cache["expires_at"]:
            return _ranking_metrics_cache["data"]
        stale_data = _ranking_metrics_cache["data"]

    try:
        response = _session.get(f"{JAVA_API_URL}/api/ranking/metrics", timeout=(1, 2))
        response.raise_for_status()
        payload = response.json()
        rows = payload.get("data", {}).get("list", [])
        metrics = {}
        for row in rows:
            try:
                source_vod_id = int(row.get("sourceVodId") or 0)
            except (TypeError, ValueError):
                continue
            if source_vod_id <= 0:
                continue
            metrics[source_vod_id] = {
                "views": int(row.get("views") or 0),
                "likes": int(row.get("likes") or 0),
            }
    except (requests.RequestException, ValueError, TypeError, AttributeError):
        metrics = stale_data

    with _ranking_metrics_lock:
        _ranking_metrics_cache["data"] = metrics
        _ranking_metrics_cache["expires_at"] = now + RANKING_METRICS_TTL_SECONDS
    return metrics


def _sort_discover_items(items: list, sort: str) -> None:
    if sort == "new":
        random.shuffle(items)
        return

    metrics = _get_ranking_metrics()
    for item in items:
        try:
            source_vod_id = int(item.get("vod_id") or 0)
        except (TypeError, ValueError):
            source_vod_id = 0
        metric = metrics.get(source_vod_id, {})
        item["views"] = int(metric.get("views") or 0)
        item["likes"] = int(metric.get("likes") or 0)
        item["hot_score"] = item["views"] + item["likes"] * 10

    items.sort(
        key=lambda item: (item.get("hot_score", 0), item.get("likes", 0), item.get("views", 0)),
        reverse=True,
    )

# 简易内存缓存 (TTL 60s)
CACHE_TTL_SECONDS = 60
CACHE_FILE = Path(__file__).with_name("api_cache.json")
_cache_lock = threading.RLock()


def _load_cache() -> dict:
    try:
        payload = json.loads(CACHE_FILE.read_text(encoding="utf-8"))
        return payload if isinstance(payload, dict) else {}
    except (OSError, ValueError, TypeError):
        return {}


_cache: dict = _load_cache()

VECTOR_SIZE = 256
VECTOR_COLLECTION = "white_bear_anime"
VECTOR_DB_PATH = Path(__file__).with_name("chroma_data_v3")
_vector_client = None
_vector_collection = None
_vector_lock = threading.RLock()

MAX_IMAGE_BYTES = 10 * 1024 * 1024
MAX_PLAYLIST_BYTES = 2 * 1024 * 1024
MAX_SEGMENT_BYTES = 50 * 1024 * 1024

def _cache_get(key: str, allow_stale: bool = False):
    with _cache_lock:
        entry = _cache.get(key)
        if not isinstance(entry, dict) or "data" not in entry:
            return None
        try:
            fresh = (time.time() - float(entry.get("ts", 0))) < CACHE_TTL_SECONDS
        except (TypeError, ValueError):
            fresh = False
        return entry["data"] if fresh or allow_stale else None

def _cache_set(key: str, data):
    with _cache_lock:
        _cache[key] = {"data": data, "ts": time.time()}
        temp_file = CACHE_FILE.with_suffix(".tmp")
        try:
            temp_file.write_text(
                json.dumps(_cache, ensure_ascii=False),
                encoding="utf-8",
            )
            temp_file.replace(CACHE_FILE)
        except (OSError, TypeError, ValueError):
            # Memory caching still works when the local cache file cannot be written.
            try:
                temp_file.unlink(missing_ok=True)
            except OSError:
                pass


def _validate_public_url(url: str) -> str:
    """仅允许指向公网 HTTP(S) 资源的 URL。"""
    parsed = urlparse(url)
    if parsed.scheme not in {"http", "https"} or not parsed.hostname:
        raise ValueError("仅支持公网 HTTP(S) URL")
    if parsed.username or parsed.password:
        raise ValueError("URL 不允许包含认证信息")

    port = parsed.port or (443 if parsed.scheme == "https" else 80)
    try:
        addresses = socket.getaddrinfo(parsed.hostname, port, type=socket.SOCK_STREAM)
    except socket.gaierror as exc:
        raise ValueError("目标域名无法解析") from exc

    if not addresses:
        raise ValueError("目标域名无法解析")
    for address in addresses:
        raw_ip = address[4][0].split("%", 1)[0]
        if not ipaddress.ip_address(raw_ip).is_global:
            raise ValueError("禁止访问内网或保留地址")
    return url


def _safe_get(url: str, **kwargs) -> requests.Response:
    """执行逐跳校验的 GET，防止重定向绕过 SSRF 检查。"""
    current = url
    kwargs.pop("allow_redirects", None)
    kwargs.pop("verify", None)
    for _ in range(5):
        _validate_public_url(current)
        response = _session.get(
            current,
            allow_redirects=False,
            verify=True,
            stream=True,
            **kwargs,
        )
        if response.status_code not in {301, 302, 303, 307, 308}:
            return response

        location = response.headers.get("location")
        response.close()
        if not location:
            raise ValueError("上游重定向缺少 Location")
        current = urljoin(current, location)
    raise ValueError("上游重定向次数过多")


def _read_limited(response: requests.Response, max_bytes: int) -> bytes:
    content_length = response.headers.get("content-length")
    if content_length:
        try:
            if int(content_length) > max_bytes:
                raise ValueError("上游响应超过大小限制")
        except ValueError as exc:
            if "超过" in str(exc):
                raise

    chunks = bytearray()
    for chunk in response.iter_content(chunk_size=64 * 1024):
        if not chunk:
            continue
        chunks.extend(chunk)
        if len(chunks) > max_bytes:
            raise ValueError("上游响应超过大小限制")
    return bytes(chunks)

# ============================================================
#  资源站配置
# ============================================================
# 红牛资源站配置
HN_BASE = "https://hongniuzy2.com/api.php/provide/vod/from/hnm3u8"
HN_TYPE = 36  # t=36 → type_name="中国动漫"

# 视频解析接口 (按优先级排序)
PARSE_SERVICES = [
    "https://jx.m3u8.tv/jiexi/?url=",
    "https://jx.xmflv.com/?url=",
    "https://dmjx.m3u8.tv/?url=",
]

# 国产动漫关键词 (用于二次过滤)
CN_ANIME_KEYWORDS = ["中国动漫", "国产动漫", "国产", "动漫片", "日韩动漫"]


# ============================================================
#  工具函数
# ============================================================
def _call_api(params: dict) -> dict:
    """调用红牛资源站 API (自动重试 3 次 + SSL 兼容)"""
    resp = _session.get(
        HN_BASE,
        params=params,
        timeout=(10, 20),
    )
    resp.raise_for_status()
    return resp.json()


def _parse_episodes(raw: str) -> list:
    """解析剧集字符串: '第01集$URL#第02集$URL#' → [{title, url}]"""
    episodes = []
    if not raw:
        return episodes
    for part in raw.split("#"):
        if "$" in part:
            raw_title, url = part.split("$", 1)
            # 去掉 m3u8 后的可能存在的额外标记
            url = url.strip()
            title = raw_title.strip()
            episodes.append({"title": title, "url": url})
    return episodes


def _build_item(v: dict) -> dict:
    """将资源站返回的原始数据转为统一格式"""
    # vod_class 是逗号分隔的标签: "动画,家庭,奇幻,冒险"
    raw_class = v.get("vod_class", "") or ""
    tags = [t.strip() for t in raw_class.split(",") if t.strip()] if raw_class else []
    return {
        "vod_id": v.get("vod_id"),
        "title": v.get("vod_name", ""),
        "cover": v.get("vod_pic", ""),
        "category": v.get("type_name", ""),
        "tags": tags,
        "status": v.get("vod_remarks", ""),
        "year": v.get("vod_year", ""),
        "area": v.get("vod_area", ""),
        "lang": v.get("vod_lang", ""),
        "director": v.get("vod_director", "") or "",
        "actor": v.get("vod_actor", "") or "",
        "desc": (v.get("vod_content") or "").replace("<p>", "").replace("</p>", "").replace("<br/>", "").replace("\\/", "/")[:300],
        "score": v.get("vod_douban_score", "") or v.get("vod_score", ""),
        "total_episodes": int(v.get("vod_total", 0)) or 0,
    }


def _get_vector_collection():
    """延迟初始化本地持久化 Chroma，无需独立数据库进程。"""
    global _vector_client, _vector_collection
    if chromadb is None:
        raise RuntimeError("缺少 chromadb，请先安装 server/requirements.txt")
    with _vector_lock:
        if _vector_client is None:
            VECTOR_DB_PATH.mkdir(parents=True, exist_ok=True)
            _vector_client = chromadb.PersistentClient(path=str(VECTOR_DB_PATH))
        if _vector_collection is None:
            _vector_collection = _vector_client.get_or_create_collection(
                name=VECTOR_COLLECTION,
                metadata={"hnsw:space": "cosine"},
            )
        return _vector_collection


def _text_features(text: str) -> list[str]:
    """提取中文单字/双字与英文词，生成稳定且无需下载模型的文本特征。"""
    normalized = re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", text or "")).lower()
    features = re.findall(r"[a-z0-9]+", normalized)
    for sequence in re.findall(r"[\u4e00-\u9fff]+", normalized):
        features.extend(sequence)
        features.extend(sequence[i:i + 2] for i in range(len(sequence) - 1))
    return features


def _text_vector(text: str) -> list[float]:
    vector = [0.0] * VECTOR_SIZE
    for feature in _text_features(text):
        digest = hashlib.sha256(feature.encode("utf-8")).digest()
        index = int.from_bytes(digest[:4], "big") % VECTOR_SIZE
        vector[index] += 1.0 if digest[4] & 1 else -1.0
    norm = math.sqrt(sum(value * value for value in vector))
    return [value / norm for value in vector] if norm else vector


def _vector_document(item: dict) -> str:
    tags = item.get("tags") or []
    if isinstance(tags, str):
        tags = tags.split(",")
    title = str(item.get("title") or item.get("vod_name") or "")
    fields = [
        title, title, title,
        str(item.get("category") or ""),
        " ".join(str(tag) for tag in tags),
        str(item.get("desc") or ""),
        str(item.get("director") or ""),
        str(item.get("actor") or ""),
    ]
    return " ".join(fields)


def _upsert_vector_items(items: list[dict]) -> int:
    ids = []
    embeddings = []
    metadatas = []
    documents = []
    for item in items:
        try:
            vod_id = int(item.get("vod_id"))
        except (TypeError, ValueError):
            continue
        if vod_id <= 0 or not item.get("title"):
            continue
        tags = item.get("tags") or []
        if isinstance(tags, str):
            tags = [tag.strip() for tag in tags.split(",") if tag.strip()]
        metadata = {
            "vod_id": vod_id,
            "title": item.get("title") or "",
            "cover": item.get("cover_proxy") or item.get("cover") or "",
            "category": item.get("category") or "",
            "tags_json": json.dumps(tags, ensure_ascii=False),
            "status": item.get("status") or "",
            "year": str(item.get("year") or ""),
            "rating": str(item.get("score") or "0"),
            "description": item.get("desc") or "",
            "playUrl": f"/play/{vod_id}",
        }
        document = _vector_document(item)
        ids.append(str(vod_id))
        embeddings.append(_text_vector(document))
        metadatas.append(metadata)
        documents.append(document)
    if ids:
        _get_vector_collection().upsert(
            ids=ids,
            embeddings=embeddings,
            metadatas=metadatas,
            documents=documents,
        )
    return len(ids)


def _try_upsert_vector_items(items: list[dict]) -> None:
    try:
        _upsert_vector_items(items)
    except Exception as exc:
        # 视频浏览接口不能因向量索引异常而不可用。
        print(f"[Vector] 自动索引失败: {exc}")


def _search_vector(query: str, limit: int) -> list[dict]:
    collection = _get_vector_collection()
    stored = collection.count()
    if stored == 0:
        return []
    candidate_limit = min(stored, max(100, limit * 20))
    result = collection.query(
        query_embeddings=[_text_vector(query)],
        n_results=candidate_limit,
        include=["metadatas", "distances"],
    )
    matches = []
    query_features = set(_text_features(query))
    metadatas = (result.get("metadatas") or [[]])[0]
    distances = (result.get("distances") or [[]])[0]
    for metadata, distance in zip(metadatas, distances):
        payload = dict(metadata or {})
        try:
            payload["tags"] = json.loads(payload.pop("tags_json", "[]"))
        except (TypeError, ValueError):
            payload["tags"] = []
        similarity = max(0.0, min(1.0, 1.0 - float(distance)))
        lexical_text = " ".join([
            str(payload.get("title") or ""),
            " ".join(str(tag) for tag in payload["tags"]),
        ])
        candidate_features = set(_text_features(lexical_text))
        lexical_score = len(query_features & candidate_features) / max(1, len(query_features))
        tag_hits = sum(1 for tag in payload["tags"] if tag and str(tag) in query)
        title = str(payload.get("title") or "").strip()
        title_hit = 1.0 if title and title in query else 0.0
        payload["score"] = round(
            similarity * 0.55 + lexical_score * 0.30 + min(1.0, tag_hits / 2) * 0.10 + title_hit * 0.05,
            4,
        )
        matches.append(payload)
    matches.sort(key=lambda item: item["score"], reverse=True)
    return matches[:limit]


def _tag_set(tags) -> set[str]:
    if isinstance(tags, str):
        tags = tags.split(",")
    ignored = {"中国动漫", "国产动漫", "动漫", "动画"}
    return {str(tag).strip() for tag in (tags or []) if str(tag).strip() not in ignored}


def _related_by_type(vod_id: int, page: int, count: int) -> list[dict]:
    """按当前视频类型标签和向量相似度返回真实可播放视频。"""
    detail = _call_api({"ac": "videolist", "ids": vod_id})
    videos = detail.get("list") or []
    if not videos:
        raise HTTPException(404, "未找到当前动漫")

    current = _build_item(videos[0])
    current_tags = _tag_set(current.get("tags"))
    _try_upsert_vector_items([current])

    search_limit = min(100, max(30, page * count * 3 + 1))
    try:
        candidates = _search_vector(_vector_document(current), search_limit)
    except Exception:
        candidates = []
        # 向量库不可用时扫描真实源，但只保留同标签视频。
        for source_page in range(1, 5):
            response = _call_api({"ac": "detail", "t": HN_TYPE, "pg": source_page})
            candidates.extend(_build_item(video) for video in response.get("list", []))

    ranked = []
    seen = {vod_id}
    for candidate in candidates:
        try:
            candidate_id = int(candidate.get("vod_id"))
        except (TypeError, ValueError):
            continue
        if candidate_id in seen or not candidate.get("title"):
            continue
        seen.add(candidate_id)

        candidate_tags = _tag_set(candidate.get("tags"))
        overlap = current_tags & candidate_tags
        # 精确同类型排在最前；其余结果已由当前视频全文向量相似度排序。
        match_priority = 0 if overlap else 1
        cover = candidate.get("cover") or ""
        cover_proxy = cover if str(cover).startswith("/api/") else (
            f"/api/proxy/image?url={requests.utils.quote(str(cover), safe='')}" if cover else ""
        )
        ranked.append((match_priority, -len(overlap), {
            "vod_id": candidate_id,
            "title": candidate.get("title") or "",
            "cover": cover,
            "cover_proxy": cover_proxy,
            "category": candidate.get("category") or "",
            "tags": candidate.get("tags") or [],
            "status": candidate.get("status") or "",
            "year": candidate.get("year") or "",
            "similarity": candidate.get("score"),
        }))

    ranked.sort(key=lambda item: (item[0], item[1]))
    start = (page - 1) * count
    return [item[2] for item in ranked[start:start + count]]


# ============================================================
#  API 端点
# ============================================================

@app.get("/api/anime/hot")
def anime_hot(
    count: int = Query(20, ge=1, le=60, description="获取数量"),
    page: int = Query(1, ge=1, description="页码"),
):
    """
    热门推荐 — 获取最新更新的动漫
    用于首页轮播 + 视频网格
    """

    # 资源站默认按更新时间倒序 = 最新 = 热门
    cache_key = f"hot_hongniu_{page}"
    try:
        resp = _call_api( {
            "ac": "detail",
            "t": HN_TYPE,
            "pg": page,
        })
        _cache_set(cache_key, resp)  # 更新缓存
    except Exception as e:
        # 上游挂了 → 尝试返回缓存
        cached = _cache_get(cache_key, allow_stale=True)
        if cached:
            resp = cached
        else:
            raise HTTPException(502, f"资源站请求失败: {str(e)}")

    items = []
    for v in (resp.get("list") or [])[:count]:
        vod_id = v.get("vod_id")
        cover = v.get("vod_pic", "")
        items.append({
            "vod_id": vod_id,
            "title": v.get("vod_name", ""),
            "cover": cover,
            "cover_proxy": f"/api/proxy/image?url={requests.utils.quote(cover, safe='')}" if cover else "",
            "category": v.get("type_name", ""),
            "status": v.get("vod_remarks", ""),
            "year": v.get("vod_year", ""),
            "area": v.get("vod_area", ""),
            "director": v.get("vod_director", "") or "",
            "actor": v.get("vod_actor", "") or "",
            "desc": (v.get("vod_content") or "").replace("<p>", "").replace("</p>", "").replace("<br/>", "").replace("\\/", "/")[:200],
            "score": v.get("vod_douban_score", "") or v.get("vod_score", ""),
            "total_episodes": int(v.get("vod_total", 0)) or 0,
        })

    _try_upsert_vector_items(items)

    return {
        "code": 200,
        "data": {
            "page": page,
            "list": items,
        },
    }


@app.get("/api/anime/list")
def anime_list(
    page: int = Query(1, ge=1, description="页码"),
):
    """
    获取动漫列表
    - 红牛资源: 自动筛选 type_name=中国动漫
    """

    resp = _call_api( {
        "ac": "detail",
        "t": HN_TYPE,
        "pg": page,
    })

    total = resp.get("total", 0)
    items = [_build_item(v) for v in resp.get("list", [])]

    return {
        "code": 200,
        "data": {
            "page": page,
            "total": total,
            "list": items,
        },
    }


@app.get("/api/anime/search")
def anime_search(
    keyword: str = Query(..., description="搜索关键词"),
):
    """搜索动漫"""

    resp = _call_api( {
        "ac": "detail",
        "wd": keyword,
    })

    items = [_build_item(v) for v in resp.get("list", [])]

    # 搜索时只返回国漫相关
    filtered = [
        item for item in items
        if any(kw in item["category"] for kw in CN_ANIME_KEYWORDS)
    ] or items  # 如果筛空了就返回全部

    _try_upsert_vector_items(filtered)

    return {
        "code": 200,
        "data": {
            "list": filtered,
        },
    }


@app.post("/api/vector/index")
def vector_index(
    pages: int = Query(60, ge=1, le=100, description="从资源站读取的页数，每页约20条"),
    max_items: int = Query(1000, ge=1, le=1000, description="最多写入的视频数量"),
):
    """从 Python 真实视频源抓取最多1000条视频并写入 Chroma。"""
    items_by_id = {}
    for page in range(1, pages + 1):
        try:
            response = _call_api({"ac": "detail", "t": HN_TYPE, "pg": page})
            source_items = response.get("list") or []
            if not source_items:
                break
            for video in source_items:
                item = _build_item(video)
                if item.get("vod_id"):
                    items_by_id[item["vod_id"]] = item
                if len(items_by_id) >= max_items:
                    break
            if len(items_by_id) >= max_items:
                break
        except Exception as exc:
            if not items_by_id:
                raise HTTPException(502, f"资源站请求失败: {exc}")
            break
    items = list(items_by_id.values())[:max_items]
    indexed = _upsert_vector_items(items)
    stored = _get_vector_collection().count()
    return {
        "code": 200,
        "data": {
            "engine": "Chroma",
            "collection": VECTOR_COLLECTION,
            "fetched": len(items),
            "indexed": indexed,
            "stored": stored,
        },
    }


@app.get("/api/vector/search")
def vector_search(
    q: str = Query(..., min_length=1, description="动漫标题、类型或描述"),
    limit: int = Query(5, ge=1, le=20),
):
    """在本地 Chroma 中进行相似度匹配，结果可直接进入真实播放页。"""
    try:
        matches = _search_vector(q.strip(), limit)
    except Exception as exc:
        raise HTTPException(503, f"向量检索暂不可用: {exc}")
    return {"code": 200, "data": {"query": q, "list": matches}}


@app.get("/api/vector/status")
def vector_status():
    """查看 Chroma 动漫知识库状态。"""
    try:
        stored = _get_vector_collection().count()
    except Exception as exc:
        raise HTTPException(503, f"Chroma 暂不可用: {exc}")
    return {
        "code": 200,
        "data": {"engine": "Chroma", "collection": VECTOR_COLLECTION, "stored": stored},
    }


@app.get("/api/anime/detail/{vod_id}")
def anime_detail(
    vod_id: int,
):
    """
    获取动漫详情 + 剧集列表
    返回剧集标题和对应的 m3u8 播放地址
    """

    resp = _call_api( {
        "ac": "videolist",
        "ids": vod_id,
    })

    items = resp.get("list") or []
    if not items:
        raise HTTPException(404, "未找到该动漫")

    v = items[0]
    if not v.get("vod_id"):
        raise HTTPException(404, "未找到该动漫")

    episodes = _parse_episodes(v.get("vod_play_url", ""))

    return {
        "code": 200,
        "data": {
            "vod_id": v.get("vod_id"),
            "title": v.get("vod_name", ""),
            "cover": v.get("vod_pic", ""),
            "director": v.get("vod_director", "") or "",
            "actor": v.get("vod_actor", "") or "",
            "desc": (v.get("vod_content") or "").replace("<p>", "").replace("</p>", "").replace("<br/>", "").replace("\\/", "/")[:300],
            "year": v.get("vod_year", ""),
            "area": v.get("vod_area", ""),
            "category": v.get("type_name", ""),
            "status": v.get("vod_remarks", ""),
            "score": v.get("vod_douban_score", "") or v.get("vod_score", ""),
            "episodes": episodes,
            "total_episodes": len(episodes),
        },
    }


@app.get("/api/anime/play/{vod_id}")
def anime_play(
    vod_id: int,
    ep: int = Query(1, ge=1, description="集数，从1开始"),
    use_parse: bool = Query(False, description="是否使用解析接口获取播放地址"),
):
    """
    获取指定集数的播放地址

    - 默认返回资源站的原始 m3u8 地址（已验证可用且带有 CORS 头）
    - use_parse=true 时，尝试使用第三方解析接口
    - 同时返回所有解析接口的备用地址
    """

    # 1. 获取剧集 URL
    resp = _call_api( {
        "ac": "videolist",
        "ids": vod_id,
    })

    items = resp.get("list") or []
    if not items:
        raise HTTPException(404, "未找到该动漫")

    v = items[0]
    episodes = _parse_episodes(v.get("vod_play_url", ""))

    if not episodes:
        raise HTTPException(404, "该动漫暂无剧集")

    if ep < 1 or ep > len(episodes):
        raise HTTPException(400, f"集数超出范围 (1-{len(episodes)})")

    episode = episodes[ep - 1]
    raw_url = episode["url"]

    # 2. 构建解析接口地址
    parse_urls = []
    for svc in PARSE_SERVICES:
        parse_urls.append({
            "service": svc.split("/")[2],  # 提取域名
            "url": f"{svc}{raw_url}",
        })

    return {
        "code": 200,
        "data": {
            "vod_id": vod_id,
            "title": v.get("vod_name", ""),
            "episode": ep,
            "episode_title": episode["title"],
            "total_episodes": len(episodes),
            "url": raw_url,               # 原始 m3u8 地址（可直接播放）
            "type": "m3u8",
            "parse_services": parse_urls,  # 解析接口备用地址
            "hls_proxy": f"/api/proxy/hls/playlist?url={raw_url}",  # HLS 代理地址
        },
    }


@app.get("/api/anime/related/{vod_id}")
def anime_related(
    vod_id: int,
    page: int = Query(1, ge=1, description="页码"),
    count: int = Query(10, ge=1, le=30, description="每页数量"),
):
    """相关推荐 — 当前视频标签匹配优先，并由向量相似度补充。"""
    try:
        items = _related_by_type(vod_id, page, count)
    except Exception as exc:
        # 推荐属于播放器的辅助数据。上游资源站或本地向量索引异常时，
        # 使用真实热门视频兜底，而不是让整个播放器页面产生 500。
        print(f"[Related] vod_id={vod_id} 向量推荐失败，改用热门视频: {exc}", flush=True)
        try:
            fallback = anime_hot(count=min(60, count + 1), page=page)
            items = [
                item for item in fallback.get("data", {}).get("list", [])
                if int(item.get("vod_id") or 0) != vod_id
            ][:count]
        except Exception as fallback_exc:
            print(f"[Related] vod_id={vod_id} 热门视频降级失败: {fallback_exc}", flush=True)
            items = []

    return {
        "code": 200,
        "data": {
            "vod_id": vod_id,
            "page": page,
            "list": items,
        },
    }


@app.get("/api/anime/parse-test")
def parse_test(
    url: str = Query(..., description="要解析的视频 URL"),
):
    """
    测试视频解析接口是否可用
    返回第一个成功返回 m3u8 链接的解析服务
    """
    results = []
    for svc in PARSE_SERVICES:
        full_url = f"{svc}{url}"
        try:
            resp = requests.get(
                full_url,
                headers={**HEADERS, "Referer": svc.split("?")[0]},
                timeout=10,
                allow_redirects=True,
            )
            # 解析服务返回 HTML ，提取可能的 m3u8 地址
            text = resp.text[:2000]
            results.append({
                "service": svc.split("/")[2],
                "url": full_url,
                "status": resp.status_code,
                "is_html": "text/html" in resp.headers.get("content-type", ""),
                "preview": text[:300],
            })
        except Exception as e:
            results.append({
                "service": svc.split("/")[2],
                "url": full_url,
                "error": str(e),
            })

    return {
        "code": 200,
        "data": {
            "input_url": url,
            "results": results,
            "note": "解析接口返回的是 HTML 播放页面（含 iframe），适合嵌入使用，不直接返回 m3u8",
        },
    }


@app.get("/api/anime/discover")
def anime_discover(
    page: int = Query(1, ge=1),
    count: int = Query(50, ge=1, le=60),
    keyword: str = Query("", description="搜索关键词"),
    tag: str = Query("", description="分类标签: 热血/恋爱/科幻..."),
    sort: str = Query("hot", description="排序: hot/new"),
    status: str = Query("all", description="状态: all/ongoing/finished"),
):
    """
    浏览页 — 支持分类筛选 + 搜索 + 排序
    """

    # 资源 API 每页 20 条，要拿更多需自动翻页
    api_pages = max(1, (count + 19) // 20)  # 50 → 3 页
    items = []
    for pg in range(page, page + api_pages):
        try:
            resp = _call_api( {
                "ac": "detail",
                "t": HN_TYPE,
                "pg": pg,
                **(                             {"wd": keyword} if keyword else {}),
            })
            items += [_build_item(v) for v in resp.get("list", [])]
        except Exception:
            break

    # 分类筛选
    if tag:
        items = [it for it in items if tag in it.get("tags", [])]

    # 状态筛选
    if status == "ongoing":
        items = [it for it in items if "更新" in it.get("status", "") or "第" in it.get("status", "")]
    elif status == "finished":
        items = [it for it in items if "完结" in it.get("status", "") or "全" in it.get("status", "") or "BD" in it.get("status", "") or "HD" in it.get("status", "")]

    # 去重 (翻页可能有重复)
    seen = set()
    unique = []
    for it in items:
        vid = it.get("vod_id")
        if vid not in seen:
            seen.add(vid)
            unique.append(it)
    items = unique

    # 最热使用数据库中的浏览量与点赞量；最新每次随机排列。
    _sort_discover_items(items, sort)

    total = len(items)
    paged = items[:count]

    return {
        "code": 200,
        "data": {
            "page": page,
            "total": total,
            "list": paged,
        },
    }


# ============================================================
#  代理接口
# ============================================================

@app.get("/api/proxy/image")
def proxy_image(url: str = Query(...)):
    """代理图片 — 绕过 CORS，允许 CDN 内网 IP，失败时返回占位图"""
    parsed = urlparse(url)
    if parsed.hostname in ("127.0.0.1", "localhost", "0.0.0.0", "[::1]", "::1"):
        raise HTTPException(403, "禁止访问本地地址")
    if parsed.scheme not in ("http", "https"):
        raise HTTPException(400, "仅支持 HTTP(S)")

    try:
        resp = _session.get(url, timeout=(5, 15), allow_redirects=True, stream=True, verify=True)
        resp.raise_for_status()
        media_type = resp.headers.get("content-type", "").split(";", 1)[0].lower()
        if not media_type.startswith("image/"):
            resp.close()
            raise ValueError("目标资源不是图片")
        content = _read_limited(resp, MAX_IMAGE_BYTES)
        resp.close()
        return Response(
            content=content,
            media_type=media_type,
            headers={"Cache-Control": "public, max-age=300"},
        )
    except Exception:
        # 返回 SVG 占位图，避免前端红叉
        placeholder = (
            '<svg xmlns="http://www.w3.org/2000/svg" width="320" height="180" viewBox="0 0 320 180">'
            '<rect fill="#f0f1fa" width="320" height="180"/>'
            '<text x="160" y="95" text-anchor="middle" fill="#8f92a1" font-size="14" font-family="sans-serif">暂无封面</text>'
            '</svg>'
        )
        return Response(
            content=placeholder.encode(),
            media_type="image/svg+xml",
            # 上游图片的临时故障不能被浏览器长期缓存，刷新页面时应重新尝试。
            headers={"Cache-Control": "no-store"},
        )


@app.get("/api/proxy/hls/segment")
def proxy_hls_segment(url: str = Query(...)):
    """HLS TS 分片 / 密钥代理（带重试，允许 CDN 内网 IP）"""
    # 基础安全检查：阻止明显的内网攻击
    parsed = urlparse(url)
    if parsed.hostname in ("127.0.0.1", "localhost", "0.0.0.0", "[::1]", "::1"):
        raise HTTPException(403, "禁止访问本地地址")
    if parsed.scheme not in ("http", "https"):
        raise HTTPException(400, "仅支持 HTTP(S)")

    last_error = None
    for attempt in range(3):
        try:
            resp = _session.get(
                url,
                headers={
                    "User-Agent": HEADERS["User-Agent"],
                    "Referer": url.rsplit("/", 1)[0] + "/",
                },
                timeout=(5, 15),
                allow_redirects=True,
                stream=True,
                verify=True,
            )
            if resp.status_code >= 400:
                resp.close()
                raise Exception(f"Upstream {resp.status_code}")
            mt = resp.headers.get("content-type", "application/octet-stream")
            content = _read_limited(resp, MAX_SEGMENT_BYTES)
            resp.close()
            return Response(
                content=content,
                media_type=mt,
                headers={"Cache-Control": "public, max-age=3600"},
            )
        except Exception as e:
            last_error = e
            if attempt < 2:
                time.sleep(0.5 * (attempt + 1))
    raise HTTPException(502, f"分片代理失败: {str(last_error)}")


@app.api_route("/api/proxy/hls/{path:path}", methods=["GET", "HEAD"])
def proxy_hls(request: Request, path: str):
    """
    HLS 流代理 — 改写 m3u8 内相对路径为代理地址，代理 TS 分片
    使用方式: /api/proxy/hls/playlist?url=<m3u8_url>
    允许 CDN 内网 IP（视频源常用）
    """
    base_url = request.query_params.get("url", "")
    if not base_url:
        raise HTTPException(400, "缺少 url 参数")

    # 基础安全检查
    parsed_base = urlparse(base_url)
    if parsed_base.hostname in ("127.0.0.1", "localhost", "0.0.0.0", "[::1]", "::1"):
        raise HTTPException(403, "禁止访问本地地址")
    if parsed_base.scheme not in ("http", "https"):
        raise HTTPException(400, "仅支持 HTTP(S)")

    # 获取目标 URL
    if path == "playlist":
        target = base_url
    else:
        target = base_url.rsplit("/", 1)[0] + "/" + path.replace("playlist/", "")

    try:
        resp = _session.get(
            target,
            headers={
                "User-Agent": HEADERS["User-Agent"],
                "Referer": base_url,
            },
            timeout=15,
            allow_redirects=True,
            stream=True,
            verify=True,
        )
        resp.raise_for_status()
        content_type = resp.headers.get("content-type", "")

        # m3u8 播放列表: 改写内部 URL 为代理 URL（含加密密钥）
        if "m3u8" in content_type or urlparse(target).path.endswith(".m3u8"):
            text = _read_limited(resp, MAX_PLAYLIST_BYTES).decode(resp.encoding or "utf-8", errors="replace")
            resp.close()
            base_dir = target.rsplit("/", 1)[0] + "/"
            lines = []
            for line in text.splitlines():
                stripped = line.strip()

                # 处理加密密钥行: #EXT-X-KEY:METHOD=AES-128,URI="enc.key"
                if stripped.startswith("#EXT-X-KEY") and "URI=" in stripped:
                    def rewrite_key(m):
                        key_url = urljoin(base_dir, m.group(1))
                        proxy_key = (
                            f"/api/proxy/hls/segment?url={requests.utils.quote(key_url, safe='')}"
                        )
                        return f'URI="{proxy_key}"'
                    new_line = re.sub(r'URI="([^"]*)"', rewrite_key, stripped)
                    lines.append(new_line)

                # 处理子播放列表和 TS 分片 URL（非注释行）
                elif stripped and not stripped.startswith("#"):
                    resource_url = urljoin(base_dir, stripped)
                    if urlparse(resource_url).path.endswith(".m3u8"):
                        lines.append(
                            f"/api/proxy/hls/playlist?url={requests.utils.quote(resource_url, safe='')}"
                        )
                    else:
                        lines.append(
                            f"/api/proxy/hls/segment?url={requests.utils.quote(resource_url, safe='')}"
                        )
                else:
                    lines.append(line)
            return Response(
                content="\n".join(lines),
                media_type=content_type,
                headers={"Cache-Control": "no-cache, no-store, must-revalidate"},
            )

        # TS 分片 / 其他二进制
        content = _read_limited(resp, MAX_SEGMENT_BYTES)
        resp.close()
        return Response(
            content=content,
            media_type=content_type or "video/mp2t",
            headers={"Cache-Control": "public, max-age=3600"},
        )

    except Exception as e:
        raise HTTPException(502, f"HLS 代理失败: {str(e)}")




# ============================================================
#  兼容旧接口（Bilibili 搜索）
# ============================================================

# ============================================================
#  兜底端点 — 用户/社区接口（Java 不可用时返回空数据，避免 502）
# ============================================================

@app.get("/api/user/history")
def user_history():
    """用户观看历史 — 兜底返回空列表"""
    return {"code": 200, "data": {"list": [], "total": 0}}


@app.get("/api/community/danmaku/{anime_id}")
def community_danmaku(anime_id: str, episodeId: int = 0):
    """弹幕列表 — 兜底返回空列表"""
    return {"code": 200, "data": {"list": [], "total": 0}}


# ============================================================
#  /api/catalog/* 兼容端点 — 前端 Discover 页使用
#  数据来源同样是红牛资源站
# ============================================================

@app.get("/api/catalog/categories")
def catalog_categories(
    limit: int = Query(10, ge=1, le=30, description="返回出现频率最高的标签数量"),
):
    """从 Python 真实视频源统计并返回高频有效标签。"""
    cache_key = "catalog_categories_v3"
    cached = _cache_get(cache_key)
    if cached:
        return {"code": 200, "data": {"list": cached[:limit]}}

    tag_counts = {}
    for pg in range(1, 4):  # 扫描前3页收集标签
        try:
            resp = _call_api({"ac": "detail", "t": HN_TYPE, "pg": pg})
            for v in resp.get("list", []):
                for tag in set(_build_item(v).get("tags") or []):
                    tag_counts[tag] = tag_counts.get(tag, 0) + 1
        except Exception:
            break

    generic_tags = {"中国动漫", "国产动漫", "动漫", "动画"}
    tag_list = [
        {"name": tag, "videoCount": total}
        for tag, total in sorted(tag_counts.items(), key=lambda item: (-item[1], item[0]))
        if tag not in generic_tags
    ]
    _cache_set(cache_key, tag_list)
    return {"code": 200, "data": {"list": tag_list[:limit]}}


@app.post("/api/catalog/play-by-title")
def catalog_play_by_title(title: str = Query("")):
    """播放统计记录（兜底）"""
    return {"code": 200, "message": "ok"}


@app.post("/api/catalog/play")
def catalog_play(videoId: int = Query(...), episodeId: int = Query(0)):
    """数据库视频播放统计（兜底）"""
    return {"code": 200, "message": "ok"}


@app.get("/api/catalog/discover")
def catalog_discover(
    page: int = Query(1, ge=1),
    count: int = Query(20, ge=1, le=60),
    keyword: str = Query("", description="搜索关键词"),
    tag: str = Query("", description="分类标签"),
    sort: str = Query("hot", description="排序: hot/new"),
):
    """浏览页 — 跟 /api/anime/discover 相同逻辑，兼容前端 /api/catalog/discover"""
    api_pages = max(1, (count + 19) // 20)
    items = []
    for pg in range(page, page + api_pages):
        try:
            resp = _call_api({
                "ac": "detail",
                "t": HN_TYPE,
                "pg": pg,
                **(                             {"wd": keyword} if keyword else {}),
            })
            items += [_build_item(v) for v in resp.get("list", [])]
        except Exception:
            break

    if tag:
        items = [it for it in items if tag in it.get("tags", [])]

    seen = set()
    unique = []
    for it in items:
        vid = it.get("vod_id")
        if vid not in seen:
            seen.add(vid)
            unique.append(it)
    items = unique

    _sort_discover_items(items, sort)

    paged = items[:count]

    _try_upsert_vector_items(paged)

    # 转换为前端兼容格式
    return {
        "code": 200,
        "data": {
            "page": page,
            "total": len(items),
            "list": [
                {
                    **it,
                    "cover_proxy": f"/api/proxy/image?url={requests.utils.quote(it.get('cover', ''), safe='')}" if it.get("cover") else "",
                }
                for it in paged
            ],
        },
    }


@app.get("/api/catalog/hot")
def catalog_hot(
    count: int = Query(20, ge=1, le=60),
    page: int = Query(1, ge=1),
):
    """首页热门 — 兜底数据源，兼容前端 /api/catalog/hot"""
    cache_key = f"catalog_hot_{page}"
    try:
        resp = _call_api({"ac": "detail", "t": HN_TYPE, "pg": page})
        _cache_set(cache_key, resp)
    except Exception:
        cached = _cache_get(cache_key, allow_stale=True)
        if cached:
            resp = cached
        else:
            raise HTTPException(502, "资源站请求失败")

    items = []
    for v in (resp.get("list") or [])[:count]:
        cover = v.get("vod_pic", "")
        items.append({
            "vod_id": v.get("vod_id"),
            "title": v.get("vod_name", ""),
            "cover": cover,
            "cover_proxy": f"/api/proxy/image?url={requests.utils.quote(cover, safe='')}" if cover else "",
            "category": v.get("type_name", ""),
            "tags": [t.strip() for t in (v.get("vod_class", "") or "").split(",") if t.strip()],
            "status": v.get("vod_remarks", ""),
            "year": v.get("vod_year", ""),
            "area": v.get("vod_area", ""),
            "director": v.get("vod_director", "") or "",
            "actor": v.get("vod_actor", "") or "",
            "desc": (v.get("vod_content") or "").replace("<p>", "").replace("</p>", "").replace("<br/>", "").replace("\\/", "/")[:200],
            "score": v.get("vod_douban_score", "") or v.get("vod_score", ""),
            "total_episodes": int(v.get("vod_total", 0)) or 0,
        })

    _try_upsert_vector_items(items)

    return {
        "code": 200,
        "data": {
            "page": page,
            "list": items,
        },
    }


@app.get("/api/catalog/{vod_id}")
def catalog_detail(vod_id: int):
    """动漫详情 — 兼容前端 /api/catalog/{id}"""
    resp = _call_api({"ac": "videolist", "ids": vod_id})
    items = resp.get("list") or []
    if not items:
        raise HTTPException(404, "未找到该动漫")

    v = items[0]
    if not v.get("vod_id"):
        raise HTTPException(404, "未找到该动漫")

    episodes = _parse_episodes(v.get("vod_play_url", ""))

    return {
        "code": 200,
        "data": {
            "vod_id": v.get("vod_id"),
            "title": v.get("vod_name", ""),
            "cover": v.get("vod_pic", ""),
            "director": v.get("vod_director", "") or "",
            "actor": v.get("vod_actor", "") or "",
            "desc": (v.get("vod_content") or "").replace("<p>", "").replace("</p>", "").replace("<br/>", "").replace("\\/", "/")[:300],
            "year": v.get("vod_year", ""),
            "area": v.get("vod_area", ""),
            "category": v.get("type_name", ""),
            "status": v.get("vod_remarks", ""),
            "score": v.get("vod_douban_score", "") or v.get("vod_score", ""),
            "episodes": episodes,
            "total_episodes": len(episodes),
        },
    }


@app.get("/api/catalog/{vod_id}/related")
def catalog_related(
    vod_id: int,
    page: int = Query(1, ge=1),
    count: int = Query(6, ge=1, le=30),
):
    """相关推荐 — 兼容前端 /api/catalog/{id}/related。"""
    return {
        "code": 200,
        "data": {
            "vod_id": vod_id,
            "list": _related_by_type(vod_id, page, count),
        },
    }


@app.get("/api/catalog/{vod_id}/episodes")
def catalog_episodes(vod_id: int):
    """剧集列表 — 兼容前端 /api/catalog/{id}/episodes"""
    return catalog_detail(vod_id)


# ============================================================
#  兼容旧接口（Bilibili 搜索）
# ============================================================

@app.get("/api/anime/bilibili-search")
def bilibili_search(q: str = Query(...)):
    """用标题搜索 Bilibili，返回第一个视频 aid"""
    try:
        resp = requests.get(
            "https://api.bilibili.com/x/web-interface/search/type",
            params={"search_type": "video", "keyword": q, "page": 1},
            headers={**HEADERS, "Referer": "https://www.bilibili.com"},
            timeout=10,
        )
        data = resp.json()
        results = data.get("data", {}).get("result", [])
        if results:
            v = results[0]
            return {
                "code": 200,
                "data": {"aid": v.get("aid"), "bvid": v.get("bvid"), "title": v.get("title", "")},
            }
        return {"code": -1, "data": None}
    except Exception as e:
        return {"code": -1, "data": None, "error": str(e)}


@app.get("/health")
async def health():
    return {"status": "ok", "version": "2.0"}
