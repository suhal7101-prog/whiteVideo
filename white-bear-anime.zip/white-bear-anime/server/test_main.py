import unittest
from pathlib import Path
from tempfile import TemporaryDirectory
import time
from unittest.mock import patch

import main


class RedirectResponse:
    status_code = 302
    headers = {"location": "http://127.0.0.1/private"}

    def close(self):
        pass


class ProxySecurityTests(unittest.TestCase):
    def test_rejects_non_public_targets(self):
        targets = [
            "http://127.0.0.1:8088/secret",
            "http://10.0.0.1/internal",
            "http://169.254.169.254/latest/meta-data",
            "file:///etc/passwd",
        ]
        for target in targets:
            with self.subTest(target=target):
                with self.assertRaises(ValueError):
                    main._validate_public_url(target)

    def test_accepts_public_ip(self):
        self.assertEqual(
            "https://8.8.8.8/image.jpg",
            main._validate_public_url("https://8.8.8.8/image.jpg"),
        )

    def test_revalidates_redirect_destination(self):
        with patch.object(main._session, "get", return_value=RedirectResponse()):
            with self.assertRaises(ValueError):
                main._safe_get("https://8.8.8.8/image.jpg")


class CacheFallbackTests(unittest.TestCase):
    def setUp(self):
        self.original_cache = main._cache
        main._cache = {}

    def tearDown(self):
        main._cache = self.original_cache

    def test_stale_cache_can_be_used_as_fallback(self):
        main._cache["hot_hongniu_1"] = {
            "data": {"list": [{"vod_id": 1, "vod_name": "缓存视频"}]},
            "ts": time.time() - main.CACHE_TTL_SECONDS - 1,
        }

        with patch.object(main, "_call_api", side_effect=RuntimeError("upstream down")), \
                patch.object(main, "_try_upsert_vector_items"):
            response = main.anime_hot(count=20, page=1)

        self.assertEqual(200, response["code"])
        self.assertEqual("缓存视频", response["data"]["list"][0]["title"])

    def test_successful_response_is_persisted(self):
        with TemporaryDirectory() as directory:
            cache_file = Path(directory) / "api_cache.json"
            with patch.object(main, "CACHE_FILE", cache_file):
                main._cache_set("ranking", {"list": [{"vod_id": 1}]})
                main._cache = {}
                main._cache = main._load_cache()

            self.assertEqual(1, main._cache["ranking"]["data"]["list"][0]["vod_id"])

    def test_catalog_categories_use_python_video_tags_and_frequency(self):
        source = {
            "list": [
                {"vod_id": 1, "vod_name": "A", "vod_class": "中国动漫,热血,冒险"},
                {"vod_id": 2, "vod_name": "B", "vod_class": "中国动漫,热血,科幻"},
            ]
        }
        with TemporaryDirectory() as directory, \
                patch.object(main, "CACHE_FILE", Path(directory) / "cache.json"), \
                patch.object(main, "_call_api", return_value=source):
            original_cache = main._cache
            main._cache = {}
            try:
                response = main.catalog_categories(limit=10)
            finally:
                main._cache = original_cache

        tags = response["data"]["list"]
        self.assertEqual("热血", tags[0]["name"])
        self.assertEqual(6, tags[0]["videoCount"])
        self.assertEqual({"冒险", "科幻"}, {tags[1]["name"], tags[2]["name"]})
        self.assertNotIn("中国动漫", [tag["name"] for tag in tags])


class VectorSearchTests(unittest.TestCase):
    def test_local_chroma_indexes_real_playable_payloads(self):
        original_path = main.VECTOR_DB_PATH
        original_client = main._vector_client
        original_collection = main._vector_collection
        with TemporaryDirectory() as directory:
            try:
                main.VECTOR_DB_PATH = Path(directory) / "chroma"
                main._vector_client = None
                main._vector_collection = None
                indexed = main._upsert_vector_items([
                    {
                        "vod_id": 1001,
                        "title": "玄幻冒险录",
                        "category": "中国动漫",
                        "tags": ["玄幻", "冒险"],
                        "desc": "少年踏上东方奇幻冒险之旅",
                        "score": "8.8",
                    },
                    {
                        "vod_id": 1002,
                        "title": "校园日常",
                        "category": "中国动漫",
                        "tags": ["校园", "日常"],
                        "desc": "轻松的校园生活",
                        "score": "7.5",
                    },
                ])
                matches = main._search_vector("玄幻冒险", 2)

                self.assertEqual(2, indexed)
                self.assertEqual(1001, matches[0]["vod_id"])
                self.assertEqual("/play/1001", matches[0]["playUrl"])
            finally:
                if main._vector_client is not None:
                    main._vector_client.close()
                main._vector_client = original_client
                main._vector_collection = original_collection
                main.VECTOR_DB_PATH = original_path

    def test_related_videos_prioritize_current_video_tags(self):
        current = {
            "vod_id": 1001,
            "vod_name": "当前玄幻动漫",
            "vod_class": "玄幻,冒险,中国动漫",
            "type_name": "中国动漫",
            "vod_content": "少年踏上冒险旅程",
        }
        vector_matches = [
            {"vod_id": 1001, "title": "当前玄幻动漫", "tags": ["玄幻"]},
            {"vod_id": 1002, "title": "校园日常", "tags": ["校园", "日常"], "score": 0.9},
            {"vod_id": 1003, "title": "异界冒险", "tags": ["冒险", "热血"], "score": 0.7},
        ]

        with patch.object(main, "_call_api", return_value={"list": [current]}), \
                patch.object(main, "_try_upsert_vector_items"), \
                patch.object(main, "_search_vector", return_value=vector_matches):
            related = main._related_by_type(1001, page=1, count=10)

        self.assertEqual([1003, 1002], [item["vod_id"] for item in related])
        self.assertNotIn(1001, [item["vod_id"] for item in related])

    def test_related_endpoint_degrades_to_real_hot_videos(self):
        fallback = {
            "code": 200,
            "data": {
                "list": [
                    {"vod_id": 150897, "title": "当前视频"},
                    {"vod_id": 152312, "title": "真实热门视频"},
                ]
            },
        }
        with patch.object(main, "_related_by_type", side_effect=RuntimeError("vector index broken")), \
                patch.object(main, "anime_hot", return_value=fallback):
            response = main.anime_related(vod_id=150897, page=1, count=10)

        self.assertEqual(200, response["code"])
        self.assertEqual([152312], [item["vod_id"] for item in response["data"]["list"]])


if __name__ == "__main__":
    unittest.main()
