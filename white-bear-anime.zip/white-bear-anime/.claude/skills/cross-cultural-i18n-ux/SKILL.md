---
name: Cross-Cultural & Internationalization UX
description: Comprehensive internationalization and localization patterns covering RTL layouts, CSS logical properties, text expansion, date/time/number/currency formatting, cultural color semantics, Hofstede's cultural dimensions applied to UX, and cross-cultural usability testing.
triggers:
  - internationalization
  - i18n
  - localization
  - l10n
  - RTL
  - right-to-left
  - translation
  - multilingual
  - cultural design
  - cross-cultural
  - locale
  - CJK
  - Arabic
  - Hebrew
  - text expansion
  - cultural UX
---

# Cross-Cultural & Internationalization UX

## Internationalization Is a Design Decision

There is a persistent misconception that internationalization is something that happens after design is finished, a phase where strings are extracted and handed off to translators. This framing is fundamentally wrong. Internationalization is a structural design decision that shapes layout systems, component architecture, typography, interaction patterns, information hierarchy, and visual semantics from the very first wireframe.

When a team treats i18n as an afterthought, the consequences are predictable and expensive: layouts that shatter when text expands by 40% in German, navigation that becomes unusable when mirrored for Arabic readers, date pickers that confuse users by defaulting to formats they have never encountered, color choices that carry unintended meaning in target markets, and payment flows that omit the dominant transaction method in an entire region. Retrofitting internationalization into a product that was designed monolingually is one of the most costly rework categories in software, often requiring fundamental changes to grid systems, component APIs, and state management.

The discipline of internationalization (i18n) addresses the technical infrastructure: making software capable of supporting multiple locales without engineering changes per locale. Localization (l10n) is the process of adapting content, visuals, and workflows for a specific locale. Both are design concerns. A designer who specifies a fixed-width button has made an i18n decision, whether they realize it or not. A designer who chooses red for error states without considering cultural color semantics has made a localization decision by omission.

This skill provides the frameworks, patterns, and technical references needed to design products that work across languages, scripts, cultures, and markets from the ground up.

## The Scope of Global Design

The scale of multilingual, multicultural design is often underestimated. The internet has roughly 5.5 billion users across 195 countries, speaking over 7,000 languages. Even a modest international expansion from English-only to 10 supported locales immediately introduces right-to-left scripts, logographic writing systems, agglutinative grammars, and at least three fundamentally different numeral systems. Each of these has implications for layout, typography, input methods, and data formatting.

The i18n discipline distinguishes between several layers of adaptation. Script support is the most fundamental: can the interface render Arabic, Devanagari, Thai, or CJK characters correctly? Layout direction comes next: does the interface reflow correctly for RTL scripts? Locale formatting follows: are dates, numbers, currencies, and units displayed according to local convention? Content localization addresses translation quality, cultural tone, and imagery appropriateness. Finally, cultural adaptation considers deeper behavioral patterns: how users evaluate trust, make decisions, and respond to interface patterns.

Teams that plan for internationalization from the start embed these concerns into their design system foundations: logical CSS properties instead of physical ones, flexible containers instead of fixed-width layouts, locale-aware formatters instead of hardcoded string concatenation, and component APIs that accept direction and locale as first-class parameters. Teams that defer internationalization accumulate technical and design debt that compounds with every new feature.

## Right-to-Left Layout: More Than Mirroring

Supporting right-to-left (RTL) scripts such as Arabic, Hebrew, Urdu, and Persian is one of the most visible i18n challenges. RTL support requires mirroring the entire layout along the inline axis: navigation flows from right to left, text alignment defaults to the right, progress indicators advance rightward to leftward, and scroll position origins shift.

However, RTL layout is not a simple mirror operation applied uniformly. Several categories of content do not mirror:

- **Numbers and phone numbers** are always displayed left-to-right, even within RTL text.
- **Icons with directionality** (back arrows, forward arrows, undo/redo) must mirror because they represent inline-direction movement. But universal icons (search, home, settings, checkmarks) do not mirror.
- **Media playback controls** do not mirror because the timeline metaphor (left-to-right progression of time) is universal.
- **Bidirectional text** occurs when RTL text contains embedded LTR content (brand names, code, URLs). The Unicode Bidirectional Algorithm (UBiDi) handles this, but designers must understand that mixed-direction strings can produce unexpected reordering without proper isolation using the `<bdi>` element or explicit direction markers.

CSS logical properties are the foundation of RTL-ready layout. Instead of `margin-left`, use `margin-inline-start`. Instead of `padding-right`, use `padding-inline-end`. This single conceptual shift eliminates the need for duplicate RTL stylesheets entirely. The detailed property mapping and code examples are in the [Internationalization Patterns](references/internationalization-patterns.md) reference.

## Text Expansion and Contraction

When English source text is translated, the resulting string length varies dramatically by target language. German text typically expands 30-35% compared to English. Finnish and Russian can expand 20-30%. French expands 15-20%. Conversely, Chinese, Japanese, and Korean (CJK) text is often more compact character-for-character, but the visual width per character is larger due to full-width glyphs occupying roughly a square em-box.

The practical implication is that every text container in the interface must accommodate significant variation without breaking. Short strings (button labels, menu items) are the most vulnerable because percentage expansion is highest for short strings. A two-word English button label might become a five-word German phrase. The W3C recommends designing for at least 200% text expansion for strings under 20 characters.

Strategies include: using flexible layout containers that grow with content, establishing maximum width constraints with ellipsis truncation as a last resort, testing with pseudo-localization strings that artificially inflate text length during development, and avoiding fixed-height containers that clip overflowing translated text.

Pseudo-localization deserves special emphasis. It is the single most effective early-detection technique for i18n layout issues. By replacing English characters with accented equivalents and padding strings with extra characters during development, teams can see exactly where layouts will break under translation pressure without waiting for actual translations. Many i18n-mature organizations run pseudo-localized builds as part of their continuous integration pipeline, catching regressions before they reach QA or translators.

## Cultural Design Dimensions

Beyond language and script, culture shapes how people perceive interfaces, evaluate trustworthiness, make decisions, and respond to persuasive patterns. Geert Hofstede's cultural dimensions framework provides a structured model for understanding these differences and their implications for UX design.

Six dimensions are particularly relevant: Power Distance (how hierarchy is perceived and expected), Individualism versus Collectivism (whether personal or group identity drives decisions), Masculinity versus Femininity (competitive versus cooperative orientations), Uncertainty Avoidance (tolerance for ambiguity and risk), Long-Term Orientation (patience and investment thinking), and Indulgence versus Restraint (acceptance of gratification and expression).

Each dimension has concrete UX implications. High Uncertainty Avoidance cultures expect extensive help systems, explicit confirmation dialogs, and detailed error messages. Collectivist cultures respond more strongly to social proof and community endorsement than to individual testimonials. High Power Distance cultures may expect formal language and visible authority signals in government or enterprise interfaces.

These dimensions are not stereotypes to be applied rigidly. They are statistical tendencies across populations that inform design hypotheses, which must then be validated through cross-cultural usability testing. The detailed mapping of each dimension to interface design patterns, along with case studies and testing methodology, is in the [Cultural UX Dimensions](references/cultural-ux-dimensions.md) reference.

## Color, Imagery, and Visual Semantics

Color meaning is culturally constructed. Red signals danger and error in Western design conventions, but it represents luck, prosperity, and celebration in Chinese culture. White is associated with purity and cleanliness in Western contexts but signifies mourning in many East Asian cultures. Green carries associations with Islam in many Muslim-majority regions, with nature and sustainability in Western markets, and with financial growth in US contexts.

Designers working on global products must audit their color usage for cultural conflict. This does not mean avoiding culturally loaded colors entirely; it means understanding the semantic layer and ensuring that color is never the sole carrier of meaning, which is also an accessibility requirement for color-blind users.

Imagery presents similar challenges. Hand gestures vary in meaning across cultures (the thumbs-up gesture is offensive in parts of the Middle East). Depictions of family structures, gender roles, and social situations carry cultural expectations. Photography styles that feel authentic in one market may feel staged or inappropriate in another.

## Formatting: Dates, Numbers, Currency, and Addresses

Locale-specific formatting is a reliability concern, not a polish concern. Displaying a date as 01/02/2026 is ambiguous: it reads as January 2nd in the US and February 1st in most other countries. Displaying currency without the correct symbol, decimal separator, and grouping separator can cause financial errors. Address formats vary dramatically (Japan uses block-based addressing rather than street-based, the UK places the city below the street, Germany places the house number after the street name).

The Intl API in JavaScript and Foundation formatters in Swift/iOS provide locale-aware formatting that should always be used instead of manual string concatenation. Hardcoding date formats, number separators, or currency symbols is a bug, not a shortcut.

Beyond basic formatting, measurement units introduce another layer of locale complexity. The United States uses imperial units (miles, pounds, Fahrenheit) while virtually every other country uses metric. India uses the lakh (100,000) and crore (10,000,000) grouping system for large numbers rather than millions and billions. Japan and Korea count large numbers in units of 10,000 (man/man). These are not edge cases; they affect any product that displays distances, weights, temperatures, or large financial figures to a global audience.

Name formatting is equally treacherous. Western name conventions (given name followed by family name) are reversed in Chinese, Japanese, Korean, and Hungarian contexts. Many cultures use patronymics rather than family names (Iceland), multiple family names (Spanish-speaking countries), or single names (parts of Indonesia). Form fields labeled "First Name" and "Last Name" impose a Western cultural assumption that breaks for a significant portion of the world's population. A robust approach uses a single "Full Name" field or, when structured data is necessary, uses culturally neutral labels like "Given name(s)" and "Family name(s)" with clear guidance.

## Cross-References to Related Skills

Internationalization intersects with nearly every other design discipline:

- **[Mobile UX Design](../mobile-ux-design/SKILL.md)**: Mobile layouts are especially vulnerable to text expansion due to constrained screen width. RTL touch targets and gesture directions require attention. CJK input methods on mobile keyboards affect form design.

- **[Accessibility & Inclusive Design](../accessibility-inclusive-design/SKILL.md)**: i18n and accessibility share the principle that content must never rely on a single channel (color alone, text alone, position alone). Screen readers must correctly announce bidirectional text. Language attributes (`lang`) are essential for both accessibility and i18n.

- **[UX Ethics & Content Strategy](../ux-ethics-content-strategy/SKILL.md)**: Translation quality is an ethical concern. Machine translation without human review can produce misleading or offensive content. Dark patterns may exploit cultural deference to authority in high Power Distance contexts.

- **[UI Visual Design System](../ui-visual-design-system/SKILL.md)**: Design tokens should use logical property naming (inline/block rather than left/right). Icon libraries need RTL-aware variants. Typography scales must account for CJK line-height requirements.

- **[Design Systems Architecture](../design-systems-architecture/SKILL.md)**: Component APIs should accept locale-aware formatters. RTL support should be built into the system layer, not applied per-component. Translation string management is a design system concern.

## References

- [Internationalization Patterns](references/internationalization-patterns.md) — CSS logical properties, RTL layout, React and iOS i18n APIs, text expansion, multi-script font loading, locale-aware formatting code examples.
- [Cultural UX Dimensions](references/cultural-ux-dimensions.md) — Hofstede's dimensions mapped to interface design, cross-cultural usability testing methodology, regional case studies, payment diversity, trust signals, and color semantics.

## When to Invest in i18n

Not every product needs full internationalization from day one. The decision of when and how deeply to invest depends on the product's market strategy and growth trajectory. However, certain foundational decisions are nearly free at the start and extremely expensive to retrofit later.

**Always do from the start**, regardless of market plans: use CSS logical properties, use locale-aware formatters for dates and numbers, externalize all user-facing strings into translation-ready files, use flexible layout containers, and set the `lang` attribute on the HTML element.

**Do when entering a new script family**: RTL layout testing and remediation, multi-script font stack configuration, bidirectional text handling, and input method testing for the target script.

**Do when entering a culturally distinct market**: cultural usability research, payment method integration, trust signal adaptation, color and imagery audit, content tone review, and locale-specific formatting validation.

**Do when scaling to many markets simultaneously**: design system locale tokens, automated pseudo-localization testing in CI, translation management system integration, and cross-cultural analytics segmentation.

The key insight is that the foundational technical decisions (logical properties, formatters, string externalization) cost almost nothing when done from the start but can require weeks of refactoring when added later. Teams that treat these as defaults rather than i18n-specific features gain optionality at no meaningful cost.
