import { copyFile, mkdir, readFile, readdir, writeFile } from 'node:fs/promises'
import { fileURLToPath } from 'node:url'
import path from 'node:path'
import { barnerImagesData1, barnerImagesData2 } from '../bilibili-banner/assets/2023-08-21/data.js'

const projectRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const sourceRoot = path.join(projectRoot, 'bilibili-banner', 'assets')
const outputRoot = path.join(projectRoot, 'public', 'banner')

function finiteNumber(value, fallback = 0) {
  const result = Number(value)
  return Number.isFinite(result) ? result : fallback
}

function pair(value, fallback) {
  if (!Array.isArray(value) || value.length !== 2) return [...fallback]
  return value.map((item, index) => finiteNumber(item, fallback[index]))
}

function matrix(value) {
  const fallback = [1, 0, 0, 1, 0, 0]
  if (!Array.isArray(value) || value.length !== 6) return fallback
  return value.map((item, index) => finiteNumber(item, fallback[index]))
}

function normalizeLayer(layer, index, themeKey, localAssets) {
  const tagName = String(layer.tagName || layer.type || 'img').toLowerCase()
  if (!['img', 'video'].includes(tagName)) {
    throw new Error(`${themeKey} 第 ${index + 1} 层包含不支持的标签: ${tagName}`)
  }

  const rawSource = String(layer.src || layer.url || '').trim()
  if (!rawSource) throw new Error(`${themeKey} 第 ${index + 1} 层缺少资源地址`)
  const isRemote = /^(https?:)?\/\//i.test(rawSource)
  const src = isRemote ? rawSource : path.basename(rawSource.replace(/\\/g, '/'))
  if (!isRemote && !localAssets.has(src)) {
    throw new Error(`${themeKey} 第 ${index + 1} 层资源不存在: ${src}`)
  }

  const normalized = {
    tagName,
    opacity: pair(layer.opacity, [1, 1]),
    transform: matrix(layer.transform),
    src,
    a: finiteNumber(layer.a, 0.01),
    deg: finiteNumber(layer.deg),
    g: finiteNumber(layer.g),
    f: finiteNumber(layer.f),
    blur: finiteNumber(layer.blur),
    zIndex: finiteNumber(layer.zIndex, index + 1),
  }

  const width = finiteNumber(layer.width, NaN)
  const height = finiteNumber(layer.height, NaN)
  if (Number.isFinite(width) && width > 0) normalized.width = width
  if (Number.isFinite(height) && height > 0) normalized.height = height
  if (layer.bottom === true) normalized.bottom = true
  return normalized
}

async function writeTheme(themeKey, layers, sourceDirectory = null) {
  const directory = path.join(outputRoot, themeKey)
  await mkdir(directory, { recursive: true })

  const localAssets = new Set()
  if (sourceDirectory) {
    const entries = await readdir(sourceDirectory, { withFileTypes: true })
    for (const entry of entries) {
      if (!entry.isFile() || /^data\.(json|js)$/i.test(entry.name)) continue
      localAssets.add(entry.name)
      await copyFile(path.join(sourceDirectory, entry.name), path.join(directory, entry.name))
    }
  }

  const normalized = layers.map((layer, index) =>
    normalizeLayer(layer, index, themeKey, localAssets),
  )
  await writeFile(path.join(directory, 'data.json'), `${JSON.stringify(normalized, null, 2)}\n`, 'utf8')
  return {
    themeKey,
    layers: normalized.length,
    videos: normalized.filter(layer => layer.tagName === 'video').length,
  }
}

const results = []
const dateDirectories = (await readdir(sourceRoot, { withFileTypes: true }))
  .filter(entry => entry.isDirectory())
  .map(entry => entry.name)
  .sort()

for (const dateKey of dateDirectories) {
  const sourceDirectory = path.join(sourceRoot, dateKey)
  if (dateKey === '2023-08-21') {
    results.push(await writeTheme(`${dateKey}-a`, barnerImagesData1))
    results.push(await writeTheme(`${dateKey}-b`, barnerImagesData2))
    continue
  }

  const layers = JSON.parse(await readFile(path.join(sourceDirectory, 'data.json'), 'utf8'))
  if (!Array.isArray(layers) || layers.length === 0) {
    throw new Error(`${dateKey} 的 data.json 不是有效的非空图层数组`)
  }
  results.push(await writeTheme(dateKey, layers, sourceDirectory))
}

const layerTotal = results.reduce((total, item) => total + item.layers, 0)
const videoTotal = results.reduce((total, item) => total + item.videos, 0)
console.table(results)
console.log(`Banner effects normalized: ${dateDirectories.length} dates, ${results.length} themes, ${layerTotal} layers, ${videoTotal} video layers`)
