/**
 * 白熊动漫 前端 Vite 配置
 *
 * 代理架构（规则按顺序匹配，先匹配先生效）：
 *  ┌──────────────────────────────────────────┐
 *  │  /api/user/**       → Java   (8088) 用户  │
 *  │  /api/community/**  → Java   (8088) 社区  │
 *  │  /api/ai/**         → Java   (8088) AI    │
 *  │  /api/admin/**      → Java   (8088) 管理  │
 *  │  /api/advertisements→ Java   (8088) 广告  │
 *  │  /api/bilibili/**   → Java   (8088) B站   │
 *  │  /api/ranking/**    → Java   (8088) 排行  │
 *  │  /api/catalog/**    → Python (8082) 目录  │
 *  │  /api/**            → Python (8082) 兜底  │
 *  │  /ws                → Java   (8088) WS    │
 *  └──────────────────────────────────────────┘
 */
import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'
import path from 'path'

export default defineConfig({
  plugins: [vue()],
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src')
    }
  },
  server: {
    host: '0.0.0.0',
    port: 5174,
    proxy: {
      // ===== Java Spring Boot 后端 (8088) — 用户/社区/AI/管理 =====
      '/api/user': {
        target: 'http://localhost:8088',
        changeOrigin: true
      },
      '/api/community': {
        target: 'http://localhost:8088',
        changeOrigin: true
      },
      '/api/video-comments': {
        target: 'http://localhost:8088',
        changeOrigin: true
      },
      '/api/ai': {
        target: 'http://localhost:8088',
        changeOrigin: true
      },
      '/api/announcements': {
        target: 'http://localhost:8088',
        changeOrigin: true
      },
      '/api/admin': {
        target: 'http://localhost:8088',
        changeOrigin: true
      },
      '/api/advertisements': {
        target: 'http://localhost:8088',
        changeOrigin: true
      },
      '/api/advertisement-images': {
        target: 'http://localhost:8088',
        changeOrigin: true
      },
      '/api/banner-effects': {
        target: 'http://localhost:8088',
        changeOrigin: true
      },
      '/api/bilibili': {
        target: 'http://localhost:8088',
        changeOrigin: true
      },
      '/api/ranking': {
        target: 'http://localhost:8088',
        changeOrigin: true
      },
      '/api/catalog/play-by-title': {
        target: 'http://localhost:8088',
        changeOrigin: true
      },
      '/api/catalog/play-by-source': {
        target: 'http://localhost:8088',
        changeOrigin: true
      },
      '/api/catalog/play': {
        target: 'http://localhost:8088',
        changeOrigin: true
      },
      // 首页热门视频必须读取 MySQL 中已持久化的浏览量数据
      '/api/catalog/hot': {
        target: 'http://localhost:8088',
        changeOrigin: true
      },

      // ===== Python FastAPI (8082) — 视频数据/代理 =====
      '/api/catalog': {
        target: 'http://localhost:8082',
        changeOrigin: true
      },
      '/api/anime': {
        target: 'http://localhost:8082',
        changeOrigin: true
      },
      '/api/proxy': {
        target: 'http://localhost:8082',
        changeOrigin: true
      },
      '/api/vector': {
        target: 'http://localhost:8082',
        changeOrigin: true
      },

      // ===== Python 兜底 =====
      '/api': {
        target: 'http://localhost:8082',
        changeOrigin: true
      },
      '/ws': {
        target: 'ws://localhost:8088',
        ws: true,
        changeOrigin: true
      }
    }
  }
})
